package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/**
 * CarSaleContractRenderer: محرك رسم عقد بيع وشراء السيارات (معارض السيارات)
 * تصميم عراقي رسمي موحد بخط أميري/نسخ، جدول مواصفات نظيف، بصمة الإبهام، وختم المعرض.
 */
class CarSaleContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? CarSaleContract ?: CarSaleContract()
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale

        // ==================== 1. الترويسة العراقية الرسمية ====================
        var curY = drawIraqiOfficialHeader(
            canvas = canvas,
            officeInfo = officeInfo,
            defaultOfficeName = "معرض السيارات المعتمد",
            specialtyText = "لتجارة وبيع وشراء السيارات الحديثة",
            contractTitle = "عقد بيع وشراء سيارة",
            contractSubtitle = "مقاولة بيع رسمية معتمدة",
            contractNo = data.contractNo.ifBlank { "0001" },
            contractDate = data.contractDate,
            overrideOfficeName = data.galleryName,
            overrideOfficePhone = data.galleryPhone,
            overrideOfficeAddress = data.galleryAddress
        )

        // ==================== 2. شريط المالك الشرعي للمركبة ====================
        val ownerBarH = 38f
        val ownerRect = RectF(contentLeft, curY, contentRight, curY + ownerBarH)
        val barBg = Paint().apply {
            color = tintColor(primary, 14)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val barBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.6f
            isAntiAlias = true
        }
        val barSplit = Paint().apply {
            color = tintColor(primary, 160)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        canvas.drawRect(ownerRect, barBg)
        canvas.drawRect(ownerRect, barBorder)
        val ownerMidX = ownerRect.left + (ownerRect.width() * 0.45f)
        canvas.drawLine(ownerMidX, ownerRect.top, ownerMidX, ownerRect.bottom, barSplit)

        drawFieldWithDots(
            canvas = canvas,
            label = "المالك الشرعي للسيارة:",
            value = data.carLegalOwner,
            x = ownerRect.right - 12f,
            y = ownerRect.top + 25f,
            totalWidth = (ownerRect.right - ownerMidX) - 24f
        )
        drawFieldWithDots(
            canvas = canvas,
            label = "العنوان:",
            value = data.ownerAddress,
            x = ownerMidX - 12f,
            y = ownerRect.top + 25f,
            totalWidth = (ownerMidX - ownerRect.left) - 24f
        )

        curY = ownerRect.bottom + 12f

        // ==================== 3. جدول الطرفين ====================
        curY = drawFormalPartiesTable(
            canvas = canvas,
            topY = curY,
            rightTitle = "الطرف الأول (البائع)",
            leftTitle = "الطرف الثاني (المشتري)",
            rightFields = listOf(
                "البائع السيد:" to data.sellerName,
                "السكن والعنوان:" to data.sellerAddress,
                "رقم الهوية / الوطنية:" to data.sellerIdNumber,
                "رقم الهاتف:" to data.sellerPhone
            ),
            leftFields = listOf(
                "المشتري السيد:" to data.buyerName,
                "السكن والعنوان:" to data.buyerAddress,
                "رقم الهوية / الوطنية:" to data.buyerIdNumber,
                "رقم الهاتف:" to data.buyerPhone
            )
        )

        // ==================== 4. جدول مواصفات المركبة ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "أولاً: باع الطرف الأول إلى الطرف الثاني السيارة المبينة أوصافها أدناه:",
            topY = curY
        )

        curY += 8f
        val gridH = 132f
        val gridRect = RectF(contentLeft, curY, contentRight, curY + gridH)
        val gridOuter = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val gridInner = Paint().apply {
            color = tintColor(primary, 165)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        canvas.drawRect(gridRect, gridOuter)

        val rowH = gridH / 3f
        val colW = gridRect.width() / 3f
        canvas.drawLine(gridRect.left, gridRect.top + rowH, gridRect.right, gridRect.top + rowH, gridInner)
        canvas.drawLine(gridRect.left, gridRect.top + (rowH * 2f), gridRect.right, gridRect.top + (rowH * 2f), gridInner)
        canvas.drawLine(gridRect.right - colW, gridRect.top, gridRect.right - colW, gridRect.top + (rowH * 2f), gridInner)
        canvas.drawLine(gridRect.right - (colW * 2f), gridRect.top, gridRect.right - (colW * 2f), gridRect.bottom, gridInner)

        val c1X = gridRect.right - 10f
        val c2X = gridRect.right - colW - 10f
        val c3X = gridRect.right - (colW * 2f) - 10f
        val cW = colW - 20f

        val r1Y = gridRect.top + 29f
        drawFieldWithDots(canvas, "نوع السيارة:", data.carBrandAndType, c1X, r1Y, cW)
        drawFieldWithDots(canvas, "الموديل:", data.modelYear, c2X, r1Y, cW)
        drawFieldWithDots(canvas, "اللون:", data.color, c3X, r1Y, cW)

        val r2Y = gridRect.top + rowH + 29f
        drawFieldWithDots(canvas, "رقم السيارة / السنوية:", data.annualRegNumber, c1X, r2Y, cW)
        drawFieldWithDots(canvas, "رقم المحرك:", data.engineNumber, c2X, r2Y, cW)
        drawFieldWithDots(canvas, "الصنف:", data.carCategory.ifBlank { "خصوصي" }, c3X, r2Y, cW)

        val r3Y = gridRect.top + (rowH * 2f) + 29f
        drawFieldWithDots(canvas, "رقم الشاصي (الهيكل):", data.chassisNumber, c1X, r3Y, (colW * 2f) - 20f)
        drawFieldWithDots(canvas, "اسم المنظم:", data.organizerName, c3X, r3Y, cW)

        curY = gridRect.bottom + 12f

        // ==================== 5. المبالغ المالية ====================
        val currencyUnit = data.currency.shortLabelAr
        val fmtTotal = FormatUtils.formatMoneyInput(data.totalPrice)
        val totalDisp = if (fmtTotal.isNotBlank()) "$fmtTotal $currencyUnit" else data.totalPrice
        val totalWords = data.totalPriceWords.trim().ifBlank {
            FormatUtils.convertNumberToArabicWords(data.totalPrice, data.currency)
        }

        val fmtPaid = FormatUtils.formatMoneyInput(data.paidAmount)
        val paidDisp = if (fmtPaid.isNotBlank()) "$fmtPaid $currencyUnit" else data.paidAmount
        val paidWords = FormatUtils.convertNumberToArabicWords(data.paidAmount, data.currency)

        val fmtRem = FormatUtils.formatMoneyInput(data.remainingAmount)
        val remDisp = if (fmtRem.isNotBlank()) "$fmtRem $currencyUnit" else data.remainingAmount
        val remWords = FormatUtils.convertNumberToArabicWords(data.remainingAmount, data.currency)

        curY = drawFinancialSummaryTableWithWords(
            canvas = canvas,
            topY = curY,
            items = listOf(
                FinancialBoxItem("بدل البيع الكلي (رقماً)", totalDisp, totalWords, dark),
                FinancialBoxItem("وقد استلم البائع مبلغ قدره", paidDisp, paidWords, primary),
                FinancialBoxItem("والباقي بذمة المشتري", remDisp, remWords, COLOR_RED_ACCENT)
            ),
            wordsRowLabel = "مبلغ البيع الكلي (كتابةً):",
            wordsRowValue = totalWords
        )

        // ==================== 6. البنود والشروط القانونية ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "ثانياً: الشروط والأحكام القانونية المتفق عليها",
            topY = curY
        )

        curY += 10f
        val clauses = listOf(
            "ثانياً" to "استلم الطرف الثاني (المشتري) المركبة أعلاه وهو المسؤول عنها قانونياً ومرورياً اعتباراً من تاريخ وساعة هذا العقد.",
            "ثالثاً" to "الطرف الأول (البائع) مسؤول عن دفع كافة الغرامات المرورية والضرائب والرسوم المترتبة على المركبة لغاية تاريخ هذا العقد.",
            "رابعاً" to "على المشتري فحص السيارة فحصاً تاماً قبل الشراء، والمعرض غير مسؤول بتاتاً عن أي عيوب خفية تظهر بعد التسليم.",
            "خامساً" to "قبلت السيارة على حالتها الراهنة بين الطرفين، والمعرض غير مسؤول عن أي اتفاق شفهي أو تعهد خارج بنود هذا العقد.",
            "سادساً" to "يلتزم البائع والمشتري بإجراء التحويل المروري خلال مدة أقصاها (٣٠) يوماً من تاريخ العقد، وعكسه يتحمل المقصر التبعات القانونية."
        )

        curY = drawIraqiLegalClauses(
            canvas = canvas,
            clauses = clauses,
            startY = curY,
            maxBottomY = footerTopY - 125f
        )

        val dateP = Paint().apply {
            color = primary
            textSize = 16f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val dateY = (curY + 14f).coerceAtMost(footerTopY - 90f)
        canvas.drawText("حرر هذا العقد بالتراضي بتاريخ: ${data.contractDate}", contentRight, dateY, dateP)

        drawAdditionalNotesBlock(
            canvas = canvas,
            notes = data.notes,
            startY = dateY + 12f
        )

        // ==================== 7. التواقيع والشهود والصور وختم المعرض ====================
        val w1 = data.witness1Name.ifBlank { data.witnessName }
        drawIraqiSignaturesFooter(
            canvas = canvas,
            party1Title = "الطرف الأول/البائع",
            party2Title = "الطرف الثاني/المشتري",
            witness1Name = w1,
            witness2Name = data.witness2Name,
            stampTitle = "ختم وتوقيع المعرض",
            party1PhotoLabel = "صورة البائع",
            party2PhotoLabel = "صورة المشتري"
        )
    }
}
