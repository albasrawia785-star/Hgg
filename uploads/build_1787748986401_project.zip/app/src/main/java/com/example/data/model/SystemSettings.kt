package com.example.data.model

import com.example.ClinicInfo

data class SystemSettings(
    val clinicName: String = ClinicInfo.clinicName,
    val doctorName: String = ClinicInfo.doctorName,
    val clinicPhone: String = ClinicInfo.clinicPhone,
    val footerMessage: String = ClinicInfo.footerMessage,
    val paperSize: PaperSize = PaperSize.WIDTH_80MM,
    val autoPrintOnAdd: Boolean = true,
    val callPhrase: String = "المُراجِع رَقْم %s",
    val speechRate: Float = 0.85f,
    val pitch: Float = 1.0f,
    val volume: Float = 1.0f,
    val enableChime: Boolean = true,
    val selectedPrinterName: String = "",
    val selectedPrinterAddress: String = "",
    val selectedSpeakerName: String = "",
    val selectedSpeakerAddress: String = ""
)
