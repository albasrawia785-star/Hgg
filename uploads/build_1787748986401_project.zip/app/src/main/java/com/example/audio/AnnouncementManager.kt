package com.example.audio

import android.content.Context
import com.example.bluetooth.AudioRouteManager
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.Locale

enum class CallingState {
    IDLE,
    CHIME_PLAYING,
    TTS_SPEAKING,
    COMPLETED,
    ERROR
}

class AnnouncementManager(
    private val context: Context,
    private val audioRouteManager: AudioRouteManager
) {
    private val chimePlayer = ChimePlayer(context)
    private val ttsManager = TtsManager(context)

    private val _callingState = MutableStateFlow(CallingState.IDLE)
    val callingState: StateFlow<CallingState> = _callingState.asStateFlow()

    private val _activeCallingPatient = MutableStateFlow<Patient?>(null)
    val activeCallingPatient: StateFlow<Patient?> = _activeCallingPatient.asStateFlow()

    /**
     * Announces a patient number cleanly using:
     * 1. Embedded raw chime alert tone played via Android MediaPlayer (if enabled)
     * 2. Clear native Arabic TextToSpeech utterance with customizable audio settings
     * @param mutePhone if true, skips local phone audio (used when audio plays exclusively from TV)
     */
    suspend fun announcePatient(
        patient: Patient,
        settings: SystemSettings = SystemSettings(),
        mutePhone: Boolean = false
    ): Boolean = withContext(Dispatchers.Main) {
        try {
            _activeCallingPatient.value = patient
            _callingState.value = CallingState.CHIME_PLAYING

            val numInt = patient.queueNumber
            val arabicNumberWord = numberToArabicWords(numInt)
            val textToSpeak = "المراجع رقم $arabicNumberWord ، يرجى التوجه إلى غرفة العيادة"

            // Synthesize audio to file for TV web audio broadcast
            try {
                val audioFile = java.io.File(context.cacheDir, "call_latest.wav")
                ttsManager.synthesizeToFile(textToSpeak, audioFile)
            } catch (_: Exception) {}

            if (mutePhone) {
                // TV is handling the audio broadcast; keep phone silent
                _callingState.value = CallingState.TTS_SPEAKING
                kotlinx.coroutines.delay(1800L)
                _callingState.value = CallingState.COMPLETED
                kotlinx.coroutines.delay(300L)
                return@withContext true
            }

            // Ensure audio routing to A2DP bluetooth speaker or fallback to phone
            audioRouteManager.routeToBluetoothA2dp()

            // 1. Play Chime with Android MediaPlayer (Raw Resource: res/raw/chime.wav) if enabled
            if (settings.enableChime) {
                chimePlayer.playChime()
            }

            // 2. Clear native Arabic TTS Utterance with user-configured rate & pitch & volume
            _callingState.value = CallingState.TTS_SPEAKING
            ttsManager.setSpeechRate(settings.speechRate)
            ttsManager.setPitch(settings.pitch)

            val ttsSuccess = ttsManager.speak(textToSpeak, volume = settings.volume)

            // 3. Mark completed briefly then return to IDLE
            _callingState.value = CallingState.COMPLETED
            kotlinx.coroutines.delay(600L)
            ttsSuccess
        } catch (_: Exception) {
            false
        } finally {
            _callingState.value = CallingState.IDLE
            _activeCallingPatient.value = null
        }
    }

    /**
     * Plays a test announcement using current audio settings
     */
    suspend fun testAnnouncement(settings: SystemSettings): Boolean = withContext(Dispatchers.Main) {
        try {
            _callingState.value = CallingState.CHIME_PLAYING

            audioRouteManager.routeToBluetoothA2dp()

            if (settings.enableChime) {
                chimePlayer.playChime()
            }

            _callingState.value = CallingState.TTS_SPEAKING
            ttsManager.setSpeechRate(settings.speechRate)
            ttsManager.setPitch(settings.pitch)

            val template = if (settings.callPhrase.isNotBlank()) settings.callPhrase else "المُراجِع رَقْم %s"
            val textToSpeak = formatCallPhrase(template, "25")

            val ttsSuccess = ttsManager.speak(textToSpeak, volume = settings.volume)
            _callingState.value = CallingState.COMPLETED
            kotlinx.coroutines.delay(400L)
            ttsSuccess
        } catch (_: Exception) {
            false
        } finally {
            _callingState.value = CallingState.IDLE
            _activeCallingPatient.value = null
        }
    }

    private fun formatCallPhrase(template: String, numberStr: String): String {
        return when {
            template.contains("%s") -> {
                try {
                    template.format(numberStr)
                } catch (_: Exception) {
                    "المُراجِع رَقْم $numberStr"
                }
            }
            template.contains("%d") -> {
                val numInt = numberStr.toIntOrNull() ?: 1
                try {
                    String.format(Locale.US, template, numInt)
                } catch (_: Exception) {
                    "المُراجِع رَقْم $numberStr"
                }
            }
            template.contains("{number}") -> {
                template.replace("{number}", numberStr)
            }
            else -> {
                "$template $numberStr"
            }
        }
    }

    fun numberToArabicWords(num: Int): String {
        if (num <= 0) return "واحد"
        val ones = arrayOf(
            "", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة",
            "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"
        )
        val tens = arrayOf("", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون")
        val hundreds = arrayOf("", "مئة", "مئتان", "ثلاثمئة", "أربعمئة", "خمسمئة", "ستمئة", "سبعمئة", "ثمانمئة", "تسعمئة")

        if (num < 20) return ones[num]
        if (num < 100) {
            val one = num % 10
            val ten = num / 10
            return if (one == 0) tens[ten] else "${ones[one]} و${tens[ten]}"
        }
        if (num < 1000) {
            val hundred = num / 100
            val rem = num % 100
            return if (rem == 0) hundreds[hundred] else "${hundreds[hundred]} و${numberToArabicWords(rem)}"
        }
        return num.toString()
    }

    fun stop() {
        ttsManager.stop()
        resetState()
    }

    fun resetState() {
        _callingState.value = CallingState.IDLE
        _activeCallingPatient.value = null
    }

    fun shutdown() {
        ttsManager.shutdown()
    }
}
