package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.ClinicInfo
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class QueueRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("clinic_queue_prefs", Context.MODE_PRIVATE)

    private val _patients = MutableStateFlow<List<Patient>>(emptyList())
    val patients: StateFlow<List<Patient>> = _patients.asStateFlow()

    private val _currentPatient = MutableStateFlow<Patient?>(null)
    val currentPatient: StateFlow<Patient?> = _currentPatient.asStateFlow()

    private val _settings = MutableStateFlow(SystemSettings())
    val settings: StateFlow<SystemSettings> = _settings.asStateFlow()

    init {
        loadSettings()
        loadQueue()
    }

    private fun loadSettings() {
        val paperSizeName = prefs.getString("paper_size", PaperSize.WIDTH_80MM.name) ?: PaperSize.WIDTH_80MM.name
        val paperSize = try {
            PaperSize.valueOf(paperSizeName)
        } catch (_: Exception) {
            PaperSize.WIDTH_80MM
        }
        val autoPrint = prefs.getBoolean("auto_print", true)
        val callPhrase = prefs.getString("call_phrase", "المُراجِع رَقْم %s") ?: "المُراجِع رَقْم %s"
        val speechRate = prefs.getFloat("speech_rate", 0.85f)
        val pitch = prefs.getFloat("pitch", 1.0f)
        val volume = prefs.getFloat("volume", 1.0f)
        val enableChime = prefs.getBoolean("enable_chime", true)

        val selectedPrinter = prefs.getString("printer_name", "") ?: ""
        val selectedPrinterAddr = prefs.getString("printer_addr", "") ?: ""
        val selectedSpeaker = prefs.getString("speaker_name", "") ?: ""
        val selectedSpeakerAddr = prefs.getString("speaker_addr", "") ?: ""

        _settings.value = SystemSettings(
            clinicName = ClinicInfo.clinicName,
            doctorName = ClinicInfo.doctorName,
            clinicPhone = ClinicInfo.clinicPhone,
            footerMessage = ClinicInfo.footerMessage,
            paperSize = paperSize,
            autoPrintOnAdd = autoPrint,
            callPhrase = callPhrase,
            speechRate = speechRate,
            pitch = pitch,
            volume = volume,
            enableChime = enableChime,
            selectedPrinterName = selectedPrinter,
            selectedPrinterAddress = selectedPrinterAddr,
            selectedSpeakerName = selectedSpeaker,
            selectedSpeakerAddress = selectedSpeakerAddr
        )
    }

    fun updateSettings(newSettings: SystemSettings) {
        _settings.value = newSettings.copy(
            clinicName = ClinicInfo.clinicName,
            doctorName = ClinicInfo.doctorName,
            clinicPhone = ClinicInfo.clinicPhone,
            footerMessage = ClinicInfo.footerMessage
        )
        prefs.edit()
            .putString("paper_size", newSettings.paperSize.name)
            .putBoolean("auto_print", newSettings.autoPrintOnAdd)
            .putString("call_phrase", newSettings.callPhrase)
            .putFloat("speech_rate", newSettings.speechRate)
            .putFloat("pitch", newSettings.pitch)
            .putFloat("volume", newSettings.volume)
            .putBoolean("enable_chime", newSettings.enableChime)
            .putString("printer_name", newSettings.selectedPrinterName)
            .putString("printer_addr", newSettings.selectedPrinterAddress)
            .putString("speaker_name", newSettings.selectedSpeakerName)
            .putString("speaker_addr", newSettings.selectedSpeakerAddress)
            .apply()
    }

    private fun loadQueue() {
        val isInitialized = prefs.getBoolean("queue_initialized_empty_v3", false)
        if (!isInitialized) {
            _patients.value = emptyList()
            _currentPatient.value = null
            prefs.edit()
                .putString("queue_data", "[]")
                .putBoolean("queue_initialized_empty_v3", true)
                .apply()
            return
        }

        val savedJson = prefs.getString("queue_data", null)
        if (!savedJson.isNullOrBlank() && savedJson != "[]") {
            try {
                val array = JSONArray(savedJson)
                val list = mutableListOf<Patient>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        Patient(
                            id = obj.getInt("id"),
                            queueNumber = obj.getInt("queueNumber"),
                            name = obj.optString("name", ""),
                            note = obj.optString("note", ""),
                            timestamp = obj.getLong("timestamp"),
                            isCalled = obj.optBoolean("isCalled", false),
                            isCurrent = obj.optBoolean("isCurrent", false),
                            isPostponed = obj.optBoolean("isPostponed", false)
                        )
                    )
                }
                _patients.value = list
                val current = list.firstOrNull { it.isCurrent && !it.isPostponed }
                    ?: list.firstOrNull { !it.isCalled && !it.isPostponed }
                    ?: list.firstOrNull { !it.isPostponed }
                _currentPatient.value = current
                return
            } catch (_: Exception) {
                // Ignore parse errors and fallback
            }
        }

        _patients.value = emptyList()
        _currentPatient.value = null
        saveQueue()
    }

    private fun saveQueue() {
        val array = JSONArray()
        for (patient in _patients.value) {
            val obj = JSONObject()
            obj.put("id", patient.id)
            obj.put("queueNumber", patient.queueNumber)
            obj.put("name", patient.name)
            obj.put("note", patient.note)
            obj.put("timestamp", patient.timestamp)
            obj.put("isCalled", patient.isCalled)
            obj.put("isCurrent", patient.isCurrent)
            obj.put("isPostponed", patient.isPostponed)
            array.put(obj)
        }
        prefs.edit().putString("queue_data", array.toString()).apply()
    }

    fun addPatient(name: String = "", note: String = ""): Patient {
        val currentList = _patients.value
        val nextNumber = if (currentList.isEmpty()) 1 else (currentList.maxOf { it.queueNumber } + 1)
        val isFirstActive = currentList.none { !it.isPostponed }
        val newPatient = Patient(
            id = nextNumber,
            queueNumber = nextNumber,
            name = name.trim(),
            note = note.trim(),
            timestamp = System.currentTimeMillis(),
            isCalled = false,
            isCurrent = isFirstActive,
            isPostponed = false
        )
        val updatedList = currentList + newPatient
        _patients.value = updatedList
        if (_currentPatient.value == null || isFirstActive) {
            _currentPatient.value = newPatient
        }
        saveQueue()
        return newPatient
    }

    fun callCurrentPatient(): Patient? {
        val currentList = _patients.value
        val activeList = currentList.filter { !it.isPostponed }
        if (activeList.isEmpty()) return null

        val current = _currentPatient.value?.takeIf { !it.isPostponed }
            ?: activeList.firstOrNull { !it.isCalled }
            ?: activeList.first()

        val updatedList = currentList.map {
            if (it.queueNumber == current.queueNumber) {
                it.copy(isCalled = true, isCurrent = true, isPostponed = false)
            } else {
                it.copy(isCurrent = false)
            }
        }
        _patients.value = updatedList
        val calledPatient = current.copy(isCalled = true, isCurrent = true, isPostponed = false)
        _currentPatient.value = calledPatient
        saveQueue()
        return calledPatient
    }

    /**
     * ينتقل للمراجع التالي في قائمة الانتظار، يقوم بتحديده كحالي ويضع عليه علامة تم الاستدعاء
     * إذا وصل لنهاية القائمة ولا يوجد مراجعون غير مستدعين بعد الحالي، يعيد null
     */
    fun callNextPatient(): Patient? {
        val currentList = _patients.value
        val activeList = currentList.filter { !it.isPostponed }
        if (activeList.isEmpty()) return null

        val current = _currentPatient.value

        // 1. نبحث حصراً عن أول مراجع غير مستدعى بعد المراجع الحالي
        val nextUncalledAfterCurrent = if (current != null) {
            activeList.firstOrNull { it.queueNumber > current.queueNumber && !it.isCalled }
        } else {
            activeList.firstOrNull { !it.isCalled }
        }

        // إذا لم يكن هناك مراجع تالٍ في الانتظار، لا نرجع للبداية بل نعيد null
        val target = nextUncalledAfterCurrent ?: return null

        val updatedList = currentList.map {
            if (it.queueNumber == target.queueNumber) {
                it.copy(isCalled = true, isCurrent = true, isPostponed = false)
            } else {
                it.copy(isCurrent = false)
            }
        }
        _patients.value = updatedList
        val calledPatient = target.copy(isCalled = true, isCurrent = true, isPostponed = false)
        _currentPatient.value = calledPatient
        saveQueue()
        return calledPatient
    }

    /**
     * تأجيل مراجع محدد وتحويله لقائمة المؤجلين
     */
    fun postponePatient(patient: Patient): Patient {
        val currentList = _patients.value
        val isTargetCurrent = _currentPatient.value?.queueNumber == patient.queueNumber

        val updatedWithPostponed = currentList.map {
            if (it.queueNumber == patient.queueNumber) {
                it.copy(isPostponed = true, isCurrent = false)
            } else {
                it
            }
        }

        if (isTargetCurrent) {
            val remainingActive = updatedWithPostponed.filter { !it.isPostponed }
            val nextCurrent = remainingActive.firstOrNull { it.queueNumber > patient.queueNumber && !it.isCalled }
                ?: remainingActive.firstOrNull { !it.isCalled }
                ?: remainingActive.firstOrNull()

            val finalList = updatedWithPostponed.map {
                if (nextCurrent != null && it.queueNumber == nextCurrent.queueNumber) {
                    it.copy(isCurrent = true)
                } else {
                    if (it.queueNumber == patient.queueNumber) it.copy(isCurrent = false) else it
                }
            }
            _patients.value = finalList
            _currentPatient.value = nextCurrent?.copy(isCurrent = true)
        } else {
            _patients.value = updatedWithPostponed
        }

        val postponedPatient = patient.copy(isPostponed = true, isCurrent = false)
        saveQueue()
        return postponedPatient
    }

    /**
     * تأجيل المراجع الحالي وتحويله لقائمة المؤجلين ثم الانتقال آلياً للمراجع التالي
     */
    fun postponeCurrentPatient(): Pair<Patient?, Patient?> {
        val current = _currentPatient.value ?: return Pair(null, null)
        val currentList = _patients.value

        // 1. تحديد المراجع كمؤجل
        val updatedWithPostponed = currentList.map {
            if (it.queueNumber == current.queueNumber) {
                it.copy(isPostponed = true, isCurrent = false)
            } else {
                it
            }
        }

        // 2. البحث عن المراجع التالي في الانتظار ليصبح الحالي
        val remainingActive = updatedWithPostponed.filter { !it.isPostponed }
        val nextCurrent = remainingActive.firstOrNull { it.queueNumber > current.queueNumber && !it.isCalled }
            ?: remainingActive.firstOrNull { !it.isCalled }
            ?: remainingActive.firstOrNull()

        val finalList = updatedWithPostponed.map {
            if (nextCurrent != null && it.queueNumber == nextCurrent.queueNumber) {
                it.copy(isCurrent = true)
            } else {
                if (it.queueNumber == current.queueNumber) it.copy(isCurrent = false) else it
            }
        }

        _patients.value = finalList
        val postponedPatient = current.copy(isPostponed = true, isCurrent = false)
        val newCurrent = nextCurrent?.copy(isCurrent = true)
        _currentPatient.value = newCurrent
        saveQueue()
        return Pair(postponedPatient, newCurrent)
    }

    /**
     * استدعاء مراجع من قائمة المؤجلين مباشرة
     */
    fun recallPostponedPatient(patient: Patient): Patient {
        val currentList = _patients.value
        val updatedList = currentList.map {
            if (it.queueNumber == patient.queueNumber) {
                it.copy(isPostponed = false, isCalled = true, isCurrent = true)
            } else {
                it.copy(isCurrent = false)
            }
        }
        _patients.value = updatedList
        val reactivated = patient.copy(isPostponed = false, isCalled = true, isCurrent = true)
        _currentPatient.value = reactivated
        saveQueue()
        return reactivated
    }

    /**
     * إعادة مراجع مؤجل إلى قائمة الانتظار العادية
     */
    fun restorePostponedToQueue(patient: Patient) {
        val currentList = _patients.value
        val updatedList = currentList.map {
            if (it.queueNumber == patient.queueNumber) {
                it.copy(isPostponed = false, isCalled = false)
            } else {
                it
            }
        }
        _patients.value = updatedList
        if (_currentPatient.value == null) {
            _currentPatient.value = patient.copy(isPostponed = false, isCalled = false, isCurrent = true)
        }
        saveQueue()
    }

    /**
     * حذف مراجع نهائياً
     */
    fun deletePatient(patient: Patient) {
        val currentList = _patients.value
        val updatedList = currentList.filter { it.queueNumber != patient.queueNumber }
        _patients.value = updatedList
        if (_currentPatient.value?.queueNumber == patient.queueNumber) {
            val nextActive = updatedList.firstOrNull { !it.isPostponed && !it.isCalled }
                ?: updatedList.firstOrNull { !it.isPostponed }
            _currentPatient.value = nextActive
        }
        saveQueue()
    }

    fun selectPatient(patient: Patient) {
        val updatedList = _patients.value.map {
            it.copy(isCurrent = (it.queueNumber == patient.queueNumber))
        }
        _patients.value = updatedList
        _currentPatient.value = patient.copy(isCurrent = true)
        saveQueue()
    }

    fun resetQueue() {
        _patients.value = emptyList()
        _currentPatient.value = null
        saveQueue()
    }
}
