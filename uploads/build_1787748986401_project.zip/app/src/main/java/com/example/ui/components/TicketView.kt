package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import com.example.ui.theme.NavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TicketView(
    patient: Patient,
    settings: SystemSettings,
    modifier: Modifier = Modifier
) {
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.US)
    val timeFormat = SimpleDateFormat("hh:mm a", Locale.US)
    val dateObj = Date(patient.timestamp)

    Card(
        modifier = modifier
            .width(270.dp)
            .clip(createSawtoothTicketShape()),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 22.dp, start = 18.dp, end = 18.dp, bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Clinic Name
            Text(
                text = settings.clinicName,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark,
                textAlign = TextAlign.Center
            )

            // 2. Doctor Name (if set)
            if (settings.doctorName.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = settings.doctorName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )
            }

            // 3. Clinic Phone (if set)
            if (settings.clinicPhone.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "هاتف: ${settings.clinicPhone}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Normal,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dashed Divider
            DashedDivider(
                modifier = Modifier.fillMaxWidth(),
                color = NavyDark.copy(alpha = 0.25f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // "المراجع رقم"
            Text(
                text = "المراجع رقم",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Large Bold Patient Number e.g. "25"
            Text(
                text = patient.formattedNumber,
                fontSize = 58.sp,
                fontWeight = FontWeight.Black,
                color = NavyDark,
                textAlign = TextAlign.Center
            )

            // Patient Name (if provided)
            if (patient.name.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "اسم المراجع: ${patient.name}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark,
                    textAlign = TextAlign.Center
                )
            }

            // Notes / Service (if provided - strictly hidden if blank)
            if (patient.note.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ملاحظات: ${patient.note}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Dashed Divider
            DashedDivider(
                modifier = Modifier.fillMaxWidth(),
                color = NavyDark.copy(alpha = 0.25f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Date and Time
            Text(
                text = dateFormat.format(dateObj),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = timeFormat.format(dateObj),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Footer Message (Required by User: "يرجى الاحتفاظ بالوصل")
            Text(
                text = settings.footerMessage.ifBlank { "يرجى الاحتفاظ بالوصل" },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "شكراً لزيارتكم • نتمنى لكم الشفاء العاجل",
                fontSize = 10.sp,
                fontWeight = FontWeight.Normal,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun DashedDivider(
    modifier: Modifier = Modifier,
    color: Color = Color.Black
) {
    Box(
        modifier = modifier
            .height(1.dp)
            .drawWithContent {
                val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
                drawLine(
                    color = color,
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = 1.5f,
                    pathEffect = pathEffect
                )
            }
    )
}

/**
 * Creates ticket shape with smooth sawtooth / zigzag bottom border cut
 */
private fun createSawtoothTicketShape(): GenericShape {
    return GenericShape { size, _ ->
        val width = size.width
        val height = size.height
        val toothWidth = 14f
        val toothHeight = 8f
        val numTeeth = (width / toothWidth).toInt()

        moveTo(0f, 0f)
        lineTo(width, 0f)
        lineTo(width, height - toothHeight)

        // Draw sawtooth bottom
        for (i in numTeeth downTo 0) {
            val xCenter = i * toothWidth - (toothWidth / 2f)
            val xLeft = (i - 1) * toothWidth
            lineTo(xCenter.coerceAtLeast(0f), height)
            lineTo(xLeft.coerceAtLeast(0f), height - toothHeight)
        }

        lineTo(0f, 0f)
        close()
    }
}
