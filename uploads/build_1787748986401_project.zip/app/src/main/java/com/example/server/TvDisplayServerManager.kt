package com.example.server

import android.content.Context
import android.util.Log
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ActiveTvCall(
    val callId: Long = 0L,
    val queueNumber: Int = 0,
    val patientName: String = "",
    val timestamp: Long = 0L
)

class TvDisplayServerManager(private val context: Context) {

    private val TAG = "TvDisplayServer"
    private val scope = CoroutineScope(Dispatchers.IO)
    private var serverJob: Job? = null
    private var serverSocket: ServerSocket? = null

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _serverPort = MutableStateFlow(8080)
    val serverPort: StateFlow<Int> = _serverPort.asStateFlow()

    private val _serverUrl = MutableStateFlow("")
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    private val _connectedClientsCount = MutableStateFlow(0)
    val connectedClientsCount: StateFlow<Int> = _connectedClientsCount.asStateFlow()

    // State cached for TV queries
    private var currentSettings = SystemSettings()
    private var currentPatientsList = listOf<Patient>()
    private var currentActivePatient: Patient? = null
    private var latestCallEvent = ActiveTvCall()

    fun updateState(settings: SystemSettings, patients: List<Patient>, activePatient: Patient?) {
        this.currentSettings = settings
        this.currentPatientsList = patients
        this.currentActivePatient = activePatient
    }

    fun notifyPatientCalled(patient: Patient) {
        latestCallEvent = ActiveTvCall(
            callId = System.currentTimeMillis(),
            queueNumber = patient.queueNumber,
            patientName = patient.name,
            timestamp = System.currentTimeMillis()
        )
    }

    fun startServer(port: Int = 8080) {
        if (_isServerRunning.value) return

        serverJob?.cancel()
        serverJob = scope.launch {
            try {
                _serverPort.value = port
                val ip = getLocalIpAddress()
                val url = "http://$ip:$port"
                _serverUrl.value = url

                serverSocket = ServerSocket(port).apply {
                    reuseAddress = true
                }
                _isServerRunning.value = true
                Log.d(TAG, "TV Display Server started at $url")

                while (isActive && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        scope.launch {
                            handleClient(clientSocket)
                        }
                    } catch (e: Exception) {
                        if (!isActive) break
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting TV server: ${e.message}", e)
            } finally {
                _isServerRunning.value = false
            }
        }
    }

    fun stopServer() {
        try {
            serverJob?.cancel()
            serverSocket?.close()
            serverSocket = null
        } catch (_: Exception) {}
        _isServerRunning.value = false
        _connectedClientsCount.value = 0
    }

    fun refreshUrl() {
        val ip = getLocalIpAddress()
        _serverUrl.value = "http://$ip:${_serverPort.value}"
    }

    fun getLocalIpAddress(): String {
        try {
            val candidateIps = mutableListOf<String>()
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val hostAddress = address.hostAddress ?: continue
                        candidateIps.add(hostAddress)
                    }
                }
            }

            // 1. Android Local-Only Hotspot interface (192.168.49.x)
            candidateIps.firstOrNull { it.startsWith("192.168.49.") }?.let { return it }

            // 2. Standard Android Hotspot Gateway (192.168.43.x)
            candidateIps.firstOrNull { it.startsWith("192.168.43.") }?.let { return it }

            // 3. Local Wi-Fi Network (192.168.x.x)
            candidateIps.firstOrNull { it.startsWith("192.168.") }?.let { return it }

            // 4. Other private IP ranges (10.x.x.x or 172.x.x.x)
            candidateIps.firstOrNull { it.startsWith("10.") || it.startsWith("172.") }?.let { return it }

            if (candidateIps.isNotEmpty()) {
                return candidateIps.first()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting IP: ${e.message}")
        }
        return "192.168.49.1"
    }

    private suspend fun handleClient(socket: Socket) = withContext(Dispatchers.IO) {
        try {
            socket.soTimeout = 10000
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val outputStream = socket.getOutputStream()

            val requestLine = reader.readLine() ?: return@withContext
            val parts = requestLine.split(" ")
            if (parts.size < 2) return@withContext

            val method = parts[0]
            val path = parts[1]

            when {
                path.startsWith("/api/status") -> {
                    serveStatusJson(outputStream)
                }
                path.startsWith("/api/audio") -> {
                    serveAudioWav(outputStream)
                }
                path == "/" || path.startsWith("/index.html") || path.startsWith("/tv") -> {
                    serveTvHtml(outputStream)
                }
                else -> {
                    serveNotFound(outputStream)
                }
            }
        } catch (_: Exception) {
        } finally {
            try {
                socket.close()
            } catch (_: Exception) {}
        }
    }

    private fun serveStatusJson(output: OutputStream) {
        val json = JSONObject().apply {
            put("clinicName", currentSettings.clinicName.ifBlank { "نظام إدارة المراجعين" })
            put("doctorName", currentSettings.doctorName)
            put("clinicPhone", currentSettings.clinicPhone)
            put("customFooter", currentSettings.footerMessage)
            put("callTemplate", currentSettings.callPhrase)

            // Current Active
            if (currentActivePatient != null) {
                put("currentPatient", JSONObject().apply {
                    put("id", currentActivePatient?.id)
                    put("number", currentActivePatient?.queueNumber)
                    put("formattedNumber", currentActivePatient?.formattedNumber)
                    put("name", currentActivePatient?.name)
                    put("isPostponed", currentActivePatient?.isPostponed)
                })
            } else {
                put("currentPatient", JSONObject.NULL)
            }

            // Latest call trigger for TV chime & speech
            put("activeCall", JSONObject().apply {
                put("callId", latestCallEvent.callId)
                put("queueNumber", latestCallEvent.queueNumber)
                put("patientName", latestCallEvent.patientName)
                put("timestamp", latestCallEvent.timestamp)
            })

            // Waiting patients
            val waitingArr = JSONArray()
            currentPatientsList
                .filter { !it.isPostponed && !it.isCalled }
                .take(8)
                .forEach { p ->
                    waitingArr.put(JSONObject().apply {
                        put("number", p.queueNumber)
                        put("formattedNumber", p.formattedNumber)
                        put("name", p.name)
                    })
                }
            put("waitingList", waitingArr)

            // Postponed patients
            val postponedArr = JSONArray()
            currentPatientsList
                .filter { it.isPostponed }
                .take(6)
                .forEach { p ->
                    postponedArr.put(JSONObject().apply {
                        put("number", p.queueNumber)
                        put("formattedNumber", p.formattedNumber)
                        put("name", p.name)
                    })
                }
            put("postponedList", postponedArr)

            put("totalPatients", currentPatientsList.size)
            put("waitingCount", currentPatientsList.count { !it.isPostponed && !it.isCalled })
            put("postponedCount", currentPatientsList.count { it.isPostponed })
            put("serverTime", SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
        }

        val bytes = json.toString().toByteArray(Charsets.UTF_8)
        val headers = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: application/json; charset=UTF-8\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"

        output.write(headers.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun serveAudioWav(output: OutputStream) {
        val audioFile = java.io.File(context.cacheDir, "call_latest.wav")
        if (audioFile.exists() && audioFile.length() > 0) {
            val bytes = audioFile.readBytes()
            val headers = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: audio/wav\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Accept-Ranges: bytes\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                    "Connection: close\r\n\r\n"
            output.write(headers.toByteArray(Charsets.UTF_8))
            output.write(bytes)
            output.flush()
        } else {
            serveNotFound(output)
        }
    }

    private fun serveTvHtml(output: OutputStream) {
        val html = generateTvHtmlPage()
        val bytes = html.toByteArray(Charsets.UTF_8)
        val headers = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"

        output.write(headers.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun serveNotFound(output: OutputStream) {
        val response = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun generateTvHtmlPage(): String {
        return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>شاشة الانتظار والمراجعين | Smart TV Display</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            user-select: none;
            -webkit-user-select: none;
        }

        html, body {
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            background: radial-gradient(circle at 50% 20%, #0F172A 0%, #020617 100%);
            color: #FFFFFF;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        /* Top Header Bar */
        header {
            height: 76px;
            background: rgba(15, 23, 42, 0.95);
            border-bottom: 2px solid rgba(56, 189, 248, 0.25);
            padding: 0 36px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }

        .clinic-brand {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .brand-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #2563EB, #1D4ED8);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            box-shadow: 0 4px 16px rgba(37, 99, 235, 0.4);
        }

        .clinic-info h1 {
            font-size: 24px;
            font-weight: 800;
            color: #FFFFFF;
            line-height: 1.2;
        }

        .clinic-info p {
            font-size: 14px;
            color: #94A3B8;
            font-weight: 600;
        }

        .header-meta {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .clock-badge {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            padding: 8px 20px;
            font-size: 20px;
            font-weight: 800;
            color: #38BDF8;
            letter-spacing: 1px;
            font-variant-numeric: tabular-nums;
        }

        .audio-btn {
            background: #16A34A;
            color: #FFFFFF;
            border: 2px solid #22C55E;
            border-radius: 12px;
            padding: 8px 20px;
            font-size: 15px;
            font-weight: 800;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 0 20px rgba(34, 197, 94, 0.4);
            animation: pulse-green 2s infinite;
            transition: transform 0.15s;
        }

        @keyframes pulse-green {
            0% { transform: scale(1); }
            50% { transform: scale(1.04); }
            100% { transform: scale(1); }
        }

        .audio-btn.enabled {
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.25);
            color: #38BDF8;
            box-shadow: none;
            animation: none;
        }

        /* Main Content Layout - Fullscreen Centered Focus for TV */
        main {
            flex: 1;
            height: calc(100vh - 128px);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 48px;
            box-sizing: border-box;
            overflow: hidden;
        }

        /* Large Centered Calling Card */
        .active-call-hero {
            width: 100%;
            max-width: 900px;
            background: rgba(255, 255, 255, 0.04);
            border: 2px solid rgba(255, 255, 255, 0.15);
            border-radius: 36px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 40px 30px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.7);
            position: relative;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        .active-call-hero.calling-animation {
            border-color: #38BDF8;
            background: rgba(37, 99, 235, 0.18);
            box-shadow: 0 0 80px rgba(56, 189, 248, 0.8), inset 0 0 60px rgba(56, 189, 248, 0.3);
            animation: pulse-glow 1s infinite alternate;
        }

        @keyframes pulse-glow {
            0% { transform: scale(1); }
            100% { transform: scale(1.02); }
        }

        .hero-top-label {
            font-size: 38px;
            font-weight: 900;
            color: #94A3B8;
            letter-spacing: 1.5px;
            margin-bottom: 6px;
        }

        .hero-tag {
            background: rgba(37, 99, 235, 0.4);
            border: 1px solid #3B82F6;
            color: #93C5FD;
            font-size: 26px;
            font-weight: 800;
            padding: 6px 36px;
            border-radius: 24px;
            margin-bottom: 12px;
            letter-spacing: 1px;
        }

        .hero-number {
            font-size: 210px;
            font-weight: 900;
            line-height: 0.95;
            color: #FFFFFF;
            text-shadow: 0 10px 40px rgba(0,0,0,0.9);
            letter-spacing: 2px;
            margin: 0 0 16px 0;
            font-variant-numeric: tabular-nums;
        }

        .hero-patient-name {
            font-size: 34px;
            font-weight: 800;
            color: #38BDF8;
            margin-bottom: 24px;
            min-height: 42px;
        }

        .hero-instruction {
            background: rgba(34, 197, 94, 0.22);
            border: 2px solid rgba(34, 197, 94, 0.6);
            color: #4ADE80;
            padding: 18px 56px;
            border-radius: 24px;
            font-size: 34px;
            font-weight: 900;
            box-shadow: 0 6px 30px rgba(34, 197, 94, 0.35);
            letter-spacing: 0.5px;
        }

        /* Bottom Footer */
        footer {
            height: 52px;
            background: rgba(15, 23, 42, 0.95);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding: 0 36px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 15px;
            color: #94A3B8;
            flex-shrink: 0;
        }

        .footer-ticker {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
            color: #E2E8F0;
        }

        .status-dot {
            width: 10px;
            height: 10px;
            background: #22C55E;
            border-radius: 50%;
            display: inline-block;
            box-shadow: 0 0 10px #22C55E;
        }
    </style>
</head>
<body onclick="autoEnableAudio()" onkeydown="autoEnableAudio()">

    <!-- Audio Element for Phone TTS Streaming -->
    <audio id="tvAudioPlayer" preload="auto"></audio>

    <!-- Header -->
    <header>
        <div class="clinic-brand">
            <div class="brand-icon">🏥</div>
            <div class="clinic-info">
                <h1 id="clinicName">نظام إدارة المراجعين</h1>
                <p id="doctorName">عيادة الطبيب</p>
            </div>
        </div>

        <div class="header-meta">
            <button id="audioEnableBtn" class="audio-btn" onclick="enableAudioOnTv(event)">
                🔊 تفعيل صوت الشاشة
            </button>
            <div class="clock-badge" id="liveClock">00:00:00</div>
        </div>
    </header>

    <!-- Main TV Screen Focus -->
    <main>
        <section class="active-call-hero" id="activeCallHero">
            <div class="hero-top-label">المراجع</div>
            <div class="hero-tag" id="statusTag">رقم</div>
            <div class="hero-number" id="currentNumber">--</div>
            <div class="hero-patient-name" id="currentPatientName"></div>
            <div class="hero-instruction" id="heroInstruction">يرجى التوجه إلى غرفة العيادة</div>
        </section>
    </main>

    <!-- Bottom Footer -->
    <footer>
        <div class="footer-ticker">
            <span class="status-dot"></span>
            <span id="footerText">الشاشة متصلة بنظام العيادة والنداء الصوتي مفعّل</span>
        </div>
        <div id="dateText">اليوم</div>
    </footer>

    <script>
        let audioContext = null;
        let isAudioAllowed = false;
        let lastPlayedCallId = 0;
        let arabicVoice = null;

        // Load and cache voices for Web Speech synthesis fallback
        function loadArabicVoices() {
            if (!('speechSynthesis' in window)) return;
            const voices = window.speechSynthesis.getVoices();
            if (voices && voices.length > 0) {
                arabicVoice = voices.find(v => v.lang && (v.lang.startsWith('ar') || v.lang.includes('AR'))) || voices[0];
            }
        }

        if ('speechSynthesis' in window) {
            loadArabicVoices();
            window.speechSynthesis.onvoiceschanged = loadArabicVoices;
        }

        // Initialize Audio Context on user click or TV remote enter
        function enableAudioOnTv(e) {
            if (e) e.stopPropagation();
            try {
                if (!audioContext) {
                    audioContext = new (window.AudioContext || window.webkitAudioContext)();
                }
                if (audioContext.state === 'suspended') {
                    audioContext.resume();
                }

                // Unlock HTML5 Audio
                const audioPlayer = document.getElementById('tvAudioPlayer');
                if (audioPlayer) {
                    audioPlayer.play().catch(() => {});
                }

                isAudioAllowed = true;
                const btn = document.getElementById('audioEnableBtn');
                if (btn) {
                    btn.classList.add('enabled');
                    btn.innerHTML = '✅ الصوت مفعّل على الشاشة';
                }

                loadArabicVoices();
                // Play gentle test chime
                playHospitalChime();
            } catch (e) {
                console.error("Audio init error:", e);
            }
        }

        function autoEnableAudio() {
            if (!isAudioAllowed) {
                enableAudioOnTv();
            }
        }

        // Synthesize authentic 2-tone clinic chime (880Hz -> 659.25Hz) with Web Audio API
        function playHospitalChime() {
            try {
                if (!audioContext) {
                    audioContext = new (window.AudioContext || window.webkitAudioContext)();
                }
                if (audioContext.state === 'suspended') {
                    audioContext.resume();
                }

                const now = audioContext.currentTime;

                // Tone 1: 880 Hz (A5)
                const osc1 = audioContext.createOscillator();
                const gain1 = audioContext.createGain();
                osc1.type = 'sine';
                osc1.frequency.setValueAtTime(880, now);
                gain1.gain.setValueAtTime(0.7, now);
                gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
                osc1.connect(gain1);
                gain1.connect(audioContext.destination);
                osc1.start(now);
                osc1.stop(now + 0.5);

                // Tone 2: 659.25 Hz (E5)
                const osc2 = audioContext.createOscillator();
                const gain2 = audioContext.createGain();
                osc2.type = 'sine';
                osc2.frequency.setValueAtTime(659.25, now + 0.35);
                gain2.gain.setValueAtTime(0.8, now + 0.35);
                gain2.gain.exponentialRampToValueAtTime(0.001, now + 1.1);
                osc2.connect(gain2);
                gain2.connect(audioContext.destination);
                osc2.start(now + 0.35);
                osc2.stop(now + 1.1);
            } catch (err) {
                console.error("Chime error:", err);
            }
        }

        // Play call announcement with direct phone TTS stream audio
        function playPatientCallAnnouncement(queueNumber) {
            // 1. Play Chime
            playHospitalChime();

            // 2. Play phone-synthesized Arabic speech file via HTML5 Audio element
            const audioPlayer = document.getElementById('tvAudioPlayer');
            if (audioPlayer) {
                setTimeout(() => {
                    audioPlayer.src = '/api/audio/latest.wav?t=' + Date.now();
                    audioPlayer.play().catch(err => {
                        console.log("Audio file play error, using speech synthesis fallback:", err);
                        speakPatientFallback(queueNumber);
                    });
                }, 550);
            } else {
                speakPatientFallback(queueNumber);
            }
        }

        // Fallback for browsers if audio file fetch fails
        function speakPatientFallback(queueNumber) {
            if (!('speechSynthesis' in window)) return;
            try {
                window.speechSynthesis.cancel();
                const phrase = "المراجع رقم " + (queueNumber || "1") + " ، يرجى التوجه إلى غرفة العيادة";
                const utterance = new SpeechSynthesisUtterance(phrase);
                utterance.lang = 'ar-SA';
                utterance.rate = 0.85;
                loadArabicVoices();
                if (arabicVoice) utterance.voice = arabicVoice;
                window.speechSynthesis.speak(utterance);
            } catch (e) {}
        }

        // Real-time polling function
        async function fetchQueueStatus() {
            try {
                const response = await fetch('/api/status?t=' + Date.now());
                if (!response.ok) return;

                const data = await response.json();

                // Update Header
                document.getElementById('clinicName').innerText = data.clinicName || 'نظام إدارة المراجعين';
                if (data.doctorName && data.doctorName.trim() !== '') {
                    document.getElementById('doctorName').innerText = 'د. ' + data.doctorName;
                } else {
                    document.getElementById('doctorName').innerText = 'لوحة الاستدعاء والانتظار';
                }

                // Update Active Patient
                const hero = document.getElementById('activeCallHero');
                const numEl = document.getElementById('currentNumber');
                const nameEl = document.getElementById('currentPatientName');

                if (data.currentPatient) {
                    numEl.innerText = data.currentPatient.number;
                    nameEl.innerText = data.currentPatient.name ? data.currentPatient.name : '';
                } else {
                    numEl.innerText = '--';
                    nameEl.innerText = '';
                }

                // Check for new calling trigger to play audio & flash animation
                if (data.activeCall && data.activeCall.callId && data.activeCall.callId > lastPlayedCallId) {
                    lastPlayedCallId = data.activeCall.callId;

                    // Trigger visual calling glow animation
                    hero.classList.add('calling-animation');
                    setTimeout(() => {
                        hero.classList.remove('calling-animation');
                    }, 6000);

                    // Play audio (chime + spoken Arabic sentence)
                    if (isAudioAllowed) {
                        playPatientCallAnnouncement(data.activeCall.queueNumber);
                    }
                }

                if (data.customFooter) {
                    document.getElementById('footerText').innerText = data.customFooter;
                }

            } catch (err) {
                console.error("Fetch error:", err);
            }
        }

        // Live Clock
        function updateClock() {
            const now = new Date();
            document.getElementById('liveClock').innerText = now.toLocaleTimeString('ar-SA', { hour12: true });
            document.getElementById('dateText').innerText = now.toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        }

        // Start polling loop
        setInterval(fetchQueueStatus, 700);
        setInterval(updateClock, 1000);
        fetchQueueStatus();
        updateClock();
    </script>
</body>
</html>
        """.trimIndent()
    }
}
