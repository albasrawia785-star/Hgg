package com.example

/**
 * ملف إعدادات العيادة والوصل
 * يتم تعديل هذه البيانات هنا يدويًا حسب رغبة العيادة:
 */
object ClinicInfo {
    // اسم العيادة / المركز الطبي
    var clinicName: String = "عيادة الشفاء التخصصية"

    // اسم الطبيب / الطبيبة
    var doctorName: String = "د. أحمد عبدالله"

    // رقم هاتف العيادة
    var clinicPhone: String = "07701234567"

    // رسالة نهاية الوصل
    var footerMessage: String = "يرجى الاحتفاظ بالوصل"
}
