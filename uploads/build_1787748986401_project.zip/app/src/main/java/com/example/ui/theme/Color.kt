package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Palette
val NavyDark = Color(0xFF1B2B48)
val NavyPrimary = Color(0xFF1B2B48)
val NavyAccent = Color(0xFF243A5E)
val NavyLight = Color(0xFF334E75)

// Emerald Green Palette (Connected / Ready)
val GreenSuccess = Color(0xFF22C55E)
val GreenDark = Color(0xFF15803D)
val GreenContainer = Color(0xFFF0FDF4)
val GreenBorder = Color(0xFFDCFCE7)
val GreenText = Color(0xFF15803D)

// Destructive Red Palette (Reset / Disconnect)
val RedDestructive = Color(0xFFDC2626)
val RedLight = Color(0xFFEF4444)
val RedContainer = Color(0xFFFEF2F2)
val RedBorder = Color(0xFFFEE2E2)
val RedText = Color(0xFFDC2626)

// Amber Palette (Postponed / Waiting)
val AmberWarning = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFFFBEB)
val AmberBorder = Color(0xFFFEF3C7)
val AmberText = Color(0xFFB45309)

// Neutral & Background (Geometric Clean Canvas)
val BackgroundWhite = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceSubtle = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)
val BorderSubtle = Color(0xFFF1F5F9)
val BorderLight = Color(0xFFE2E8F0)

// Text Colors
val TextPrimary = Color(0xFF1B2B48)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)
val TextOnNavy = Color(0xFFFFFFFF)
