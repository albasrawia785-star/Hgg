package com.example.data.model

data class Patient(
    val id: Int,
    val queueNumber: Int,
    val name: String = "",
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isCalled: Boolean = false,
    val isCurrent: Boolean = false,
    val isPostponed: Boolean = false
) {
    val formattedNumber: String
        get() = queueNumber.toString()
}
