package com.example.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

class TtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var textToSpeech: TextToSpeech? = null

    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()

    private val _isArabicSupported = MutableStateFlow(true)
    val isArabicSupported: StateFlow<Boolean> = _isArabicSupported.asStateFlow()

    private var currentSpeechRate: Float = 0.85f
    private var currentPitch: Float = 1.0f

    init {
        textToSpeech = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val arabicLocale = Locale("ar", "SA")
            val result = textToSpeech?.setLanguage(arabicLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to standard "ar" or default
                val generalAr = textToSpeech?.setLanguage(Locale("ar"))
                _isArabicSupported.value = (generalAr != TextToSpeech.LANG_MISSING_DATA && generalAr != TextToSpeech.LANG_NOT_SUPPORTED)
            } else {
                _isArabicSupported.value = true
            }
            textToSpeech?.setSpeechRate(currentSpeechRate)
            textToSpeech?.setPitch(currentPitch)
            
            // Prefer high-quality/neural Arabic voices if available on device
            try {
                val voices = textToSpeech?.voices
                if (voices != null) {
                    val arabicVoices = voices.filter { it.locale.language == "ar" }
                    val highQualityVoice = arabicVoices.firstOrNull { 
                        !it.isNetworkConnectionRequired && it.quality >= android.speech.tts.Voice.QUALITY_HIGH 
                    } ?: arabicVoices.firstOrNull()
                    
                    if (highQualityVoice != null) {
                        textToSpeech?.voice = highQualityVoice
                    }
                }
            } catch (_: Exception) {}
            
            _isInitialized.value = true
        } else {
            _isInitialized.value = false
        }
    }

    fun setSpeechRate(rate: Float) {
        currentSpeechRate = rate.coerceIn(0.4f, 2.0f)
        textToSpeech?.setSpeechRate(currentSpeechRate)
    }

    fun setPitch(pitch: Float) {
        currentPitch = pitch.coerceIn(0.4f, 2.0f)
        textToSpeech?.setPitch(currentPitch)
    }

    suspend fun speak(text: String, volume: Float = 1.0f): Boolean {
        val result = kotlinx.coroutines.withTimeoutOrNull(4000L) {
            suspendCancellableCoroutine { continuation ->
                val tts = textToSpeech
                if (tts == null) {
                    continuation.resume(false)
                    return@suspendCancellableCoroutine
                }

                // Apply speech rate & pitch
                tts.setSpeechRate(currentSpeechRate)
                tts.setPitch(currentPitch)

                val utteranceId = "queue_call_${System.currentTimeMillis()}"
                val params = Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0.0f, 1.0f))
                }

                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}

                    override fun onDone(id: String?) {
                        if (id == utteranceId && continuation.isActive) {
                            continuation.resume(true)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        if (id == utteranceId && continuation.isActive) {
                            continuation.resume(false)
                        }
                    }

                    override fun onError(id: String?, errorCode: Int) {
                        if (id == utteranceId && continuation.isActive) {
                            continuation.resume(false)
                        }
                    }
                })

                val speakResult = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
                if (speakResult != TextToSpeech.SUCCESS && continuation.isActive) {
                    continuation.resume(false)
                }
            }
        }
        return result ?: false
    }

    suspend fun synthesizeToFile(text: String, outputFile: java.io.File): Boolean {
        val result = kotlinx.coroutines.withTimeoutOrNull(4000L) {
            suspendCancellableCoroutine { continuation ->
                val tts = textToSpeech
                if (tts == null) {
                    continuation.resume(false)
                    return@suspendCancellableCoroutine
                }

                tts.setSpeechRate(currentSpeechRate)
                tts.setPitch(currentPitch)

                val utteranceId = "synth_${System.currentTimeMillis()}"
                val params = Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
                }

                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}

                    override fun onDone(id: String?) {
                        if (id == utteranceId && continuation.isActive) {
                            continuation.resume(true)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        if (id == utteranceId && continuation.isActive) {
                            continuation.resume(false)
                        }
                    }

                    override fun onError(id: String?, errorCode: Int) {
                        if (id == utteranceId && continuation.isActive) {
                            continuation.resume(false)
                        }
                    }
                })

                val synthResult = tts.synthesizeToFile(text, params, outputFile, utteranceId)
                if (synthResult != TextToSpeech.SUCCESS && continuation.isActive) {
                    continuation.resume(false)
                }
            }
        }
        return result ?: false
    }

    fun stop() {
        try {
            textToSpeech?.stop()
        } catch (_: Exception) {}
    }

    fun shutdown() {
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (_: Exception) {}
        textToSpeech = null
    }
}
