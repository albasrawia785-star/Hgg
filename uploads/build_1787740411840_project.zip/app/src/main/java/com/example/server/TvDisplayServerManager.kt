package com.example.server

import android.content.Context
import android.util.Log
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ActiveTvCall(
    val callId: Long = 0L,
    val queueNumber: Int = 0,
    val patientName: String = "",
    val timestamp: Long = 0L
)

class TvDisplayServerManager(private val context: Context) {

    private val TAG = "TvDisplayServer"
    private val scope = CoroutineScope(Dispatchers.IO)
    private var serverJob: Job? = null
    private var serverSocket: ServerSocket? = null

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _serverPort = MutableStateFlow(8080)
    val serverPort: StateFlow<Int> = _serverPort.asStateFlow()

    private val _serverUrl = MutableStateFlow("")
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    private val _connectedClientsCount = MutableStateFlow(0)
    val connectedClientsCount: StateFlow<Int> = _connectedClientsCount.asStateFlow()

    // State cached for TV queries
    private var currentSettings = SystemSettings()
    private var currentPatientsList = listOf<Patient>()
    private var currentActivePatient: Patient? = null
    private var latestCallEvent = ActiveTvCall()

    fun updateState(settings: SystemSettings, patients: List<Patient>, activePatient: Patient?) {
        this.currentSettings = settings
        this.currentPatientsList = patients
        this.currentActivePatient = activePatient
    }

    fun notifyPatientCalled(patient: Patient) {
        latestCallEvent = ActiveTvCall(
            callId = System.currentTimeMillis(),
            queueNumber = patient.queueNumber,
            patientName = patient.name,
            timestamp = System.currentTimeMillis()
        )
    }

    fun startServer(port: Int = 8080) {
        if (_isServerRunning.value) return

        serverJob?.cancel()
        serverJob = scope.launch {
            try {
                _serverPort.value = port
                val ip = getLocalIpAddress()
                val url = "http://$ip:$port"
                _serverUrl.value = url

                serverSocket = ServerSocket(port).apply {
                    reuseAddress = true
                }
                _isServerRunning.value = true
                Log.d(TAG, "TV Display Server started at $url")

                while (isActive && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        scope.launch {
                            handleClient(clientSocket)
                        }
                    } catch (e: Exception) {
                        if (!isActive) break
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting TV server: ${e.message}", e)
            } finally {
                _isServerRunning.value = false
            }
        }
    }

    fun stopServer() {
        try {
            serverJob?.cancel()
            serverSocket?.close()
            serverSocket = null
        } catch (_: Exception) {}
        _isServerRunning.value = false
        _connectedClientsCount.value = 0
    }

    fun refreshUrl() {
        val ip = getLocalIpAddress()
        _serverUrl.value = "http://$ip:${_serverPort.value}"
    }

    fun getLocalIpAddress(): String {
        try {
            val candidateIps = mutableListOf<String>()
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val hostAddress = address.hostAddress ?: continue
                        candidateIps.add(hostAddress)
                    }
                }
            }

            // 1. Android Local-Only Hotspot interface (192.168.49.x)
            candidateIps.firstOrNull { it.startsWith("192.168.49.") }?.let { return it }

            // 2. Standard Android Hotspot Gateway (192.168.43.x)
            candidateIps.firstOrNull { it.startsWith("192.168.43.") }?.let { return it }

            // 3. Local Wi-Fi Network (192.168.x.x)
            candidateIps.firstOrNull { it.startsWith("192.168.") }?.let { return it }

            // 4. Other private IP ranges (10.x.x.x or 172.x.x.x)
            candidateIps.firstOrNull { it.startsWith("10.") || it.startsWith("172.") }?.let { return it }

            if (candidateIps.isNotEmpty()) {
                return candidateIps.first()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting IP: ${e.message}")
        }
        return "192.168.49.1"
    }

    private suspend fun handleClient(socket: Socket) = withContext(Dispatchers.IO) {
        try {
            socket.soTimeout = 10000
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val outputStream = socket.getOutputStream()

            val requestLine = reader.readLine() ?: return@withContext
            val parts = requestLine.split(" ")
            if (parts.size < 2) return@withContext

            val method = parts[0]
            val path = parts[1]

            when {
                path.startsWith("/api/status") -> {
                    serveStatusJson(outputStream)
                }
                path == "/" || path.startsWith("/index.html") || path.startsWith("/tv") -> {
                    serveTvHtml(outputStream)
                }
                else -> {
                    serveNotFound(outputStream)
                }
            }
        } catch (_: Exception) {
        } finally {
            try {
                socket.close()
            } catch (_: Exception) {}
        }
    }

    private fun serveStatusJson(output: OutputStream) {
        val json = JSONObject().apply {
            put("clinicName", currentSettings.clinicName.ifBlank { "نظام إدارة المراجعين" })
            put("doctorName", currentSettings.doctorName)
            put("clinicPhone", currentSettings.clinicPhone)
            put("customFooter", currentSettings.footerMessage)
            put("callTemplate", currentSettings.callPhrase)

            // Current Active
            if (currentActivePatient != null) {
                put("currentPatient", JSONObject().apply {
                    put("id", currentActivePatient?.id)
                    put("number", currentActivePatient?.queueNumber)
                    put("formattedNumber", currentActivePatient?.formattedNumber)
                    put("name", currentActivePatient?.name)
                    put("isPostponed", currentActivePatient?.isPostponed)
                })
            } else {
                put("currentPatient", JSONObject.NULL)
            }

            // Latest call trigger for TV chime & speech
            put("activeCall", JSONObject().apply {
                put("callId", latestCallEvent.callId)
                put("queueNumber", latestCallEvent.queueNumber)
                put("patientName", latestCallEvent.patientName)
                put("timestamp", latestCallEvent.timestamp)
            })

            // Waiting patients
            val waitingArr = JSONArray()
            currentPatientsList
                .filter { !it.isPostponed && !it.isCalled }
                .take(8)
                .forEach { p ->
                    waitingArr.put(JSONObject().apply {
                        put("number", p.queueNumber)
                        put("formattedNumber", p.formattedNumber)
                        put("name", p.name)
                    })
                }
            put("waitingList", waitingArr)

            // Postponed patients
            val postponedArr = JSONArray()
            currentPatientsList
                .filter { it.isPostponed }
                .take(6)
                .forEach { p ->
                    postponedArr.put(JSONObject().apply {
                        put("number", p.queueNumber)
                        put("formattedNumber", p.formattedNumber)
                        put("name", p.name)
                    })
                }
            put("postponedList", postponedArr)

            put("totalPatients", currentPatientsList.size)
            put("waitingCount", currentPatientsList.count { !it.isPostponed && !it.isCalled })
            put("postponedCount", currentPatientsList.count { it.isPostponed })
            put("serverTime", SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
        }

        val bytes = json.toString().toByteArray(Charsets.UTF_8)
        val headers = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: application/json; charset=UTF-8\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"

        output.write(headers.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun serveTvHtml(output: OutputStream) {
        val html = generateTvHtmlPage()
        val bytes = html.toByteArray(Charsets.UTF_8)
        val headers = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"

        output.write(headers.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun serveNotFound(output: OutputStream) {
        val response = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun generateTvHtmlPage(): String {
        return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>شاشة الانتظار والمراجعين | Smart TV Display</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            user-select: none;
            -webkit-user-select: none;
        }

        html, body {
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            background: radial-gradient(circle at 50% 20%, #131E3A 0%, #080D1A 100%);
            color: #FFFFFF;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        /* Top Header Bar */
        header {
            height: 72px;
            background: rgba(15, 23, 42, 0.9);
            border-bottom: 2px solid rgba(56, 189, 248, 0.2);
            padding: 0 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }

        .clinic-brand {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .brand-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #2563EB, #1D4ED8);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            box-shadow: 0 4px 16px rgba(37, 99, 235, 0.4);
        }

        .clinic-info h1 {
            font-size: 22px;
            font-weight: 800;
            color: #FFFFFF;
            line-height: 1.2;
        }

        .clinic-info p {
            font-size: 14px;
            color: #94A3B8;
            font-weight: 600;
        }

        .header-meta {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .clock-badge {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            padding: 6px 18px;
            font-size: 20px;
            font-weight: 800;
            color: #38BDF8;
            letter-spacing: 1px;
            font-variant-numeric: tabular-nums;
        }

        .audio-btn {
            background: #16A34A;
            color: #FFFFFF;
            border: none;
            border-radius: 12px;
            padding: 8px 18px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 12px rgba(22, 163, 74, 0.35);
            transition: transform 0.15s;
        }

        .audio-btn:hover {
            transform: scale(1.03);
        }

        .audio-btn.enabled {
            background: rgba(255, 255, 255, 0.12);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #38BDF8;
            box-shadow: none;
        }

        /* Main Content Layout (16:9 TV Proportioned) */
        main {
            flex: 1;
            height: calc(100vh - 122px);
            display: grid;
            grid-template-columns: 1.35fr 0.9fr;
            gap: 20px;
            padding: 16px 32px;
            box-sizing: border-box;
            overflow: hidden;
        }

        /* Left Side: Large Active Patient Hero */
        .active-call-hero {
            background: rgba(255, 255, 255, 0.04);
            border: 2px solid rgba(255, 255, 255, 0.14);
            border-radius: 24px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 24px;
            box-shadow: 0 16px 36px rgba(0, 0, 0, 0.5);
            position: relative;
            height: 100%;
            box-sizing: border-box;
        }

        .active-call-hero.calling-animation {
            border-color: #38BDF8;
            background: rgba(37, 99, 235, 0.08);
            box-shadow: 0 0 60px rgba(56, 189, 248, 0.6), inset 0 0 40px rgba(56, 189, 248, 0.25);
            animation: pulse-glow 1s infinite alternate;
        }

        @keyframes pulse-glow {
            0% { transform: scale(1); }
            100% { transform: scale(1.02); }
        }

        .hero-tag {
            background: rgba(37, 99, 235, 0.3);
            border: 1px solid #3B82F6;
            color: #93C5FD;
            font-size: 16px;
            font-weight: 800;
            padding: 6px 24px;
            border-radius: 20px;
            margin-bottom: 12px;
            letter-spacing: 0.5px;
        }

        .hero-number-title {
            font-size: 20px;
            color: #94A3B8;
            font-weight: 700;
        }

        .hero-number {
            font-size: 140px;
            font-weight: 900;
            line-height: 1;
            color: #FFFFFF;
            text-shadow: 0 8px 24px rgba(0,0,0,0.7);
            letter-spacing: 2px;
            margin: 8px 0;
            font-variant-numeric: tabular-nums;
        }

        .hero-patient-name {
            font-size: 34px;
            font-weight: 800;
            color: #F8FAFC;
            min-height: 44px;
            max-width: 90%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .hero-instruction {
            margin-top: 18px;
            background: rgba(34, 197, 94, 0.15);
            border: 1px solid rgba(34, 197, 94, 0.4);
            color: #4ADE80;
            padding: 10px 32px;
            border-radius: 14px;
            font-size: 18px;
            font-weight: 800;
        }

        /* Right Side: Supporting Lists */
        .side-panel {
            display: flex;
            flex-direction: column;
            gap: 16px;
            height: 100%;
            box-sizing: border-box;
            overflow: hidden;
        }

        .panel-card {
            flex: 1;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 14px 20px;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            box-sizing: border-box;
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 8px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            margin-bottom: 10px;
            flex-shrink: 0;
        }

        .panel-header h3 {
            font-size: 16px;
            font-weight: 800;
            color: #E2E8F0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .badge-count {
            background: rgba(255, 255, 255, 0.12);
            padding: 2px 10px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 800;
            color: #94A3B8;
        }

        .items-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
            overflow-y: auto;
            flex: 1;
            align-content: start;
        }

        .queue-item-pill {
            background: rgba(255, 255, 255, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 12px;
            padding: 8px 12px;
            display: flex;
            align-items: center;
            gap: 10px;
            box-sizing: border-box;
        }

        .pill-number {
            background: #2563EB;
            color: #FFFFFF;
            width: 34px;
            height: 34px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: 900;
            flex-shrink: 0;
        }

        .pill-number.postponed {
            background: #D97706;
        }

        .pill-name {
            font-size: 14px;
            font-weight: 700;
            color: #F1F5F9;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            flex: 1;
        }

        .empty-hint {
            grid-column: span 2;
            text-align: center;
            color: #64748B;
            font-size: 14px;
            font-weight: 600;
            padding: 24px 0;
        }

        /* Bottom Footer Ticker */
        footer {
            height: 48px;
            background: rgba(15, 23, 42, 0.95);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding: 0 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
            color: #94A3B8;
            flex-shrink: 0;
        }

        .footer-ticker {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
            color: #E2E8F0;
        }

        .status-dot {
            width: 10px;
            height: 10px;
            background: #22C55E;
            border-radius: 50%;
            display: inline-block;
            box-shadow: 0 0 10px #22C55E;
        }
    </style>
</head>
<body>

    <!-- Header -->
    <header>
        <div class="clinic-brand">
            <div class="brand-icon">🏥</div>
            <div class="clinic-info">
                <h1 id="clinicName">نظام إدارة المراجعين</h1>
                <p id="doctorName">عيادة الطبيب</p>
            </div>
        </div>

        <div class="header-meta">
            <button id="audioEnableBtn" class="audio-btn" onclick="enableAudioOnTv()">
                🔊 تفعيل صوت الشاشة
            </button>
            <div class="clock-badge" id="liveClock">00:00:00</div>
        </div>
    </header>

    <!-- Main 16:9 Dashboard -->
    <main>
        <!-- Large Center Calling Hero -->
        <section class="active-call-hero" id="activeCallHero">
            <div class="hero-tag" id="statusTag">المُراجِع الحَالي</div>
            <div class="hero-number-title">رقم الدور</div>
            <div class="hero-number" id="currentNumber">--</div>
            <div class="hero-patient-name" id="currentName">في انتظار بدء الاستدعاء...</div>
            <div class="hero-instruction" id="heroInstruction">يرجى التوجه إلى غرفة الكشف</div>
        </section>

        <!-- Right Side Supporting Lists -->
        <section class="side-panel">
            <!-- Next in queue -->
            <div class="panel-card">
                <div class="panel-header">
                    <h3>👥 في قائمة الانتظار</h3>
                    <span class="badge-count" id="waitingBadge">0</span>
                </div>
                <div class="items-grid" id="waitingGrid">
                    <div class="empty-hint">لا يوجد مراجعين في الانتظار</div>
                </div>
            </div>

            <!-- Postponed list -->
            <div class="panel-card">
                <div class="panel-header">
                    <h3>⏳ المراجعين المؤجلين</h3>
                    <span class="badge-count" id="postponedBadge">0</span>
                </div>
                <div class="items-grid" id="postponedGrid">
                    <div class="empty-hint">لا يوجد مراجعين مؤجلين</div>
                </div>
            </div>
        </section>
    </main>

    <!-- Bottom Footer -->
    <footer>
        <div class="footer-ticker">
            <span class="status-dot"></span>
            <span id="footerText">الشاشة متصلة بالنظام وتحدث البيانات فورياً</span>
        </div>
        <div id="dateText">اليوم</div>
    </footer>

    <script>
        let audioContext = null;
        let isAudioAllowed = false;
        let lastPlayedCallId = 0;

        // Initialize Audio Context on user click or TV remote enter
        function enableAudioOnTv() {
            try {
                if (!audioContext) {
                    audioContext = new (window.AudioContext || window.webkitAudioContext)();
                }
                if (audioContext.state === 'suspended') {
                    audioContext.resume();
                }
                isAudioAllowed = true;
                const btn = document.getElementById('audioEnableBtn');
                btn.classList.add('enabled');
                btn.innerHTML = '✅ الصوت مفعّل على الشاشة';

                // Play test gentle welcome chime
                playHospitalChime();
            } catch (e) {
                console.error("Audio init error:", e);
            }
        }

        // Synthesize authentic 2-tone clinic chime (880Hz -> 659.25Hz) with pure Web Audio API
        function playHospitalChime() {
            if (!audioContext) {
                audioContext = new (window.AudioContext || window.webkitAudioContext)();
            }
            if (audioContext.state === 'suspended') {
                audioContext.resume();
            }

            const now = audioContext.currentTime;

            // Tone 1: 880 Hz (A5)
            const osc1 = audioContext.createOscillator();
            const gain1 = audioContext.createGain();
            osc1.type = 'sine';
            osc1.frequency.setValueAtTime(880, now);
            gain1.gain.setValueAtTime(0.7, now);
            gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
            osc1.connect(gain1);
            gain1.connect(audioContext.destination);
            osc1.start(now);
            osc1.stop(now + 0.5);

            // Tone 2: 659.25 Hz (E5)
            const osc2 = audioContext.createOscillator();
            const gain2 = audioContext.createGain();
            osc2.type = 'sine';
            osc2.frequency.setValueAtTime(659.25, now + 0.35);
            gain2.gain.setValueAtTime(0.8, now + 0.35);
            gain2.gain.exponentialRampToValueAtTime(0.001, now + 1.1);
            osc2.connect(gain2);
            gain2.connect(audioContext.destination);
            osc2.start(now + 0.35);
            osc2.stop(now + 1.1);
        }

        // Arabic Web Speech synthesis from TV speaker
        function speakPatientAnnouncement(queueNumber, patientName) {
            if (!('speechSynthesis' in window)) return;

            window.speechSynthesis.cancel();

            let phrase = "المراجع رقم " + queueNumber;
            if (patientName && patientName.trim() !== '') {
                phrase += " ، " + patientName;
            }
            phrase += " ، يرجى التوجه إلى غرفة الكشف";

            const utterance = new SpeechSynthesisUtterance(phrase);
            utterance.lang = 'ar-SA';
            utterance.rate = 0.9;
            utterance.pitch = 1.0;

            setTimeout(() => {
                window.speechSynthesis.speak(utterance);
            }, 750);
        }

        // Real-time polling function
        async function fetchQueueStatus() {
            try {
                const response = await fetch('/api/status?t=' + Date.now());
                if (!response.ok) return;

                const data = await response.json();

                // Update Header
                document.getElementById('clinicName').innerText = data.clinicName || 'نظام إدارة المراجعين';
                if (data.doctorName && data.doctorName.trim() !== '') {
                    document.getElementById('doctorName').innerText = 'د. ' + data.doctorName;
                } else {
                    document.getElementById('doctorName').innerText = 'لوحة الاستدعاء والانتظار';
                }

                // Update Active Patient
                const hero = document.getElementById('activeCallHero');
                const numEl = document.getElementById('currentNumber');
                const nameEl = document.getElementById('currentName');

                if (data.currentPatient) {
                    numEl.innerText = data.currentPatient.number;
                    nameEl.innerText = data.currentPatient.name ? data.currentPatient.name : 'المراجع رقم ' + data.currentPatient.number;
                } else {
                    numEl.innerText = '--';
                    nameEl.innerText = 'في انتظار بدء الاستدعاء...';
                }

                // Check for new calling trigger to play audio & flash animation
                if (data.activeCall && data.activeCall.callId && data.activeCall.callId > lastPlayedCallId) {
                    lastPlayedCallId = data.activeCall.callId;

                    // Trigger visual calling glow animation
                    hero.classList.add('calling-animation');
                    setTimeout(() => {
                        hero.classList.remove('calling-animation');
                    }, 6000);

                    // Play audio and announce directly from TV
                    if (isAudioAllowed) {
                        playHospitalChime();
                        speakPatientAnnouncement(data.activeCall.queueNumber, data.activeCall.patientName);
                    }
                }

                // Update Waiting List
                document.getElementById('waitingBadge').innerText = data.waitingCount || 0;
                const waitingGrid = document.getElementById('waitingGrid');
                if (!data.waitingList || data.waitingList.length === 0) {
                    waitingGrid.innerHTML = '<div class="empty-hint">لا يوجد مراجعين في الانتظار</div>';
                } else {
                    waitingGrid.innerHTML = data.waitingList.map(p => `
                        <div class="queue-item-pill">
                            <div class="pill-number">${'$'}{p.number}</div>
                            <div class="pill-name">${'$'}{p.name || 'مراجع'}</div>
                        </div>
                    `).join('');
                }

                // Update Postponed List
                document.getElementById('postponedBadge').innerText = data.postponedCount || 0;
                const postponedGrid = document.getElementById('postponedGrid');
                if (!data.postponedList || data.postponedList.length === 0) {
                    postponedGrid.innerHTML = '<div class="empty-hint">لا يوجد مراجعين مؤجلين</div>';
                } else {
                    postponedGrid.innerHTML = data.postponedList.map(p => `
                        <div class="queue-item-pill">
                            <div class="pill-number postponed">${'$'}{p.number}</div>
                            <div class="pill-name">${'$'}{p.name || 'مراجع'}</div>
                        </div>
                    `).join('');
                }

                if (data.customFooter) {
                    document.getElementById('footerText').innerText = data.customFooter;
                }

            } catch (err) {
                console.error("Fetch error:", err);
            }
        }

        // Live Clock
        function updateClock() {
            const now = new Date();
            document.getElementById('liveClock').innerText = now.toLocaleTimeString('ar-SA', { hour12: true });
            document.getElementById('dateText').innerText = now.toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        }

        // Start polling loop
        setInterval(fetchQueueStatus, 750);
        setInterval(updateClock, 1000);
        fetchQueueStatus();
        updateClock();

        // Auto audio resume on any TV remote button or key
        window.addEventListener('keydown', () => {
            if (!isAudioAllowed) enableAudioOnTv();
        });
        window.addEventListener('click', () => {
            if (!isAudioAllowed) enableAudioOnTv();
        });
    </script>
</body>
</html>
        """.trimIndent()
    }
}
