package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import com.example.data.model.PaperSize
import com.example.data.model.UserAccountType
import com.example.ui.components.AppTopBar
import com.example.ui.theme.GreenBorder
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedBorder
import com.example.ui.theme.RedContainer
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

/**
 * شاشة الإعدادات المنظمة بتصميم الأقسام التفاعلية (Accordion / Expandable Sections)
 * - بدون ظهور بيانات العيادة
 * - أقسام منظمة تفتح وتغلق عند الضغط عليها
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeviceSettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    val isPrinterConnected by viewModel.printerManager.isConnected.collectAsState()
    val printerName by viewModel.printerManager.connectedDeviceName.collectAsState()
    val isTestingAudio by viewModel.isTestingAudio.collectAsState()
    val isTvServerRunning by viewModel.isTvServerRunning.collectAsState()
    val tvServerUrl by viewModel.tvServerUrl.collectAsState()
    val isHotspotActive by viewModel.isHotspotActive.collectAsState()
    val hotspotSsid by viewModel.hotspotSsid.collectAsState()
    val hotspotPassword by viewModel.hotspotPassword.collectAsState()
    val hotspotStatusMessage by viewModel.hotspotStatusMessage.collectAsState()
    val isHotspotLoading by viewModel.isHotspotLoading.collectAsState()
    val isTvAudioOnly by viewModel.isTvAudioOnly.collectAsState()
    val authState by viewModel.authState.collectAsState()

    val context = LocalContext.current
    val clipboardManager = remember { context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager }
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    // حالات فتح وإغلاق الأقسام (Expandable State) - جميعها مغلقة افتراضياً
    var isBluetoothSectionOpen by remember { mutableStateOf(false) }
    var isAudioSectionOpen by remember { mutableStateOf(false) }
    var isTvSectionOpen by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Top Bar
        AppTopBar(
            title = "لوحة الإعدادات",
            subtitle = "التحكم في الصوت، الطابعة، وشاشة TV",
            showBackButton = true,
            showMenuButton = false,
            showSettingsButton = false,
            onBackClick = { viewModel.navigateBack() }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            // ==========================================
            // 1. قسم إعدادات التحكم في الصوت والنداء (Audio & Voice Call)
            // ==========================================
            SettingsAccordionCard(
                title = "إعدادات التحكم في الصوت والنداء",
                subtitle = "شدة الصوت، سرعة ونبرة النطق، نغمة التنبيه، وعبارة النداء",
                icon = Icons.Default.Tune,
                isOpen = isAudioSectionOpen,
                onToggle = { isAudioSectionOpen = !isAudioSectionOpen },
                statusBadge = "${(settings.volume * 100).toInt()}% صوت"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // شريط العنوان مع زر استعادة الإعدادات الافتراضية
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "التحكم الصوتي الشامل (الهاتف وشاشة TV)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )

                        // زر استعادة الإعدادات الافتراضية
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF1F5F9))
                                .clickable { viewModel.onResetAudioDefaults() }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "استعادة الافتراضي",
                                tint = TextSecondary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "افتراضي",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 1.1 سرعة نطق الصوت (Speed Rate)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "سرعة نطق الصوت",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                        val speedLabel = when {
                            settings.speechRate <= 0.85f -> "طبيعي وموصى به"
                            settings.speechRate < 1.1f -> "معتدل"
                            else -> "سريع"
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "($speedLabel) ",
                                fontSize = 11.5.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = "${String.format(java.util.Locale.US, "%.2f", settings.speechRate)}x",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                    }
                    Slider(
                        value = settings.speechRate,
                        onValueChange = { viewModel.onSpeechRateChanged(it) },
                        valueRange = 0.5f..1.5f,
                        steps = 9,
                        colors = SliderDefaults.colors(
                            thumbColor = NavyDark,
                            activeTrackColor = NavyDark,
                            inactiveTrackColor = Color(0xFFE2E8F0)
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 1.3 نغمة تنبيه العيادة (Ding-Dong Chime Switch)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF8FAFC))
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "نغمة تنبيه العيادة (Ding-Dong)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyDark
                                )
                                Text(
                                    text = "رنة تنبيه صوتية لطيفة تسبق النداء",
                                    fontSize = 11.5.sp,
                                    color = TextSecondary
                                )
                            }
                            Switch(
                                checked = settings.enableChime,
                                onCheckedChange = { viewModel.onToggleChime(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = NavyDark
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 1.4 صيغة عبارة النداء الصوتي المخصصة
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(17.dp)
                            )
                            Text(
                                text = "صيغة النداء الصوتي المخصصة",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "استخدم {number} ليتم استبداله تلقائياً برقم المراجع بالعربية",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = settings.callPhrase,
                            onValueChange = { viewModel.onCallPhraseChanged(it) },
                            placeholder = {
                                Text(
                                    text = "المراجع رقم {number} ، يرجى التوجه إلى غرفة العيادة",
                                    fontSize = 12.5.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("call_phrase_input"),
                            shape = RoundedCornerShape(10.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = NavyDark
                            )
                        )
                    }
                }
            }

            // ==========================================
            // 2. قسم أجهزة البلوتوث - الطابعة الحرارية وإعدادات الورق
            // ==========================================
            SettingsAccordionCard(
                title = "إعدادات طابعة البلوتوث الحرارية",
                subtitle = "الطابعة المقترنة ومقاس رول الورق المستخدم (${settings.paperSize.label})",
                icon = Icons.Default.Bluetooth,
                isOpen = isBluetoothSectionOpen,
                onToggle = { isBluetoothSectionOpen = !isBluetoothSectionOpen },
                statusBadge = if (isPrinterConnected) "متصل" else "غير متصل"
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // بطاقة الطابعة الحرارية
                    DeviceSubCard(
                        icon = Icons.Default.Print,
                        categoryTag = "طابعة الإيصالات والوصولات",
                        title = "الطابعة الحرارية (Thermal Printer)",
                        deviceName = if (printerName.isNotBlank()) printerName else if (settings.selectedPrinterName.isNotBlank()) settings.selectedPrinterName else "لم يتم تعيين طابعة بعد",
                        deviceAddress = settings.selectedPrinterAddress,
                        isConnected = isPrinterConnected,
                        selectButtonText = "اختيار أو تغيير الطابعة",
                        onSelectClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) },
                        onDisconnectClick = { viewModel.onDisconnectPrinter() }
                    )

                    HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 1.dp)

                    // إعدادات مقاس ورق الطباعة مدمجة داخل إعدادات الطابعة
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(17.dp)
                            )
                            Text(
                                text = "مقاس ورق الطباعة الحرارية",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "اختر المقاس المطابق لطابعتك لضبط هوامش الوصل بدقة:",
                            fontSize = 11.5.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PaperSizeOption(
                                size = PaperSize.WIDTH_58MM,
                                isSelected = settings.paperSize == PaperSize.WIDTH_58MM,
                                onSelect = { viewModel.onPaperSizeChanged(PaperSize.WIDTH_58MM) },
                                modifier = Modifier.weight(1f)
                            )

                            PaperSizeOption(
                                size = PaperSize.WIDTH_80MM,
                                isSelected = settings.paperSize == PaperSize.WIDTH_80MM,
                                onSelect = { viewModel.onPaperSizeChanged(PaperSize.WIDTH_80MM) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // ==========================================
            // 4. قسم بث الشاشة الذكية والتلفزيون (Smart TV Display)
            // ==========================================
            SettingsAccordionCard(
                title = "بث شاشة الانتظار (Smart TV)",
                subtitle = "عرض اسم العيادة ورقم المراجع والصوت على التلفزيون",
                icon = Icons.Default.Tv,
                isOpen = isTvSectionOpen,
                onToggle = { isTvSectionOpen = !isTvSectionOpen },
                statusBadge = if (isTvServerRunning) "مفعّل" else "متوقف"
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // تشغيل / إيقاف الخادم
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isTvServerRunning) Color(0xFFDCFCE7) else Color(0xFFF8FAFC))
                            .border(1.dp, if (isTvServerRunning) Color(0xFF86EFAC) else Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isTvServerRunning) Color(0xFF16A34A) else Color(0xFF94A3B8))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isTvServerRunning) "خادم شاشة التلفزيون نشط" else "تشغيل خادم شاشة التلفزيون",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isTvServerRunning) Color(0xFF166534) else NavyDark
                            )
                        }

                        Switch(
                            checked = isTvServerRunning,
                            onCheckedChange = { viewModel.onToggleTvServer(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF2563EB)
                            )
                        )
                    }

                    // خيار كتم صوت الهاتف وخروج الصوت من التلفزيون فقط
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isTvAudioOnly) Color(0xFFF0FDF4) else Color(0xFFF8FAFC))
                            .border(
                                1.dp,
                                if (isTvAudioOnly) Color(0xFFBBF7D0) else Color(0xFFE2E8F0),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isTvAudioOnly) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = if (isTvAudioOnly) Color(0xFF16A34A) else TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "إخراج الصوت من التلفزيون فقط",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isTvAudioOnly) Color(0xFF166534) else NavyDark
                                )
                                Text(
                                    text = if (isTvAudioOnly) "كتم صوت الهاتف وخروج النداء من TV فقط" else "تشغيل الصوت من الهاتف والتلفزيون معاً",
                                    fontSize = 11.sp,
                                    color = if (isTvAudioOnly) Color(0xFF15803D) else TextMuted
                                )
                            }
                        }

                        Switch(
                            checked = isTvAudioOnly,
                            onCheckedChange = { viewModel.onToggleTvAudioOnly(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF16A34A)
                            )
                        )
                    }

                    // صندوق الرابط
                    if (isTvServerRunning && tvServerUrl.isNotBlank()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0F172A))
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "الرابط المطلوب إدخاله في متصفح التلفزيون:",
                                    fontSize = 11.sp,
                                    color = Color(0xFF94A3B8)
                                )

                                IconButton(
                                    onClick = { viewModel.onRefreshTvIp() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "تحديث العنوان",
                                        tint = Color(0xFF38BDF8),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = tvServerUrl,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF38BDF8)
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // زر النسخ
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF1E293B))
                                            .clickable {
                                                val clip = ClipData.newPlainText("TV Server URL", tvServerUrl)
                                                clipboardManager.setPrimaryClip(clip)
                                            }
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.ContentCopy,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = "نسخ", fontSize = 11.sp, color = Color.White)
                                        }
                                    }

                                    // فتح التجربة
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF2563EB))
                                            .clickable {
                                                try {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(tvServerUrl))
                                                    context.startActivity(intent)
                                                } catch (_: Exception) {}
                                            }
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.OpenInBrowser,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = "معاينة", fontSize = 11.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // بطاقة الإرشادات لعرض شاشة الانتظار
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF8FAFC))
                            .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Tv,
                                contentDescription = null,
                                tint = Color(0xFF2563EB),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "كيفية ربط شاشة التلفزيون (Smart TV):",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }

                        Text(
                            text = "1. تأكد من اتصال شاشة التلفزيون الذكي بنفس شبكة الهاتف.\n2. افتح متصفح شاشة التلفزيون واكتب الرابط الموضح في الأعلى.\n3. ستظهر أرقام واستدعاء المراجعين والصوت تلقائياً ومباشرة على شاشة التلفزيون.",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // ==========================================
            // 5. قسم التقارير والأرشيف العام (حصرياً في الإعدادات)
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(16.dp))
                    .clickable { viewModel.navigateTo(AppScreen.REPORTS) }
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NavyDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assessment,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "سجل التقارير والأرشيف",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyDark
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFFEFF6FF))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "كشف شامل",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2563EB)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "عرض كشف المراجعين السابقين، الجلسات، والطباعة الحرارية",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ==========================================
            // 6. قسم الدعم الفني (Technical Support)
            // ==========================================
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0F766E).copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SupportAgent,
                                contentDescription = null,
                                tint = Color(0xFF0F766E),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "الدعم الفني والمساعدة",
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                            Text(
                                text = "تواصل مع فريق الدعم الفني للاستفسارات والمساعدة",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    // زر واتساب الدعم الفني
                    Button(
                        onClick = {
                            try {
                                val message = "مرحباً، أود الاستفسار حول تطبيق إدارة العيادات والمراجعين"
                                val uri = Uri.parse("https://wa.me/9647810936407?text=${Uri.encode(message)}")
                                val intent = Intent(Intent.ACTION_VIEW, uri)
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                val clip = ClipData.newPlainText("رقم الدعم الفني", "+9647810936407")
                                clipboardManager.setPrimaryClip(clip)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = "واتساب",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "مراسلة الدعم الفني عبر واتساب",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ==========================================
            // 7. قسم الحساب والاشتراك (تسجيل الخروج / حالة الحساب)
            // ==========================================
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (authState.accountType == UserAccountType.FULL) Color(0xFF0F766E).copy(alpha = 0.12f)
                                        else Color(0xFFF59E0B).copy(alpha = 0.12f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (authState.accountType == UserAccountType.FULL) Icons.Default.Star else Icons.Default.AccountCircle,
                                    contentDescription = null,
                                    tint = if (authState.accountType == UserAccountType.FULL) Color(0xFF0F766E) else Color(0xFFD97706),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (authState.accountType == UserAccountType.FULL) "حساب مفعل (النسخة الكاملة)" else "حساب تجريبي",
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (authState.username.isNotBlank()) "المستخدم: ${authState.username}" else "وضع التجربة السريع",
                                    fontSize = 12.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        // زر تسجيل الخروج
                        OutlinedButton(
                            onClick = { viewModel.logout() },
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFF475569)
                            ),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "تسجيل الخروج",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تسجيل الخروج",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Bottom Navigation Bar
        com.example.ui.components.ClinicBottomNavBar(
            activeScreen = AppScreen.DEVICE_SETTINGS,
            onQueueClick = { viewModel.navigateTo(AppScreen.QUEUE_LIST) },
            onAddClick = { viewModel.onAddPatientClicked() },
            onSettingsClick = { /* Already here */ }
        )
    }
}

/**
 * بطاقة إعداد قابلة للطي والفتح (Accordion Section)
 */
@Composable
fun SettingsAccordionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    isOpen: Boolean,
    onToggle: () -> Unit,
    statusBadge: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.90f))
            .border(
                1.dp,
                if (isOpen) Color(0xFF3B82F6) else Color.White.copy(alpha = 0.95f),
                RoundedCornerShape(18.dp)
            )
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header (Clickable row to toggle open/close)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isOpen) {
                                    androidx.compose.ui.graphics.Brush.linearGradient(
                                        listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                                    )
                                } else {
                                    androidx.compose.ui.graphics.Brush.linearGradient(
                                        listOf(Color(0xFFF1F5F9), Color(0xFFE2E8F0))
                                    )
                                }
                            )
                            .border(
                                1.dp,
                                if (isOpen) Color.White.copy(alpha = 0.6f) else Color(0xFFCBD5E1),
                                RoundedCornerShape(14.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (isOpen) Color.White else NavyDark,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = subtitle,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (statusBadge != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFEFF6FF))
                                .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = statusBadge,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1D4ED8)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Icon(
                        imageVector = if (isOpen) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = if (isOpen) "إغلاق" else "فتح",
                        tint = NavyDark,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Animated Collapsible Content
            AnimatedVisibility(
                visible = isOpen,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 18.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFFF1F5F9))
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    content()
                }
            }
        }
    }
}

/**
 * بطاقة إعداد جهاز البلوتوث (طابعة أو سماعة) داخل القسم
 */
@Composable
fun DeviceSubCard(
    icon: ImageVector,
    categoryTag: String,
    title: String,
    deviceName: String,
    deviceAddress: String,
    isConnected: Boolean,
    selectButtonText: String,
    onSelectClick: () -> Unit,
    onDisconnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFF8FAFC))
            .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row: Icon + Title + Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(NavyDark.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = NavyDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = categoryTag,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextMuted
                        )
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                }

                // Status Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (isConnected) GreenContainer else Color(0xFFF1F5F9))
                        .border(
                            1.dp,
                            if (isConnected) GreenBorder else Color(0xFFE2E8F0),
                            CircleShape
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isConnected) GreenSuccess else TextMuted)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isConnected) "متصل" else "غير متصل",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isConnected) GreenText else TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // الجهاز المحدد
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "الجهاز المختار:",
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                        Text(
                            text = deviceName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                    if (deviceAddress.isNotBlank()) {
                        Text(
                            text = deviceAddress,
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // أزرار الاختيار وقطع الاتصال
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // زر الاختيار
                Button(
                    onClick = onSelectClick,
                    modifier = Modifier
                        .weight(1.3f)
                        .height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = selectButtonText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // زر قطع الاتصال
                if (isConnected) {
                    Box(
                        modifier = Modifier
                            .weight(0.9f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(RedContainer)
                            .border(1.dp, RedBorder, RoundedCornerShape(10.dp))
                            .clickable { onDisconnectClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                tint = RedDestructive,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "قطع الاتصال",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = RedDestructive
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PaperSizeOption(
    size: PaperSize,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) NavyDark else Color(0xFFE2E8F0),
                shape = RoundedCornerShape(12.dp)
            )
            .background(if (isSelected) NavyDark.copy(alpha = 0.05f) else Color.White)
            .clickable { onSelect() }
            .padding(vertical = 12.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isSelected) NavyDark else TextMuted,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = size.label,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) NavyDark else TextPrimary
            )
        }
    }
}
