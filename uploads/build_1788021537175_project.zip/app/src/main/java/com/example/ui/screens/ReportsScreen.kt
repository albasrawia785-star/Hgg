package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import com.example.ui.components.ClinicBottomNavBar
import com.example.ui.viewmodel.AppScreen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Patient
import com.example.ui.theme.AmberBorder
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberText
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenDark
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.RedContainer
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.rememberDatePickerState
import java.util.Calendar
import java.util.TimeZone
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ReportFilterTab(val label: String) {
    ALL("كافة المراجعين"),
    SERVED("مكتمل"),
    WAITING("قيد الانتظار"),
    POSTPONED("المؤجلون")
}

data class DateFilterOption(
    val key: String, // "ALL", "TODAY", or "yyyy-MM-dd"
    val chipLabel: String,
    val fullDateDisplay: String,
    val patientCount: Int,
    val isToday: Boolean = false,
    val timestamp: Long = 0L
)

data class SessionOption(
    val sessionId: String,
    val title: String,
    val isLive: Boolean,
    val patientCount: Int,
    val servedCount: Int,
    val waitingCount: Int,
    val postponedCount: Int,
    val timestamp: Long
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val patients by viewModel.allReportsPatients.collectAsState()

    // Date & Time Formats
    val dateFormatIso = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val todayKey = remember { dateFormatIso.format(Date()) }
    val arabicDayMonth = remember { SimpleDateFormat("d MMMM", Locale("ar")) }
    val arabicFullDate = remember { SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")) }
    val shortDateDisplay = remember { SimpleDateFormat("yyyy/MM/dd", Locale("ar")) }

    // All available distinct dates in the archive
    val allDateOptions = remember(patients) {
        val calYesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val yesterdayKey = dateFormatIso.format(calYesterday.time)

        patients.groupBy { dateFormatIso.format(Date(it.timestamp)) }
            .map { (dateStr, datePatients) ->
                val sampleTimestamp = datePatients.maxOf { it.timestamp }
                val chipLabel = when (dateStr) {
                    todayKey -> "اليوم"
                    yesterdayKey -> "أمس"
                    else -> arabicDayMonth.format(Date(sampleTimestamp))
                }
                val fullDate = arabicFullDate.format(Date(sampleTimestamp))
                DateFilterOption(
                    key = dateStr,
                    chipLabel = chipLabel,
                    fullDateDisplay = fullDate,
                    patientCount = datePatients.size,
                    isToday = (dateStr == todayKey),
                    timestamp = sampleTimestamp
                )
            }
            .sortedByDescending { it.timestamp }
    }

    // Filter states
    var selectedDateKey by remember { mutableStateOf("TODAY") } // "TODAY", "ALL", or "yyyy-MM-dd"
    var selectedSessionId by remember { mutableStateOf("ALL") } // "ALL" or specific sessionId
    var selectedTab by remember { mutableStateOf(ReportFilterTab.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var showMenu by remember { mutableStateOf(false) }

    // Dialog States
    var patientToDelete by remember { mutableStateOf<Patient?>(null) }
    var sessionToDelete by remember { mutableStateOf<SessionOption?>(null) }
    var dateToDelete by remember { mutableStateOf<DateFilterOption?>(null) }
    var showDeleteServedDialog by remember { mutableStateOf(false) }
    var showDeletePostponedDialog by remember { mutableStateOf(false) }
    var showClearAllDialog by remember { mutableStateOf(false) }
    var showDatePickerModal by remember { mutableStateOf(false) }
    var showDateListDialog by remember { mutableStateOf(false) }

    val effectiveDateKey = if (selectedDateKey == "TODAY") todayKey else selectedDateKey

    // Filter patients by Date
    val dateFilteredPatients = remember(patients, selectedDateKey, effectiveDateKey) {
        when (selectedDateKey) {
            "ALL" -> patients
            "TODAY" -> patients.filter { dateFormatIso.format(Date(it.timestamp)) == todayKey }
            else -> patients.filter { dateFormatIso.format(Date(it.timestamp)) == selectedDateKey }
        }
    }

    // Sessions available in current date filter
    val availableSessionsInDate = remember(dateFilteredPatients) {
        dateFilteredPatients.groupBy { it.sessionId }
            .map { (sId, sPatients) ->
                val isLive = (sId == "live_session")
                val title = if (isLive) "الجلسة الحالية النشطة (مباشر)" else (sPatients.firstOrNull()?.sessionTitle?.takeIf { it.isNotBlank() } ?: "جلسة سابقة")
                val maxTime = sPatients.maxOfOrNull { it.timestamp } ?: 0L
                SessionOption(
                    sessionId = sId,
                    title = title,
                    isLive = isLive,
                    patientCount = sPatients.size,
                    servedCount = sPatients.count { !it.isPostponed && it.isCalled },
                    waitingCount = sPatients.count { !it.isPostponed && !it.isCalled },
                    postponedCount = sPatients.count { it.isPostponed },
                    timestamp = maxTime
                )
            }
            .sortedByDescending { if (it.isLive) Long.MAX_VALUE else it.timestamp }
    }

    // Filter patients by Session
    val sessionFilteredPatients = remember(dateFilteredPatients, selectedSessionId) {
        if (selectedSessionId == "ALL") {
            dateFilteredPatients
        } else {
            dateFilteredPatients.filter { it.sessionId == selectedSessionId }
        }
    }

    // Display string for the selected date
    val currentSelectedDateDisplay = remember(selectedDateKey, allDateOptions, effectiveDateKey) {
        when (selectedDateKey) {
            "ALL" -> "كافة التواريخ والأرشيف العام"
            "TODAY" -> "اليوم (${arabicFullDate.format(Date())})"
            else -> allDateOptions.find { it.key == selectedDateKey }?.fullDateDisplay ?: selectedDateKey
        }
    }

    // Calculations based on sessionFilteredPatients
    val totalCount = sessionFilteredPatients.size
    val servedCount = sessionFilteredPatients.count { !it.isPostponed && it.isCalled }
    val waitingCount = sessionFilteredPatients.count { !it.isPostponed && !it.isCalled }
    val postponedCount = sessionFilteredPatients.count { it.isPostponed }

    val servedPercent = if (totalCount > 0) (servedCount.toFloat() / totalCount) * 100 else 0f
    val waitingPercent = if (totalCount > 0) (waitingCount.toFloat() / totalCount) * 100 else 0f
    val postponedPercent = if (totalCount > 0) (postponedCount.toFloat() / totalCount) * 100 else 0f

    // Final filtered list based on tab and search
    val filteredList = remember(sessionFilteredPatients, selectedTab, searchQuery) {
        var list = when (selectedTab) {
            ReportFilterTab.ALL -> sessionFilteredPatients
            ReportFilterTab.SERVED -> sessionFilteredPatients.filter { !it.isPostponed && it.isCalled }
            ReportFilterTab.WAITING -> sessionFilteredPatients.filter { !it.isPostponed && !it.isCalled }
            ReportFilterTab.POSTPONED -> sessionFilteredPatients.filter { it.isPostponed }
        }
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.formattedNumber.contains(q) || it.name.lowercase().contains(q) || it.note.lowercase().contains(q)
            }
        }
        list
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Top Header Bar
            ReportsHeader(
                onBack = { viewModel.navigateBack() },
                onPrintReport = {
                    viewModel.onPrintReportSummary(
                        title = "تقرير العيادة",
                        dateText = currentSelectedDateDisplay,
                        totalCount = totalCount,
                        servedCount = servedCount,
                        waitingCount = waitingCount,
                        postponedCount = postponedCount
                    )
                },
                onMenuClick = { showMenu = true }
            )

            // Dropdown Menu for Bulk Actions
            Box(modifier = Modifier.align(Alignment.End)) {
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(Color.White)
                ) {
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Print, contentDescription = null, tint = NavyDark, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("طباعة هذا التقرير (طابعة حرارية)", color = TextPrimary, fontSize = 13.sp)
                            }
                        },
                        onClick = {
                            showMenu = false
                            viewModel.onPrintReportSummary(
                                title = "تقرير العيادة",
                                dateText = currentSelectedDateDisplay,
                                totalCount = totalCount,
                                servedCount = servedCount,
                                waitingCount = waitingCount,
                                postponedCount = postponedCount
                            )
                        }
                    )
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DoneAll, contentDescription = null, tint = GreenDark, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("حذف المراجعين المكتملين (في العرض الحالي)", color = TextPrimary, fontSize = 13.sp)
                            }
                        },
                        onClick = {
                            showMenu = false
                            showDeleteServedDialog = true
                        }
                    )
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PauseCircle, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("حذف المراجعين المؤجلين (في العرض الحالي)", color = TextPrimary, fontSize = 13.sp)
                            }
                        },
                        onClick = {
                            showMenu = false
                            showDeletePostponedDialog = true
                        }
                    )
                    if (selectedDateKey != "ALL") {
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = RedDestructive, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("حذف أرشيف هذا اليوم بالكامل", color = RedDestructive, fontSize = 13.sp)
                                }
                            },
                            onClick = {
                                showMenu = false
                                dateToDelete = allDateOptions.find { it.key == effectiveDateKey }
                                    ?: DateFilterOption(
                                        key = effectiveDateKey,
                                        chipLabel = if (selectedDateKey == "TODAY") "اليوم" else effectiveDateKey,
                                        fullDateDisplay = currentSelectedDateDisplay,
                                        patientCount = dateFilteredPatients.size
                                    )
                            }
                        )
                    }
                    DropdownMenuItem(
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ClearAll, contentDescription = null, tint = RedDestructive, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("مسح كافة السجلات بالكامل (تصفير شامل)", color = RedDestructive, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        onClick = {
                            showMenu = false
                            showClearAllDialog = true
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {

                // 1. Date & Session Filter Card (Enterprise Archive Controller)
                item {
                    DateAndSessionFilterCard(
                        selectedDateKey = selectedDateKey,
                        currentDateDisplay = currentSelectedDateDisplay,
                        dateCount = dateFilteredPatients.size,
                        allDateOptions = allDateOptions,
                        todayCount = patients.count { dateFormatIso.format(Date(it.timestamp)) == todayKey },
                        totalAllCount = patients.size,
                        onSelectDate = { key ->
                            selectedDateKey = key
                            selectedSessionId = "ALL"
                        },
                        onOpenDatePicker = { showDatePickerModal = true },
                        onOpenDateList = { showDateListDialog = true },
                        availableSessions = availableSessionsInDate,
                        selectedSessionId = selectedSessionId,
                        onSelectSession = { sId ->
                            selectedSessionId = sId
                        }
                    )
                }

                // 2. KPI Summary Cards Grid (4 Cards)
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Total Patients
                            KpiMetricCard(
                                title = "إجمالي المسجلين",
                                value = "$totalCount",
                                subtitle = if (selectedDateKey == "TODAY") "مراجع مسجل اليوم" else "مراجع في هذا الأرشيف",
                                icon = Icons.Default.People,
                                color = NavyPrimary,
                                bgColor = Color(0xFFF1F5F9),
                                modifier = Modifier.weight(1f)
                            )
                            // Served Patients
                            KpiMetricCard(
                                title = "مكتمل",
                                value = "$servedCount",
                                subtitle = "${String.format(Locale.US, "%.0f", servedPercent)}% من الإجمالي",
                                icon = Icons.Default.CheckCircle,
                                color = Color(0xFF0D9488),
                                bgColor = Color(0xFFCCFBF1),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Waiting Patients
                            KpiMetricCard(
                                title = "قيد الانتظار",
                                value = "$waitingCount",
                                subtitle = "${String.format(Locale.US, "%.0f", waitingPercent)}% في الصالة",
                                icon = Icons.Default.HourglassTop,
                                color = Color(0xFF2563EB),
                                bgColor = Color(0xFFEFF6FF),
                                modifier = Modifier.weight(1f)
                            )
                            // Postponed Patients
                            KpiMetricCard(
                                title = "المؤجلون",
                                value = "$postponedCount",
                                subtitle = "${String.format(Locale.US, "%.0f", postponedPercent)}% بانتظار العودة",
                                icon = Icons.Default.PauseCircle,
                                color = Color(0xFFD97706),
                                bgColor = Color(0xFFFEF3C7),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // 3. Recharts-style Interactive Visual Charts Card
                item {
                    RechartsStyleAnalyticsCard(
                        totalCount = totalCount,
                        servedCount = servedCount,
                        waitingCount = waitingCount,
                        postponedCount = postponedCount,
                        servedPercent = servedPercent,
                        waitingPercent = waitingPercent,
                        postponedPercent = postponedPercent
                    )
                }

                // 4. Quick Action & Search Bar
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "سجل المراجعين التفصيلي",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )

                            if (totalCount > 0) {
                                Text(
                                    text = "${filteredList.size} من $totalCount مراجع",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        // Search Input
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("بحث برقم المراجع أو الاسم...", fontSize = 12.5.sp, color = TextMuted) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted, modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotBlank()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.ClearAll, contentDescription = "مسح البحث", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedBorderColor = Color(0xFF0D9488),
                                unfocusedBorderColor = Color(0xFFE2E8F0)
                            )
                        )

                        // Filter Tabs
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(ReportFilterTab.values()) { tab ->
                                val isSelected = selectedTab == tab
                                val count = when (tab) {
                                    ReportFilterTab.ALL -> totalCount
                                    ReportFilterTab.SERVED -> servedCount
                                    ReportFilterTab.WAITING -> waitingCount
                                    ReportFilterTab.POSTPONED -> postponedCount
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) NavyDark else Color.White)
                                        .border(1.dp, if (isSelected) NavyDark else Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                                        .clickable { selectedTab = tab }
                                        .padding(horizontal = 14.dp, vertical = 7.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = tab.label,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color.White else TextPrimary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(CircleShape)
                                                .background(if (isSelected) Color.White.copy(alpha = 0.2f) else Color(0xFFF1F5F9))
                                                .padding(horizontal = 6.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "$count",
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color.White else TextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 5. Patients List or Empty State (Grouped by session when multiple sessions exist)
                if (filteredList.isEmpty()) {
                    item {
                        EmptyReportStateCard(
                            totalCount = totalCount,
                            selectedDateKey = selectedDateKey,
                            onResetFilter = {
                                selectedDateKey = "ALL"
                                selectedSessionId = "ALL"
                                selectedTab = ReportFilterTab.ALL
                                searchQuery = ""
                            }
                        )
                    }
                } else if (selectedSessionId == "ALL" && availableSessionsInDate.size > 1 && searchQuery.isBlank()) {
                    // Group patients by session to isolate numbers clearly
                    availableSessionsInDate.forEach { session ->
                        val sessionPatients = filteredList.filter { it.sessionId == session.sessionId }
                        if (sessionPatients.isNotEmpty()) {
                            item(key = "session_header_${session.sessionId}") {
                                SessionGroupHeaderCard(
                                    session = session,
                                    onDeleteSession = { sessionToDelete = session }
                                )
                            }
                            items(sessionPatients, key = { "${it.sessionId}_${it.id}_${it.timestamp}" }) { patient ->
                                ReportPatientItem(
                                    patient = patient,
                                    showSessionBadge = false,
                                    showDateBadge = (selectedDateKey == "ALL"),
                                    onDelete = { patientToDelete = patient }
                                )
                            }
                        }
                    }
                } else {
                    items(filteredList, key = { "${it.sessionId}_${it.id}_${it.timestamp}" }) { patient ->
                        ReportPatientItem(
                            patient = patient,
                            showSessionBadge = (availableSessionsInDate.size > 1 || selectedDateKey == "ALL"),
                            showDateBadge = (selectedDateKey == "ALL"),
                            onDelete = { patientToDelete = patient }
                        )
                    }
                }
            }

            // شريط التنقل السفلي: قائمة المراجعين + زر الإضافة (+) + الإعدادات
            ClinicBottomNavBar(
                activeScreen = AppScreen.REPORTS,
                onQueueClick = { viewModel.navigateTo(AppScreen.QUEUE_LIST) },
                onAddClick = { viewModel.onAddPatientClicked() },
                onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
            )
        }
    }

    // ==========================================
    // CONFIRMATION & FILTER DIALOGS
    // ==========================================

    // 1. Single Patient Deletion Dialog
    patientToDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientToDelete = null },
            icon = {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = RedDestructive, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "حذف المراجع من التقرير",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف المراجع رقم (${patient.formattedNumber})${if (patient.name.isNotBlank()) " - ${patient.name}" else ""} نهائياً من سجلات العيادة؟",
                    fontSize = 13.5.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeletePatient(patient)
                        patientToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("نعم، حذف المراجع", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { patientToDelete = null },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White
        )
    }

    // 2. Delete Served Patients Dialog (Scoped to current date / session)
    if (showDeleteServedDialog) {
        val scopeText = when {
            selectedSessionId != "ALL" -> "في هذه الجلسة المحددة"
            selectedDateKey == "TODAY" -> "ليوم اليوم"
            selectedDateKey == "ALL" -> "في كافة الأرشيف"
            else -> "لتاريخ $currentSelectedDateDisplay"
        }
        AlertDialog(
            onDismissRequest = { showDeleteServedDialog = false },
            icon = {
                Icon(Icons.Default.DoneAll, contentDescription = null, tint = GreenDark, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "حذف المراجعين المكتملين",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "سيتم حذف المراجعين المكتملين ($servedCount مراجع) $scopeText. هل ترغب في المتابعة؟",
                    fontSize = 13.5.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeleteServedPatients(
                            dateKey = if (selectedDateKey == "ALL") null else effectiveDateKey,
                            sessionId = if (selectedSessionId == "ALL") null else selectedSessionId
                        )
                        showDeleteServedDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("تأكيد الحذف", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteServedDialog = false },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White
        )
    }

    // 3. Delete Postponed Patients Dialog (Scoped to current date / session)
    if (showDeletePostponedDialog) {
        val scopeText = when {
            selectedSessionId != "ALL" -> "في هذه الجلسة المحددة"
            selectedDateKey == "TODAY" -> "ليوم اليوم"
            selectedDateKey == "ALL" -> "في كافة الأرشيف"
            else -> "لتاريخ $currentSelectedDateDisplay"
        }
        AlertDialog(
            onDismissRequest = { showDeletePostponedDialog = false },
            icon = {
                Icon(Icons.Default.PauseCircle, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "حذف المراجعين المؤجلين",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "سيتم حذف المراجعين المؤجلين ($postponedCount مراجع) $scopeText. هل أنت متأكد؟",
                    fontSize = 13.5.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeletePostponedPatients(
                            dateKey = if (selectedDateKey == "ALL") null else effectiveDateKey,
                            sessionId = if (selectedSessionId == "ALL") null else selectedSessionId
                        )
                        showDeletePostponedDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberWarning),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("نعم، حذف المؤجلين", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeletePostponedDialog = false },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White
        )
    }

    // 4. Session Deletion Dialog
    sessionToDelete?.let { session ->
        AlertDialog(
            onDismissRequest = { sessionToDelete = null },
            icon = {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = RedDestructive, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "حذف بيانات الجلسة بالكامل",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف ${session.title} بما تحتويه من (${session.patientCount} مراجع) نهائياً من الأرشيف؟",
                    fontSize = 13.5.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeleteSession(session.sessionId, session.title)
                        if (selectedSessionId == session.sessionId) {
                            selectedSessionId = "ALL"
                        }
                        sessionToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("نعم، حذف الجلسة", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { sessionToDelete = null },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White
        )
    }

    // 5. Date Deletion Dialog
    dateToDelete?.let { dateOpt ->
        AlertDialog(
            onDismissRequest = { dateToDelete = null },
            icon = {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = RedDestructive, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "حذف أرشيف اليوم بالكامل",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف كافة سجلات ${dateOpt.fullDateDisplay} (${dateOpt.patientCount} مراجع) نهائياً من قاعدة البيانات؟",
                    fontSize = 13.5.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeleteByDate(dateOpt.key, dateOpt.chipLabel)
                        selectedDateKey = "TODAY"
                        selectedSessionId = "ALL"
                        dateToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("نعم، حذف أرشيف اليوم", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { dateToDelete = null },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White
        )
    }

    // 6. Clear All Records Dialog
    if (showClearAllDialog) {
        AlertDialog(
            onDismissRequest = { showClearAllDialog = false },
            icon = {
                Icon(Icons.Default.ClearAll, contentDescription = null, tint = RedDestructive, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "مسح كافة السجلات والتقارير",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = RedDestructive,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "تحذير: سيؤدي هذا الإجراء إلى حذف جميع المراجعين في الأرشيف (${patients.size} مراجع) وتصفير قائمة الدور بالكامل. لا يمكن التراجع عن هذا الإجراء.",
                    fontSize = 13.5.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onClearAllReports()
                        showClearAllDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("مسح الكل نهائياً", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showClearAllDialog = false },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White
        )
    }

    // 7. Material 3 Calendar Date Picker Dialog
    if (showDatePickerModal) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = System.currentTimeMillis()
        )
        DatePickerDialog(
            onDismissRequest = { showDatePickerModal = false },
            confirmButton = {
                Button(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                                timeInMillis = millis
                            }
                            val chosenIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                                timeZone = TimeZone.getTimeZone("UTC")
                            }.format(cal.time)
                            selectedDateKey = chosenIso
                            selectedSessionId = "ALL"
                        }
                        showDatePickerModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyDark),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("تطبيق التاريخ", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDatePickerModal = false },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // 8. Date List Quick Selection Dialog
    if (showDateListDialog) {
        AlertDialog(
            onDismissRequest = { showDateListDialog = false },
            icon = {
                Icon(Icons.Default.DateRange, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(32.dp))
            },
            title = {
                Text(
                    text = "اختيار تاريخ التقرير من الأرشيف",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "التواريخ المسجلة في قاعدة البيانات:",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    // Option: Today
                    DateSelectionItemRow(
                        title = "اليوم",
                        subtitle = arabicFullDate.format(Date()),
                        count = patients.count { dateFormatIso.format(Date(it.timestamp)) == todayKey },
                        isSelected = (selectedDateKey == "TODAY" || selectedDateKey == todayKey),
                        onClick = {
                            selectedDateKey = "TODAY"
                            selectedSessionId = "ALL"
                            showDateListDialog = false
                        }
                    )
                    // Option: All Archive
                    DateSelectionItemRow(
                        title = "كافة الأرشيف",
                        subtitle = "عرض جميع التواريخ والجلسات",
                        count = patients.size,
                        isSelected = (selectedDateKey == "ALL"),
                        onClick = {
                            selectedDateKey = "ALL"
                            selectedSessionId = "ALL"
                            showDateListDialog = false
                        }
                    )
                    // Past dates
                    allDateOptions.filter { !it.isToday }.forEach { opt ->
                        DateSelectionItemRow(
                            title = opt.chipLabel,
                            subtitle = opt.fullDateDisplay,
                            count = opt.patientCount,
                            isSelected = (selectedDateKey == opt.key),
                            onClick = {
                                selectedDateKey = opt.key
                                selectedSessionId = "ALL"
                                showDateListDialog = false
                            }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDateListDialog = false
                        showDatePickerModal = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("فتح التقويم الكامل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDateListDialog = false },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إغلاق", color = TextSecondary)
                }
            },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White
        )
    }
}

/**
 * Top Header for Reports
 */
@Composable
private fun ReportsHeader(
    onBack: () -> Unit,
    onPrintReport: () -> Unit,
    onMenuClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = NavyDark
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "التقارير والإحصائيات",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                    Text(
                        text = "مخططات بيانية وإدارة مراجعي العيادة",
                        fontSize = 11.5.sp,
                        color = TextSecondary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPrintReport) {
                    Icon(
                        imageVector = Icons.Default.Print,
                        contentDescription = "طباعة التقرير",
                        tint = NavyDark
                    )
                }
                IconButton(onClick = onMenuClick) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "خيارات إضافية",
                        tint = NavyDark
                    )
                }
            }
        }
    }
}

/**
 * Single KPI Metric Card
 */
@Composable
private fun KpiMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(bgColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )

            Text(
                text = subtitle,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Modern Recharts-Style Interactive Analytics Card
 * Featuring a Donut Chart and Bar Breakdown
 */
@Composable
private fun RechartsStyleAnalyticsCard(
    totalCount: Int,
    servedCount: Int,
    waitingCount: Int,
    postponedCount: Int,
    servedPercent: Float,
    waitingPercent: Float,
    postponedPercent: Float
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Card Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "مخطط التوزيع البياني (Recharts Visualizer)",
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                    Text(
                        text = "نسب الإنجاز وتوزيع حالات المراجعين",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFF0FDF4))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "إنجاز ${String.format(Locale.US, "%.0f", servedPercent)}%",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Donut Chart & Details Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Donut Chart with Center Text
                Box(
                    modifier = Modifier.size(130.dp),
                    contentAlignment = Alignment.Center
                ) {
                    DonutChartCanvas(
                        servedPercent = servedPercent,
                        waitingPercent = waitingPercent,
                        postponedPercent = postponedPercent,
                        totalCount = totalCount
                    )

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "$totalCount",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NavyDark
                        )
                        Text(
                            text = "إجمالي",
                            fontSize = 10.5.sp,
                            color = TextSecondary
                        )
                    }
                }

                // Legend and Percentages
                Column(
                    modifier = Modifier.padding(start = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LegendItem(
                        label = "مكتمل",
                        count = servedCount,
                        percent = servedPercent,
                        color = Color(0xFF0D9488)
                    )
                    LegendItem(
                        label = "قيد الانتظار",
                        count = waitingCount,
                        percent = waitingPercent,
                        color = Color(0xFF2563EB)
                    )
                    LegendItem(
                        label = "المؤجلون",
                        count = postponedCount,
                        percent = postponedPercent,
                        color = Color(0xFFD97706)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Recharts-Style Horizontal Multi-Bar
            Text(
                text = "مقارنة الحالات البيانية",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
            )
            Spacer(modifier = Modifier.height(8.dp))

            RechartsBarProgress(
                label = "مكتمل",
                value = servedCount,
                percent = servedPercent,
                barColor = Color(0xFF0D9488),
                trackColor = Color(0xFFCCFBF1)
            )
            Spacer(modifier = Modifier.height(6.dp))
            RechartsBarProgress(
                label = "قيد الانتظار",
                value = waitingCount,
                percent = waitingPercent,
                barColor = Color(0xFF2563EB),
                trackColor = Color(0xFFEFF6FF)
            )
            Spacer(modifier = Modifier.height(6.dp))
            RechartsBarProgress(
                label = "المؤجلون",
                value = postponedCount,
                percent = postponedPercent,
                barColor = Color(0xFFD97706),
                trackColor = Color(0xFFFEF3C7)
            )
        }
    }
}

/**
 * Donut Chart Canvas with smooth animated stroke arcs
 */
@Composable
private fun DonutChartCanvas(
    servedPercent: Float,
    waitingPercent: Float,
    postponedPercent: Float,
    totalCount: Int
) {
    val animatedServed by animateFloatAsState(
        targetValue = servedPercent,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "served_arc"
    )
    val animatedWaiting by animateFloatAsState(
        targetValue = waitingPercent,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "waiting_arc"
    )
    val animatedPostponed by animateFloatAsState(
        targetValue = postponedPercent,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "postponed_arc"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 14.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
        val arcSize = Size(diameter, diameter)

        if (totalCount == 0) {
            // Empty placeholder ring
            drawArc(
                color = Color(0xFFE2E8F0),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            return@Canvas
        }

        var startAngle = -90f

        // 1. Served (Teal/Green)
        val servedSweep = (animatedServed / 100f) * 360f
        if (servedSweep > 0) {
            drawArc(
                color = Color(0xFF0D9488),
                startAngle = startAngle,
                sweepAngle = servedSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
            )
            startAngle += servedSweep
        }

        // 2. Waiting (Blue)
        val waitingSweep = (animatedWaiting / 100f) * 360f
        if (waitingSweep > 0) {
            drawArc(
                color = Color(0xFF2563EB),
                startAngle = startAngle,
                sweepAngle = waitingSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
            )
            startAngle += waitingSweep
        }

        // 3. Postponed (Amber)
        val postponedSweep = (animatedPostponed / 100f) * 360f
        if (postponedSweep > 0) {
            drawArc(
                color = Color(0xFFD97706),
                startAngle = startAngle,
                sweepAngle = postponedSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
            )
        }
    }
}

@Composable
private fun LegendItem(
    label: String,
    count: Int,
    percent: Float,
    color: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "($count) ${String.format(Locale.US, "%.0f", percent)}%",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
        )
    }
}

/**
 * Recharts-style horizontal comparison bar
 */
@Composable
private fun RechartsBarProgress(
    label: String,
    value: Int,
    percent: Float,
    barColor: Color,
    trackColor: Color
) {
    val animatedPercent by animateFloatAsState(
        targetValue = if (percent > 0) percent / 100f else 0f,
        animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
        label = "bar_progress"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 11.5.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
            Text(
                text = "$value مراجع (${String.format(Locale.US, "%.0f", percent)}%)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = barColor
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(trackColor)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedPercent.coerceIn(0f, 1f))
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(barColor)
            )
        }
    }
}

/**
 * Single Patient Row in the Reports Table with Delete Button & Session/Date badges
 */
@Composable
private fun ReportPatientItem(
    patient: Patient,
    showSessionBadge: Boolean = false,
    showDateBadge: Boolean = false,
    onDelete: () -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale("ar")) }
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd", Locale.US) }
    val formattedTime = remember(patient.timestamp) {
        timeFormat.format(Date(patient.timestamp))
    }
    val formattedDate = remember(patient.timestamp) {
        dateFormat.format(Date(patient.timestamp))
    }

    val statusTitle = when {
        patient.isPostponed -> "مؤجل"
        patient.isCalled -> "مكتمل"
        else -> "قيد الانتظار"
    }

    val statusBg = when {
        patient.isPostponed -> AmberContainer
        patient.isCalled -> Color(0xFFCCFBF1)
        else -> Color(0xFFEFF6FF)
    }

    val statusText = when {
        patient.isPostponed -> AmberText
        patient.isCalled -> Color(0xFF0F766E)
        else -> Color(0xFF1D4ED8)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("report_patient_${patient.queueNumber}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left details: Queue Number + Info
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Number Box
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NavyDark),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = patient.formattedNumber,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (patient.name.isNotBlank()) patient.name else "المراجع #${patient.formattedNumber}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        // Status Chip
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusBg)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = statusTitle,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusText
                            )
                        }

                        // Session Badge if multiple sessions or archive
                        if (showSessionBadge && patient.sessionTitle.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF1F5F9))
                                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
                            ) {
                                Text(
                                    text = patient.sessionTitle,
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (showDateBadge) {
                            Text(
                                text = formattedDate,
                                fontSize = 11.sp,
                                color = NavyPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(text = "•", fontSize = 11.sp, color = TextMuted)
                        }

                        Text(
                            text = "وقت التسجيل: $formattedTime",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        if (patient.note.isNotBlank()) {
                            Text(text = "•", fontSize = 11.sp, color = TextMuted)
                            Text(
                                text = patient.note,
                                fontSize = 11.sp,
                                color = TextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Right: Single Delete Action Button
            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFEF2F2))
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "حذف المراجع",
                    tint = RedDestructive,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/**
 * Enterprise Date & Session Filter Card
 * Provides quick chips for Today, Yesterday, past dates, Full Calendar, and Session segregation.
 */
@Composable
private fun DateAndSessionFilterCard(
    selectedDateKey: String,
    currentDateDisplay: String,
    dateCount: Int,
    allDateOptions: List<DateFilterOption>,
    todayCount: Int,
    totalAllCount: Int,
    onSelectDate: (String) -> Unit,
    onOpenDatePicker: () -> Unit,
    onOpenDateList: () -> Unit,
    availableSessions: List<SessionOption>,
    selectedSessionId: String,
    onSelectSession: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Title & Selected Date Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFEFF6FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = Color(0xFF2563EB),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "تصفية الأرشيف حسب التاريخ",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Text(
                            text = currentDateDisplay,
                            fontSize = 11.5.sp,
                            color = Color(0xFF0D9488),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Calendar Picker Action Button
                OutlinedButton(
                    onClick = onOpenDateList,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Icon(
                        imageVector = Icons.Default.DateRange,
                        contentDescription = null,
                        tint = NavyPrimary,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "التواريخ",
                        fontSize = 11.5.sp,
                        color = NavyPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Date Selection Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 1. Today Chip
                item {
                    DateFilterChip(
                        label = "اليوم",
                        count = todayCount,
                        isSelected = (selectedDateKey == "TODAY"),
                        onClick = { onSelectDate("TODAY") }
                    )
                }

                // 2. Past distinct dates (e.g. yesterday, earlier days)
                val pastDates = allDateOptions.filter { !it.isToday }.take(4)
                items(pastDates) { opt ->
                    DateFilterChip(
                        label = opt.chipLabel,
                        count = opt.patientCount,
                        isSelected = (selectedDateKey == opt.key),
                        onClick = { onSelectDate(opt.key) }
                    )
                }

                // 3. All Records Chip
                item {
                    DateFilterChip(
                        label = "كافة الأرشيف",
                        count = totalAllCount,
                        isSelected = (selectedDateKey == "ALL"),
                        onClick = { onSelectDate("ALL") }
                    )
                }

                // 4. Custom Calendar Date Picker Chip
                item {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF8FAFC))
                            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                            .clickable { onOpenDatePicker() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = Color(0xFF0D9488),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "تقويم...",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // If there are multiple sessions in this date, show session switcher
            if (availableSessions.size > 1) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0xFFF1F5F9))
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "جلسات العمل المسجلة في هذا التاريخ:",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )

                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // All Sessions
                        item {
                            SessionFilterChip(
                                label = "كافة الجلسات (${availableSessions.sumOf { it.patientCount }})",
                                isSelected = (selectedSessionId == "ALL"),
                                isLive = false,
                                onClick = { onSelectSession("ALL") }
                            )
                        }

                        items(availableSessions) { session ->
                            SessionFilterChip(
                                label = "${session.title} (${session.patientCount})",
                                isSelected = (selectedSessionId == session.sessionId),
                                isLive = session.isLive,
                                onClick = { onSelectSession(session.sessionId) }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Filter Chip for Date Selection
 */
@Composable
private fun DateFilterChip(
    label: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) NavyDark else Color(0xFFF8FAFC))
            .border(1.dp, if (isSelected) NavyDark else Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 11.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = label,
                fontSize = 11.5.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else TextPrimary
            )
            Spacer(modifier = Modifier.width(5.dp))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (isSelected) Color.White.copy(alpha = 0.2f) else Color(0xFFE2E8F0))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "$count",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else TextSecondary
                )
            }
        }
    }
}

/**
 * Filter Chip for Session Selection
 */
@Composable
private fun SessionFilterChip(
    label: String,
    isSelected: Boolean,
    isLive: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) Color(0xFF0D9488) else Color(0xFFF1F5F9))
            .border(1.dp, if (isSelected) Color(0xFF0D9488) else Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isLive) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) Color.White else Color(0xFF10B981))
                )
                Spacer(modifier = Modifier.width(5.dp))
            }
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else TextPrimary
            )
        }
    }
}

/**
 * Section Header for grouped sessions in report
 */
@Composable
private fun SessionGroupHeaderCard(
    session: SessionOption,
    onDeleteSession: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = if (session.isLive) Icons.Default.CheckCircle else Icons.Default.DateRange,
                    contentDescription = null,
                    tint = if (session.isLive) Color(0xFF10B981) else NavyPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = session.title,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.White)
                        .padding(horizontal = 6.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "${session.patientCount} مراجع",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                }
            }

            IconButton(
                onClick = onDeleteSession,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "حذف الجلسة",
                    tint = RedDestructive,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Item row in Date list selection dialog
 */
@Composable
private fun DateSelectionItemRow(
    title: String,
    subtitle: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFEFF6FF) else Color(0xFFF8FAFC)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) Color(0xFF2563EB) else Color(0xFFE2E8F0)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color(0xFF2563EB) else TextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) Color(0xFF2563EB) else Color(0xFFE2E8F0))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "$count مراجع",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else TextSecondary
                )
            }
        }
    }
}

/**
 * Empty state card for filtered report
 */
@Composable
private fun EmptyReportStateCard(
    totalCount: Int,
    selectedDateKey: String,
    onResetFilter: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF1F5F9)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(30.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = if (totalCount == 0) "لا توجد سجلات مراجعين في هذا التاريخ المحدد" else "لا توجد نتائج مطابقة لشروط البحث أو التصفية",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (totalCount == 0) "يمكنك التبديل إلى تاريخ آخر أو عرض كافة الأرشيف للاطلاع على السجلات السابقة" else "جرّب اختيار تبويب آخر، أو مسح كلمة البحث، أو تغيير التاريخ المحدد",
                fontSize = 12.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedButton(
                onClick = onResetFilter,
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.ClearAll, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("عرض كافة الأرشيف وتصفير الفلاتر", fontSize = 12.sp)
            }
        }
    }
}

