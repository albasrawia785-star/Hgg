package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hotspot.HotspotManager
import com.example.model.ConnectedDevice
import com.example.model.HostedVideo
import com.example.model.HotspotInfo
import com.example.model.HotspotStatus
import com.example.model.ServerLog
import com.example.server.LocalHttpServer
import com.example.service.HotspotPortalService
import com.example.util.VideoAssetHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class HotspotViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context = application.applicationContext

    private val _hotspotStatus = MutableStateFlow(HotspotStatus.STOPPED)
    val hotspotStatus: StateFlow<HotspotStatus> = _hotspotStatus.asStateFlow()

    private val _hotspotInfo = MutableStateFlow(
        HotspotInfo(
            ssid = "VideoPortal_Open",
            ipAddress = "192.168.49.1",
            port = 8080,
            isSecurityOpen = true
        )
    )
    val hotspotInfo: StateFlow<HotspotInfo> = _hotspotInfo.asStateFlow()

    private val _hostedVideo = MutableStateFlow(HostedVideo())
    val hostedVideo: StateFlow<HostedVideo> = _hostedVideo.asStateFlow()

    private val _connectedDevices = MutableStateFlow<List<ConnectedDevice>>(emptyList())
    val connectedDevices: StateFlow<List<ConnectedDevice>> = _connectedDevices.asStateFlow()

    private val _serverLogs = MutableStateFlow<List<ServerLog>>(emptyList())
    val serverLogs: StateFlow<List<ServerLog>> = _serverLogs.asStateFlow()

    private val _customSsid = MutableStateFlow("VideoPortal_Open")
    val customSsid: StateFlow<String> = _customSsid.asStateFlow()

    private val hotspotManager: HotspotManager
    private var httpServer: LocalHttpServer? = null
    private var devicePollingJob: Job? = null

    init {
        // Prepare default sample video if needed
        val defaultVideo = VideoAssetHelper.ensureDefaultSampleVideo(context)
        _hostedVideo.value = defaultVideo

        hotspotManager = HotspotManager(context) { status, info ->
            _hotspotStatus.value = status
            _hotspotInfo.value = info
            if (status == HotspotStatus.ACTIVE) {
                startHttpServer(info.port)
                startDevicePolling()
                HotspotPortalService.startService(context, info.ssid, info.serverUrl)
            } else if (status == HotspotStatus.STOPPED || status == HotspotStatus.ERROR) {
                stopHttpServer()
                stopDevicePolling()
                HotspotPortalService.stopService(context)
            }
        }
    }

    fun setCustomSsid(ssid: String) {
        _customSsid.value = ssid
        _hotspotInfo.update { it.copy(ssid = ssid) }
    }

    fun onVideoSelected(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val savedVideo = VideoAssetHelper.saveVideoFromUri(context, uri)
                _hostedVideo.value = savedVideo
                addLog(
                    ServerLog(
                        clientIp = "127.0.0.1",
                        requestPath = "تم تحميل فيديو جديد: ${savedVideo.fileName} (${savedVideo.fileSizeFormatted})",
                        statusCode = 200
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun startHotspotAndServer() {
        val ssid = _customSsid.value.ifBlank { "VideoPortal_Open" }
        hotspotManager.startHotspot(ssid)
    }

    fun stopHotspotAndServer() {
        hotspotManager.stopHotspot()
        stopHttpServer()
        stopDevicePolling()
    }

    fun startHttpServerOnlyWithTethering() {
        val ssid = _customSsid.value.ifBlank { "VideoPortal_Open" }
        hotspotManager.updateToSystemTethering(ssid)
    }

    fun openTetheringSettings(activityContext: Context) {
        hotspotManager.openSystemTetheringSettings(activityContext)
    }

    private fun startHttpServer(port: Int) {
        stopHttpServer()
        try {
            httpServer = LocalHttpServer(
                port = port,
                videoFileProvider = { VideoAssetHelper.getHostedVideoFile(context) },
                videoMetaProvider = { _hostedVideo.value },
                onLog = { log -> addLog(log) }
            ).apply {
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopHttpServer() {
        httpServer?.stop()
        httpServer = null
    }

    private fun startDevicePolling() {
        devicePollingJob?.cancel()
        devicePollingJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                val devices = hotspotManager.scanConnectedDevices()
                _connectedDevices.value = devices
                delay(4000)
            }
        }
    }

    private fun stopDevicePolling() {
        devicePollingJob?.cancel()
        devicePollingJob = null
        _connectedDevices.value = emptyList()
    }

    fun refreshDevices() {
        viewModelScope.launch(Dispatchers.IO) {
            val devices = hotspotManager.scanConnectedDevices()
            _connectedDevices.value = devices
        }
    }

    private fun addLog(log: ServerLog) {
        _serverLogs.update { current ->
            // Keep last 30 logs for smooth UI performance
            (listOf(log) + current).take(30)
        }
    }

    fun clearLogs() {
        _serverLogs.value = emptyList()
    }

    override fun onCleared() {
        super.onCleared()
        stopHotspotAndServer()
    }
}
