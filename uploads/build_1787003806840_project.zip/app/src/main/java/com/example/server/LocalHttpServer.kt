package com.example.server

import com.example.model.HostedVideo
import com.example.model.ServerLog
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class LocalHttpServer(
    private val port: Int = 8080,
    private val videoFileProvider: () -> File,
    private val videoMetaProvider: () -> HostedVideo,
    private val onLog: (ServerLog) -> Unit
) {

    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val threadPool = Executors.newCachedThreadPool()

    fun start() {
        if (isRunning.get()) return
        try {
            serverSocket = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(port))
            }
            isRunning.set(true)
            threadPool.execute {
                listen()
            }
            onLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "SERVER_START",
                    statusCode = 200,
                    isVideoChunk = false
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            isRunning.set(false)
            onLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "ERROR: ${e.message}",
                    statusCode = 500,
                    isVideoChunk = false
                )
            )
            throw e
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        serverSocket = null
    }

    fun isServerRunning(): Boolean = isRunning.get()

    private fun listen() {
        while (isRunning.get()) {
            try {
                val socket = serverSocket?.accept() ?: break
                threadPool.execute {
                    handleClient(socket)
                }
            } catch (e: SocketException) {
                // Server socket closed
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun handleClient(socket: Socket) {
        val clientIp = socket.inetAddress?.hostAddress ?: "unknown"
        try {
            socket.soTimeout = 15000
            val inputStream = socket.getInputStream()
            val outputStream = socket.getOutputStream()
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))

            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return

            val method = parts[0]
            val rawPath = parts[1]
            val path = rawPath.substringBefore("?")

            // Parse Headers
            val headers = mutableMapOf<String, String>()
            var line: String? = reader.readLine()
            while (!line.isNullOrEmpty()) {
                val colonIdx = line.indexOf(':')
                if (colonIdx != -1) {
                    val key = line.substring(0, colonIdx).trim().lowercase()
                    val value = line.substring(colonIdx + 1).trim()
                    headers[key] = value
                }
                line = reader.readLine()
            }

            when {
                // Video Streaming Endpoint
                path == "/video.mp4" || path == "/stream" -> {
                    handleVideoStream(socket, outputStream, clientIp, path, headers)
                }

                // Captive Portal Probe Interceptions (Google, Apple, Microsoft, Firefox)
                isCaptivePortalProbe(path) -> {
                    handleCaptivePortal(outputStream, clientIp, path)
                }

                // Favicon & Assets
                path == "/favicon.ico" -> {
                    send404(outputStream, clientIp, path)
                }

                // Default Home / Portal Landing Page
                else -> {
                    servePortalHtml(outputStream, clientIp, path)
                }
            }
        } catch (e: Exception) {
            // Client disconnect or socket reset during streaming is normal
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {}
        }
    }

    private fun isCaptivePortalProbe(path: String): Boolean {
        val p = path.lowercase()
        return p.contains("generate_204") ||
                p.contains("gen_204") ||
                p.contains("hotspot-detect.html") ||
                p.contains("library/test/success.html") ||
                p.contains("ncsi.txt") ||
                p.contains("connecttest.txt") ||
                p.contains("canonical.html") ||
                p.contains("success.txt") ||
                p.contains("redirect")
    }

    private fun handleCaptivePortal(output: OutputStream, clientIp: String, path: String) {
        // Return 200 with HTML portal or 302 redirect so OS triggers captive browser
        onLog(ServerLog(clientIp = clientIp, requestPath = "CAPTIVE_PROBE: $path", statusCode = 200))
        val html = generatePortalHtml()
        val bytes = html.toByteArray(Charsets.UTF_8)
        val response = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                "Pragma: no-cache\r\n" +
                "Expires: 0\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun servePortalHtml(output: OutputStream, clientIp: String, path: String) {
        val html = generatePortalHtml()
        val bytes = html.toByteArray(Charsets.UTF_8)
        val response = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
        onLog(ServerLog(clientIp = clientIp, requestPath = path, statusCode = 200))
    }

    private fun handleVideoStream(
        socket: Socket,
        output: OutputStream,
        clientIp: String,
        path: String,
        headers: Map<String, String>
    ) {
        val videoFile = videoFileProvider()
        if (!videoFile.exists() || videoFile.length() == 0L) {
            send404(output, clientIp, path)
            return
        }

        val totalLength = videoFile.length()
        val rangeHeader = headers["range"]

        var start: Long = 0
        var end: Long = totalLength - 1

        val isRange = if (!rangeHeader.isNullOrEmpty() && rangeHeader.startsWith("bytes=")) {
            val ranges = rangeHeader.substring(6).split("-")
            try {
                if (ranges[0].isNotEmpty()) {
                    start = ranges[0].toLong()
                }
                if (ranges.size > 1 && ranges[1].isNotEmpty()) {
                    end = ranges[1].toLong()
                }
                true
            } catch (e: Exception) {
                false
            }
        } else {
            false
        }

        if (end >= totalLength) end = totalLength - 1
        if (start > end) {
            val res = "HTTP/1.1 416 Range Not Satisfiable\r\n" +
                    "Content-Range: bytes */$totalLength\r\n\r\n"
            output.write(res.toByteArray(Charsets.UTF_8))
            output.flush()
            return
        }

        val contentLength = end - start + 1
        val statusLine = if (isRange) "HTTP/1.1 206 Partial Content" else "HTTP/1.1 200 OK"
        val responseHeaders = StringBuilder().apply {
            append("$statusLine\r\n")
            append("Content-Type: video/mp4\r\n")
            append("Accept-Ranges: bytes\r\n")
            append("Content-Length: $contentLength\r\n")
            if (isRange) {
                append("Content-Range: bytes $start-$end/$totalLength\r\n")
            }
            append("Cache-Control: no-cache\r\n")
            append("Connection: keep-alive\r\n\r\n")
        }

        output.write(responseHeaders.toString().toByteArray(Charsets.UTF_8))
        output.flush()

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "$path [Range: $start-$end]",
                statusCode = if (isRange) 206 else 200,
                isVideoChunk = true
            )
        )

        // Stream byte chunk with RandomAccessFile
        RandomAccessFile(videoFile, "r").use { raf ->
            raf.seek(start)
            val buffer = ByteArray(64 * 1024)
            var bytesToRead = contentLength
            while (bytesToRead > 0 && isRunning.get()) {
                val readSize = Math.min(buffer.size.toLong(), bytesToRead).toInt()
                val bytesRead = raf.read(buffer, 0, readSize)
                if (bytesRead == -1) break
                output.write(buffer, 0, bytesRead)
                bytesToRead -= bytesRead
            }
            output.flush()
        }
    }

    private fun send404(output: OutputStream, clientIp: String, path: String) {
        val body = "404 Not Found"
        val res = "HTTP/1.1 404 Not Found\r\n" +
                "Content-Type: text/plain\r\n" +
                "Content-Length: ${body.length}\r\n" +
                "Connection: close\r\n\r\n$body"
        output.write(res.toByteArray(Charsets.UTF_8))
        output.flush()
        onLog(ServerLog(clientIp = clientIp, requestPath = path, statusCode = 404))
    }

    private fun generatePortalHtml(): String {
        val videoMeta = videoMetaProvider()
        val title = videoMeta.fileName
        val size = videoMeta.fileSizeFormatted

        return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>$title - بث الفيديو المحلي</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }
        body {
            background-color: #0b0f19;
            color: #f3f4f6;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 16px;
            overflow-x: hidden;
        }
        .container {
            width: 100%;
            max-width: 680px;
            background: #111827;
            border: 1px solid #1f2937;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6);
            display: flex;
            flex-direction: column;
        }
        .header {
            padding: 18px 22px;
            background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%);
            border-bottom: 1px solid #374151;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .badge {
            background: #06b6d4;
            color: #082f49;
            font-weight: 700;
            font-size: 12px;
            padding: 4px 10px;
            border-radius: 9999px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .badge-dot {
            width: 8px;
            height: 8px;
            background: #0284c7;
            border-radius: 50%;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.4; transform: scale(0.8); }
        }
        .title {
            font-size: 16px;
            font-weight: 600;
            color: #f9fafb;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 60%;
        }
        .video-wrapper {
            position: relative;
            width: 100%;
            background: #000;
            aspect-ratio: 16 / 9;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        video {
            width: 100%;
            height: 100%;
            object-fit: contain;
            outline: none;
        }
        .overlay-btn {
            position: absolute;
            background: rgba(6, 182, 212, 0.9);
            color: #fff;
            border: none;
            border-radius: 50%;
            width: 64px;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 8px 24px rgba(6, 182, 212, 0.5);
            transition: transform 0.2s, background 0.2s;
            z-index: 10;
        }
        .overlay-btn:active {
            transform: scale(0.92);
        }
        .footer-info {
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #111827;
            font-size: 13px;
            color: #9ca3af;
        }
        .btn-fullscreen {
            background: #1f2937;
            border: 1px solid #374151;
            color: #e5e7eb;
            padding: 8px 14px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-fullscreen:active {
            background: #374151;
        }
        .live-note {
            margin-top: 14px;
            font-size: 12px;
            color: #6b7280;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="title" title="$title">$title</div>
        <div class="badge">
            <span class="badge-dot"></span>
            بث مباشر محلي
        </div>
    </div>

    <div class="video-wrapper">
        <video id="videoPlayer" playsinline autoplay loop controls preload="auto">
            <source src="/video.mp4" type="video/mp4">
            متصفحك لا يدعم تشغيل الفيديو.
        </video>
        <button id="unmuteOverlay" class="overlay-btn" style="display: none;" onclick="startAudioVideo()">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8 5v14l11-7z"/>
            </svg>
        </button>
    </div>

    <div class="footer-info">
        <span>الحجم: $size • تكرار مستمر (Loop)</span>
        <button class="btn-fullscreen" onclick="toggleFullscreen()">
            <span>تكبير الشاشة ⛶</span>
        </button>
    </div>
</div>

<p class="live-note">تم الاتصال بنقطة البث بنجاح • يعمل بالكامل دون إنترنت</p>

<script>
    const player = document.getElementById('videoPlayer');
    const overlay = document.getElementById('unmuteOverlay');

    function attemptPlay() {
        player.muted = false;
        player.play().catch(function(err) {
            console.log("Unmuted autoplay restricted, attempting muted autoplay", err);
            player.muted = true;
            player.play().then(function() {
                overlay.style.display = 'flex';
            }).catch(function(e) {
                overlay.style.display = 'flex';
            });
        });
    }

    function startAudioVideo() {
        player.muted = false;
        player.play();
        overlay.style.display = 'none';
    }

    function toggleFullscreen() {
        if (!document.fullscreenElement) {
            if (player.requestFullscreen) {
                player.requestFullscreen();
            } else if (player.webkitRequestFullscreen) {
                player.webkitRequestFullscreen();
            }
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    }

    window.addEventListener('DOMContentLoaded', function() {
        attemptPlay();
    });

    // Auto restart on end (extra guard for loop attribute)
    player.addEventListener('ended', function() {
        player.currentTime = 0;
        player.play();
    });
</script>

</body>
</html>
        """.trimIndent()
    }
}
