package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkChipBg
import com.example.ui.theme.ElegantGlowGreen
import com.example.ui.theme.ElegantLilacDark
import com.example.ui.theme.ElegantLilacPrimary

@Composable
fun NetworkConfigCard(
    currentSsid: String,
    currentPassword: String,
    isHotspotActive: Boolean,
    onSaveCredentials: (ssid: String, password: String) -> Unit,
    onOpenSystemSettings: () -> Unit,
    onShowCaptiveGuide: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var ssidInput by remember(currentSsid) { mutableStateOf(currentSsid) }
    var passwordInput by remember(currentPassword) { mutableStateOf(currentPassword) }
    var passwordVisible by remember { mutableStateOf(false) }
    var hasChanges by remember { mutableStateOf(false) }

    LaunchedEffect(ssidInput, passwordInput, currentSsid, currentPassword) {
        hasChanges = (ssidInput != currentSsid || passwordInput != currentPassword)
    }

    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(28.dp))
            .testTag("network_config_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "إعدادات شبكة Wi-Fi وكلمة المرور",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    color = ElegantLilacPrimary
                )

                if (passwordInput.isBlank()) {
                    AssistChip(
                        onClick = {},
                        label = { Text("شبكة مفتوحة", fontSize = 11.sp) },
                        leadingIcon = {
                            Icon(
                                Icons.Default.LockOpen,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = ElegantLilacPrimary
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = DarkChipBg,
                            labelColor = ElegantLilacPrimary
                        ),
                        border = null
                    )
                } else {
                    AssistChip(
                        onClick = {},
                        label = { Text("محمية بكلمة سر", fontSize = 11.sp) },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Lock,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = ElegantGlowGreen
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = DarkChipBg,
                            labelColor = ElegantGlowGreen
                        ),
                        border = null
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // SSID Input Field
            OutlinedTextField(
                value = ssidInput,
                onValueChange = { ssidInput = it },
                label = { Text("اسم نقطة الاتصال (SSID)") },
                singleLine = true,
                enabled = !isHotspotActive,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElegantLilacPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ssid_input_field")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Wi-Fi Password Input Field
            OutlinedTextField(
                value = passwordInput,
                onValueChange = { passwordInput = it },
                label = { Text("كلمة مرور Wi-Fi (اتركه فارغاً لشبكة مفتوحة)") },
                singleLine = true,
                enabled = !isHotspotActive,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (passwordVisible) "إخفاء كلمة المرور" else "إظهار كلمة المرور",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElegantLilacPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("password_input_field")
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (passwordInput.isNotBlank() && passwordInput.length < 8) {
                    "⚠️ تنبيه: معيار WPA2 يتطلب أن تكون كلمة المرور 8 خانات على الأقل."
                } else if (passwordInput.isBlank()) {
                    "💡 ترك الحقل فارغاً يجعل نقطة الاتصال مفتوحة بدون كلمة سر."
                } else {
                    "✓ كلمة المرور جاهزة ومحفوظة."
                },
                style = MaterialTheme.typography.bodySmall,
                color = if (passwordInput.isNotBlank() && passwordInput.length < 8) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkChipBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = ElegantLilacPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "كلمة المرور الموحدة هي (00000000). يمكنك تغييرها أو حفظ أي كلمة مرور مخصصة من 8 خانات مباشرة من هذا الحقل.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Confirm & Save Button
            Button(
                onClick = {
                    if (passwordInput.isNotBlank() && passwordInput.length < 8) {
                        Toast.makeText(context, "كلمة المرور يجب أن تكون 8 أحرف أو أرقام على الأقل", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onSaveCredentials(ssidInput, passwordInput)
                    Toast.makeText(context, "تم حفظ وتطبيق إعدادات Wi-Fi بنجاح", Toast.LENGTH_SHORT).show()
                },
                enabled = !isHotspotActive,
                shape = RoundedCornerShape(99.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (hasChanges) ElegantLilacPrimary else DarkChipBg,
                    contentColor = if (hasChanges) ElegantLilacDark else ElegantLilacPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_credentials_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تأكيد وحفظ الإعدادات مباشرة",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (isHotspotActive) {
                Text(
                    text = "لتعديل الاسم أو كلمة المرور، يرجى إيقاف نقطة الاتصال أولاً.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp, start = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Helper Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onShowCaptiveGuide,
                    shape = RoundedCornerShape(99.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outline)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("captive_guide_button")
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("دليل التوجيه", style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = onOpenSystemSettings,
                    shape = RoundedCornerShape(99.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outline)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("system_settings_button")
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إعدادات النظام", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

