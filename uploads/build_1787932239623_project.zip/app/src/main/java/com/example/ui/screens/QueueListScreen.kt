package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.CallingState
import com.example.data.model.Patient
import com.example.ui.components.ClinicBottomNavBar
import com.example.ui.components.TvDisplayDialog
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.QueueFilterType

@Composable
fun QueueListScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val pagedPatients by viewModel.pagedPatients.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val liveTotalCount by viewModel.liveTotalCount.collectAsState()
    val waitingCount by viewModel.waitingCount.collectAsState()
    val postponedCount by viewModel.postponedCount.collectAsState()
    val servedCount by viewModel.servedCount.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()
    val totalPages by viewModel.totalPages.collectAsState()
    val currentFilterCount by viewModel.currentFilterCount.collectAsState()
    val pageSize by viewModel.pageSize.collectAsState()
    val nextNumber by viewModel.nextQueueNumber.collectAsState()

    val currentPatient by viewModel.currentPatient.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val callingState by viewModel.callingState.collectAsState()
    val activeCallingPatient by viewModel.activeCallingPatient.collectAsState()

    val showAddDialog by viewModel.showAddPatientDialog.collectAsState()
    val previewPatient by viewModel.previewTicketPatient.collectAsState()
    val showTvDialog by viewModel.showTvDialog.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()

    val isTvServerRunning by viewModel.isTvServerRunning.collectAsState()
    val tvServerUrl by viewModel.tvServerUrl.collectAsState()
    val isTvConnected by viewModel.isTvConnected.collectAsState()
    val isPrinterConnected by viewModel.isPrinterConnected.collectAsState()
    val isHotspotActive by viewModel.isHotspotActive.collectAsState()
    val hotspotSsid by viewModel.hotspotSsid.collectAsState()
    val hotspotPassword by viewModel.hotspotPassword.collectAsState()
    val hotspotStatusMessage by viewModel.hotspotStatusMessage.collectAsState()
    val isHotspotLoading by viewModel.isHotspotLoading.collectAsState()
    val isTvAudioOnly by viewModel.isTvAudioOnly.collectAsState()
    val isQueueStarted by viewModel.isQueueStarted.collectAsState()

    var patientToDelete by remember { mutableStateOf<Patient?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // =========================================================
            // 1. أعلى الصفحة: اسم العيادة، حالة الشاشة والطابعة، وحذف جميع المراجعين
            // =========================================================
            TopClinicHeader(
                clinicName = settings.clinicName.ifBlank { "عيادة الشفاء التخصصية" },
                doctorName = settings.doctorName.ifBlank { "د. أحمد عبدالله" },
                isTvConnected = isTvConnected,
                isPrinterConnected = isPrinterConnected,
                onDeleteAllClick = { viewModel.onOpenResetDialog() },
                onTvClick = { viewModel.onOpenTvDialog() },
                onPrinterClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) },
                onBatchTestClick = { viewModel.generateBatchTestPatients(100) }
            )

            // شريط النداء الصوتي الحي المباشر
            AnimatedVisibility(
                visible = callingState != CallingState.IDLE,
                enter = slideInVertically() + fadeIn(),
                exit = slideOutVertically() + fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(15.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "جاري النداء الصوتي للمراجع رقم ${activeCallingPatient?.formattedNumber ?: (currentPatient?.formattedNumber ?: "")}...",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = Color(0xFF22C55E),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // =========================================================
            // 2. بطاقة التحكم بالاستدعاء وزر "بدء" و "إيقاف مؤقت" و "استدعاء التالي"
            // =========================================================
            QueueStartCallCard(
                currentPatient = currentPatient,
                waitingCount = waitingCount,
                isQueueStarted = isQueueStarted,
                onStartClick = { viewModel.onStartQueueClicked() },
                onPauseClick = { viewModel.onPauseQueue() },
                onNextClick = { viewModel.onCallNextPatientClicked() },
                onRecallClick = { viewModel.onRecallCurrentPatient() },
                onPostponeClick = { viewModel.onPostponeCurrentPatient() }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // =========================================================
            // 3. تبويبات التصفية الأفقية الأنيقة (الكل، في الانتظار، المؤجلين، تم الاستدعاء)
            // =========================================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QueueFilterPill(
                    label = "الكل",
                    count = liveTotalCount,
                    isSelected = selectedFilter == QueueFilterType.ALL,
                    onClick = { viewModel.onSelectFilter(QueueFilterType.ALL) },
                    modifier = Modifier.weight(1f)
                )
                QueueFilterPill(
                    label = "في الانتظار",
                    count = waitingCount,
                    isSelected = selectedFilter == QueueFilterType.WAITING,
                    onClick = { viewModel.onSelectFilter(QueueFilterType.WAITING) },
                    modifier = Modifier.weight(1.25f)
                )
                QueueFilterPill(
                    label = "المؤجلين",
                    count = postponedCount,
                    isSelected = selectedFilter == QueueFilterType.POSTPONED,
                    onClick = { viewModel.onSelectFilter(QueueFilterType.POSTPONED) },
                    modifier = Modifier.weight(1.1f)
                )
                QueueFilterPill(
                    label = "تم استدعاء",
                    count = servedCount,
                    isSelected = selectedFilter == QueueFilterType.SERVED,
                    onClick = { viewModel.onSelectFilter(QueueFilterType.SERVED) },
                    modifier = Modifier.weight(1.25f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // =========================================================
            // 6. قائمة بطاقات المراجعين المرقمة مستخرجة من Room Database
            // =========================================================
            if (pagedPatients.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0F172A).copy(alpha = 0.05f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FormatListNumbered,
                                contentDescription = null,
                                tint = Color(0xFF0F172A).copy(alpha = 0.5f),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = when (selectedFilter) {
                                QueueFilterType.ALL -> "قائمة المراجعين فارغة"
                                QueueFilterType.WAITING -> "لا يوجد مراجعين في الانتظار"
                                QueueFilterType.POSTPONED -> "لا يوجد مراجعين مؤجلين"
                                QueueFilterType.SERVED -> "لم يتم استدعاء أي مراجع بعد"
                            },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "اضغط على زر (+) في الأسفل لإضافة مراجع جديد",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(pagedPatients, key = { it.id }) { patient ->
                        val isActive = (currentPatient?.id == patient.id) || (activeCallingPatient?.id == patient.id)
                        PatientCardExact(
                            patient = patient,
                            isActive = isActive,
                            onCardClick = { viewModel.onCallSpecificPatient(patient) },
                            onHourglassClick = {
                                if (patient.isPostponed) {
                                    viewModel.onRestorePostponedToQueue(patient)
                                } else {
                                    viewModel.onPostponeSpecificPatient(patient)
                                }
                            },
                            onReceiptClick = { viewModel.onOpenTicketPreview(patient) },
                            onDeleteClick = { patientToDelete = patient }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(130.dp))
                    }
                }
            }

            // =========================================================
            // شريط الترقيم (Pagination Bar) عالي الأداء من Room
            // =========================================================
            if (totalPages > 1 || currentFilterCount > 20) {
                QueuePaginationBar(
                    currentPage = currentPage,
                    totalPages = totalPages,
                    totalCount = currentFilterCount,
                    pageSize = pageSize,
                    onPrevClick = { viewModel.onPrevPage() },
                    onNextClick = { viewModel.onNextPage() },
                    onPageSizeClick = { viewModel.onSetPageSize(it) }
                )
            }

            // =========================================================
            // 7. شريط التنقل السفلي: قائمة المراجعين + الإعدادات
            // =========================================================
            ClinicBottomNavBar(
                activeScreen = AppScreen.QUEUE_LIST,
                onQueueClick = { /* Already here */ },
                onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
            )
        }

        // =========================================================
        // زر الإضافة العائم (+) مرفوع للأعلى لتجنب حجب زر 'التالي' وشريط الترقيم
        // =========================================================
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 20.dp, bottom = 136.dp)
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF1E293B))
                .clickable { viewModel.onAddPatientClicked() }
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(16.dp), spotColor = Color(0x55000000))
                .testTag("fab_add_patient"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة مراجع",
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
        }
    }

    // =========================================================
    // النوافذ المنبثقة (إضافة، طباعة، TV، وتصفير)
    // =========================================================
    if (showAddDialog) {
        AddPatientDialog(
            nextQueueNumber = nextNumber,
            initialAutoPrint = settings.autoPrintOnAdd,
            onConfirm = { name, note, shouldPrint ->
                viewModel.onConfirmAddPatient(name, note, shouldPrint)
            },
            onDismiss = { viewModel.onDismissAddPatientDialog() }
        )
    }

    if (previewPatient != null) {
        TicketPreviewDialog(
            patient = previewPatient!!,
            settings = settings,
            onPrintClick = { viewModel.onPrintPreviewTicket() },
            onDismiss = { viewModel.onDismissTicketPreview() }
        )
    }

    if (showTvDialog) {
        TvDisplayDialog(
            isRunning = isTvServerRunning,
            serverUrl = tvServerUrl,
            isHotspotActive = isHotspotActive,
            hotspotSsid = hotspotSsid,
            hotspotPassword = hotspotPassword,
            hotspotStatusMessage = hotspotStatusMessage,
            isHotspotLoading = isHotspotLoading,
            isTvAudioOnly = isTvAudioOnly,
            onToggleServer = { viewModel.onToggleTvServer(it) },
            onToggleHotspot = { viewModel.onToggleLocalHotspot(it) },
            onToggleTvAudioOnly = { viewModel.onToggleTvAudioOnly(it) },
            onRefreshIp = { viewModel.onRefreshTvIp() },
            onDismiss = { viewModel.onDismissTvDialog() }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.onDismissResetDialog() },
            modifier = Modifier.testTag("delete_all_confirm_dialog"),
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFFEF2F2)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = "حذف جميع المراجعين",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف جميع المراجعين من قائمة الدور؟ سيتم ترحيل بيانات الجلسة الحالية تلقائياً إلى صفحة التقارير، وتفريغ القائمة للبدء من جديد.",
                    fontSize = 14.sp,
                    color = Color(0xFF475569),
                    lineHeight = 22.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.onConfirmResetQueue() },
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("confirm_delete_all_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(
                        text = "تأكيد حذف الجميع",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.onDismissResetDialog() },
                    modifier = Modifier.height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Text(
                        text = "إلغاء",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF475569)
                    )
                }
            }
        )
    }

    patientToDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientToDelete = null },
            title = {
                Text(
                    text = "حذف المراجع",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = NavyDark
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف المراجع رقم ${patient.formattedNumber}${if (patient.name.isNotBlank()) " (${patient.name})" else ""} من القائمة؟",
                    fontSize = 14.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeletePatient(patient)
                        patientToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "حذف", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { patientToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "إلغاء", color = NavyDark, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

/**
 * الشريط العلوي المنظم وفق أعلى معايير التصميم المؤسسي:
 * - اليمين: اسم العيادة واسم الطبيب
 * - اليسار: زر "حذف جميع المراجعين" الأنيق والواضح بتدرج ناعم يحمي من الأخطاء
 * - الصف السفلي: مؤشرات الأجهزة المتصلة (شاشة متصلة / غير متصلة، وطابعة متصلة / غير متصلة)
 */
@Composable
private fun TopClinicHeader(
    clinicName: String,
    doctorName: String,
    isTvConnected: Boolean,
    isPrinterConnected: Boolean,
    onDeleteAllClick: () -> Unit,
    onTvClick: () -> Unit,
    onPrinterClick: () -> Unit,
    onBatchTestClick: () -> Unit = {}
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // الصف الأول: اسم العيادة والطبيب باليمين، وأزرار التحكم باليسار
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f, fill = false),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = clinicName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = doctorName,
                        fontSize = 12.5.sp,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // زر إضافة 100 مراجع لاختبار سرعة واستقرار Room والترقيم
                    Surface(
                        onClick = onBatchTestClick,
                        shape = RoundedCornerShape(9.dp),
                        color = Color(0xFFEFF6FF),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = "اختبار سعة Room",
                                tint = Color(0xFF2563EB),
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "+100 تجريبي",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2563EB)
                            )
                        }
                    }

                    // زر حذف جميع المراجعين المرتب والأنيق
                    Surface(
                        onClick = onDeleteAllClick,
                        shape = RoundedCornerShape(9.dp),
                        color = Color(0xFFFEF2F2),
                        border = BorderStroke(1.dp, Color(0xFFFECACA)),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("delete_all_patients_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "حذف جميع المراجعين",
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "حذف الجميع",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFDC2626)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // الصف الثاني: شريط حالة الأجهزة المتصلة (شاشة TV، والطابعة الحرارية)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // مؤشر شاشة متصلة أو غير متصلة
                DeviceStatusChip(
                    label = if (isTvConnected) "شاشة متصلة" else "شاشة غير متصلة",
                    icon = Icons.Default.Tv,
                    isConnected = isTvConnected,
                    onClick = onTvClick,
                    modifier = Modifier.weight(1f),
                    testTag = "tv_status_chip"
                )

                // مؤشر طابعة متصلة أو غير متصلة
                DeviceStatusChip(
                    label = if (isPrinterConnected) "طابعة متصلة" else "طابعة غير متصلة",
                    icon = Icons.Default.Print,
                    isConnected = isPrinterConnected,
                    onClick = onPrinterClick,
                    modifier = Modifier.weight(1f),
                    testTag = "printer_status_chip"
                )
            }
        }
    }
}

/**
 * كبسولة عرض حالة الأجهزة (شاشة / طابعة) بتصميم راقٍ متناسق وعالي الدقة
 */
@Composable
private fun DeviceStatusChip(
    label: String,
    icon: ImageVector,
    isConnected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val activeBg = Color(0xFFF0FDF4)
    val activeBorder = Color(0xFFBBF7D0)
    val activeText = Color(0xFF166534)
    val activeDot = Color(0xFF22C55E)
    val activeIcon = Color(0xFF16A34A)

    val inactiveBg = Color(0xFFF8FAFC)
    val inactiveBorder = Color(0xFFE2E8F0)
    val inactiveText = Color(0xFF64748B)
    val inactiveDot = Color(0xFF94A3B8)
    val inactiveIcon = Color(0xFF64748B)

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(9.dp),
        color = if (isConnected) activeBg else inactiveBg,
        border = BorderStroke(1.dp, if (isConnected) activeBorder else inactiveBorder),
        modifier = modifier
            .height(36.dp)
            .then(if (testTag.isNotBlank()) Modifier.testTag(testTag) else Modifier)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // أيقونة الجهاز والنص
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isConnected) activeIcon else inactiveIcon,
                    modifier = Modifier.size(17.dp)
                )
                Text(
                    text = label,
                    fontSize = 12.sp,
                    fontWeight = if (isConnected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isConnected) activeText else inactiveText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // مؤشر نقطة الحالة الحية (أخضر حي عند الاتصال / رمادي عند عدم الاتصال)
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (isConnected) activeDot else inactiveDot)
            )
        }
    }
}

/**
 * كبسولة الفلترة الأفقية المطابقة للصورة:
 * - عند التحديد: خلفية كحلية داكنة مع نص أبيض
 * - بدون تحديد: خلفية بيضاء مع إطار رمادي أنيق #CBD5E1
 */
@Composable
private fun QueueFilterPill(
    label: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) Color(0xFF0F172A) else Color.White)
            .border(
                1.dp,
                if (isSelected) Color(0xFF0F172A) else Color(0xFFCBD5E1),
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = label,
                fontSize = 12.5.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFF0F172A)
            )
            Text(
                text = "$count",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color(0xFF0F172A)
            )
        }
    }
}

/**
 * بطاقة المراجع المطابقة للصورة 100%:
 * - بطاقة المراجع النشط (الأولى بالصورة): إطار أزرق سماوي #93C5FD، مربع رقم أزرق صلب، شارة "نشط الآن"
 * - بطاقة المراجع غير النشط (الثانية بالصورة): إطار رمادي خفيف، رقم عادي أسود، نص "تم الاستدعاء"
 * - أزرار العمليات باليسار:
 *    1. ساعة رملية في دائرة ذهبية دافئة (في أقصى اليسار)
 *    2. أيقونة التقويم والتذكرة
 *    3. أيقونة الحذف
 */
@Composable
private fun PatientCardExact(
    patient: Patient,
    isActive: Boolean,
    onCardClick: () -> Unit,
    onHourglassClick: () -> Unit,
    onReceiptClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val isPostponed = patient.isPostponed
    val isCalled = patient.isCalled && !isPostponed

    val cardBorderColor = if (isActive) Color(0xFF93C5FD) else Color(0xFFE2E8F0)
    val cardBorderWidth = if (isActive) 1.5.dp else 1.dp

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(cardBorderWidth, cardBorderColor, RoundedCornerShape(16.dp))
            .clickable { onCardClick() }
            .shadow(
                elevation = if (isActive) 2.dp else 0.dp,
                shape = RoundedCornerShape(16.dp),
                spotColor = Color(0x202563EB)
            )
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // بيانات المراجع ورقم الدور إلى اليمين (Start في RTL)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // صندوق رقم الدور مع استجابة لمسية مباشرة عند الضغط
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isActive) Color(0xFF2563EB) else Color(0xFFF1F5F9))
                        .clickable { onCardClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = patient.formattedNumber,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isActive) Color.White else Color(0xFF0F172A)
                    )
                }

                // عنوان واسم المراجع وملاحظاته
                Column {
                    Text(
                        text = if (patient.name.isNotBlank()) {
                            "المراجع ${patient.name} (${patient.formattedNumber})"
                        } else {
                            "المراجع رقم ${patient.formattedNumber}"
                        },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    if (patient.note.isNotBlank()) {
                        Text(
                            text = patient.note,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                // شارة الحالة ("نشط الآن" بالأخضر الفاتح، أو نص "تم الاستدعاء" بالرمادي)
                if (isActive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFDCFCE7))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "نشط الآن",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF16A34A)
                        )
                    }
                } else {
                    Text(
                        text = when {
                            isPostponed -> "مؤجل"
                            isCalled -> "تم الاستدعاء"
                            else -> "في الانتظار"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = when {
                            isPostponed -> Color(0xFFD97706)
                            isCalled -> Color(0xFF64748B)
                            else -> Color(0xFF2563EB)
                        }
                    )
                }
            }

            // أزرار العمليات إلى اليسار (End في RTL)
            // في RTL: الحذف يظهر يمين التقويم، والتقويم يمين الساعة الرملية،
            // وبالتالي تظهر الساعة الرملية في أقصى اليسار تماماً كما في الصورة!
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // 1. أيقونة الحذف
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // 2. أيقونة التذكرة والتقويم
                IconButton(
                    onClick = onReceiptClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DateRange,
                        contentDescription = "تذكرة المراجع",
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // 3. زر الساعة الرملية الدائري الذهبي المطابق للصورة تماماً
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFFFDE68A),
                                    Color(0xFFF59E0B),
                                    Color(0xFFD97706)
                                )
                            )
                        )
                        .clickable { onHourglassClick() }
                        .shadow(
                            elevation = 4.dp,
                            shape = CircleShape,
                            spotColor = Color(0x66D97706)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.HourglassTop,
                        contentDescription = "تأجيل أو استعادة المراجع",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * شريط الترقيم المؤسسي عالي الأداء والسرعة:
 * يدعم التبديل بين الصفحات بلمسة واحدة، ويعرض عدد المراجعين الإجمالي بدقة فائقة من SQLite
 */
@Composable
private fun QueuePaginationBar(
    currentPage: Int,
    totalPages: Int,
    totalCount: Int,
    pageSize: Int,
    onPrevClick: () -> Unit,
    onNextClick: () -> Unit,
    onPageSizeClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // زر الصفحة السابقة
            Surface(
                onClick = onPrevClick,
                enabled = currentPage > 1,
                shape = RoundedCornerShape(8.dp),
                color = if (currentPage > 1) Color(0xFFF1F5F9) else Color(0xFFF8FAFC),
                border = BorderStroke(1.dp, if (currentPage > 1) Color(0xFFCBD5E1) else Color(0xFFE2E8F0)),
                modifier = Modifier.height(34.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "السابق",
                        tint = if (currentPage > 1) Color(0xFF1E293B) else Color(0xFF94A3B8),
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "السابق",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentPage > 1) Color(0xFF1E293B) else Color(0xFF94A3B8)
                    )
                }
            }

            // معلومات الصفحة والعدد الإجمالي
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "صفحة $currentPage من $totalPages",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = "($totalCount مراجع)",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }

            // زر الصفحة التالية
            Surface(
                onClick = onNextClick,
                enabled = currentPage < totalPages,
                shape = RoundedCornerShape(8.dp),
                color = if (currentPage < totalPages) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                border = BorderStroke(1.dp, if (currentPage < totalPages) Color(0xFF1E293B) else Color(0xFFE2E8F0)),
                modifier = Modifier.height(34.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "التالي",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentPage < totalPages) Color.White else Color(0xFF94A3B8)
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "التالي",
                        tint = if (currentPage < totalPages) Color.White else Color(0xFF94A3B8),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * لوحة التحكم الرئيسية بالنداء والبدء والإيقاف المؤقت:
 * - تحتوي على زر "بدء" لتفعيل عرض أرقام المراجعين على الشاشات
 * - تحتوي على زر "إيقاف مؤقت" لإيقاف الدور وإخفاء الأرقام من الشاشات
 * - تحتوي على زر "استدعاء التالي" وأزرار إعادة النداء والتأجيل
 */
@Composable
private fun QueueStartCallCard(
    currentPatient: Patient?,
    waitingCount: Int,
    isQueueStarted: Boolean,
    onStartClick: () -> Unit,
    onPauseClick: () -> Unit,
    onNextClick: () -> Unit,
    onRecallClick: () -> Unit,
    onPostponeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shadowElevation = 1.5.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // معلومات المراجع الحالي أو حالة وضع الاستعداد
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f, fill = false)
            ) {
                if (isQueueStarted) {
                    if (currentPatient != null) {
                        // شارة رقم المراجع الحالي
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF2563EB))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = currentPatient.formattedNumber,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF22C55E))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "المراجع الحالي",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF166534)
                                )
                            }
                            Text(
                                text = currentPatient.name.ifBlank { "مراجع بدون اسم" },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        // الدور نشط ولكن لا يوجد مراجع مستدعى حالياً
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF22C55E).copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFF16A34A),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF22C55E))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "العرض نشط على الشاشة",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF166534)
                                )
                            }
                            Text(
                                text = if (waitingCount > 0) "$waitingCount مراجع بالانتظار" else "لا يوجد مراجعين في الانتظار",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                        }
                    }
                } else {
                    // حالة وضع الاستعداد (الأرقام معلقة ومخفية عن الشاشة حتى الضغط على 'بدء')
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFD97706).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pause,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "وضع الاستعداد (الأرقام مخفية)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = if (waitingCount > 0) "$waitingCount مراجع بانتظار البدء" else "اضغط 'بدء' لتفعيل العرض",
                            fontSize = 11.5.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // أزرار التحكم والعمليات (بدء / إيقاف مؤقت / التالي / إعادة النداء / تأجيل)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!isQueueStarted) {
                    // ==========================================
                    // زر "بدء" الرئيسي (لتفعيل العرض والبدء)
                    // ==========================================
                    Button(
                        onClick = onStartClick,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF16A34A)
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("start_queue_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "بدء",
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                } else {
                    // ==========================================
                    // وضع التشغيل: زر إيقاف مؤقت + أزرار العمليات
                    // ==========================================

                    // 1. زر "إيقاف مؤقت"
                    Surface(
                        onClick = onPauseClick,
                        shape = RoundedCornerShape(9.dp),
                        color = Color(0xFFFFFBEB),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("pause_queue_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pause,
                                contentDescription = "إيقاف مؤقت",
                                tint = Color(0xFFB45309),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "إيقاف مؤقت",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309)
                            )
                        }
                    }

                    // أزرار المراجع الحالي: إعادة نداء وتأجيل
                    if (currentPatient != null) {
                        // زر إعادة النداء
                        Surface(
                            onClick = onRecallClick,
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "إعادة النداء",
                                    tint = Color(0xFF0F172A),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // زر تأجيل
                        Surface(
                            onClick = onPostponeClick,
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFEFF6FF),
                            border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.HourglassTop,
                                    contentDescription = "تأجيل المراجع",
                                    tint = Color(0xFF2563EB),
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }

                    // 2. زر "استدعاء التالي"
                    Button(
                        onClick = onNextClick,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF0F172A)
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("call_next_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "التالي",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

