package com.example.quality

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class QualityPreset(val displayName: String, val description: String) {
    ULTRA_120FPS("120 FPS Turbo GT", "120 FPS Ultra Refresh Rate — Zero Latency for GT 30 Pro Gaming"),
    GAMING_90FPS("90 FPS High-Speed", "90 FPS Fast Refresh Rate — Ultra smooth gameplay"),
    PRO_60FPS("60 FPS Pro Gaming", "60 FPS Crisp & Smooth — Optimal 1080p/720p performance"),
    AUTO("Adaptive Turbo AI (120Hz)", "Dynamically tunes frame rate (30–120 FPS) and latency"),
    BALANCED_30FPS("30 FPS Balanced", "720p - Low power and battery saving mode")
}

data class StreamMetrics(
    val currentFps: Int = 0,
    val targetFps: Int = 120,
    val jpegQuality: Int = 75,
    val scaleFactor: Float = 0.70f,
    val frameProcessingLatencyMs: Long = 0,
    val bitrateKbps: Long = 0,
    val totalFramesStreamed: Long = 0,
    val activeViewers: Int = 0,
    val isAudioStreaming: Boolean = false,
    val qualityPreset: QualityPreset = QualityPreset.ULTRA_120FPS
)

class StreamQualityManager {

    private val _metrics = MutableStateFlow(StreamMetrics())
    val metrics: StateFlow<StreamMetrics> = _metrics.asStateFlow()

    private var activePreset: QualityPreset = QualityPreset.ULTRA_120FPS
    private var currentQuality: Int = 68
    private var currentScale: Float = 0.65f
    private var currentTargetFps: Int = 120
    private var isAudioActive: Boolean = false

    // High performance sliding window metrics
    private var frameCountInInterval = 0
    private var bytesInInterval = 0L
    private var lastIntervalTimestamp = System.currentTimeMillis()
    private var totalFrames = 0L
    private var recentLatencies = LongArray(10) { 8L }
    private var latencyIndex = 0

    init {
        applyPreset(QualityPreset.ULTRA_120FPS)
    }

    fun setPreset(preset: QualityPreset) {
        activePreset = preset
        applyPreset(preset)
    }

    fun setAudioStreaming(active: Boolean) {
        isAudioActive = active
        _metrics.update { it.copy(isAudioStreaming = active) }
    }

    private fun applyPreset(preset: QualityPreset) {
        when (preset) {
            QualityPreset.ULTRA_120FPS -> {
                currentQuality = 65
                currentScale = 0.60f
                currentTargetFps = 120
            }
            QualityPreset.GAMING_90FPS -> {
                currentQuality = 70
                currentScale = 0.65f
                currentTargetFps = 90
            }
            QualityPreset.PRO_60FPS -> {
                currentQuality = 75
                currentScale = 0.75f
                currentTargetFps = 60
            }
            QualityPreset.AUTO -> {
                currentQuality = 72
                currentScale = 0.70f
                currentTargetFps = 120
            }
            QualityPreset.BALANCED_30FPS -> {
                currentQuality = 80
                currentScale = 0.80f
                currentTargetFps = 30
            }
        }
        updateMetricsState()
    }

    fun getJpegQuality(): Int = currentQuality

    fun getScaleFactor(): Float = currentScale

    fun getTargetFps(): Int = currentTargetFps

    fun getTargetFrameIntervalMs(): Long {
        return when (currentTargetFps) {
            120 -> 8L
            90 -> 11L
            60 -> 16L
            30 -> 33L
            else -> (1000L / currentTargetFps.coerceIn(15, 120)).coerceAtLeast(8L)
        }
    }

    /**
     * Reports a newly processed and dispatched frame to the adaptive quality engine.
     */
    fun recordFrameProcessed(frameSizeBytes: Int, processingDurationMs: Long) {
        totalFrames++
        frameCountInInterval++
        bytesInInterval += frameSizeBytes

        recentLatencies[latencyIndex % recentLatencies.size] = processingDurationMs
        latencyIndex++

        val now = System.currentTimeMillis()
        val timeElapsed = now - lastIntervalTimestamp

        if (timeElapsed >= 1000L) {
            val measuredFps = ((frameCountInInterval * 1000L) / timeElapsed).toInt()
            val measuredBitrateKbps = ((bytesInInterval * 8L) / timeElapsed)

            val avgLatency = recentLatencies.average().toLong()

            if (activePreset == QualityPreset.AUTO) {
                adaptQuality(avgLatency, measuredFps)
            }

            _metrics.update { current ->
                current.copy(
                    currentFps = measuredFps,
                    targetFps = currentTargetFps,
                    jpegQuality = currentQuality,
                    scaleFactor = currentScale,
                    frameProcessingLatencyMs = avgLatency,
                    bitrateKbps = measuredBitrateKbps,
                    totalFramesStreamed = totalFrames,
                    isAudioStreaming = isAudioActive,
                    qualityPreset = activePreset
                )
            }

            frameCountInInterval = 0
            bytesInInterval = 0L
            lastIntervalTimestamp = now
        }
    }

    private fun adaptQuality(avgLatencyMs: Long, measuredFps: Int) {
        if (avgLatencyMs > 25) {
            if (currentQuality > 45) {
                currentQuality = (currentQuality - 5).coerceAtLeast(45)
            }
        } else if (avgLatencyMs < 10) {
            if (currentQuality < 80) {
                currentQuality = (currentQuality + 2).coerceAtMost(80)
            }
        }
    }

    fun updateActiveClients(count: Int) {
        _metrics.update { it.copy(activeViewers = count) }
    }

    fun reset() {
        totalFrames = 0L
        frameCountInInterval = 0
        bytesInInterval = 0L
        lastIntervalTimestamp = System.currentTimeMillis()
        applyPreset(activePreset)
    }

    private fun updateMetricsState() {
        _metrics.update {
            it.copy(
                targetFps = currentTargetFps,
                jpegQuality = currentQuality,
                scaleFactor = currentScale,
                isAudioStreaming = isAudioActive,
                qualityPreset = activePreset
            )
        }
    }
}
