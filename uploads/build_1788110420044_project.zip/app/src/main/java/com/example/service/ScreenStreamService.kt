package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.AudioStreamManager
import com.example.quality.QualityPreset
import com.example.quality.StreamQualityManager
import com.example.util.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

class ScreenStreamService : Service() {

    companion object {
        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_DATA_INTENT = "EXTRA_DATA_INTENT"
        const val EXTRA_PORT = "EXTRA_PORT"
        const val EXTRA_ENABLE_AUDIO = "EXTRA_ENABLE_AUDIO"

        private const val NOTIFICATION_ID = 4040
        private const val CHANNEL_ID = "screen_stream_channel"

        val qualityManager = StreamQualityManager()

        private val _isStreaming = MutableStateFlow(false)
        val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

        private val _serverUrl = MutableStateFlow<String?>(null)
        val serverUrl: StateFlow<String?> = _serverUrl.asStateFlow()

        private val _connectedClients = MutableStateFlow(0)
        val connectedClients: StateFlow<Int> = _connectedClients.asStateFlow()

        private val _isAudioActive = MutableStateFlow(false)
        val isAudioActive: StateFlow<Boolean> = _isAudioActive.asStateFlow()

        fun start(
            context: Context,
            resultCode: Int,
            data: Intent,
            port: Int = NetworkUtils.DEFAULT_PORT,
            enableAudio: Boolean = true
        ) {
            val intent = Intent(context, ScreenStreamService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA_INTENT, data)
                putExtra(EXTRA_PORT, port)
                putExtra(EXTRA_ENABLE_AUDIO, enableAudio)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, ScreenStreamService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var httpServer: ScreenHttpServer? = null
    private var audioStreamManager: AudioStreamManager? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private var captureHandlerThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = 400
    private var port = NetworkUtils.DEFAULT_PORT
    private var isAudioEnabled = true

    private val activeSubscribers = AtomicInteger(0)
    private val latestFrame = AtomicReference<ByteArray?>(null)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        audioStreamManager = AudioStreamManager(applicationContext)

        captureHandlerThread = HandlerThread("TurboFrameCaptureThread").apply {
            start()
        }
        captureHandler = Handler(captureHandlerThread!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA_INTENT)
                port = intent.getIntExtra(EXTRA_PORT, NetworkUtils.DEFAULT_PORT)
                isAudioEnabled = intent.getBooleanExtra(EXTRA_ENABLE_AUDIO, true)

                if (resultCode != 0 && data != null) {
                    startStreamingService(resultCode, data)
                } else {
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                stopStreaming()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startStreamingService(resultCode: Int, data: Intent) {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ScreenCast:WakeLock").apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {}

        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiLock = wifiManager.createWifiLock(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF,
                "ScreenCast:WifiLock"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}

        val ip = NetworkUtils.getLocalIpAddress()
        val url = NetworkUtils.getStreamUrl(ip, port)
        _serverUrl.value = url

        startForegroundNotification(url)
        _isStreaming.value = true

        queryScreenDimensions()
        startHttpServer(port)
        startScreenCapture(resultCode, data)

        // Start Audio Streaming if enabled
        if (isAudioEnabled && audioStreamManager != null) {
            val audioStarted = audioStreamManager?.startCapture(
                scope = serviceScope,
                mediaProjection = mediaProjection,
                useInternalAudio = true
            ) ?: false
            _isAudioActive.value = audioStarted
            qualityManager.setAudioStreaming(audioStarted)
        }
    }

    private fun startForegroundNotification(url: String) {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, ScreenStreamService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("120 FPS Turbo Screen Cast & Audio Active")
            .setContentText("Broadcasting to: $url")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Stream", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            }
            startForeground(NOTIFICATION_ID, notification, serviceType)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @Suppress("DEPRECATION")
    private fun queryScreenDimensions() {
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.currentWindowMetrics
            val bounds = windowMetrics.bounds
            screenWidth = bounds.width()
            screenHeight = bounds.height()
            screenDensity = resources.configuration.densityDpi
        } else {
            val metrics = DisplayMetrics()
            windowManager.defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi
        }
    }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        val mainHandler = Handler(Looper.getMainLooper())
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopStreaming()
                stopSelf()
            }
        }, mainHandler)

        val scale = qualityManager.getScaleFactor()
        val captureWidth = ((screenWidth * scale).toInt() / 2) * 2
        val captureHeight = ((screenHeight * scale).toInt() / 2) * 2

        imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 3)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "TurboCastVirtualDisplay",
            captureWidth,
            captureHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            mainHandler
        )

        serviceScope.launch(Dispatchers.Default) {
            turboFrameCaptureLoop(captureWidth, captureHeight)
        }
    }

    private suspend fun turboFrameCaptureLoop(width: Int, height: Int) {
        val bufferStream = ByteArrayOutputStream(width * height / 2)
        var reusableBitmap: Bitmap? = null

        while (serviceScope.isActive) {
            val loopStart = System.currentTimeMillis()
            var image: Image? = null
            try {
                image = imageReader?.acquireLatestImage()
                if (image != null) {
                    val planes = image.planes
                    val buffer: ByteBuffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * width

                    val bitmapWidth = width + rowPadding / pixelStride
                    if (reusableBitmap == null || reusableBitmap.width != bitmapWidth || reusableBitmap.height != height) {
                        reusableBitmap?.recycle()
                        reusableBitmap = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888)
                    }

                    reusableBitmap.copyPixelsFromBuffer(buffer)

                    val finalBitmap = if (rowPadding > 0) {
                        Bitmap.createBitmap(reusableBitmap, 0, 0, width, height)
                    } else {
                        reusableBitmap
                    }

                    bufferStream.reset()
                    val compressionQuality = qualityManager.getJpegQuality()
                    finalBitmap.compress(Bitmap.CompressFormat.JPEG, compressionQuality, bufferStream)

                    val frameBytes = bufferStream.toByteArray()
                    latestFrame.set(frameBytes)

                    val duration = System.currentTimeMillis() - loopStart
                    qualityManager.recordFrameProcessed(frameBytes.size, duration)

                    if (rowPadding > 0 && finalBitmap != reusableBitmap) {
                        finalBitmap.recycle()
                    }
                }
            } catch (_: Exception) {
            } finally {
                image?.close()
            }

            val targetInterval = qualityManager.getTargetFrameIntervalMs()
            val timeTaken = System.currentTimeMillis() - loopStart
            val waitTime = (targetInterval - timeTaken).coerceAtLeast(2L)
            delay(waitTime)
        }

        reusableBitmap?.recycle()
    }

    private fun startHttpServer(serverPort: Int) {
        httpServer?.stop()
        httpServer = ScreenHttpServer(
            port = serverPort,
            qualityManager = qualityManager,
            audioStreamManager = audioStreamManager ?: AudioStreamManager(applicationContext),
            latestFrame = latestFrame,
            onViewerCountChanged = { count ->
                _connectedClients.value = count
            },
            htmlSupplier = { generatePlayerHtml() }
        ).apply {
            start(serviceScope)
        }
    }

    private fun generatePlayerHtml(): String {
        return """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>120 FPS TurboCast Pro — Ultra Low Latency & Live Audio</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        body {
            background-color: #080B11;
            color: #F3F4F6;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 20px;
            background: #0F172A;
            border-bottom: 1px solid #1E293B;
            z-index: 10;
        }
        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .brand-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #10B981;
            box-shadow: 0 0 10px #10B981;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.95); opacity: 0.8; }
            50% { transform: scale(1.15); opacity: 1; }
            100% { transform: scale(0.95); opacity: 0.8; }
        }
        .brand-title {
            font-size: 16px;
            font-weight: 700;
            letter-spacing: -0.02em;
            color: #F8FAFC;
        }
        .brand-badge {
            font-size: 10px;
            background: linear-gradient(135deg, #3B82F6, #8B5CF6);
            color: #FFFFFF;
            padding: 2px 8px;
            border-radius: 6px;
            font-weight: 800;
            letter-spacing: 0.05em;
        }
        .controls {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .btn {
            background: #1E293B;
            border: 1px solid #334155;
            color: #F8FAFC;
            padding: 7px 14px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.15s ease;
        }
        .btn:hover {
            background: #334155;
            border-color: #475569;
        }
        .btn-audio {
            background: #2563EB;
            border-color: #3B82F6;
        }
        .btn-audio.active {
            background: #059669;
            border-color: #10B981;
        }
        .viewer-container {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            background: #040711;
            overflow: hidden;
        }
        #streamImage {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            user-select: none;
            will-change: transform;
        }
        .hud-overlay {
            position: absolute;
            top: 14px;
            left: 14px;
            background: rgba(15, 23, 42, 0.85);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 6px 12px;
            font-size: 12px;
            display: flex;
            gap: 14px;
            color: #94A3B8;
            pointer-events: none;
            z-index: 5;
        }
        .hud-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .hud-value {
            color: #38BDF8;
            font-weight: 700;
            font-family: monospace;
        }
        .hud-fps {
            color: #4ADE80;
        }
        .standby-card {
            display: none;
            flex-direction: column;
            align-items: center;
            text-align: center;
            padding: 32px;
            background: #0F172A;
            border: 1px solid #1E293B;
            border-radius: 16px;
            max-width: 440px;
            margin: 20px;
        }
        .standby-card h2 {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 8px;
            color: #F8FAFC;
        }
        .standby-card p {
            color: #94A3B8;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 20px;
        }
        audio {
            display: none;
        }
    </style>
</head>
<body>
    <header>
        <div class="brand">
            <div class="brand-dot"></div>
            <span class="brand-title">120 FPS TurboCast Pro</span>
            <span class="brand-badge">GT 30 PRO TURBO</span>
        </div>
        <div class="controls">
            <button class="btn btn-audio" id="audioBtn" onclick="toggleAudio()">
                <span id="audioIcon">🔊</span>
                <span id="audioText">Start Audio</span>
            </button>
            <button class="btn" onclick="toggleFullscreen()">
                <span>⛶</span> Fullscreen
            </button>
        </div>
    </header>

    <div class="viewer-container" id="container">
        <div class="hud-overlay" id="hud">
            <div class="hud-item">FPS: <span class="hud-value hud-fps" id="fpsCounter">--</span></div>
            <div class="hud-item">Bitrate: <span class="hud-value" id="bitrateCounter">--</span></div>
            <div class="hud-item">Latency: <span class="hud-value" id="latencyCounter">--</span></div>
            <div class="hud-item">Audio: <span class="hud-value" id="audioStatus">OFF</span></div>
        </div>

        <img id="streamImage" src="/stream" alt="Live Screen Stream" />

        <div class="standby-card" id="standbyCard">
            <h2>Screen Stream Ready</h2>
            <p>Connected to your phone. Press <strong>"Start Screen Broadcast"</strong> on your GT 30 Pro to view high-refresh rate gaming screen & audio.</p>
            <button class="btn btn-audio" onclick="location.reload()">🔄 Refresh Stream</button>
        </div>
    </div>

    <!-- Hidden Audio Element -->
    <audio id="audioStream" preload="none"></audio>

    <script>
        const img = document.getElementById('streamImage');
        const standby = document.getElementById('standbyCard');
        const fpsCounter = document.getElementById('fpsCounter');
        const bitrateCounter = document.getElementById('bitrateCounter');
        const latencyCounter = document.getElementById('latencyCounter');
        const audioStatus = document.getElementById('audioStatus');
        const audioBtn = document.getElementById('audioBtn');
        const audioText = document.getElementById('audioText');
        const audioStream = document.getElementById('audioStream');

        let frameCount = 0;
        let lastTime = performance.now();
        let audioActive = false;

        // High precision Client FPS counter
        function calcFps() {
            frameCount++;
            const now = performance.now();
            if (now - lastTime >= 1000) {
                const fps = Math.round((frameCount * 1000) / (now - lastTime));
                fpsCounter.textContent = fps + ' FPS';
                frameCount = 0;
                lastTime = now;
            }
            requestAnimationFrame(calcFps);
        }
        requestAnimationFrame(calcFps);

        // Fallback to rapid polling if MJPEG is unsupported on specific smart TV browser
        img.onerror = function() {
            img.style.display = 'none';
            standby.style.display = 'flex';
            setTimeout(startPolling, 1500);
        };

        function startPolling() {
            standby.style.display = 'none';
            img.style.display = 'block';
            let active = true;
            function pollFrame() {
                if (!active) return;
                const nextImg = new Image();
                nextImg.onload = function() {
                    img.src = nextImg.src;
                    requestAnimationFrame(pollFrame);
                };
                nextImg.onerror = function() {
                    setTimeout(pollFrame, 500);
                };
                nextImg.src = '/frame?t=' + Date.now();
            }
            pollFrame();
        }

        // Live stats polling from backend
        setInterval(async () => {
            try {
                const res = await fetch('/api/status');
                if (res.ok) {
                    const data = await res.json();
                    bitrateCounter.textContent = (data.bitrateKbps / 1000).toFixed(1) + ' Mbps';
                    latencyCounter.textContent = (data.latencyMs || 8) + ' ms';
                }
            } catch (_) {}
        }, 1000);

        // Web Audio Live Stream Toggle
        function toggleAudio() {
            if (!audioActive) {
                audioStream.src = '/audio.wav?t=' + Date.now();
                audioStream.play().then(() => {
                    audioActive = true;
                    audioBtn.classList.add('active');
                    audioText.textContent = 'Mute Audio';
                    audioStatus.textContent = 'ON';
                    audioStatus.style.color = '#4ADE80';
                }).catch(e => {
                    console.log('Audio autoplay blocked or connecting:', e);
                });
            } else {
                audioStream.pause();
                audioStream.src = '';
                audioActive = false;
                audioBtn.classList.remove('active');
                audioText.textContent = 'Start Audio';
                audioStatus.textContent = 'OFF';
                audioStatus.style.color = '#94A3B8';
            }
        }

        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => {});
            } else {
                document.exitFullscreen().catch(() => {});
            }
        }
    </script>
</body>
</html>
        """.trimIndent()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "120 FPS TurboCast Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Streaming phone screen and internal audio"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun stopStreaming() {
        _isStreaming.value = false
        _isAudioActive.value = false
        qualityManager.setAudioStreaming(false)
        activeSubscribers.set(0)

        try {
            audioStreamManager?.stopCapture()
        } catch (_: Exception) {}

        try {
            wakeLock?.let { if (it.isHeld) it.release() }
            wakeLock = null
        } catch (_: Exception) {}

        try {
            wifiLock?.let { if (it.isHeld) it.release() }
            wifiLock = null
        } catch (_: Exception) {}

        try {
            virtualDisplay?.release()
            virtualDisplay = null
        } catch (_: Exception) {}

        try {
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {}

        try {
            mediaProjection?.stop()
            mediaProjection = null
        } catch (_: Exception) {}

        httpServer?.stop()
        httpServer = null
        latestFrame.set(null)
        qualityManager.reset()
    }

    override fun onDestroy() {
        stopStreaming()
        serviceScope.cancel()
        captureHandlerThread?.quitSafely()
        super.onDestroy()
    }
}
