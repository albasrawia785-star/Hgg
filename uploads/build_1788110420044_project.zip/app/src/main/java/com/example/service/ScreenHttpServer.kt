package com.example.service

import android.util.Log
import com.example.audio.AudioStreamManager
import com.example.quality.StreamQualityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

class ScreenHttpServer(
    private val port: Int,
    private val qualityManager: StreamQualityManager,
    private val audioStreamManager: AudioStreamManager,
    private val latestFrame: AtomicReference<ByteArray?>,
    private val onViewerCountChanged: (Int) -> Unit,
    private val htmlSupplier: () -> String
) {
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private val activeClients = AtomicInteger(0)

    fun start(scope: CoroutineScope) {
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket().apply {
                    reuseAddress = true
                    receiveBufferSize = 64 * 1024
                    bind(InetSocketAddress("0.0.0.0", port))
                }

                while (isActive && serverSocket?.isClosed == false) {
                    val socket = try {
                        serverSocket?.accept() ?: break
                    } catch (_: Exception) {
                        break
                    }

                    launch(Dispatchers.IO) {
                        handleClient(socket, scope)
                    }
                }
            } catch (e: Exception) {
                Log.e("ScreenHttpServer", "Server error: ${e.message}")
            }
        }
    }

    private suspend fun handleClient(socket: Socket, scope: CoroutineScope) {
        socket.use { client ->
            client.tcpNoDelay = true
            client.sendBufferSize = 128 * 1024
            client.soTimeout = 10000

            val reader = BufferedReader(InputStreamReader(client.getInputStream()))
            val output: OutputStream = BufferedOutputStream(client.getOutputStream())

            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return

            val rawPath = parts[1]
            val path = rawPath.substringBefore("?")

            when {
                path == "/" || path.isEmpty() -> {
                    val html = htmlSupplier().toByteArray(Charsets.UTF_8)
                    val header = ("HTTP/1.1 200 OK\r\n" +
                            "Content-Type: text/html; charset=utf-8\r\n" +
                            "Content-Length: ${html.size}\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Connection: close\r\n\r\n").toByteArray(Charsets.UTF_8)
                    output.write(header)
                    output.write(html)
                    output.flush()
                }

                path == "/stream" -> {
                    client.soTimeout = 0 // Infinite timeout for continuous 120 FPS MJPEG
                    val header = ("HTTP/1.1 200 OK\r\n" +
                            "Server: TurboCast-120FPS/2.0\r\n" +
                            "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n" +
                            "Pragma: no-cache\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Connection: close\r\n" +
                            "Content-Type: multipart/x-mixed-replace; boundary=--frame\r\n\r\n")
                        .toByteArray(Charsets.UTF_8)
                    output.write(header)
                    output.flush()

                    val count = activeClients.incrementAndGet()
                    onViewerCountChanged(count)
                    qualityManager.updateActiveClients(count)

                    try {
                        var lastSentFrame: ByteArray? = null
                        while (scope.isActive && !client.isClosed && client.isConnected) {
                            val frame = latestFrame.get()
                            if (frame != null && frame !== lastSentFrame) {
                                lastSentFrame = frame
                                val frameHeader = ("--frame\r\n" +
                                        "Content-Type: image/jpeg\r\n" +
                                        "Content-Length: ${frame.size}\r\n\r\n")
                                    .toByteArray(Charsets.UTF_8)

                                output.write(frameHeader)
                                output.write(frame)
                                output.write("\r\n".toByteArray(Charsets.UTF_8))
                                output.flush()
                            }
                            val interval = qualityManager.getTargetFrameIntervalMs()
                            delay(interval)
                        }
                    } catch (_: Exception) {
                        // Client disconnected
                    } finally {
                        val current = activeClients.decrementAndGet().coerceAtLeast(0)
                        onViewerCountChanged(current)
                        qualityManager.updateActiveClients(current)
                    }
                }

                path == "/audio" || path == "/audio.wav" -> {
                    client.soTimeout = 0 // Infinite streaming for audio
                    val wavHeader = audioStreamManager.createWavHeader()
                    val httpHeader = ("HTTP/1.1 200 OK\r\n" +
                            "Server: TurboCast-Audio/2.0\r\n" +
                            "Content-Type: audio/wav\r\n" +
                            "Cache-Control: no-cache, no-store\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Connection: close\r\n\r\n").toByteArray(Charsets.UTF_8)

                    output.write(httpHeader)
                    output.write(wavHeader)
                    output.flush()

                    audioStreamManager.addClient(output)
                    try {
                        while (scope.isActive && !client.isClosed && client.isConnected) {
                            delay(1000)
                        }
                    } catch (_: Exception) {
                    } finally {
                        audioStreamManager.removeClient(output)
                    }
                }

                path == "/frame" || path == "/snapshot" -> {
                    val frame = latestFrame.get()
                    if (frame != null) {
                        val header = ("HTTP/1.1 200 OK\r\n" +
                                "Content-Type: image/jpeg\r\n" +
                                "Content-Length: ${frame.size}\r\n" +
                                "Cache-Control: no-store, no-cache, must-revalidate\r\n" +
                                "Access-Control-Allow-Origin: *\r\n" +
                                "Connection: close\r\n\r\n").toByteArray(Charsets.UTF_8)
                        output.write(header)
                        output.write(frame)
                        output.flush()
                    } else {
                        val noContent = "HTTP/1.1 204 No Content\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n"
                            .toByteArray(Charsets.UTF_8)
                        output.write(noContent)
                        output.flush()
                    }
                }

                path == "/api/status" -> {
                    val metrics = qualityManager.metrics.value
                    val json = """
                        {
                          "status": "online",
                          "fps": ${metrics.currentFps},
                          "targetFps": ${metrics.targetFps},
                          "quality": ${metrics.jpegQuality},
                          "bitrateKbps": ${metrics.bitrateKbps},
                          "latencyMs": ${metrics.frameProcessingLatencyMs},
                          "audioActive": ${metrics.isAudioStreaming},
                          "viewers": ${metrics.activeViewers}
                        }
                    """.trimIndent().toByteArray(Charsets.UTF_8)

                    val header = ("HTTP/1.1 200 OK\r\n" +
                            "Content-Type: application/json; charset=utf-8\r\n" +
                            "Content-Length: ${json.size}\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Connection: close\r\n\r\n").toByteArray(Charsets.UTF_8)
                    output.write(header)
                    output.write(json)
                    output.flush()
                }

                else -> {
                    val notFound = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
                        .toByteArray(Charsets.UTF_8)
                    output.write(notFound)
                    output.flush()
                }
            }
        }
    }

    fun stop() {
        try {
            serverJob?.cancel()
            serverSocket?.close()
        } catch (_: Exception) {
        } finally {
            serverSocket = null
            serverJob = null
            activeClients.set(0)
            onViewerCountChanged(0)
            qualityManager.updateActiveClients(0)
        }
    }
}
