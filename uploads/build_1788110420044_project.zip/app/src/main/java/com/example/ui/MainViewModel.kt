package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.quality.QualityPreset
import com.example.quality.StreamMetrics
import com.example.service.ScreenStreamService
import com.example.util.NetworkUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val isStreaming: Boolean = false,
    val localIp: String? = null,
    val port: Int = NetworkUtils.DEFAULT_PORT,
    val streamUrl: String = "",
    val isWifiConnected: Boolean = false,
    val wifiName: String = "Wi-Fi",
    val metrics: StreamMetrics = StreamMetrics(),
    val selectedPreset: QualityPreset = QualityPreset.ULTRA_120FPS,
    val enableAudio: Boolean = true,
    val isAudioStreaming: Boolean = false,
    val showQrCode: Boolean = false,
    val errorMessage: String? = null,
    val copiedFeedback: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        refreshNetworkInfo()
        observeServiceState()
    }

    private fun observeServiceState() {
        viewModelScope.launch {
            ScreenStreamService.isStreaming.collect { streaming ->
                _uiState.update { it.copy(isStreaming = streaming) }
                if (streaming) {
                    refreshNetworkInfo()
                }
            }
        }

        viewModelScope.launch {
            ScreenStreamService.isAudioActive.collect { active ->
                _uiState.update { it.copy(isAudioStreaming = active) }
            }
        }

        viewModelScope.launch {
            ScreenStreamService.qualityManager.metrics.collect { metrics ->
                _uiState.update { 
                    it.copy(
                        metrics = metrics,
                        selectedPreset = metrics.qualityPreset,
                        isAudioStreaming = metrics.isAudioStreaming
                    ) 
                }
            }
        }

        viewModelScope.launch {
            ScreenStreamService.serverUrl.collect { url ->
                if (url != null) {
                    _uiState.update { it.copy(streamUrl = url) }
                }
            }
        }
    }

    fun refreshNetworkInfo() {
        val context = getApplication<Application>()
        val isConnected = NetworkUtils.isConnectedToLocalNetwork(context)
        val ip = NetworkUtils.getLocalIpAddress()
        val currentPort = _uiState.value.port
        val url = NetworkUtils.getStreamUrl(ip, currentPort)
        val wifiName = NetworkUtils.getWifiName(context)

        _uiState.update {
            it.copy(
                isWifiConnected = isConnected,
                localIp = ip,
                streamUrl = url,
                wifiName = wifiName,
                errorMessage = if (!isConnected && ip == null) {
                    "Please connect this phone and your Smart TV to the same Wi-Fi or turn on Mobile Hotspot."
                } else null
            )
        }
    }

    fun setQualityPreset(preset: QualityPreset) {
        ScreenStreamService.qualityManager.setPreset(preset)
        _uiState.update { it.copy(selectedPreset = preset) }
    }

    fun toggleAudio(enabled: Boolean) {
        _uiState.update { it.copy(enableAudio = enabled) }
    }

    fun setPort(port: Int) {
        val validPort = port.coerceIn(1024, 65535)
        val url = NetworkUtils.getStreamUrl(_uiState.value.localIp, validPort)
        _uiState.update { it.copy(port = validPort, streamUrl = url) }
    }

    fun toggleQrCode(show: Boolean? = null) {
        _uiState.update { it.copy(showQrCode = show ?: !it.showQrCode) }
    }

    fun onUrlCopied() {
        _uiState.update { it.copy(copiedFeedback = true) }
        viewModelScope.launch {
            kotlinx.coroutines.delay(2000)
            _uiState.update { it.copy(copiedFeedback = false) }
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }
}
