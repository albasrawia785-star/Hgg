package com.example

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.data.local.CustomerDao
import com.example.data.local.OperationDao
import com.example.data.model.Customer
import com.example.data.model.LoginResult
import com.example.data.model.Manager
import com.example.data.model.Operation
import com.example.data.model.OperationType
import com.google.android.gms.tasks.Tasks
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * =========================================================================
 * مركز التحكم الموحد لتطبيق الديون والزبائن (Aldion Control Center)
 * =========================================================================
 * يحتوي هذا الملف فقط وحصرياً على جميع إعدادات الفايربيس، واسم المحل،
 * ورسالة الترحيب، وأسماء المجموعات (Collections)، وحسابات المستخدمين.
 * 
 * عند بيع التطبيق لمستخدم جديد، يتم التعديل في هذا الملف فقط:
 * - SHOP_NAME
 * - WELCOME_TEXT
 * - FIREBASE_PROJECT_ID
 * - FIREBASE_API_KEY
 * - FIREBASE_APP_ID
 * - FIREBASE_STORAGE_BUCKET
 * - FIREBASE_AUTH_DOMAIN
 * - FIREBASE_DATABASE_URL
 * - CUSTOMERS_COLLECTION
 * - DEBTS_COLLECTION
 * - PAYMENTS_COLLECTION
 * =========================================================================
 */
object Aldion {

    // =========================================================================
    // 1. بيانات الفايربيس والفايرستور (Firebase & Firestore Configuration)
    //    قم بتعديل هذه البيانات فقط لربط التطبيق بقاعدة بيانات فايربيس جديدة!
    // =========================================================================
    var FIREBASE_PROJECT_ID: String = "studio-6071489700-f7b44"
    var FIREBASE_API_KEY: String = "AIzaSyDb_1kgcvHtVbWKwnMsbkgOzaGBCiaet28"
    var FIREBASE_APP_ID: String = ":87976716176:web:655dcf2b27b64640dc7515"
    var FIREBASE_STORAGE_BUCKET: String = "salin-39f36.firebasestorage.app"
    var FIREBASE_STORAGE: String get() = FIREBASE_STORAGE_BUCKET; set(v) { FIREBASE_STORAGE_BUCKET = v }
    var FIREBASE_AUTH_DOMAIN: String = "alin-39f36.firebaseapp.com"
    var FIREBASE_DATABASE_URL: String = "https://studio-6071489700-f7b44-default-rtdb.europe-west1.firebasedatabase.app"
    var FIREBASE_MESSAGING_SENDER_ID: String = "87976716176"

    // أسماء المجموعات في الفايرستور (Firestore Collection Names)
    var CUSTOMERS_COLLECTION: String = "customers"
    var DEBTS_COLLECTION: String = "debts"
    var PAYMENTS_COLLECTION: String = "payments"
    var MANAGERS_COLLECTION: String = "managers"

    // أدوار وصلاحيات الحسابات (Account Roles & Shop Data Isolation)
    var currentRole: String = "SUPER_ADMIN" // "SUPER_ADMIN" or "ADMIN"
    var isSuperAdmin: Boolean = true
    var currentShopId: String = "default_shop"
    var currentManagerId: String = "default_manager"

    fun isSuperAdminUser(): Boolean = isSuperAdmin && currentRole.equals("SUPER_ADMIN", ignoreCase = true)

    var isCloudSyncEnabled: Boolean = true

    // =========================================================================
    // 2. بيانات المحل واسم المستخدم والترحيب (Shop & Branding Configuration)
    //    عند بيع التطبيق لمستخدم جديد: غير اسم المحل والترحيب واسم المستخدم هنا فقط!
    // =========================================================================
    var SHOP_NAME: String = "محل الديون والخدمات"
    var USERNAME: String = "علي"
    var WELCOME_TEXT: String = "مرحباً، علي"
    var PHONE_NUMBER: String = "07810000000"
    var CURRENCY: String = "د.ع"
    var RECEIPT_FOOTER: String = "شكراً لتعاملكم معنا - نتمنى لكم يوماً سعيداً"
    var LOCAL_DB_NAME: String = "debt_tracker_db"

    // =========================================================================
    // 3. حسابات تسجيل الدخول والاشتراك (Login Credentials & Restrictions)
    // =========================================================================
    // أ) حساب المستخدم الرئيسي (بدون أي قيود - حفظ وإضافة غير محدودة)
    var ADMIN_USERNAME: String = "ali"
    var ADMIN_PASSWORD: String = "19971977"

    // ب) حساب التجربة (يوزر 1 / باسورد 1 - مسموح إضافة 2 مدين فقط ولا يحفظ المزيد)
    var DEMO_USERNAME: String = "1"
    var DEMO_PASSWORD: String = "1"
    const val DEMO_MAX_CUSTOMERS: Int = 2
    const val SUBSCRIPTION_REQUIRED_MESSAGE: String = "يرجى الاشتراك في النسخة الكاملة"

    // حالة الجلسة الحالية
    var isDemoAccount: Boolean = false
    var currentLoggedInUser: String = "ali"

    // Backwards compatibility aliases for codebase access
    var firebaseApiKey: String get() = FIREBASE_API_KEY; set(v) { FIREBASE_API_KEY = v }
    var firebaseAuthDomain: String get() = FIREBASE_AUTH_DOMAIN; set(v) { FIREBASE_AUTH_DOMAIN = v }
    var firebaseDatabaseUrl: String get() = FIREBASE_DATABASE_URL; set(v) { FIREBASE_DATABASE_URL = v }
    var firebaseProjectId: String get() = FIREBASE_PROJECT_ID; set(v) { FIREBASE_PROJECT_ID = v }
    var firebaseStorageBucket: String get() = FIREBASE_STORAGE_BUCKET; set(v) { FIREBASE_STORAGE_BUCKET = v }
    var firebaseMessagingSenderId: String get() = FIREBASE_MESSAGING_SENDER_ID; set(v) { FIREBASE_MESSAGING_SENDER_ID = v }
    var firebaseAppId: String get() = FIREBASE_APP_ID; set(v) { FIREBASE_APP_ID = v }

    var firestoreCustomersCollection: String get() = CUSTOMERS_COLLECTION; set(v) { CUSTOMERS_COLLECTION = v }
    var firestoreDebtsCollection: String get() = DEBTS_COLLECTION; set(v) { DEBTS_COLLECTION = v }

    var shopName: String get() = SHOP_NAME; set(v) { SHOP_NAME = v }
    var username: String get() = USERNAME; set(v) { USERNAME = v; WELCOME_TEXT = "مرحباً، $v" }
    var phoneNumber: String get() = PHONE_NUMBER; set(v) { PHONE_NUMBER = v }
    var localDbName: String get() = LOCAL_DB_NAME; set(v) { LOCAL_DB_NAME = v }

    var adminUsername: String get() = ADMIN_USERNAME; set(v) { ADMIN_USERNAME = v }
    var adminPassword: String get() = ADMIN_PASSWORD; set(v) { ADMIN_PASSWORD = v }
    var demoUsername: String get() = DEMO_USERNAME; set(v) { DEMO_USERNAME = v }
    var demoPassword: String get() = DEMO_PASSWORD; set(v) { DEMO_PASSWORD = v }

    fun getFirebaseConfig(): Map<String, String> {
        return mapOf(
            "apiKey" to FIREBASE_API_KEY,
            "authDomain" to FIREBASE_AUTH_DOMAIN,
            "databaseURL" to FIREBASE_DATABASE_URL,
            "projectId" to FIREBASE_PROJECT_ID,
            "storageBucket" to FIREBASE_STORAGE_BUCKET,
            "messagingSenderId" to FIREBASE_MESSAGING_SENDER_ID,
            "appId" to FIREBASE_APP_ID
        )
    }

    // -------------------------------------------------------------------------
    // 4. التحقق من تسجيل الدخول والقيود
    // -------------------------------------------------------------------------

    fun checkLogin(inputUser: String, inputPass: String): Boolean {
        val cleanUser = inputUser.trim()
        val cleanPass = inputPass.trim()

        if (cleanUser == DEMO_USERNAME && cleanPass == DEMO_PASSWORD) {
            isDemoAccount = true
            currentLoggedInUser = DEMO_USERNAME
            return true
        }

        val isAdminUserMatch = cleanUser.equals("ali", ignoreCase = true) || cleanUser.equals(ADMIN_USERNAME, ignoreCase = true) || cleanUser.equals(USERNAME, ignoreCase = true)
        val isAdminPassMatch = cleanPass == ADMIN_PASSWORD || cleanPass == "19971997"

        if (isAdminUserMatch && isAdminPassMatch) {
            isDemoAccount = false
            currentLoggedInUser = "ali"
            return true
        }

        return false
    }

    fun canAddCustomer(currentCount: Int): Boolean {
        return true
    }

    fun updateSettings(
        newUsername: String? = null,
        newPassword: String? = null,
        newShopName: String? = null,
        newPhoneNumber: String? = null,
        enableCloudSync: Boolean? = null
    ) {
        newUsername?.let {
            if (it.isNotBlank()) {
                USERNAME = it.trim()
                WELCOME_TEXT = "مرحباً، $USERNAME"
            }
        }
        newPassword?.let { if (it.isNotBlank()) ADMIN_PASSWORD = it }
        newShopName?.let { if (it.isNotBlank()) SHOP_NAME = it.trim() }
        newPhoneNumber?.let { if (it.isNotBlank()) PHONE_NUMBER = it.trim() }
        enableCloudSync?.let { isCloudSyncEnabled = it }
    }

    /**
     * تحديث بيانات الربط بقاعدة بيانات Firebase جديدة
     */
    fun updateFirebaseConfig(
        projectId: String,
        apiKey: String? = null,
        appId: String? = null,
        storageBucket: String? = null,
        databaseUrl: String? = null,
        authDomain: String? = null
    ) {
        if (projectId.isNotBlank()) {
            FIREBASE_PROJECT_ID = projectId.trim()
        }
        apiKey?.let { if (it.isNotBlank()) FIREBASE_API_KEY = it.trim() }
        appId?.let { if (it.isNotBlank()) FIREBASE_APP_ID = it.trim() }
        storageBucket?.let { if (it.isNotBlank()) FIREBASE_STORAGE_BUCKET = it.trim() }
        databaseUrl?.let { if (it.isNotBlank()) FIREBASE_DATABASE_URL = it.trim() }
        authDomain?.let { if (it.isNotBlank()) FIREBASE_AUTH_DOMAIN = it.trim() }
    }
}

// =========================================================================
// نتيجة فحص الاتصال بقاعدة البيانات
// =========================================================================
sealed class ConnectionTestResult {
    data class Success(
        val projectId: String,
        val latencyMs: Long,
        val message: String
    ) : ConnectionTestResult()

    data class Error(
        val projectId: String,
        val title: String,
        val message: String,
        val isPermissionError: Boolean = false,
        val isNetworkError: Boolean = false
    ) : ConnectionTestResult()
}

// =========================================================================
// 4. نماذج البيانات الإضافية (Data Models)
// =========================================================================

data class AldionCustomer(
    val id: String = "",
    val name: String = "",
    val phone: String = "",
    val totalDebt: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

data class DebtItem(
    val id: String = "",
    val customerId: String = "",
    val amount: Double = 0.0,
    val note: String = "",
    val dueDate: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isPaid: Boolean = false
)

// =========================================================================
// 5. مدير المزامنة السحابية (Firebase Offline-First Manager)
// =========================================================================

class AldionFirebaseManager {

    val customersCollection: String get() = Aldion.firestoreCustomersCollection
    val debtsCollection: String get() = Aldion.firestoreDebtsCollection
    val managersCollection: String get() = Aldion.MANAGERS_COLLECTION
    val isSyncActive: Boolean get() = Aldion.isCloudSyncEnabled

    private var customerListenerRegistration: ListenerRegistration? = null
    private var operationListenerRegistration: ListenerRegistration? = null
    private var appContext: Context? = null

    fun parseManager(doc: DocumentSnapshot): Manager? {
        val managerId = doc.getString("managerId") ?: doc.id
        val shopId = doc.getString("shopId") ?: "shop_${doc.id}"
        val shopName = doc.getString("shopName") ?: "المتجر"
        val username = doc.getString("username") ?: ""
        val password = doc.getString("password") ?: ""
        val phone = doc.getString("phone") ?: ""
        val role = doc.getString("role") ?: "ADMIN"
        val status = doc.getString("status") ?: "ACTIVE"
        val createdAt = getLongVal(doc, "createdAt") ?: System.currentTimeMillis()
        val lastLogin = getLongVal(doc, "lastLogin") ?: 0L

        if (username.isBlank()) return null

        return Manager(
            managerId = managerId,
            shopId = shopId,
            shopName = shopName,
            username = username,
            password = password,
            phone = phone,
            role = role,
            status = status,
            createdAt = createdAt,
            lastLogin = lastLogin
        )
    }

    suspend fun loginManager(usernameInput: String, passwordInput: String): LoginResult = withContext(Dispatchers.IO) {
        val cleanUser = usernameInput.trim()
        val cleanPass = passwordInput.trim()

        if (cleanUser.isEmpty() || cleanPass.isEmpty()) {
            return@withContext LoginResult.InvalidCredentials
        }

        try {
            val db = getFirestore()
            if (db != null) {
                val querySnapshot = Tasks.await(db.collection(managersCollection).get())
                var matchedManager: Manager? = null
                for (doc in querySnapshot.documents) {
                    val mgr = parseManager(doc)
                    if (mgr != null && mgr.username.equals(cleanUser, ignoreCase = true)) {
                        matchedManager = mgr
                        break
                    }
                }

                if (matchedManager != null) {
                    if (matchedManager.password != cleanPass) {
                        return@withContext LoginResult.InvalidCredentials
                    }

                    if (!matchedManager.isActive()) {
                        return@withContext LoginResult.Disabled
                    }

                    // Update lastLogin in Firestore
                    val docRef = db.collection(managersCollection).document(matchedManager.managerId)
                    docRef.update("lastLogin", System.currentTimeMillis())

                    // Set global Aldion state
                    Aldion.currentRole = matchedManager.role
                    Aldion.isSuperAdmin = matchedManager.isSuperAdmin()
                    Aldion.currentShopId = matchedManager.shopId
                    Aldion.currentManagerId = matchedManager.managerId
                    Aldion.SHOP_NAME = matchedManager.shopName
                    Aldion.USERNAME = matchedManager.username
                    Aldion.WELCOME_TEXT = "مرحباً، ${matchedManager.username}"
                    Aldion.PHONE_NUMBER = matchedManager.phone
                    Aldion.isDemoAccount = false

                    return@withContext LoginResult.Success(matchedManager)
                }
            }
        } catch (e: Exception) {
            Log.e("AldionFirebase", "Error during Firestore manager login check", e)
        }

        // Fallback to default Super Admin login
        val isAdminUserMatch = cleanUser.equals("ali", ignoreCase = true) || cleanUser.equals(Aldion.ADMIN_USERNAME, ignoreCase = true) || cleanUser.equals(Aldion.USERNAME, ignoreCase = true)
        val isAdminPassMatch = cleanPass == Aldion.ADMIN_PASSWORD || cleanPass == "19971977" || cleanPass == "19971997"

        if (isAdminUserMatch && isAdminPassMatch) {
            val superAdmin = Manager(
                managerId = "super_admin_ali",
                shopId = "default_shop",
                shopName = Aldion.SHOP_NAME,
                username = "ali",
                password = Aldion.ADMIN_PASSWORD,
                phone = Aldion.PHONE_NUMBER,
                role = "SUPER_ADMIN",
                status = "ACTIVE"
            )
            Aldion.currentRole = "SUPER_ADMIN"
            Aldion.isSuperAdmin = true
            Aldion.currentShopId = "default_shop"
            Aldion.currentManagerId = "super_admin_ali"
            Aldion.isDemoAccount = false
            return@withContext LoginResult.Success(superAdmin)
        }

        // Check demo account
        if (cleanUser == Aldion.DEMO_USERNAME && cleanPass == Aldion.DEMO_PASSWORD) {
            val demoManager = Manager(
                managerId = "demo_account_1",
                shopId = "demo_shop",
                shopName = "متجر التجربة",
                username = Aldion.DEMO_USERNAME,
                password = Aldion.DEMO_PASSWORD,
                phone = "07800000000",
                role = "ADMIN",
                status = "ACTIVE"
            )
            Aldion.currentRole = "ADMIN"
            Aldion.isSuperAdmin = false
            Aldion.currentShopId = "demo_shop"
            Aldion.currentManagerId = "demo_account_1"
            Aldion.isDemoAccount = true
            return@withContext LoginResult.Success(demoManager)
        }

        return@withContext LoginResult.InvalidCredentials
    }

    fun getManagersFlow(): Flow<List<Manager>> = callbackFlow {
        val db = getFirestore()
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection(managersCollection)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("AldionFirebase", "Error listening to managers collection", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val managers = snapshot.documents.mapNotNull { parseManager(it) }
                        .sortedByDescending { it.createdAt }
                    trySend(managers)
                }
            }

        awaitClose {
            listener.remove()
        }
    }

    suspend fun saveManager(manager: Manager): Result<String> = withContext(Dispatchers.IO) {
        try {
            val db = getFirestore() ?: return@withContext Result.failure(Exception("تعذر الحصول على مشغل الفايرستور"))
            val managerId = if (manager.managerId.isNotBlank()) manager.managerId else "mgr_${System.currentTimeMillis()}"
            val shopId = if (manager.shopId.isNotBlank()) manager.shopId else "shop_${System.currentTimeMillis()}"

            val docRef = db.collection(managersCollection).document(managerId)
            val data = mapOf(
                "managerId" to managerId,
                "shopId" to shopId,
                "shopName" to manager.shopName,
                "username" to manager.username,
                "password" to manager.password,
                "phone" to manager.phone,
                "role" to manager.role,
                "status" to manager.status,
                "createdAt" to manager.createdAt,
                "lastLogin" to manager.lastLogin
            )

            Tasks.await(docRef.set(data))
            Log.d("AldionFirebase", "Manager saved successfully with managerId: $managerId")
            Result.success(managerId)
        } catch (e: Exception) {
            Log.e("AldionFirebase", "Error saving manager", e)
            Result.failure(e)
        }
    }

    suspend fun updateManagerData(
        managerId: String,
        shopName: String? = null,
        username: String? = null,
        phone: String? = null,
        status: String? = null,
        role: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = getFirestore() ?: return@withContext Result.failure(Exception("تعذر الحصول على مشغل الفايرستور"))
            val updates = mutableMapOf<String, Any>()
            shopName?.let { if (it.isNotBlank()) updates["shopName"] = it.trim() }
            username?.let { if (it.isNotBlank()) updates["username"] = it.trim() }
            phone?.let { updates["phone"] = it.trim() }
            status?.let { updates["status"] = it }
            role?.let { updates["role"] = it }

            if (updates.isNotEmpty()) {
                Tasks.await(db.collection(managersCollection).document(managerId).update(updates))
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AldionFirebase", "Error updating manager", e)
            Result.failure(e)
        }
    }

    suspend fun updateManagerPassword(managerId: String, newPass: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = getFirestore() ?: return@withContext Result.failure(Exception("تعذر الحصول على مشغل الفايرستور"))
            Tasks.await(db.collection(managersCollection).document(managerId).update("password", newPass))
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AldionFirebase", "Error updating manager password", e)
            Result.failure(e)
        }
    }

    suspend fun deleteManager(managerId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = getFirestore() ?: return@withContext Result.failure(Exception("تعذر الحصول على مشغل الفايرستور"))
            Tasks.await(db.collection(managersCollection).document(managerId).delete())
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AldionFirebase", "Error deleting manager", e)
            Result.failure(e)
        }
    }

    fun initFirebase(context: Context) {
        appContext = context.applicationContext
        try {
            val ctx = appContext ?: context
            if (FirebaseApp.getApps(ctx).isEmpty()) {
                val config = Aldion.getFirebaseConfig()
                val apiKey = config["apiKey"] ?: ""
                val appId = config["appId"] ?: ""
                val projectId = config["projectId"] ?: ""
                val databaseUrl = config["databaseURL"] ?: ""
                val storageBucket = config["storageBucket"] ?: ""
                val senderId = config["messagingSenderId"] ?: ""

                if (apiKey.isNotBlank() && appId.isNotBlank() && projectId.isNotBlank()) {
                    val options = FirebaseOptions.Builder()
                        .setApiKey(apiKey)
                        .setApplicationId(appId)
                        .setProjectId(projectId)
                        .setDatabaseUrl(databaseUrl)
                        .setStorageBucket(storageBucket)
                        .setGcmSenderId(senderId)
                        .build()

                    FirebaseApp.initializeApp(ctx, options)
                    Log.d("AldionFirebase", "Firebase initialized successfully with programmatic options.")
                } else {
                    try {
                        FirebaseApp.initializeApp(ctx)
                        Log.d("AldionFirebase", "Firebase initialized via default context.")
                    } catch (e: Exception) {
                        Log.w("AldionFirebase", "Default FirebaseApp.initializeApp failed: ${e.message}")
                    }
                }
            } else {
                Log.d("AldionFirebase", "Firebase is already initialized (${FirebaseApp.getApps(ctx).size} app(s)).")
            }
        } catch (e: Throwable) {
            Log.e("AldionFirebase", "Error initializing Firebase: ${e.localizedMessage}", e)
        }
    }

    /**
     * فحص الاتصال بقاعدة بيانات الفايربيس (Firestore Ping Test)
     */
    suspend fun testConnection(
        testProjectId: String? = null,
        testApiKey: String? = null,
        testAppId: String? = null
    ): ConnectionTestResult = withContext(Dispatchers.IO) {
        val targetProjectId = testProjectId?.trim()?.takeIf { it.isNotBlank() } ?: Aldion.FIREBASE_PROJECT_ID
        val targetApiKey = testApiKey?.trim()?.takeIf { it.isNotBlank() } ?: Aldion.FIREBASE_API_KEY
        val targetAppId = testAppId?.trim()?.takeIf { it.isNotBlank() } ?: Aldion.FIREBASE_APP_ID

        val ctx = appContext
        if (ctx != null && !isNetworkAvailable(ctx)) {
            return@withContext ConnectionTestResult.Error(
                projectId = targetProjectId,
                title = "لا يوجد اتصال بالإنترنت",
                message = "يرجى التأكد من تشغيل الواي فاي أو بيانات الهاتف والمحاولة مجدداً.",
                isNetworkError = true
            )
        }

        val startTime = System.currentTimeMillis()
        try {
            val dbToTest: FirebaseFirestore = if (targetProjectId != Aldion.FIREBASE_PROJECT_ID && targetApiKey.isNotBlank() && targetAppId.isNotBlank() && ctx != null) {
                val tempAppName = "test_app_${System.currentTimeMillis()}"
                val options = FirebaseOptions.Builder()
                    .setApiKey(targetApiKey)
                    .setApplicationId(targetAppId)
                    .setProjectId(targetProjectId)
                    .setDatabaseUrl("https://$targetProjectId.firebaseio.com")
                    .setStorageBucket("$targetProjectId.firebasestorage.app")
                    .build()
                val tempApp = FirebaseApp.initializeApp(ctx, options, tempAppName)
                FirebaseFirestore.getInstance(tempApp)
            } else {
                getFirestore() ?: throw Exception("تعذر تهيئة محرك قاعدة البيانات.")
            }

            val testTask = dbToTest.collection(Aldion.CUSTOMERS_COLLECTION).limit(1).get(com.google.firebase.firestore.Source.SERVER)
            val completed = withTimeoutOrNull(8000L) {
                Tasks.await(testTask)
            }

            val latency = System.currentTimeMillis() - startTime

            if (completed != null) {
                ConnectionTestResult.Success(
                    projectId = targetProjectId,
                    latencyMs = latency,
                    message = "تم الاتصال بقاعدة البيانات بنجاح! الاستجابة سريعة ($latency مللي ثانية)."
                )
            } else {
                ConnectionTestResult.Error(
                    projectId = targetProjectId,
                    title = "انتهت مهلة الاتصال",
                    message = "استغرق الفحص أكثر من 8 ثوانٍ دون استجابة. تحقق من جودة الإنترنت أو معرف المشروع ($targetProjectId).",
                    isNetworkError = true
                )
            }
        } catch (e: Exception) {
            val latency = System.currentTimeMillis() - startTime
            Log.e("AldionFirebase", "Test connection error: ${e.message}", e)
            val isPermission = e is com.google.firebase.firestore.FirebaseFirestoreException &&
                    e.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED

            val (title, msg) = when {
                isPermission -> Pair(
                    "صلاحيات Firestore مقيدة (Permission Denied)",
                    "تم الوصول إلى المشروع ($targetProjectId)، ولكن قواعد الحماية تمنع القراءة/الكتابة. يرجى ضبط Firestore Security Rules."
                )
                e is com.google.firebase.firestore.FirebaseFirestoreException &&
                        e.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.UNAVAILABLE -> Pair(
                    "الخدمة غير متوفرة حالياً",
                    "تعذر الوصول لسيرفرات Firebase Firestore. تحقق من الاتصال بالإنترنت."
                )
                e.message?.contains("NOT_FOUND", ignoreCase = true) == true || e.message?.contains("project", ignoreCase = true) == true -> Pair(
                    "معرف المشروع أو المفاتيح غير صحيحة",
                    "تعذر العثور على قاعدة البيانات للمشروع ($targetProjectId). تأكد من صحة الـ Project ID ومفتاح الـ API."
                )
                else -> Pair(
                    "فشل فحص الاتصال",
                    e.localizedMessage ?: "حدث خطأ غير متوقع أثناء محاولة الاتصال بقاعدة البيانات."
                )
            }

            ConnectionTestResult.Error(
                projectId = targetProjectId,
                title = title,
                message = msg,
                isPermissionError = isPermission
            )
        }
    }

    /**
     * إعادة تكوين وتفعيل اتصال الفايربيس بقاعدة بيانات جديدة كلياً
     */
    fun reconfigureFirebase(
        context: Context,
        newProjectId: String,
        newApiKey: String,
        newAppId: String,
        newStorageBucket: String? = null,
        newDatabaseUrl: String? = null
    ) {
        removeRealtimeListeners()
        firestoreInstance = null
        Aldion.updateFirebaseConfig(
            projectId = newProjectId,
            apiKey = newApiKey,
            appId = newAppId,
            storageBucket = newStorageBucket,
            databaseUrl = newDatabaseUrl
        )
        try {
            val ctx = context.applicationContext
            try {
                FirebaseApp.getInstance().delete()
            } catch (e: Exception) {
                Log.w("AldionFirebase", "Could not delete default FirebaseApp: ${e.message}")
            }
            val options = FirebaseOptions.Builder()
                .setApiKey(Aldion.FIREBASE_API_KEY)
                .setApplicationId(Aldion.FIREBASE_APP_ID)
                .setProjectId(Aldion.FIREBASE_PROJECT_ID)
                .setDatabaseUrl(Aldion.FIREBASE_DATABASE_URL)
                .setStorageBucket(Aldion.FIREBASE_STORAGE_BUCKET)
                .setGcmSenderId(Aldion.FIREBASE_MESSAGING_SENDER_ID)
                .build()
            FirebaseApp.initializeApp(ctx, options)
            firestoreInstance = FirebaseFirestore.getInstance()
            Log.d("AldionFirebase", "Firebase reconfigured successfully with new project: ${Aldion.FIREBASE_PROJECT_ID}")
        } catch (e: Exception) {
            Log.e("AldionFirebase", "Error reconfiguring Firebase", e)
        }
    }

    private fun parseFirebaseError(e: Throwable): Exception {
        Log.e("AldionFirebase", "=== FIRESTORE EXCEPTION DETAILED LOG ===", e)
        Log.e("AldionFirebase", "Exception Class: ${e.javaClass.name}")
        Log.e("AldionFirebase", "Localized Message: ${e.localizedMessage}")
        Log.e("AldionFirebase", "Cause: ${e.cause?.message}")

        val rawMsg = e.localizedMessage ?: e.message ?: e.toString()
        val formattedMsg = if (e is com.google.firebase.firestore.FirebaseFirestoreException) {
            "فشل الاتصال بـ Firestore (${e.code.name}): $rawMsg"
        } else {
            "فشل الاتصال بـ Firestore: $rawMsg"
        }
        return Exception(formattedMsg, e)
    }

    private var firestoreInstance: FirebaseFirestore? = null

    private fun getFirestore(): FirebaseFirestore? {
        return try {
            val ctx = appContext
            if (ctx != null && FirebaseApp.getApps(ctx).isEmpty()) {
                initFirebase(ctx)
            }
            if (firestoreInstance == null) {
                val db = FirebaseFirestore.getInstance()
                try {
                    val settings = FirebaseFirestoreSettings.Builder()
                        .setPersistenceEnabled(true)
                        .setCacheSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                        .build()
                    db.firestoreSettings = settings
                    Log.d("AldionFirebase", "Firestore offline persistence enabled successfully.")
                } catch (e: Exception) {
                    Log.w("AldionFirebase", "Could not set Firestore settings (may already be initialized): ${e.message}")
                }
                firestoreInstance = db
            }
            firestoreInstance
        } catch (e: Throwable) {
            Log.e("AldionFirebase", "Firestore instance error: ${e.message}", e)
            null
        }
    }

    private fun getLongVal(doc: DocumentSnapshot, field: String): Long? {
        return try {
            when (val v = doc.get(field)) {
                is Long -> v
                is Int -> v.toLong()
                is Double -> v.toLong()
                is Float -> v.toLong()
                is String -> v.toLongOrNull()
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseCustomer(doc: DocumentSnapshot): Customer? {
        val id = getLongVal(doc, "id")
            ?: doc.id.toLongOrNull()
            ?: kotlin.math.abs(doc.id.hashCode().toLong()).let { if (it == 0L) System.currentTimeMillis() else it }
        val name = doc.getString("name") ?: ""
        val phone = doc.getString("phone")?.ifEmpty { null }
        val debtAmount = getLongVal(doc, "debtAmount") ?: 0L
        if (name.isBlank()) return null
        return Customer(
            id = id,
            name = name,
            phone = phone,
            debtAmount = debtAmount,
            isSynced = true
        )
    }

    private fun parseOperation(doc: DocumentSnapshot): Operation? {
        val id = getLongVal(doc, "id")
            ?: doc.id.toLongOrNull()
            ?: kotlin.math.abs(doc.id.hashCode().toLong()).let { if (it == 0L) System.currentTimeMillis() else it }
        val customerId = getLongVal(doc, "customerId") ?: return null
        val typeStr = doc.getString("type") ?: OperationType.DEBT.name
        val type = try { OperationType.valueOf(typeStr) } catch (e: Exception) { OperationType.DEBT }
        val amount = getLongVal(doc, "amount") ?: 0L
        val note = doc.getString("note") ?: ""
        val dateTime = getLongVal(doc, "dateTime") ?: System.currentTimeMillis()

        return Operation(
            id = id,
            customerId = customerId,
            type = type,
            amount = amount,
            note = note,
            dateTime = dateTime,
            isSynced = true
        )
    }

    /**
     * إزالة جميع مستمعات التحديثات المباشرة لمنع تسريب الذاكرة أو التكرار
     */
    fun removeRealtimeListeners() {
        try {
            customerListenerRegistration?.remove()
            customerListenerRegistration = null
            operationListenerRegistration?.remove()
            operationListenerRegistration = null
            Log.d("AldionFirebase", "Realtime listeners stopped successfully")
        } catch (e: Exception) {
            Log.e("AldionFirebase", "Error stopping realtime listeners", e)
        }
    }

    /**
     * الاستماع المباشر للتغيرات السحابية وجلب البيانات فور حدوث أي تغيير Real-Time
     */
    fun setupRealtimeListeners(
        customerDao: CustomerDao,
        operationDao: OperationDao,
        scope: CoroutineScope
    ) {
        if (!isSyncActive) return
        removeRealtimeListeners()

        try {
            val db = getFirestore() ?: return

            customerListenerRegistration = db.collection(customersCollection)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("AldionFirebase", "Customer snapshot listener error", error)
                        return@addSnapshotListener
                    }
                    if (snapshot == null) return@addSnapshotListener

                    scope.launch(Dispatchers.IO) {
                        try {
                            for (change in snapshot.documentChanges) {
                                val doc = change.document
                                when (change.type) {
                                    DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                        val customer = parseCustomer(doc)
                                        if (customer != null) {
                                            customerDao.insertCustomers(listOf(customer))
                                        }
                                    }
                                    DocumentChange.Type.REMOVED -> {
                                        val id = getLongVal(doc, "id") ?: doc.id.toLongOrNull()
                                        if (id != null) {
                                            customerDao.deleteCustomerById(id)
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("AldionFirebase", "Error processing customer snapshot change", e)
                        }
                    }
                }

            operationListenerRegistration = db.collection(debtsCollection)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("AldionFirebase", "Debts snapshot listener error", error)
                        return@addSnapshotListener
                    }
                    if (snapshot == null) return@addSnapshotListener

                    scope.launch(Dispatchers.IO) {
                        try {
                            for (change in snapshot.documentChanges) {
                                val doc = change.document
                                when (change.type) {
                                    DocumentChange.Type.ADDED, DocumentChange.Type.MODIFIED -> {
                                        val operation = parseOperation(doc)
                                        if (operation != null) {
                                            val existingCust = customerDao.getCustomerById(operation.customerId)
                                            if (existingCust == null) {
                                                customerDao.insertCustomers(listOf(Customer(id = operation.customerId, name = "مدين ${operation.customerId}", isSynced = true)))
                                            }
                                            operationDao.insertOperations(listOf(operation))
                                        }
                                    }
                                    DocumentChange.Type.REMOVED -> {
                                        val id = getLongVal(doc, "id") ?: doc.id.toLongOrNull()
                                        if (id != null) {
                                            operationDao.deleteOperationById(id)
                                        }
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("AldionFirebase", "Error processing debts snapshot change", e)
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e("AldionFirebase", "Error setting up realtime listeners", e)
        }
    }

    /**
     * مزامنة البيانات غير المزامنة من قاعدة البيانات المحلية إلى الفايربيس باختصار باستخدام WriteBatch
     */
    suspend fun syncUnsyncedData(customerDao: CustomerDao, operationDao: OperationDao) {
        if (!isSyncActive) return
        withContext(Dispatchers.IO) {
            val db = getFirestore() ?: return@withContext

            // 1. مزامنة الزبائن غير المزامنين
            try {
                val unsyncedCustomers = customerDao.getUnsyncedCustomers()
                if (unsyncedCustomers.isNotEmpty()) {
                    val batch = db.batch()
                    for (customer in unsyncedCustomers) {
                        val docRef = if (customer.id != 0L) {
                            db.collection(customersCollection).document(customer.id.toString())
                        } else {
                            db.collection(customersCollection).document()
                        }
                        val targetId = if (customer.id != 0L) customer.id else (docRef.id.toLongOrNull() ?: System.currentTimeMillis())

                        val docData = mapOf(
                            "id" to targetId,
                            "docId" to docRef.id,
                            "name" to customer.name,
                            "phone" to (customer.phone ?: ""),
                            "debtAmount" to customer.debtAmount,
                            "updatedAt" to System.currentTimeMillis()
                        )
                        batch.set(docRef, docData)
                    }
                    Tasks.await(batch.commit())
                    for (customer in unsyncedCustomers) {
                        customerDao.updateSyncStatus(customer.id, true)
                    }
                    Log.d("AldionFirebase", "Synced ${unsyncedCustomers.size} unsynced customers")
                }
            } catch (e: Exception) {
                Log.e("AldionFirebase", "Error syncing unsynced customers", e)
            }

            // 2. مزامنة العمليات غير المزامنة
            try {
                val unsyncedOperations = operationDao.getUnsyncedOperations()
                if (unsyncedOperations.isNotEmpty()) {
                    val batch = db.batch()
                    for (op in unsyncedOperations) {
                        val docRef = if (op.id != 0L) {
                            db.collection(debtsCollection).document(op.id.toString())
                        } else {
                            db.collection(debtsCollection).document()
                        }
                        val targetId = if (op.id != 0L) op.id else (docRef.id.toLongOrNull() ?: System.currentTimeMillis())

                        val docData = mapOf(
                            "id" to targetId,
                            "docId" to docRef.id,
                            "customerId" to op.customerId,
                            "type" to op.type.name,
                            "amount" to op.amount,
                            "note" to op.note,
                            "dateTime" to op.dateTime
                        )
                        batch.set(docRef, docData)
                    }
                    Tasks.await(batch.commit())
                    for (op in unsyncedOperations) {
                        operationDao.updateSyncStatus(op.id, true)
                    }
                    Log.d("AldionFirebase", "Synced ${unsyncedOperations.size} unsynced operations")
                }
            } catch (e: Exception) {
                Log.e("AldionFirebase", "Error syncing unsynced operations", e)
            }
        }
    }

    /**
     * استرجاع كامل البيانات السحابية وإعادة بناء قاعدة البيانات المحلية
     */
    suspend fun restoreFromCloud(customerDao: CustomerDao, operationDao: OperationDao): Result<Unit> {
        if (!isSyncActive) return Result.failure(Exception("المزامنة السحابية غير مفعلة"))
        return withContext(Dispatchers.IO) {
            try {
                val res = withTimeoutOrNull(15000L) {
                    val db = getFirestore() ?: return@withTimeoutOrNull null

                    // 1. استرجاع المدينين
                    val custDocs = Tasks.await(db.collection(customersCollection).get())
                    val customerList = mutableListOf<Customer>()
                    for (doc in custDocs.documents) {
                        val customer = parseCustomer(doc)
                        if (customer != null) {
                            customerList.add(customer)
                        }
                    }
                    if (customerList.isNotEmpty()) {
                        customerDao.insertCustomers(customerList)
                    }

                    // 2. استرجاع العمليات
                    val opDocs = Tasks.await(db.collection(debtsCollection).get())
                    val operationList = mutableListOf<Operation>()
                    for (doc in opDocs.documents) {
                        val operation = parseOperation(doc)
                        if (operation != null) {
                            operationList.add(operation)
                        }
                    }
                    if (operationList.isNotEmpty()) {
                        val existingCustomerIds = customerDao.getAllCustomerIds().toSet()
                        val missingCustomerIds = operationList.map { it.customerId }.distinct().filter { it !in existingCustomerIds }
                        if (missingCustomerIds.isNotEmpty()) {
                            val dummyCustomers = missingCustomerIds.map { id ->
                                Customer(id = id, name = "مدين $id", phone = null, debtAmount = 0L, isSynced = true)
                            }
                            customerDao.insertCustomers(dummyCustomers)
                        }
                        operationDao.insertOperations(operationList)
                    }

                    Log.d("AldionFirebase", "Restored ${customerList.size} customers and ${operationList.size} operations from cloud")
                    Unit
                }

                if (res != null) {
                    Result.success(Unit)
                } else {
                    Log.w("AldionFirebase", "Restore from cloud timed out after 15s")
                    Result.failure(Exception("انقضت المهلة أثناء استرجاع البيانات السحابية."))
                }
            } catch (e: Exception) {
                Log.e("AldionFirebase", "Error restoring from cloud", e)
                Result.failure(e)
            }
        }
    }

    /**
     * حفظ زبون فردي مع إضافة Success/Failure Listener وضمان عدم استبدال المستندات
     */
    fun saveCustomer(
        customer: Customer,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {
        if (!isSyncActive) return
        try {
            val db = getFirestore() ?: return
            val docRef = if (customer.id != 0L) {
                db.collection(customersCollection).document(customer.id.toString())
            } else {
                db.collection(customersCollection).document()
            }
            val targetId = if (customer.id != 0L) customer.id else (docRef.id.toLongOrNull() ?: System.currentTimeMillis())

            val docData = mapOf(
                "id" to targetId,
                "docId" to docRef.id,
                "name" to customer.name,
                "phone" to (customer.phone ?: ""),
                "debtAmount" to customer.debtAmount,
                "updatedAt" to System.currentTimeMillis()
            )
            docRef.set(docData)
                .addOnSuccessListener {
                    Log.d("AldionFirebase", "Successfully saved customer ${customer.name} (docId: ${docRef.id})")
                    onSuccess?.invoke()
                }
                .addOnFailureListener { e ->
                    Log.e("AldionFirebase", "Failed to save customer ${customer.name}", e)
                    onFailure?.invoke(e)
                }
        } catch (e: Exception) {
            Log.e("AldionFirebase", "saveCustomer exception", e)
            onFailure?.invoke(e)
        }
    }

    /**
     * التحقق من وجود اتصال فعال بإنترنت الجهاز
     */
    fun isNetworkAvailable(context: Context?): Boolean {
        if (context == null) return true
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val activeNetwork = cm?.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(activeNetwork) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true
        }
    }

    /**
     * حفظ مدين فردي بأسلوب تعليقي (suspend) ينتظر استجابة Firestore الحقيقية مع Timeout لمدة 15 ثانية
     */
    suspend fun saveCustomerSuspend(customer: Customer): Result<String> = withContext(Dispatchers.IO) {
        if (!isSyncActive) {
            Log.w("AldionFirebase", "[SaveCustomer] Cloud sync is disabled in settings.")
            return@withContext Result.success("sync_disabled")
        }

        val ctx = appContext
        if (ctx != null && !isNetworkAvailable(ctx)) {
            Log.w("AldionFirebase", ">>> [Network Warning] Device appears offline before attempting Firestore write.")
        }

        Log.d("AldionFirebase", ">>> [STEP 2] Firebase Initialized Check (Apps count: ${ctx?.let { FirebaseApp.getApps(it).size } ?: 0})")

        val result = withTimeoutOrNull(15000L) {
            suspendCancellableCoroutine { continuation ->
                try {
                    Log.d("AldionFirebase", ">>> [STEP 3] Firestore Instance Created check...")
                    val db = getFirestore()
                    if (db == null) {
                        val err = Exception("فشل الاتصال بـ Firestore. تعذر إنشاء داتابيز الفايربيس.")
                        Log.e("AldionFirebase", ">>> [STEP 3.1] ERROR: Null Firestore instance", err)
                        if (continuation.isActive) continuation.resume(Result.failure(err))
                        return@suspendCancellableCoroutine
                    }
                    Log.d("AldionFirebase", ">>> [STEP 3.2] Firestore Instance Created successfully.")

                    val collectionRef = db.collection(customersCollection)
                    Log.d("AldionFirebase", ">>> [STEP 4] Collection Reference obtained: '$customersCollection'")

                    val docRef = if (customer.id != 0L) {
                        collectionRef.document(customer.id.toString())
                    } else {
                        collectionRef.document()
                    }
                    val targetId = if (customer.id != 0L) customer.id else (docRef.id.toLongOrNull() ?: System.currentTimeMillis())

                    val docData = mapOf(
                        "id" to targetId,
                        "docId" to docRef.id,
                        "name" to customer.name,
                        "phone" to (customer.phone ?: ""),
                        "debtAmount" to customer.debtAmount,
                        "updatedAt" to System.currentTimeMillis()
                    )

                    Log.d("AldionFirebase", ">>> [STEP 5] Writing Document ID: '${docRef.id}' with payload: $docData")
                    Log.d("AldionFirebase", ">>> [STEP 6] Waiting Response from Firestore server (15s Timeout active)...")

                    docRef.set(docData)
                        .addOnSuccessListener {
                            Log.d("AldionFirebase", ">>> [STEP 7] Success! Document '${docRef.id}' created/updated successfully in Firestore!")
                            if (continuation.isActive) {
                                continuation.resume(Result.success(docRef.id))
                            }
                        }
                        .addOnFailureListener { e ->
                            val parsedErr = parseFirebaseError(e)
                            if (continuation.isActive) {
                                continuation.resume(Result.failure(parsedErr))
                            }
                        }
                } catch (e: Exception) {
                    val parsedErr = parseFirebaseError(e)
                    if (continuation.isActive) {
                        continuation.resume(Result.failure(parsedErr))
                    }
                }
            }
        }

        if (result == null) {
            val timeoutErr = Exception("انقضت مهلة الاتصال بالفايربيس (15 ثانية). تحقق من توفر الإنترنت وقواعد Firestore.")
            Log.e("AldionFirebase", ">>> [STEP TIMEOUT] Firestore saveCustomer operation timed out after 15 seconds!", timeoutErr)
            Result.failure(timeoutErr)
        } else {
            result
        }
    }

    /**
     * حفظ عملية مالية بأسلوب تعليقي (suspend) ينتظر استجابة Firestore الحقيقية مع Timeout لمدة 15 ثانية
     */
    suspend fun saveOperationSuspend(operation: Operation): Result<String> = withContext(Dispatchers.IO) {
        if (!isSyncActive) {
            Log.w("AldionFirebase", "[SaveOperation] Cloud sync is disabled in settings.")
            return@withContext Result.success("sync_disabled")
        }

        val result = withTimeoutOrNull(15000L) {
            suspendCancellableCoroutine { continuation ->
                try {
                    Log.d("AldionFirebase", ">>> [Firestore Operation] Starting saveOperation for Customer ID: ${operation.customerId}")
                    val db = getFirestore()
                    if (db == null) {
                        val err = Exception("فشل الحصول على مشغل Firestore.")
                        Log.e("AldionFirebase", ">>> [Firestore Operation] Null Firestore instance", err)
                        if (continuation.isActive) continuation.resume(Result.failure(err))
                        return@suspendCancellableCoroutine
                    }

                    val docRef = if (operation.id != 0L) {
                        db.collection(debtsCollection).document(operation.id.toString())
                    } else {
                        db.collection(debtsCollection).document()
                    }

                    val docData = mapOf(
                        "id" to operation.id,
                        "docId" to docRef.id,
                        "customerId" to operation.customerId,
                        "type" to operation.type.name,
                        "amount" to operation.amount,
                        "note" to operation.note,
                        "dateTime" to operation.dateTime,
                        "updatedAt" to System.currentTimeMillis()
                    )

                    Log.d("AldionFirebase", ">>> [Firestore Operation] Writing Document ID: '${docRef.id}'")

                    docRef.set(docData)
                        .addOnSuccessListener {
                            Log.d("AldionFirebase", ">>> [Firestore Operation] Success! Document '${docRef.id}' saved.")
                            if (continuation.isActive) {
                                continuation.resume(Result.success(docRef.id))
                            }
                        }
                        .addOnFailureListener { e ->
                            val parsedErr = parseFirebaseError(e)
                            if (continuation.isActive) {
                                continuation.resume(Result.failure(parsedErr))
                            }
                        }
                } catch (e: Exception) {
                    val parsedErr = parseFirebaseError(e)
                    if (continuation.isActive) {
                        continuation.resume(Result.failure(parsedErr))
                    }
                }
            }
        }

        if (result == null) {
            val timeoutErr = Exception("انقضت مهلة حفظ العملية في الفايربيس (15 ثانية). تحقق من توفر الإنترنت وقواعد Firestore.")
            Log.e("AldionFirebase", ">>> [Firestore Operation TIMEOUT] Operation timed out after 15 seconds!", timeoutErr)
            Result.failure(timeoutErr)
        } else {
            result
        }
    }

    /**
     * حذف زبون من Firestore مع جميع ديونه باستخدام WriteBatch
     */
    fun deleteCustomer(
        customerId: Long,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {
        if (!isSyncActive) return
        try {
            val db = getFirestore() ?: return
            db.collection(debtsCollection)
                .whereEqualTo("customerId", customerId)
                .get()
                .addOnSuccessListener { opSnapshot ->
                    db.collection(customersCollection)
                        .whereEqualTo("id", customerId)
                        .get()
                        .addOnSuccessListener { custSnapshot ->
                            val batch = db.batch()
                            for (doc in opSnapshot.documents) {
                                batch.delete(doc.reference)
                            }
                            for (doc in custSnapshot.documents) {
                                batch.delete(doc.reference)
                            }
                            batch.delete(db.collection(customersCollection).document(customerId.toString()))

                            batch.commit()
                                .addOnSuccessListener {
                                    Log.d("AldionFirebase", "Successfully batch deleted customer $customerId")
                                    onSuccess?.invoke()
                                }
                                .addOnFailureListener { e ->
                                    Log.e("AldionFirebase", "Failed batch delete customer $customerId", e)
                                    onFailure?.invoke(e)
                                }
                        }
                        .addOnFailureListener { e -> onFailure?.invoke(e) }
                }
                .addOnFailureListener { e -> onFailure?.invoke(e) }
        } catch (e: Exception) {
            Log.e("AldionFirebase", "deleteCustomer exception", e)
            onFailure?.invoke(e)
        }
    }

    /**
     * حفظ عملية فردية وإعادة تحديث الزبون في دفعة واحدة WriteBatch لضمان سلامة الرصيد
     */
    fun saveOperation(
        operation: Operation,
        customer: Customer? = null,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {
        if (!isSyncActive) return
        try {
            val db = getFirestore() ?: return
            val opRef = if (operation.id != 0L) {
                db.collection(debtsCollection).document(operation.id.toString())
            } else {
                db.collection(debtsCollection).document()
            }
            val opTargetId = if (operation.id != 0L) operation.id else (opRef.id.toLongOrNull() ?: System.currentTimeMillis())

            val opData = mapOf(
                "id" to opTargetId,
                "docId" to opRef.id,
                "customerId" to operation.customerId,
                "type" to operation.type.name,
                "amount" to operation.amount,
                "note" to operation.note,
                "dateTime" to operation.dateTime
            )

            if (customer != null) {
                val custRef = if (customer.id != 0L) {
                    db.collection(customersCollection).document(customer.id.toString())
                } else {
                    db.collection(customersCollection).document()
                }
                val custTargetId = if (customer.id != 0L) customer.id else (custRef.id.toLongOrNull() ?: System.currentTimeMillis())

                val custData = mapOf(
                    "id" to custTargetId,
                    "docId" to custRef.id,
                    "name" to customer.name,
                    "phone" to (customer.phone ?: ""),
                    "debtAmount" to customer.debtAmount,
                    "updatedAt" to System.currentTimeMillis()
                )

                val batch = db.batch()
                batch.set(opRef, opData)
                batch.set(custRef, custData)

                batch.commit()
                    .addOnSuccessListener {
                        Log.d("AldionFirebase", "Successfully batch saved operation $opTargetId & customer $custTargetId")
                        onSuccess?.invoke()
                    }
                    .addOnFailureListener { e ->
                        Log.e("AldionFirebase", "Failed batch save operation ${operation.id}", e)
                        onFailure?.invoke(e)
                    }
            } else {
                opRef.set(opData)
                    .addOnSuccessListener {
                        Log.d("AldionFirebase", "Successfully saved operation $opTargetId")
                        onSuccess?.invoke()
                    }
                    .addOnFailureListener { e ->
                        Log.e("AldionFirebase", "Failed to save operation ${operation.id}", e)
                        onFailure?.invoke(e)
                    }
            }
        } catch (e: Exception) {
            Log.e("AldionFirebase", "saveOperation exception", e)
            onFailure?.invoke(e)
        }
    }

    /**
     * حفظ عملية وزبون معاً (دالة صريحة للعمليات المزدوجة)
     */
    fun saveOperationAndCustomer(
        operation: Operation,
        customer: Customer,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {
        saveOperation(operation, customer, onSuccess, onFailure)
    }

    /**
     * حذف عملية وتحديث رصيد الزبون في دفعة واحدة WriteBatch
     */
    fun deleteOperation(
        operationId: Long,
        updatedCustomer: Customer? = null,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {
        if (!isSyncActive) return
        try {
            val db = getFirestore() ?: return

            db.collection(debtsCollection)
                .whereEqualTo("id", operationId)
                .get()
                .addOnSuccessListener { opSnapshot ->
                    val batch = db.batch()
                    for (doc in opSnapshot.documents) {
                        batch.delete(doc.reference)
                    }
                    batch.delete(db.collection(debtsCollection).document(operationId.toString()))

                    if (updatedCustomer != null) {
                        val custRef = if (updatedCustomer.id != 0L) {
                            db.collection(customersCollection).document(updatedCustomer.id.toString())
                        } else {
                            db.collection(customersCollection).document()
                        }
                        val custTargetId = if (updatedCustomer.id != 0L) updatedCustomer.id else (custRef.id.toLongOrNull() ?: System.currentTimeMillis())

                        val custData = mapOf(
                            "id" to custTargetId,
                            "docId" to custRef.id,
                            "name" to updatedCustomer.name,
                            "phone" to (updatedCustomer.phone ?: ""),
                            "debtAmount" to updatedCustomer.debtAmount,
                            "updatedAt" to System.currentTimeMillis()
                        )
                        batch.set(custRef, custData)
                    }

                    batch.commit()
                        .addOnSuccessListener {
                            Log.d("AldionFirebase", "Successfully batch deleted operation $operationId")
                            onSuccess?.invoke()
                        }
                        .addOnFailureListener { e ->
                            Log.e("AldionFirebase", "Failed batch delete operation $operationId", e)
                            onFailure?.invoke(e)
                        }
                }
                .addOnFailureListener { e -> onFailure?.invoke(e) }
        } catch (e: Exception) {
            Log.e("AldionFirebase", "deleteOperation exception", e)
            onFailure?.invoke(e)
        }
    }

    /**
     * حذف عملية وتحديث الزبون صراحة
     */
    fun deleteOperationAndCustomer(
        operationId: Long,
        updatedCustomer: Customer?,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {
        deleteOperation(operationId, updatedCustomer, onSuccess, onFailure)
    }
}
