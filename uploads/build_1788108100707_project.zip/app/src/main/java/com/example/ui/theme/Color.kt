package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Notion & Linear Inspired Minimalist Light Palette
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Slate950 = Color(0xFF020617)

val PureWhite = Color(0xFFFFFFFF)
val AccentBlue = Color(0xFF2563EB)
val AccentEmerald = Color(0xFF059669)
val EmeraldLight = Color(0xFFECFDF5)
val AccentAmber = Color(0xFFD97706)
val AmberLight = Color(0xFFFFFBEB)
val AccentRed = Color(0xFFDC2626)
val RedLight = Color(0xFFFEF2F2)
