package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.quality.QualityPreset
import com.example.quality.StreamQualityManager
import com.example.util.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

class ScreenStreamService : Service() {

    companion object {
        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_DATA_INTENT = "EXTRA_DATA_INTENT"
        const val EXTRA_PORT = "EXTRA_PORT"

        private const val NOTIFICATION_ID = 4040
        private const val CHANNEL_ID = "screen_stream_channel"

        val qualityManager = StreamQualityManager()

        private val _isStreaming = MutableStateFlow(false)
        val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

        private val _serverUrl = MutableStateFlow<String?>(null)
        val serverUrl: StateFlow<String?> = _serverUrl.asStateFlow()

        private val _connectedClients = MutableStateFlow(0)
        val connectedClients: StateFlow<Int> = _connectedClients.asStateFlow()

        fun start(context: Context, resultCode: Int, data: Intent, port: Int = NetworkUtils.DEFAULT_PORT) {
            val intent = Intent(context, ScreenStreamService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA_INTENT, data)
                putExtra(EXTRA_PORT, port)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, ScreenStreamService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var httpServer: ScreenHttpServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private var screenWidth = 720
    private var screenHeight = 1280
    private var screenDensity = 320
    private var port = NetworkUtils.DEFAULT_PORT

    private val activeSubscribers = AtomicInteger(0)
    private val latestFrame = AtomicReference<ByteArray?>(null)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA_INTENT)
                }
                port = intent.getIntExtra(EXTRA_PORT, NetworkUtils.DEFAULT_PORT)

                if (resultCode != 0 && data != null) {
                    startStreamingService(resultCode, data)
                } else {
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                stopStreaming()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startStreamingService(resultCode: Int, data: Intent) {
        // Prevent CPU and Wi-Fi sleep on aggressive power-saving devices (e.g. Infinix XOS / MediaTek GT series)
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ScreenCast:WakeLock").apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L)
            }
        } catch (_: Exception) {}

        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiLock = wifiManager.createWifiLock(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF,
                "ScreenCast:WifiLock"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}

        val ip = NetworkUtils.getLocalIpAddress()
        val url = NetworkUtils.getStreamUrl(ip, port)
        _serverUrl.value = url

        val notification = createNotification(url)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        setupDisplayMetrics()
        startHttpServer(port)
        startScreenCapture(resultCode, data)
        _isStreaming.value = true
    }

    private fun setupDisplayMetrics() {
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            screenWidth = bounds.width()
            screenHeight = bounds.height()
            screenDensity = resources.configuration.densityDpi
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi
        }
    }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        val mainHandler = Handler(Looper.getMainLooper())
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopStreaming()
                stopSelf()
            }
        }, mainHandler)

        val scale = qualityManager.getScaleFactor()
        val captureWidth = ((screenWidth * scale).toInt() / 2) * 2
        val captureHeight = ((screenHeight * scale).toInt() / 2) * 2

        imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 3)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScreenCastVirtualDisplay",
            captureWidth,
            captureHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            mainHandler
        )

        serviceScope.launch {
            frameCaptureLoop(captureWidth, captureHeight)
        }
    }

    private suspend fun frameCaptureLoop(width: Int, height: Int) {
        val bufferStream = ByteArrayOutputStream(width * height / 2)
        var reusableBitmap: Bitmap? = null

        while (serviceScope.isActive) {
            val loopStart = System.currentTimeMillis()
            var image: Image? = null
            try {
                image = imageReader?.acquireLatestImage()
                if (image != null) {
                    val planes = image.planes
                    val buffer: ByteBuffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * width

                    val bitmapWidth = width + rowPadding / pixelStride
                    if (reusableBitmap == null || reusableBitmap.width != bitmapWidth || reusableBitmap.height != height) {
                        reusableBitmap?.recycle()
                        reusableBitmap = Bitmap.createBitmap(bitmapWidth, height, Bitmap.Config.ARGB_8888)
                    }

                    reusableBitmap.copyPixelsFromBuffer(buffer)

                    // Crop to exact width if there is padding
                    val finalBitmap = if (rowPadding > 0) {
                        Bitmap.createBitmap(reusableBitmap, 0, 0, width, height)
                    } else {
                        reusableBitmap
                    }

                    bufferStream.reset()
                    val compressionQuality = qualityManager.getJpegQuality()
                    finalBitmap.compress(Bitmap.CompressFormat.JPEG, compressionQuality, bufferStream)

                    val frameBytes = bufferStream.toByteArray()
                    latestFrame.set(frameBytes)

                    val duration = System.currentTimeMillis() - loopStart
                    qualityManager.recordFrameProcessed(frameBytes.size, duration)

                    if (rowPadding > 0 && finalBitmap != reusableBitmap) {
                        finalBitmap.recycle()
                    }
                }
            } catch (_: Exception) {
                // Ignore transient image acquisition errors
            } finally {
                image?.close()
            }

            val targetInterval = qualityManager.getTargetFrameIntervalMs()
            val timeTaken = System.currentTimeMillis() - loopStart
            val waitTime = (targetInterval - timeTaken).coerceAtLeast(10L)
            delay(waitTime)
        }

        reusableBitmap?.recycle()
    }

    private fun startHttpServer(serverPort: Int) {
        httpServer?.stop()
        httpServer = ScreenHttpServer(
            port = serverPort,
            qualityManager = qualityManager,
            latestFrame = latestFrame,
            onViewerCountChanged = { count ->
                _connectedClients.value = count
            },
            htmlSupplier = { generatePlayerHtml() }
        ).apply {
            start(serviceScope)
        }
    }

    private fun generatePlayerHtml(): String {
        return """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>CastScreen TV — Live Screen Mirror</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        body {
            background-color: #0B0F17;
            color: #E2E8F0;
            display: flex;
            flex-direction: column;
            height: 100vh;
            overflow: hidden;
        }
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 24px;
            background: #111827;
            border-bottom: 1px solid #1F2937;
            z-index: 10;
        }
        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .brand-dot {
            width: 10px;
            height: 10px;
            background-color: #10B981;
            border-radius: 50%;
            box-shadow: 0 0 8px #10B981;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(0.9); }
        }
        .title {
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 0.3px;
            color: #F8FAFC;
        }
        .subtitle {
            font-size: 12px;
            color: #94A3B8;
        }
        .stats-bar {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .stat-item {
            font-size: 12px;
            color: #94A3B8;
        }
        .stat-value {
            font-weight: 600;
            color: #F8FAFC;
        }
        .btn {
            background-color: #1E293B;
            border: 1px solid #334155;
            color: #F8FAFC;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            outline: none;
            transition: all 0.15s ease;
        }
        .btn:hover, .btn:focus {
            background-color: #334155;
            border-color: #475569;
        }
        main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #030712;
            position: relative;
            overflow: hidden;
        }
        #stream-container {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #stream-image {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            user-select: none;
            -webkit-user-drag: none;
        }
        .remote-hint {
            position: absolute;
            bottom: 20px;
            background: rgba(15, 23, 42, 0.85);
            border: 1px solid #334155;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            color: #94A3B8;
            pointer-events: none;
            opacity: 0.85;
            transition: opacity 0.5s ease;
        }
        .fullscreen-active header {
            display: none;
        }
    </style>
</head>
<body>
    <header id="header">
        <div class="brand">
            <div class="brand-dot"></div>
            <div>
                <div class="title">CastScreen TV</div>
                <div class="subtitle">Direct Local Wi-Fi Mirror</div>
            </div>
        </div>
        <div class="stats-bar">
            <div class="stat-item">Status: <span class="stat-value" style="color: #10B981;">Active Live</span></div>
            <div class="stat-item">Network: <span class="stat-value">Local LAN</span></div>
            <button class="btn" id="fs-btn" onclick="toggleFullscreen()">Enter Fullscreen</button>
        </div>
    </header>

    <main id="main-view">
        <div id="stream-container">
            <img id="stream-image" src="/stream" alt="Live Screen Stream" onerror="handleStreamError()" />
        </div>
        <div class="remote-hint" id="hint">Press OK / Enter on TV remote for Fullscreen</div>
    </main>

    <script>
        const img = document.getElementById('stream-image');
        const hint = document.getElementById('hint');
        const fsBtn = document.getElementById('fs-btn');

        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(err => {});
                fsBtn.innerText = "Exit Fullscreen";
                document.body.classList.add('fullscreen-active');
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                }
                fsBtn.innerText = "Enter Fullscreen";
                document.body.classList.remove('fullscreen-active');
            }
        }

        // TV Remote Navigation and Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ' || e.keyCode === 13) {
                toggleFullscreen();
            }
        });

        // Auto hide remote hint after 6 seconds
        setTimeout(() => {
            if (hint) hint.style.opacity = '0';
        }, 6000);

        function handleStreamError() {
            setTimeout(() => {
                img.src = '/stream?t=' + new Date().getTime();
            }, 1000);
        }

        document.addEventListener('fullscreenchange', () => {
            if (!document.fullscreenElement) {
                fsBtn.innerText = "Enter Fullscreen";
                document.body.classList.remove('fullscreen-active');
            }
        });
    </script>
</body>
</html>
        """.trimIndent()
    }

    private fun createNotification(url: String): Notification {
        val stopIntent = Intent(this, ScreenStreamService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val activityIntent = Intent(this, MainActivity::class.java)
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            102,
            activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Screen Broadcast Active")
            .setContentText("Broadcasting live on $url")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(contentPendingIntent)
            .addAction(0, "Stop Stream", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Screen Cast Stream",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground screen mirroring service notification"
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun stopStreaming() {
        _isStreaming.value = false
        _serverUrl.value = null
        _connectedClients.value = 0
        activeSubscribers.set(0)

        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
            wakeLock = null
        } catch (_: Exception) {}

        try {
            wifiLock?.let {
                if (it.isHeld) it.release()
            }
            wifiLock = null
        } catch (_: Exception) {}

        try {
            virtualDisplay?.release()
            virtualDisplay = null
        } catch (_: Exception) {}

        try {
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {}

        try {
            mediaProjection?.stop()
            mediaProjection = null
        } catch (_: Exception) {}

        try {
            httpServer?.stop()
            httpServer = null
        } catch (_: Exception) {}

        qualityManager.reset()
    }

    override fun onDestroy() {
        stopStreaming()
        serviceScope.cancel()
        super.onDestroy()
    }
}
