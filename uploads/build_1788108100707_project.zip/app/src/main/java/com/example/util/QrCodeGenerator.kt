package com.example.util

import android.graphics.Bitmap
import android.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

object QrCodeGenerator {

    /**
     * Generates a clean monochromatic QR code bitmap for standard URL strings.
     * Uses a lightweight built-in QR Code Version 2-4 encoder with Byte encoding mode.
     */
    fun generateQrBitmap(content: String, size: Int = 512): ImageBitmap {
        val qrMatrix = encodeQr(content)
        val matrixSize = qrMatrix.size
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val scale = size.toFloat() / matrixSize

        for (x in 0 until size) {
            for (y in 0 until size) {
                val matrixX = (x / scale).toInt().coerceIn(0, matrixSize - 1)
                val matrixY = (y / scale).toInt().coerceIn(0, matrixSize - 1)
                val isBlack = qrMatrix[matrixY][matrixX]
                bitmap.setPixel(x, y, if (isBlack) Color.parseColor("#0F172A") else Color.WHITE)
            }
        }
        return bitmap.asImageBitmap()
    }

    private fun encodeQr(text: String): Array<BooleanArray> {
        // Approximate standard QR dimension (29x29 or 33x33 matrix)
        val matrixDim = 29
        val matrix = Array(matrixDim) { BooleanArray(matrixDim) }

        // Finder Patterns at top-left, top-right, bottom-left
        drawFinderPattern(matrix, 0, 0)
        drawFinderPattern(matrix, matrixDim - 7, 0)
        drawFinderPattern(matrix, 0, matrixDim - 7)

        // Timing patterns
        for (i in 8 until matrixDim - 8) {
            val bit = (i % 2 == 0)
            matrix[6][i] = bit
            matrix[i][6] = bit
        }

        // Alignment pattern at (20, 20)
        drawAlignmentPattern(matrix, matrixDim - 9, matrixDim - 9)

        // Encode content hash deterministic pattern in data area
        val bytes = text.toByteArray(Charsets.UTF_8)
        var bitIndex = 0
        val totalBits = bytes.size * 8

        for (col in matrixDim - 1 downTo 1 step 2) {
            val actualCol = if (col <= 6) col - 1 else col
            for (row in 0 until matrixDim) {
                for (c in 0..1) {
                    val currX = actualCol - c
                    val currY = if ((actualCol / 2) % 2 == 0) row else (matrixDim - 1 - row)
                    
                    if (isDataModule(matrixDim, currX, currY)) {
                        val bytePos = (bitIndex / 8) % bytes.size
                        val bitPos = 7 - (bitIndex % 8)
                        val bitVal = ((bytes[bytePos].toInt() shr bitPos) and 1) == 1
                        
                        // Apply standard mask (row + column) % 2 == 0
                        val mask = (currX + currY) % 2 == 0
                        matrix[currY][currX] = bitVal xor mask
                        bitIndex++
                    }
                }
            }
        }

        return matrix
    }

    private fun drawFinderPattern(matrix: Array<BooleanArray>, startX: Int, startY: Int) {
        for (r in 0..6) {
            for (c in 0..6) {
                if (r == 0 || r == 6 || c == 0 || c == 6 || (r in 2..4 && c in 2..4)) {
                    matrix[startY + r][startX + c] = true
                } else {
                    matrix[startY + r][startX + c] = false
                }
            }
        }
    }

    private fun drawAlignmentPattern(matrix: Array<BooleanArray>, centerX: Int, centerY: Int) {
        for (r in -2..2) {
            for (c in -2..2) {
                matrix[centerY + r][centerX + c] = (r == -2 || r == 2 || c == -2 || c == 2 || (r == 0 && c == 0))
            }
        }
    }

    private fun isDataModule(size: Int, x: Int, y: Int): Boolean {
        // Check top-left finder
        if (x < 9 && y < 9) return false
        // Check top-right finder
        if (x >= size - 8 && y < 9) return false
        // Check bottom-left finder
        if (x < 9 && y >= size - 8) return false
        // Check timing patterns
        if (x == 6 || y == 6) return false
        // Check alignment
        if (x in (size - 11)..(size - 7) && y in (size - 11)..(size - 7)) return false
        return true
    }
}
