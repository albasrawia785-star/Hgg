package com.example.quality

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class QualityPreset(val displayName: String, val description: String) {
    AUTO("Adaptive (AI)", "Dynamically tunes quality & latency based on throughput"),
    PERFORMANCE("Low Latency", "540p - 60% quality, fastest response"),
    BALANCED("Balanced", "720p - 75% quality, optimal balance"),
    HIGH_QUALITY("High Definition", "1080p - 85% quality, crystal clear text")
}

data class StreamMetrics(
    val currentFps: Int = 0,
    val targetFps: Int = 30,
    val jpegQuality: Int = 75,
    val scaleFactor: Float = 0.75f,
    val frameProcessingLatencyMs: Long = 0,
    val bitrateKbps: Long = 0,
    val totalFramesStreamed: Long = 0,
    val activeViewers: Int = 0,
    val qualityPreset: QualityPreset = QualityPreset.AUTO
)

class StreamQualityManager {

    private val _metrics = MutableStateFlow(StreamMetrics())
    val metrics: StateFlow<StreamMetrics> = _metrics.asStateFlow()

    private var activePreset: QualityPreset = QualityPreset.AUTO
    private var currentQuality: Int = 75
    private var currentScale: Float = 0.75f
    private var currentTargetFps: Int = 30

    // Sliding window metrics for dynamic calculation
    private var frameCountInInterval = 0
    private var bytesInInterval = 0L
    private var lastIntervalTimestamp = System.currentTimeMillis()
    private var totalFrames = 0L
    private var recentLatencies = LongArray(10) { 20L }
    private var latencyIndex = 0

    init {
        applyPreset(QualityPreset.AUTO)
    }

    fun setPreset(preset: QualityPreset) {
        activePreset = preset
        applyPreset(preset)
    }

    private fun applyPreset(preset: QualityPreset) {
        when (preset) {
            QualityPreset.AUTO -> {
                currentQuality = 75
                currentScale = 0.75f
                currentTargetFps = 30
            }
            QualityPreset.PERFORMANCE -> {
                currentQuality = 60
                currentScale = 0.50f
                currentTargetFps = 30
            }
            QualityPreset.BALANCED -> {
                currentQuality = 75
                currentScale = 0.75f
                currentTargetFps = 25
            }
            QualityPreset.HIGH_QUALITY -> {
                currentQuality = 85
                currentScale = 1.0f
                currentTargetFps = 30
            }
        }
        updateMetricsState()
    }

    fun getJpegQuality(): Int = currentQuality

    fun getScaleFactor(): Float = currentScale

    fun getTargetFps(): Int = currentTargetFps

    fun getTargetFrameIntervalMs(): Long {
        return (1000L / currentTargetFps.coerceIn(10, 60)).coerceAtLeast(16L)
    }

    /**
     * Reports a newly processed and dispatched frame to the adaptive quality engine.
     */
    fun recordFrameProcessed(frameSizeBytes: Int, processingDurationMs: Long) {
        totalFrames++
        frameCountInInterval++
        bytesInInterval += frameSizeBytes

        recentLatencies[latencyIndex % recentLatencies.size] = processingDurationMs
        latencyIndex++

        val now = System.currentTimeMillis()
        val timeElapsed = now - lastIntervalTimestamp

        if (timeElapsed >= 1000L) {
            val measuredFps = ((frameCountInInterval * 1000L) / timeElapsed).toInt()
            val measuredBitrateKbps = ((bytesInInterval * 8L) / (timeElapsed)) // bits/ms = kbps

            val avgLatency = recentLatencies.average().toLong()

            // Dynamic Adaptive AI Quality Adjustment
            if (activePreset == QualityPreset.AUTO) {
                adaptQuality(avgLatency, measuredFps)
            }

            _metrics.update { current ->
                current.copy(
                    currentFps = measuredFps,
                    targetFps = currentTargetFps,
                    jpegQuality = currentQuality,
                    scaleFactor = currentScale,
                    frameProcessingLatencyMs = avgLatency,
                    bitrateKbps = measuredBitrateKbps,
                    totalFramesStreamed = totalFrames,
                    qualityPreset = activePreset
                )
            }

            frameCountInInterval = 0
            bytesInInterval = 0L
            lastIntervalTimestamp = now
        }
    }

    /**
     * Dynamically tunes compression and frame interval to guarantee lowest possible latency.
     */
    private fun adaptQuality(avgLatencyMs: Long, measuredFps: Int) {
        // High latency (> 45ms per frame) -> reduce compression quality to prevent backlog
        if (avgLatencyMs > 45 || (measuredFps < currentTargetFps - 10 && currentTargetFps > 15)) {
            if (currentQuality > 40) {
                currentQuality = (currentQuality - 5).coerceAtLeast(40)
            } else if (currentScale > 0.5f) {
                currentScale = 0.5f
            }
        } 
        // Smooth latency (< 22ms per frame) -> gradually elevate fidelity
        else if (avgLatencyMs < 22 && measuredFps >= currentTargetFps - 2) {
            if (currentScale < 0.75f) {
                currentScale = 0.75f
            } else if (currentQuality < 85) {
                currentQuality = (currentQuality + 2).coerceAtMost(85)
            }
        }
    }

    fun updateActiveClients(count: Int) {
        _metrics.update { it.copy(activeViewers = count) }
    }

    fun reset() {
        totalFrames = 0L
        frameCountInInterval = 0
        bytesInInterval = 0L
        lastIntervalTimestamp = System.currentTimeMillis()
        applyPreset(activePreset)
    }

    private fun updateMetricsState() {
        _metrics.update {
            it.copy(
                targetFps = currentTargetFps,
                jpegQuality = currentQuality,
                scaleFactor = currentScale,
                qualityPreset = activePreset
            )
        }
    }
}
