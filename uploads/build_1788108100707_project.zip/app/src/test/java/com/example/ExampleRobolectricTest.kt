package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Screen Cast TV", appName)
  }

  @Test
  fun `verify network stream url formatting`() {
    val url = com.example.util.NetworkUtils.getStreamUrl("192.168.1.50", 8080)
    assertEquals("http://192.168.1.50:8080", url)
  }

  @Test
  fun `verify stream quality manager adaptive logic`() {
    val qualityManager = com.example.quality.StreamQualityManager()
    assertEquals(30, qualityManager.getTargetFps())
    assertEquals(75, qualityManager.getJpegQuality())

    qualityManager.setPreset(com.example.quality.QualityPreset.PERFORMANCE)
    assertEquals(60, qualityManager.getJpegQuality())
    assertEquals(0.50f, qualityManager.getScaleFactor(), 0.01f)
  }
}
