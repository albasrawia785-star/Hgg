package com.example.data.model

enum class UserAccountType(val titleAr: String, val badgeText: String) {
    FULL("النسخة الكاملة", "النسخة الكاملة (غير محدود)")
}

data class AuthState(
    val isLoggedIn: Boolean = true,
    val username: String = "طبيب العيادة",
    val accountType: UserAccountType = UserAccountType.FULL
)
