package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.R

/**
 * قوالب التصميم المختلفة للواجهة (UI Design Themes)
 */
enum class AppThemePreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val isDark: Boolean,
    val previewPrimaryColor: Color,
    val previewAccentColor: Color,
    val previewBackgroundColor: Color,
    val cornerRadiusDp: Int = 14
) {
    BLACK(
        id = "executive_dark",
        title = "الأسود الملكي الفاخر",
        subtitle = "أناقة السواد الفاخر عالي التباين ومريح للعين في الإضاءة الخافتة",
        isDark = true,
        previewPrimaryColor = Color(0xFF0F172A),
        previewAccentColor = Color(0xFF38BDF8),
        previewBackgroundColor = Color(0xFF090D16),
        cornerRadiusDp = 14
    ),
    CYAN(
        id = "cyan_sky",
        title = "السماوي الطبي الحديث",
        subtitle = "أزرق سماوي منعش وعصري يمنح شاشة العيادة إشراقاً وحيوية",
        isDark = false,
        previewPrimaryColor = Color(0xFF0284C7),
        previewAccentColor = Color(0xFF0EA5E9),
        previewBackgroundColor = Color(0xFFF0F9FF),
        cornerRadiusDp = 12
    ),
    NAVY(
        id = "original_glass",
        title = "الكحلي الكلاسيكي الأنيق",
        subtitle = "التصميم الطبي الرصين بألوان الكحلي وتأثير الزجاج البلوري",
        isDark = false,
        previewPrimaryColor = Color(0xFF1B2B48),
        previewAccentColor = Color(0xFF22C55E),
        previewBackgroundColor = Color(0xFFF1F5F9),
        cornerRadiusDp = 14
    ),
    GREEN(
        id = "emerald_health",
        title = "الأخضر الطبي المنعش",
        subtitle = "رمز العافية والصحة بلمسات الزمرد والنعناع التي تبعث على الهدوء",
        isDark = false,
        previewPrimaryColor = Color(0xFF059669),
        previewAccentColor = Color(0xFF10B981),
        previewBackgroundColor = Color(0xFFF0FDF4),
        cornerRadiusDp = 12
    ),
    PURPLE(
        id = "royal_indigo",
        title = "البنفسجي الأرجواني الملكي",
        subtitle = "فخامة وأناقة خاصة للأقسام والمراكز الطبية التخصصية",
        isDark = false,
        previewPrimaryColor = Color(0xFF4338CA),
        previewAccentColor = Color(0xFFF59E0B),
        previewBackgroundColor = Color(0xFFEEF2FF),
        cornerRadiusDp = 16
    ),
    GRAY(
        id = "minimal_flat",
        title = "الرمادي العصري النظيف",
        subtitle = "نمط مسطح عملي وراقي يركز على صفاء البيانات وسهولة القراءة",
        isDark = false,
        previewPrimaryColor = Color(0xFF334155),
        previewAccentColor = Color(0xFF0284C7),
        previewBackgroundColor = Color(0xFFF8FAFC),
        cornerRadiusDp = 8
    ),
    WHITE(
        id = "minimal_white",
        title = "الأبيض الساطع النقي",
        subtitle = "مساحات بيضاء ناصعة تعكس نقاء بيئة العيادة مع خطوط مريحة",
        isDark = false,
        previewPrimaryColor = Color(0xFF0284C7),
        previewAccentColor = Color(0xFF10B981),
        previewBackgroundColor = Color(0xFFFFFFFF),
        cornerRadiusDp = 12
    )
}

/**
 * خيارات كثافة الواجهة (Density Options)
 */
enum class UiDensity(
    val id: String,
    val title: String,
    val description: String,
    val cardPaddingVerticalDp: Int,
    val cardPaddingHorizontalDp: Int,
    val itemSpacingDp: Int,
    val numberBoxSizeDp: Int,
    val numberFontSizeSp: Int,
    val titleFontSizeSp: Int,
    val noteFontSizeSp: Int,
    val actionButtonHeightDp: Int
) {
    COMFORTABLE(
        id = "comfortable",
        title = "مريح (Comfortable)",
        description = "مسافات واسعة وبطاقات واضحة بحجم كبير لسهولة القراءة واللمس",
        cardPaddingVerticalDp = 10,
        cardPaddingHorizontalDp = 12,
        itemSpacingDp = 10,
        numberBoxSizeDp = 42,
        numberFontSizeSp = 17,
        titleFontSizeSp = 14,
        noteFontSizeSp = 12,
        actionButtonHeightDp = 30
    ),
    BALANCED(
        id = "balanced",
        title = "متوازن (Balanced)",
        description = "الوضع الافتراضي المتناسق بين استغلال المساحة والوضوح البصري",
        cardPaddingVerticalDp = 7,
        cardPaddingHorizontalDp = 10,
        itemSpacingDp = 8,
        numberBoxSizeDp = 36,
        numberFontSizeSp = 15,
        titleFontSizeSp = 13,
        noteFontSizeSp = 11,
        actionButtonHeightDp = 26
    ),
    COMPACT(
        id = "compact",
        title = "مضغوط (Compact - أقصى استغلال للشاشة)",
        description = "صفوف وبطاقات مصغرة ومرتبة لعرض أكبر عدد من المراجعين دون الحاجة للتمرير",
        cardPaddingVerticalDp = 4,
        cardPaddingHorizontalDp = 8,
        itemSpacingDp = 5,
        numberBoxSizeDp = 30,
        numberFontSizeSp = 13,
        titleFontSizeSp = 12,
        noteFontSizeSp = 10,
        actionButtonHeightDp = 22
    )
}

/**
 * خيارات نوع خلفية الشاشة
 */
enum class AppBackgroundType(
    val id: String,
    val title: String
) {
    CLINIC_IMAGE("clinic_image", "صورة العيادة الافتراضية"),
    CUSTOM_IMAGE("custom_image", "صورتك الخاصة (من الهاتف)"),
    SOLID_COLOR("solid_color", "لون نقي / موحد")
}

/**
 * حالة تخصيص الواجهة الكاملة التي يتم حفظها واسترجاعها
 */
data class UiCustomizationConfig(
    val themePreset: AppThemePreset = AppThemePreset.NAVY,
    val density: UiDensity = UiDensity.BALANCED,
    val backgroundType: AppBackgroundType = AppBackgroundType.CLINIC_IMAGE,
    val backgroundOpacity: Float = 0.20f, // الشفافية من 0.05f إلى 0.80f (افتراضي 20% لتظهر الخلفية بوضوح تام)
    val customImagePath: String? = null
) {
    val isDark: Boolean get() = themePreset.isDark

    // ألوان عناصر البطاقة والخلفيات حسب القالب
    val primaryColor: Color
        get() = when (themePreset) {
            AppThemePreset.BLACK -> Color(0xFF38BDF8)
            AppThemePreset.CYAN -> Color(0xFF0284C7)
            AppThemePreset.NAVY -> Color(0xFF1B2B48)
            AppThemePreset.GREEN -> Color(0xFF059669)
            AppThemePreset.PURPLE -> Color(0xFF4F46E5)
            AppThemePreset.GRAY -> Color(0xFF334155)
            AppThemePreset.WHITE -> Color(0xFF0284C7)
        }

    val headerGradient: Brush
        get() = when (themePreset) {
            AppThemePreset.BLACK -> Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF020617)))
            AppThemePreset.CYAN -> Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF0369A1)))
            AppThemePreset.NAVY -> Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
            AppThemePreset.GREEN -> Brush.linearGradient(listOf(Color(0xFF059669), Color(0xFF047857)))
            AppThemePreset.PURPLE -> Brush.linearGradient(listOf(Color(0xFF4338CA), Color(0xFF3730A3)))
            AppThemePreset.GRAY -> Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF1E293B)))
            AppThemePreset.WHITE -> Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF0369A1)))
        }

    val cardBackground: Color
        get() = when (themePreset) {
            AppThemePreset.BLACK -> Color(0xFF0F172A).copy(alpha = 0.86f)
            AppThemePreset.CYAN -> Color.White.copy(alpha = 0.86f)
            AppThemePreset.NAVY -> Color.White.copy(alpha = 0.86f)
            AppThemePreset.GREEN -> Color.White.copy(alpha = 0.86f)
            AppThemePreset.PURPLE -> Color.White.copy(alpha = 0.86f)
            AppThemePreset.GRAY -> Color.White.copy(alpha = 0.88f)
            AppThemePreset.WHITE -> Color.White.copy(alpha = 0.90f)
        }

    val cardBorderColor: Color
        get() = when (themePreset) {
            AppThemePreset.BLACK -> Color(0xFF334155)
            AppThemePreset.CYAN -> Color(0xFFBAE6FD)
            AppThemePreset.NAVY -> Color.White.copy(alpha = 0.95f)
            AppThemePreset.GREEN -> Color(0xFFA7F3D0)
            AppThemePreset.PURPLE -> Color(0xFFC7D2FE)
            AppThemePreset.GRAY -> Color(0xFFCBD5E1)
            AppThemePreset.WHITE -> Color(0xFFE2E8F0)
        }

    val textPrimaryColor: Color
        get() = when (themePreset) {
            AppThemePreset.BLACK -> Color(0xFFF8FAFC)
            AppThemePreset.CYAN -> Color(0xFF0F172A)
            AppThemePreset.NAVY -> Color(0xFF0F172A)
            AppThemePreset.GREEN -> Color(0xFF064E3B)
            AppThemePreset.PURPLE -> Color(0xFF1E1B4B)
            AppThemePreset.GRAY -> Color(0xFF0F172A)
            AppThemePreset.WHITE -> Color(0xFF0F172A)
        }

    val textSecondaryColor: Color
        get() = when (themePreset) {
            AppThemePreset.BLACK -> Color(0xFF94A3B8)
            AppThemePreset.CYAN -> Color(0xFF0369A1)
            AppThemePreset.NAVY -> Color(0xFF64748B)
            AppThemePreset.GREEN -> Color(0xFF047857).copy(alpha = 0.8f)
            AppThemePreset.PURPLE -> Color(0xFF6366F1)
            AppThemePreset.GRAY -> Color(0xFF64748B)
            AppThemePreset.WHITE -> Color(0xFF64748B)
        }

    val screenBackgroundColor: Color
        get() = when (themePreset) {
            AppThemePreset.BLACK -> Color(0xFF090D16)
            AppThemePreset.CYAN -> Color(0xFFF0F9FF)
            AppThemePreset.NAVY -> Color(0xFFF1F5F9)
            AppThemePreset.GREEN -> Color(0xFFECFDF5)
            AppThemePreset.PURPLE -> Color(0xFFEEF2FF)
            AppThemePreset.GRAY -> Color(0xFFF8FAFC)
            AppThemePreset.WHITE -> Color(0xFFFFFFFF)
        }
}
