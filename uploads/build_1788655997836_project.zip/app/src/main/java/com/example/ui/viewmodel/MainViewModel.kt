package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AnnouncementManager
import com.example.audio.CallingState
import com.example.bluetooth.AudioRouteManager
import com.example.bluetooth.BluetoothDeviceManager
import com.example.bluetooth.printer.PrinterManager
import com.example.data.model.AuthState
import com.example.data.model.BluetoothDeviceInfo
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import com.example.data.model.UserAccountType
import com.example.data.repository.QueueRepository
import com.example.server.LocalHotspotManager
import com.example.server.TvDisplayServerManager
import com.example.ui.theme.AppBackgroundType
import com.example.ui.theme.AppThemePreset
import com.example.ui.theme.UiCustomizationConfig
import com.example.ui.theme.UiDensity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class QueueFilterType(val label: String, val dbCode: String) {
    ALL("الكل", "ALL"),
    WAITING("في الانتظار", "WAITING"),
    POSTPONED("المؤجلين", "POSTPONED"),
    SERVED("تم استدعاء", "SERVED")
}

enum class AppScreen {
    LOGIN,
    HOME,
    QUEUE_LIST,
    DEVICE_SETTINGS,
    CHOOSE_PRINTER,
    CALLING_ACTIVE,
    REPORTS
}

data class SessionReportGroup(
    val sessionId: String,
    val sessionTitle: String,
    val isLive: Boolean,
    val timestamp: Long,
    val patients: List<Patient>
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val authPrefs = application.getSharedPreferences("clinic_auth_prefs", android.content.Context.MODE_PRIVATE)

    private val _authState = MutableStateFlow(
        AuthState(
            isLoggedIn = authPrefs.getBoolean("is_logged_in", true),
            username = authPrefs.getString("username", "طبيب العيادة") ?: "طبيب العيادة",
            accountType = UserAccountType.FULL
        )
    )
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    val repository = QueueRepository(application)
    val bluetoothDeviceManager = BluetoothDeviceManager(application)
    val printerManager = PrinterManager(application)
    val audioRouteManager = AudioRouteManager(application)
    val announcementManager = AnnouncementManager(application, audioRouteManager)
    val tvDisplayServerManager = TvDisplayServerManager(application)
    val localHotspotManager = LocalHotspotManager(application)

    private val initialScreen = if (_authState.value.isLoggedIn) AppScreen.QUEUE_LIST else AppScreen.LOGIN
    private val _currentScreen = MutableStateFlow(initialScreen)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val backStack = mutableListOf(initialScreen)

    val patients: StateFlow<List<Patient>> = repository.patients
    val archivedPatients: StateFlow<List<Patient>> = repository.archivedPatients

    // قائمة كافة المراجعين المؤرشفين الموجهة لشاشة التقارير والإحصائيات مستخرجة من قاعدة البيانات
    val allReportsPatients: StateFlow<List<Patient>> = repository.archivedPatients
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val sessionGroups: StateFlow<List<SessionReportGroup>> = repository.archivedPatients
        .map { archivedList ->
            val result = mutableListOf<SessionReportGroup>()
            val grouped = archivedList.groupBy { it.sessionId }
            grouped.forEach { (sId, sPatients) ->
                val title = sPatients.firstOrNull()?.sessionTitle?.takeIf { it.isNotBlank() } ?: "جلسة سابقة"
                val maxTime = sPatients.maxOfOrNull { it.timestamp } ?: 0L
                result.add(
                    SessionReportGroup(
                        sessionId = sId,
                        sessionTitle = title,
                        isLive = false,
                        timestamp = maxTime,
                        patients = sPatients
                    )
                )
            }
            result.sortedByDescending { it.timestamp }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val currentPatient: StateFlow<Patient?> = repository.currentPatient
    val settings: StateFlow<SystemSettings> = repository.settings

    val isTvServerRunning: StateFlow<Boolean> = tvDisplayServerManager.isServerRunning
    val tvServerUrl: StateFlow<String> = tvDisplayServerManager.serverUrl
    val isTvConnected: StateFlow<Boolean> = tvDisplayServerManager.isTvConnected
    val isPrinterConnected: StateFlow<Boolean> = printerManager.isConnected

    val isHotspotActive: StateFlow<Boolean> = localHotspotManager.isHotspotActive
    val hotspotSsid: StateFlow<String> = localHotspotManager.ssid
    val hotspotPassword: StateFlow<String> = localHotspotManager.password
    val hotspotStatusMessage: StateFlow<String> = localHotspotManager.statusMessage
    val isHotspotLoading: StateFlow<Boolean> = localHotspotManager.isLoading

    private val _isTvAudioOnly = MutableStateFlow(true)
    val isTvAudioOnly: StateFlow<Boolean> = _isTvAudioOnly.asStateFlow()

    private val _showTvDialog = MutableStateFlow(false)
    val showTvDialog: StateFlow<Boolean> = _showTvDialog.asStateFlow()

    val postponedPatients: StateFlow<List<Patient>> = patients
        .map { list -> list.filter { it.isPostponed } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val activeWaitingPatients: StateFlow<List<Patient>> = patients
        .map { list -> list.filter { !it.isPostponed && !it.isCalled } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // تدفقات إحصائيات Room فائقة السرعة للأعداد الضخمة مباشرة من SQLite
    val liveTotalCount: StateFlow<Int> = repository.liveQueueCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val waitingCount: StateFlow<Int> = repository.waitingCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val postponedCount: StateFlow<Int> = repository.postponedCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val servedCount: StateFlow<Int> = repository.servedCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val nextQueueNumber: StateFlow<Int> = repository.nextQueueNumberFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1)

    // إدارة الترقيم (Pagination) والبحث لضمان الأداء الفائق عند تزايد البيانات
    private val _selectedFilter = MutableStateFlow(QueueFilterType.ALL)
    val selectedFilter: StateFlow<QueueFilterType> = _selectedFilter.asStateFlow()

    private val _currentPage = MutableStateFlow(1)
    val currentPage: StateFlow<Int> = _currentPage.asStateFlow()

    private val _pageSize = MutableStateFlow(15)
    val pageSize: StateFlow<Int> = _pageSize.asStateFlow()

    private val _queueSearchQuery = MutableStateFlow("")
    val queueSearchQuery: StateFlow<String> = _queueSearchQuery.asStateFlow()

    fun onQueueSearchQueryChanged(query: String) {
        _queueSearchQuery.value = query
        _currentPage.value = 1
    }

    val currentFilterCount: StateFlow<Int> = combine(_selectedFilter, _queueSearchQuery) { filter, query ->
        Pair(filter, query)
    }.flatMapLatest { (filter, query) ->
        repository.getFilterCountFlow(filter.dbCode, query.trim())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalPages: StateFlow<Int> = combine(currentFilterCount, _pageSize) { count, size ->
        if (count <= 0) 1 else kotlin.math.max(1, kotlin.math.ceil(count.toDouble() / size).toInt())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1)

    // قائمة المراجعين المرقمة مستخرجة بدقة واستجابة فورية من Room Database بحد أقصى للصفحة الواحدة
    val pagedPatients: StateFlow<List<Patient>> = combine(
        _selectedFilter,
        _currentPage,
        _pageSize,
        _queueSearchQuery
    ) { filter, page, size, query ->
        listOf(filter.dbCode, page, size, query.trim())
    }.flatMapLatest { params ->
        val filterCode = params[0] as String
        val page = params[1] as Int
        val size = params[2] as Int
        val query = params[3] as String
        val offset = (page - 1) * size
        repository.getPagedLiveQueue(filterCode, limit = size, offset = offset, search = query)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onSelectFilter(filter: QueueFilterType) {
        _selectedFilter.value = filter
        _currentPage.value = 1
    }

    fun onNextPage() {
        if (_currentPage.value < totalPages.value) {
            _currentPage.value += 1
        }
    }

    fun onPrevPage() {
        if (_currentPage.value > 1) {
            _currentPage.value -= 1
        }
    }

    fun onGoToPage(page: Int) {
        _currentPage.value = page.coerceIn(1, totalPages.value)
    }

    fun onSetPageSize(size: Int) {
        if (size in listOf(10, 20, 50, 100)) {
            _pageSize.value = size
            _currentPage.value = 1
        }
    }

    fun generateBatchTestPatients(count: Int = 100) {
        viewModelScope.launch(Dispatchers.IO) {
            val currentMax = repository.queueDaoInstance.getMaxLiveQueueNumber() ?: 0
            val sampleNames = listOf(
                "محمد الشمري", "عبدالله العتيبي", "فاطمة الزهراني", "سارة القحطاني",
                "خالد المطيري", "أحمد الحربي", "نورة الدوسري", "عمر الغامدي",
                "مريم العنزي", "يوسف السبيعي", "هدى الرشيدي", "علي الشهري",
                "ريم القرني", "إبراهيم الخالدي", "منى العسيري", "سلطان التميمي",
                "أسماء المالكي", "فهد السعيد", "هيا السهلي", "سعود الشريف"
            )
            val sampleNotes = listOf(
                "فحص دوري", "استشارة طبية", "متابعة نتائج التحاليل", "فحص ضغط الدم",
                "تجديد وصفة علاجية", "عيادة الأسنان", "فحص سكر الدم", "معاينة باطنية",
                "تحويل مخبري", "كشف عام"
            )
            val now = System.currentTimeMillis()
            val batch = ArrayList<Patient>(count)
            for (i in 1..count) {
                val qNum = currentMax + i
                val name = sampleNames[(qNum - 1) % sampleNames.size]
                val note = sampleNotes[(qNum - 1) % sampleNotes.size]
                batch.add(
                    Patient(
                        id = 0,
                        queueNumber = qNum,
                        name = "$name #$qNum",
                        note = note,
                        timestamp = now + (i * 500L),
                        isCalled = (i % 4 == 0),
                        isCurrent = false,
                        isPostponed = (i % 7 == 0),
                        sessionId = "live_session",
                        sessionTitle = "الجلسة الحالية النشطة"
                    )
                )
            }
            repository.insertBatchPatients(batch)
            _toastMessage.value = "تمت إضافة $count مراجع في قاعدة بيانات Room بنجاح"
        }
    }

    val callingState: StateFlow<CallingState> = announcementManager.callingState
    val activeCallingPatient: StateFlow<Patient?> = announcementManager.activeCallingPatient

    private val _showResetDialog = MutableStateFlow(false)
    val showResetDialog: StateFlow<Boolean> = _showResetDialog.asStateFlow()

    private val _showTvNotConnectedDialog = MutableStateFlow(false)
    val showTvNotConnectedDialog: StateFlow<Boolean> = _showTvNotConnectedDialog.asStateFlow()

    private var pendingCallAction: (() -> Unit)? = null

    // إعدادات تخصيص الواجهة والقوالب مع الحفظ الدائم عبر SharedPreferences
    private val uiPrefs = application.getSharedPreferences("clinic_ui_customization_prefs", android.content.Context.MODE_PRIVATE)

    private val _uiCustomizationConfig = MutableStateFlow(loadUiCustomizationConfig())
    val uiCustomizationConfig: StateFlow<UiCustomizationConfig> = _uiCustomizationConfig.asStateFlow()

    private fun loadUiCustomizationConfig(): UiCustomizationConfig {
        val presetId = uiPrefs.getString("ui_theme_preset", AppThemePreset.NAVY.id)
        val densityId = uiPrefs.getString("ui_density", UiDensity.BALANCED.id)
        val bgTypeId = uiPrefs.getString("ui_bg_type", AppBackgroundType.CLINIC_IMAGE.id)
        val opacity = uiPrefs.getFloat("ui_bg_opacity", 0.52f)
        val customBgPath = uiPrefs.getString("ui_custom_bg_path", null)?.takeIf { java.io.File(it).exists() }

        val preset = AppThemePreset.values().find { it.id == presetId } ?: AppThemePreset.NAVY
        val density = UiDensity.values().find { it.id == densityId } ?: UiDensity.BALANCED
        val bgType = if (bgTypeId == AppBackgroundType.CUSTOM_IMAGE.id && customBgPath != null) {
            AppBackgroundType.CUSTOM_IMAGE
        } else {
            AppBackgroundType.values().find { it.id == bgTypeId } ?: AppBackgroundType.CLINIC_IMAGE
        }

        return UiCustomizationConfig(
            themePreset = preset,
            density = density,
            backgroundType = bgType,
            backgroundOpacity = opacity.coerceIn(0.15f, 0.95f),
            customImagePath = customBgPath
        )
    }

    fun onSelectThemePreset(preset: AppThemePreset) {
        val updated = _uiCustomizationConfig.value.copy(themePreset = preset)
        _uiCustomizationConfig.value = updated
        uiPrefs.edit().putString("ui_theme_preset", preset.id).apply()
        _toastMessage.value = "تم تطبيق قالب: ${preset.title}"
    }

    fun onSelectUiDensity(density: UiDensity) {
        val updated = _uiCustomizationConfig.value.copy(density = density)
        _uiCustomizationConfig.value = updated
        uiPrefs.edit().putString("ui_density", density.id).apply()
        _toastMessage.value = "تم ضبط كثافة الواجهة: ${density.title}"
    }

    fun onSelectBackgroundType(type: AppBackgroundType) {
        val updated = _uiCustomizationConfig.value.copy(backgroundType = type)
        _uiCustomizationConfig.value = updated
        uiPrefs.edit().putString("ui_bg_type", type.id).apply()
    }

    fun onChangeBackgroundOpacity(opacity: Float) {
        val updated = _uiCustomizationConfig.value.copy(backgroundOpacity = opacity)
        _uiCustomizationConfig.value = updated
        uiPrefs.edit().putFloat("ui_bg_opacity", opacity).apply()
    }

    fun onSetCustomBackgroundImage(uri: android.net.Uri) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val destinationFile = java.io.File(context.filesDir, "custom_clinic_bg.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    java.io.FileOutputStream(destinationFile).use { output ->
                        input.copyTo(output)
                    }
                }
                val path = destinationFile.absolutePath
                val updated = _uiCustomizationConfig.value.copy(
                    backgroundType = AppBackgroundType.CUSTOM_IMAGE,
                    customImagePath = path
                )
                _uiCustomizationConfig.value = updated
                uiPrefs.edit()
                    .putString("ui_bg_type", AppBackgroundType.CUSTOM_IMAGE.id)
                    .putString("ui_custom_bg_path", path)
                    .apply()
                _toastMessage.value = "تم حفظ وتعيين صورتك الخاصة كخلفية للعيادة بنجاح"
            } catch (e: Exception) {
                _toastMessage.value = "تعذر تحميل الصورة المختارة: ${e.localizedMessage}"
            }
        }
    }

    fun onRemoveCustomBackgroundImage() {
        val context = getApplication<Application>()
        val destinationFile = java.io.File(context.filesDir, "custom_clinic_bg.jpg")
        if (destinationFile.exists()) {
            destinationFile.delete()
        }
        val updated = _uiCustomizationConfig.value.copy(
            backgroundType = AppBackgroundType.CLINIC_IMAGE,
            customImagePath = null
        )
        _uiCustomizationConfig.value = updated
        uiPrefs.edit()
            .putString("ui_bg_type", AppBackgroundType.CLINIC_IMAGE.id)
            .remove("ui_custom_bg_path")
            .apply()
        _toastMessage.value = "تمت إزالة الصورة واستعادة خلفية العيادة الافتراضية"
    }

    fun onResetUiCustomizationDefaults() {
        val default = UiCustomizationConfig()
        val context = getApplication<Application>()
        val destinationFile = java.io.File(context.filesDir, "custom_clinic_bg.jpg")
        if (destinationFile.exists()) {
            destinationFile.delete()
        }
        _uiCustomizationConfig.value = default
        uiPrefs.edit()
            .putString("ui_theme_preset", default.themePreset.id)
            .putString("ui_density", default.density.id)
            .putString("ui_bg_type", default.backgroundType.id)
            .putFloat("ui_bg_opacity", default.backgroundOpacity)
            .remove("ui_custom_bg_path")
            .apply()
        _toastMessage.value = "تمت استعادة التصميم والخصائص الأصلية بنجاح"
    }

    private val _showAddPatientDialog = MutableStateFlow(false)
    val showAddPatientDialog: StateFlow<Boolean> = _showAddPatientDialog.asStateFlow()

    private val _showPostponedSheet = MutableStateFlow(false)
    val showPostponedSheet: StateFlow<Boolean> = _showPostponedSheet.asStateFlow()

    private val _previewTicketPatient = MutableStateFlow<Patient?>(null)
    val previewTicketPatient: StateFlow<Patient?> = _previewTicketPatient.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _currentTimeFormatted = MutableStateFlow("")
    val currentTimeFormatted: StateFlow<String> = _currentTimeFormatted.asStateFlow()

    private val _currentDateFormatted = MutableStateFlow("")
    val currentDateFormatted: StateFlow<String> = _currentDateFormatted.asStateFlow()

    private val _isTestingAudio = MutableStateFlow(false)
    val isTestingAudio: StateFlow<Boolean> = _isTestingAudio.asStateFlow()

    private val _isQueueStarted = MutableStateFlow(false)
    val isQueueStarted: StateFlow<Boolean> = _isQueueStarted.asStateFlow()

    private var callingJob: Job? = null
    private var testAudioJob: Job? = null

    init {
        updateTimeAndDate()
        // Automatically start the TV display server so it's always ready for Smart TV / Hotspot
        tvDisplayServerManager.startServer()

        // Synchronize state with TV server
        viewModelScope.launch {
            patients.collect { list ->
                tvDisplayServerManager.updateState(settings.value, list, currentPatient.value, _isQueueStarted.value)
            }
        }
        viewModelScope.launch {
            settings.collect { currentSettings ->
                tvDisplayServerManager.updateState(currentSettings, patients.value, currentPatient.value, _isQueueStarted.value)
            }
        }
        viewModelScope.launch {
            currentPatient.collect { current ->
                tvDisplayServerManager.updateState(settings.value, patients.value, current, _isQueueStarted.value)
            }
        }
        viewModelScope.launch {
            _isQueueStarted.collect { started ->
                tvDisplayServerManager.updateState(settings.value, patients.value, currentPatient.value, started)
            }
        }
    }

    fun onToggleTvAudioOnly(enable: Boolean) {
        _isTvAudioOnly.value = enable
        _toastMessage.value = if (enable) "تم تفعيل خروج الصوت من شاشة التلفزيون فقط" else "تم تفعيل خروج الصوت من الهاتف أيضاً"
    }

    fun onToggleLocalHotspot(enable: Boolean) {
        if (enable) {
            localHotspotManager.startLocalHotspot(
                onSuccess = {
                    tvDisplayServerManager.refreshUrl()
                    _toastMessage.value = "تم إنشاء شبكة الواي فاي للعيادة بنجاح"
                },
                onFailure = { error: String ->
                    _toastMessage.value = error
                }
            )
        } else {
            localHotspotManager.stopLocalHotspot()
            tvDisplayServerManager.refreshUrl()
            _toastMessage.value = "تم إيقاف شبكة الواي فاي"
        }
    }

    fun onOpenTvDialog() {
        tvDisplayServerManager.startServer()
        _showTvDialog.value = true
    }

    fun onDismissTvDialog() {
        _showTvDialog.value = false
    }

    fun onToggleTvServer(enable: Boolean) {
        if (enable) {
            tvDisplayServerManager.startServer()
            _toastMessage.value = "تم تشغيل خادم شاشة التلفزيون"
        } else {
            tvDisplayServerManager.stopServer()
            _toastMessage.value = "تم إيقاف خادم شاشة التلفزيون"
        }
    }

    fun onRefreshTvIp() {
        tvDisplayServerManager.refreshUrl()
        _toastMessage.value = "تم تحديث عنوان الشبكة: ${tvDisplayServerManager.serverUrl.value}"
    }

    fun updateTimeAndDate() {
        val now = Date()
        val timeFmt = SimpleDateFormat("hh:mm a", Locale.US)
        val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        _currentTimeFormatted.value = timeFmt.format(now)
        _currentDateFormatted.value = dateFmt.format(now)
    }

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            backStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (backStack.size > 1) {
            backStack.removeAt(backStack.size - 1)
            _currentScreen.value = backStack.last()
            return true
        }
        return false
    }

    fun login(username: String = "طبيب العيادة", password: String = "") {
        val user = if (username.isNotBlank()) username else "طبيب العيادة"
        _authState.value = AuthState(
            isLoggedIn = true,
            username = user,
            accountType = UserAccountType.FULL
        )
        authPrefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("username", user)
            .putString("account_type", "FULL")
            .apply()

        _toastMessage.value = "مرحباً بك، تم تسجيل الدخول بنجاح"
        backStack.clear()
        backStack.add(AppScreen.QUEUE_LIST)
        _currentScreen.value = AppScreen.QUEUE_LIST
    }

    fun logout() {
        _authState.value = AuthState(
            isLoggedIn = false,
            username = "",
            accountType = UserAccountType.FULL
        )
        authPrefs.edit()
            .putBoolean("is_logged_in", false)
            .putString("username", "")
            .putString("account_type", "FULL")
            .apply()

        _toastMessage.value = "تم تسجيل الخروج"
        backStack.clear()
        backStack.add(AppScreen.LOGIN)
        _currentScreen.value = AppScreen.LOGIN
    }

    fun canAddPatient(): Boolean {
        return true
    }

    fun onAddPatientClicked() {
        if (!canAddPatient()) return
        _showAddPatientDialog.value = true
    }

    fun onDismissAddPatientDialog() {
        _showAddPatientDialog.value = false
    }

    fun onOpenPostponedSheet() {
        _showPostponedSheet.value = true
    }

    fun onDismissPostponedSheet() {
        _showPostponedSheet.value = false
    }

    fun onConfirmAddPatient(name: String, note: String, shouldPrint: Boolean) {
        if (!canAddPatient()) return
        _showAddPatientDialog.value = false
        viewModelScope.launch {
            updateTimeAndDate()
            val newPatient = repository.addPatient(name = name, note = note)

            if (shouldPrint) {
                val currentSettings = settings.value
                val success = printerManager.printTicket(
                    patient = newPatient,
                    settings = currentSettings,
                    paperSize = currentSettings.paperSize
                )
                if (success) {
                    _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber} وطباعة الوصل"
                } else {
                    _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber} (لم تتم الطباعة - تأكد من اتصال الطابعة)"
                }
            } else {
                _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber}"
            }
        }
    }

    private fun shouldMutePhone(): Boolean {
        return _isTvAudioOnly.value && (isTvServerRunning.value || isHotspotActive.value)
    }

    fun onDismissTvNotConnectedDialog() {
        _showTvNotConnectedDialog.value = false
        pendingCallAction = null
    }

    fun onConfirmContinueCallWithoutTv() {
        _showTvNotConnectedDialog.value = false
        val action = pendingCallAction
        pendingCallAction = null
        action?.invoke()
    }

    /**
     * فحص اتصال الشاشة قبل استدعاء أي مراجع.
     * إذا كانت الشاشة غير متصلة، تظهر نافذة التنبيه مع خيارات المتابعة أو الإلغاء.
     */
    private fun checkTvConnectionBeforeCall(action: () -> Unit) {
        if (!isTvConnected.value) {
            pendingCallAction = action
            _showTvNotConnectedDialog.value = true
        } else {
            action()
        }
    }

    /**
     * استدعاء المراجع الحالي في نفس الشاشة دون الانتقال لشاشة منفصلة
     */
    fun onCallCurrentPatientClicked() {
        if (!_isQueueStarted.value) {
            _toastMessage.value = "يرجى الضغط على زر بدء أولاً لتفعيل الدور واستدعاء المراجعين"
            return
        }
        checkTvConnectionBeforeCall {
            executeCallCurrentPatient()
        }
    }

    private fun executeCallCurrentPatient() {
        viewModelScope.launch {
            val patientToCall = repository.callCurrentPatient()
            if (patientToCall == null) {
                _toastMessage.value = "القائمة فارغة. يرجى إضافة مراجع أولاً."
                return@launch
            }

            tvDisplayServerManager.notifyPatientCalled(patientToCall)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = patientToCall,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
        }
    }

    /**
     * استدعاء المراجع التالي والانتقال إليه مباشرة
     */
    fun onCallNextPatientClicked() {
        if (!_isQueueStarted.value) {
            _toastMessage.value = "يرجى الضغط على زر بدء أولاً لتفعيل الدور واستدعاء المراجعين"
            return
        }
        checkTvConnectionBeforeCall {
            executeCallNextPatient()
        }
    }

    private fun executeCallNextPatient() {
        viewModelScope.launch {
            val nextPatient = repository.callNextPatient()
            if (nextPatient == null) {
                _toastMessage.value = "لا يوجد مراجعين حالياً"
                return@launch
            }

            tvDisplayServerManager.notifyPatientCalled(nextPatient)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = nextPatient,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
            _toastMessage.value = "تم استدعاء المراجع التالي رقم ${nextPatient.formattedNumber}"
        }
    }

    /**
     * إعادة استدعاء المراجع الحالي
     */
    fun onRecallCurrentPatient() {
        if (!_isQueueStarted.value) {
            _toastMessage.value = "يرجى الضغط على زر بدء أولاً لتفعيل الدور واستدعاء المراجعين"
            return
        }
        checkTvConnectionBeforeCall {
            executeRecallCurrentPatient()
        }
    }

    private fun executeRecallCurrentPatient() {
        val current = currentPatient.value ?: return
        tvDisplayServerManager.notifyPatientCalled(current)
        callingJob?.cancel()
        callingJob = viewModelScope.launch {
            announcementManager.announcePatient(
                patient = current,
                settings = settings.value,
                mutePhone = shouldMutePhone()
            )
        }
    }

    /**
     * تأجيل المراجع الحالي وإضافته لقائمة المؤجلين ثم الانتقال للتالي تلقائياً
     */
    fun onPostponeCurrentPatient() {
        viewModelScope.launch {
            val (postponed, next) = repository.postponeCurrentPatient()
            if (postponed != null) {
                callingJob?.cancel()
                announcementManager.resetState()
                if (next != null) {
                    _toastMessage.value = "تم تأجيل المراجع ${postponed.formattedNumber} وتعيين المراجع ${next.formattedNumber}"
                } else {
                    _toastMessage.value = "تم نقل المراجع رقم ${postponed.formattedNumber} إلى قائمة المؤجلين"
                }
            } else {
                _toastMessage.value = "لا يوجد مراجع حالي لتأجيله"
            }
        }
    }

    /**
     * تأجيل مراجع محدد من القائمة
     */
    fun onPostponeSpecificPatient(patient: Patient) {
        viewModelScope.launch {
            val postponed = repository.postponePatient(patient)
            callingJob?.cancel()
            announcementManager.resetState()
            _toastMessage.value = "تم تأجيل المراجع رقم ${postponed.formattedNumber}"
        }
    }

    /**
     * استدعاء مراجع مؤجل مباشرة
     */
    fun onRecallPostponedPatient(patient: Patient) {
        if (!_isQueueStarted.value) {
            _toastMessage.value = "يرجى الضغط على زر بدء أولاً لتفعيل الدور واستدعاء المراجعين"
            return
        }
        checkTvConnectionBeforeCall {
            executeRecallPostponedPatient(patient)
        }
    }

    private fun executeRecallPostponedPatient(patient: Patient) {
        viewModelScope.launch {
            val reactivated = repository.recallPostponedPatient(patient)
            tvDisplayServerManager.notifyPatientCalled(reactivated)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = reactivated,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
            _toastMessage.value = "تم استدعاء المراجع المؤجل رقم ${reactivated.formattedNumber}"
        }
    }

    /**
     * إعادة المراجع المؤجل إلى قائمة الانتظار
     */
    fun onRestorePostponedToQueue(patient: Patient) {
        viewModelScope.launch {
            repository.restorePostponedToQueue(patient)
            _toastMessage.value = "تمت إعادة المراجع رقم ${patient.formattedNumber} إلى قائمة الانتظار"
        }
    }

    /**
     * حذف مراجع
     */
    fun onDeletePatient(patient: Patient) {
        viewModelScope.launch {
            repository.deletePatient(patient)
            _toastMessage.value = "تم حذف المراجع رقم ${patient.formattedNumber}"
        }
    }

    /**
     * حذف جميع المراجعين المكتملين من التقارير
     */
    fun onDeleteServedPatients(dateKey: String? = null, sessionId: String? = null) {
        viewModelScope.launch {
            repository.deleteServedPatients(dateKey, sessionId)
            _toastMessage.value = "تم حذف المراجعين المكتملين من التقرير المحدد"
        }
    }

    /**
     * حذف جميع المراجعين المؤجلين من التقارير
     */
    fun onDeletePostponedPatients(dateKey: String? = null, sessionId: String? = null) {
        viewModelScope.launch {
            repository.deletePostponedPatients(dateKey, sessionId)
            _toastMessage.value = "تم حذف المراجعين المؤجلين"
        }
    }

    /**
     * حذف جلسة كاملة
     */
    fun onDeleteSession(sessionId: String, sessionTitle: String = "") {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            val titleText = if (sessionTitle.isNotBlank()) " ($sessionTitle)" else ""
            _toastMessage.value = "تم حذف بيانات الجلسة$titleText بالكامل من التقارير"
        }
    }

    /**
     * حذف تاريخ محدد بالكامل من الأرشيف
     */
    fun onDeleteByDate(dateKey: String, displayDate: String) {
        viewModelScope.launch {
            repository.deleteByDate(dateKey)
            _toastMessage.value = "تم حذف أرشيف يوم $displayDate بالكامل"
        }
    }

    /**
     * طباعة ملخص التقرير والإحصائيات عبر طابعة البلوتوث
     */
    fun onPrintReportSummary(
        title: String = "تقرير العيادة",
        dateText: String,
        totalCount: Int,
        servedCount: Int,
        waitingCount: Int,
        postponedCount: Int
    ) {
        viewModelScope.launch {
            if (!printerManager.isConnected.value) {
                _toastMessage.value = "الطابعة غير متصلة، يرجى توصيلها من الإعدادات"
                return@launch
            }
            val success = printerManager.printReportSummary(
                title = title,
                dateText = dateText,
                totalCount = totalCount,
                servedCount = servedCount,
                waitingCount = waitingCount,
                postponedCount = postponedCount,
                settings = settings.value
            )
            if (success) {
                _toastMessage.value = "تم إرسال التقرير للطابعة بنجاح"
            } else {
                _toastMessage.value = printerManager.lastPrintStatus.value
            }
        }
    }

    /**
     * مسح وحذف كافة السجلات في التقرير وقائمة الانتظار نهائياً
     */
    fun onClearAllReports() {
        viewModelScope.launch {
            repository.clearAllReportsAndQueue()
            _isQueueStarted.value = false
            _toastMessage.value = "تم مسح كافة سجلات التقارير بنجاح"
        }
    }

    fun onCallSpecificPatient(patient: Patient) {
        if (!_isQueueStarted.value) {
            _toastMessage.value = "يرجى الضغط على زر بدء أولاً لتفعيل الدور واستدعاء المراجعين"
            return
        }
        checkTvConnectionBeforeCall {
            executeCallSpecificPatient(patient)
        }
    }

    private fun executeCallSpecificPatient(patient: Patient) {
        viewModelScope.launch {
            val patientToCall = repository.callSpecificPatient(patient.id)
                ?: patient.copy(isCalled = true, isCurrent = true, isPostponed = false)
            tvDisplayServerManager.notifyPatientCalled(patientToCall)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = patientToCall,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
        }
    }

    fun onCallNextPatientFromCallingScreen() {
        if (!_isQueueStarted.value) {
            _toastMessage.value = "يرجى الضغط على زر بدء أولاً لتفعيل الدور واستدعاء المراجعين"
            return
        }
        checkTvConnectionBeforeCall {
            executeCallNextPatientFromCallingScreen()
        }
    }

    private fun executeCallNextPatientFromCallingScreen() {
        viewModelScope.launch {
            val nextPatient = repository.callNextPatient() ?: return@launch
            tvDisplayServerManager.notifyPatientCalled(nextPatient)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = nextPatient,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
        }
    }

    fun onDismissCallingScreen() {
        callingJob?.cancel()
        announcementManager.resetState()
        navigateBack()
    }

    fun onToggleQueueState() {
        if (_isQueueStarted.value) {
            onPauseQueue()
        } else {
            onStartQueueClicked()
        }
    }

    fun onStartQueue() {
        _isQueueStarted.value = true
        tvDisplayServerManager.updateState(settings.value, patients.value, currentPatient.value, true)
        _toastMessage.value = "تم بدء الدور (انقر على أي مراجع لاستدعائه وعرض رقمه على الشاشة)"
    }

    fun onPauseQueue() {
        _isQueueStarted.value = false
        tvDisplayServerManager.updateState(settings.value, patients.value, currentPatient.value, false)
        _toastMessage.value = "تم إيقاف عرض المراجعين على شاشة TV"
    }

    fun onStartQueueClicked() {
        _isQueueStarted.value = true
        tvDisplayServerManager.updateState(settings.value, patients.value, currentPatient.value, true)
        _toastMessage.value = "تم بدء الدور (انقر على أي مراجع لاستدعائه وعرض رقمه على الشاشة)"
    }

    fun onOpenResetDialog() {
        _showResetDialog.value = true
    }

    fun onDismissResetDialog() {
        _showResetDialog.value = false
    }

    /**
     * تصفير وتفريغ قائمة الدور الحالية:
     * - في حال archive = true: يتم نقل سجل المراجعين إلى صفحة الإحصائيات والتقارير وتفريغ الدور.
     * - في حال archive = false: يتم حذف وتفريغ القائمة نهائياً دون نقل المراجعين للإحصائيات.
     */
    fun onConfirmResetQueue(archive: Boolean = true) {
        _isQueueStarted.value = false
        _showResetDialog.value = false
        callingJob?.cancel()
        announcementManager.resetState()
        viewModelScope.launch {
            if (archive) {
                val count = repository.archiveAndResetQueue()
                if (count > 0) {
                    _toastMessage.value = "تم نقل سجل $count مراجع إلى الإحصائيات وتفريغ الدور بنجاح"
                } else {
                    _toastMessage.value = "تم تصفير وتفريغ قائمة الدور"
                }
            } else {
                val count = repository.clearLiveQueueWithoutArchiving()
                if (count > 0) {
                    _toastMessage.value = "تم حذف $count مراجع وتفريغ القائمة دون نقلهم للإحصائيات"
                } else {
                    _toastMessage.value = "تم تفريغ قائمة الدور"
                }
            }
        }
    }

    fun onOpenTicketPreview(patient: Patient) {
        _previewTicketPatient.value = patient
    }

    fun onDismissTicketPreview() {
        _previewTicketPatient.value = null
    }

    fun onPrintPreviewTicket() {
        val patient = _previewTicketPatient.value ?: return
        viewModelScope.launch {
            val success = printerManager.printTicket(
                patient = patient,
                settings = settings.value,
                paperSize = settings.value.paperSize
            )
            if (success) {
                _toastMessage.value = "تمت طباعة التذكرة بنجاح"
            }
        }
    }

    // Clinic and Doctor Settings
    fun onClinicNameChanged(name: String) {
        repository.updateSettings(settings.value.copy(clinicName = name))
    }

    fun onDoctorNameChanged(name: String) {
        repository.updateSettings(settings.value.copy(doctorName = name))
    }

    fun onClinicPhoneChanged(phone: String) {
        repository.updateSettings(settings.value.copy(clinicPhone = phone))
    }

    fun onFooterMessageChanged(msg: String) {
        repository.updateSettings(settings.value.copy(footerMessage = msg))
    }

    fun onPaperSizeChanged(size: PaperSize) {
        repository.updateSettings(settings.value.copy(paperSize = size))
    }

    fun onToggleAutoPrint(enabled: Boolean) {
        repository.updateSettings(settings.value.copy(autoPrintOnAdd = enabled))
    }

    fun onLayoutDirectionChanged(isRtl: Boolean) {
        repository.updateSettings(settings.value.copy(isRtlLayout = isRtl))
    }

    // Audio Control Methods
    fun onVoiceGenderChanged(gender: com.example.data.model.VoiceGender) {
        repository.updateSettings(settings.value.copy(voiceGender = gender))
    }

    fun onSpeechRateChanged(rate: Float) {
        repository.updateSettings(settings.value.copy(speechRate = rate))
    }

    fun onPitchChanged(pitch: Float) {
        repository.updateSettings(settings.value.copy(pitch = pitch))
    }

    fun onVolumeChanged(volume: Float) {
        announcementManager.applyVolume(volume)
        repository.updateSettings(settings.value.copy(volume = volume))
    }

    fun onToggleChime(enabled: Boolean) {
        repository.updateSettings(settings.value.copy(enableChime = enabled))
    }

    fun onCallPhraseChanged(phrase: String) {
        repository.updateSettings(settings.value.copy(callPhrase = phrase))
    }

    fun onTestAudio() {
        testAudioJob?.cancel()
        testAudioJob = viewModelScope.launch {
            _isTestingAudio.value = true
            announcementManager.testAnnouncement(settings.value)
            _isTestingAudio.value = false
        }
    }

    fun onResetAudioDefaults() {
        announcementManager.applyVolume(1.0f)
        repository.updateSettings(
            settings.value.copy(
                speechRate = 0.85f,
                pitch = 1.0f,
                volume = 1.0f,
                voiceGender = com.example.data.model.VoiceGender.MALE,
                enableChime = true,
                callPhrase = "المراجع رقم {number} ، يرجى التوجه إلى غرفة العيادة"
            )
        )
        _toastMessage.value = "تمت استعادة إعدادات الصوت الافتراضية"
    }

    fun onSelectPrinter(device: BluetoothDeviceInfo) {
        viewModelScope.launch {
            val btDevice = bluetoothDeviceManager.getDevice(device.address)
            if (btDevice != null) {
                _toastMessage.value = "جاري الاتصال بالطابعة ${device.name}..."
                val success = printerManager.connectPrinter(btDevice)
                if (success) {
                    repository.updateSettings(
                        settings.value.copy(
                            selectedPrinterName = device.name,
                            selectedPrinterAddress = device.address
                        )
                    )
                    _toastMessage.value = "تم الاتصال بالطابعة ${device.name} بنجاح"
                    navigateBack()
                } else {
                    _toastMessage.value = "فشل الاتصال بالطابعة ${device.name}. تأكد من تشغيلها واقترانها."
                }
            } else {
                _toastMessage.value = "تعذر العثور على عنوان جهاز الطابعة"
            }
        }
    }

    fun onDisconnectPrinter() {
        viewModelScope.launch {
            printerManager.disconnectPrinter()
            repository.updateSettings(
                settings.value.copy(
                    selectedPrinterName = "",
                    selectedPrinterAddress = ""
                )
            )
            _toastMessage.value = "تم قطع الاتصال بالطابعة"
        }
    }

    fun onSelectSpeaker(device: BluetoothDeviceInfo) {
        audioRouteManager.connectSpeaker(device.name, device.address)
        repository.updateSettings(
            settings.value.copy(
                selectedSpeakerName = device.name,
                selectedSpeakerAddress = device.address
            )
        )
        _toastMessage.value = "تم تحديد وتحويل الصوت إلى السماعة ${device.name}"
        navigateBack()
    }

    fun onDisconnectSpeaker() {
        audioRouteManager.disconnectSpeaker()
        repository.updateSettings(
            settings.value.copy(
                selectedSpeakerName = "",
                selectedSpeakerAddress = ""
            )
        )
        _toastMessage.value = "تم قطع الاتصال بالسماعة والتحويل إلى سماعة الهاتف"
    }

    fun clearToastMessage() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        announcementManager.shutdown()
    }
}
