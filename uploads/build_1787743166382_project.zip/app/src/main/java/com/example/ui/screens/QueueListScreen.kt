package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.CallingState
import com.example.data.model.Patient
import com.example.ui.components.TvDisplayDialog
import com.example.ui.theme.AmberBorder
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberText
import com.example.ui.theme.GreenBorder
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

enum class QueueFilter(val label: String) {
    ALL("الكل"),
    WAITING("في الانتظار"),
    POSTPONED("المؤجلين"),
    CALLED("تم الاستدعاء")
}

@Composable
fun QueueListScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val patients by viewModel.patients.collectAsState()
    val currentPatient by viewModel.currentPatient.collectAsState()
    val showAddDialog by viewModel.showAddPatientDialog.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val previewPatient by viewModel.previewTicketPatient.collectAsState()
    val callingState by viewModel.callingState.collectAsState()
    val isPrinterConnected by viewModel.printerManager.isConnected.collectAsState()
    val isSpeakerConnected by viewModel.audioRouteManager.isSpeakerConnected.collectAsState()
    val isTvServerRunning by viewModel.isTvServerRunning.collectAsState()
    val tvServerUrl by viewModel.tvServerUrl.collectAsState()
    val showTvDialog by viewModel.showTvDialog.collectAsState()
    val isHotspotActive by viewModel.isHotspotActive.collectAsState()
    val hotspotSsid by viewModel.hotspotSsid.collectAsState()
    val hotspotPassword by viewModel.hotspotPassword.collectAsState()
    val hotspotStatusMessage by viewModel.hotspotStatusMessage.collectAsState()
    val isHotspotLoading by viewModel.isHotspotLoading.collectAsState()
    val isTvAudioOnly by viewModel.isTvAudioOnly.collectAsState()
    val isQueueStarted by viewModel.isQueueStarted.collectAsState()

    var selectedFilter by remember { mutableStateOf(QueueFilter.ALL) }

    val filteredPatients = when (selectedFilter) {
        QueueFilter.ALL -> patients
        QueueFilter.WAITING -> patients.filter { !it.isPostponed && !it.isCalled }
        QueueFilter.POSTPONED -> patients.filter { it.isPostponed }
        QueueFilter.CALLED -> patients.filter { !it.isPostponed && it.isCalled }
    }

    val waitingCount = patients.count { !it.isPostponed && !it.isCalled }
    val postponedCount = patients.count { it.isPostponed }
    val calledCount = patients.count { !it.isPostponed && it.isCalled }

    val nextNumber = if (patients.isEmpty()) 1 else (patients.maxOf { it.queueNumber } + 1)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Top Header Bar
            QueueScreenHeader(
                clinicName = settings.clinicName.ifBlank { "نظام إدارة المراجعين" },
                doctorName = settings.doctorName,
                isPrinterConnected = isPrinterConnected,
                isSpeakerConnected = isSpeakerConnected,
                isTvServerRunning = isTvServerRunning,
                onAddPatient = { viewModel.onAddPatientClicked() },
                onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) },
                onTvClick = { viewModel.onOpenTvDialog() },
                onResetClick = { viewModel.onOpenResetDialog() }
            )

            // Calling Audio Notification Banner (if actively speaking/playing chime)
            AnimatedVisibility(
                visible = callingState != CallingState.IDLE,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF2563EB))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (callingState == CallingState.CHIME_PLAYING) "جاري تشغيل نغمة التنبيه..." else "جاري النداء الصوتي للمراجع...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Start Queue & Active Control Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                if (!isQueueStarted) {
                    // Pre-Start Setup Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2563EB).copy(alpha = 0.3f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFEAB308))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "مرحلة تسجيل المراجعين",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyDark
                                    )
                                }

                                Text(
                                    text = "المسجلين: ${patients.size}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2563EB)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "أضف المراجعين أولاً، ثم اضغط (بدأ) لبدء الدور والمناداة وعرض الأرقام على الشاشة",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.onStartQueueClicked() },
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .height(46.dp)
                                        .testTag("btn_start_queue"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF16A34A),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "بدأ الدور والاستدعاء",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                OutlinedButton(
                                    onClick = { viewModel.onAddPatientClicked() },
                                    modifier = Modifier
                                        .weight(0.9f)
                                        .height(46.dp)
                                        .testTag("btn_quick_add_patient"),
                                    shape = RoundedCornerShape(12.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyDark)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = null,
                                        tint = NavyDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "إضافة مراجع",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyDark
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // Active Queue Control Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = NavyDark),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF22C55E))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "الدور جاري الآن 🟢",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF4ADE80)
                                    )
                                }

                                if (currentPatient != null) {
                                    Text(
                                        text = "المراجع الحالي: ${currentPatient!!.formattedNumber}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action buttons: Next, Recall, Postpone
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.onCallNextPatientClicked() },
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(42.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF2563EB),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "المراجع التالي ◀",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                OutlinedButton(
                                    onClick = { viewModel.onRecallCurrentPatient() },
                                    modifier = Modifier
                                        .weight(0.9f)
                                        .height(42.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = Color.White
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "إعادة",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                OutlinedButton(
                                    onClick = { viewModel.onPostponeCurrentPatient() },
                                    modifier = Modifier
                                        .weight(0.8f)
                                        .height(42.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = Color(0xFFFDE68A)
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.6f)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.HourglassTop,
                                        contentDescription = null,
                                        tint = Color(0xFFFDE68A),
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "تأجيل",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Quick instruction tip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "اضغط على أي مراجع للاستدعاء الصوتي مباشرة",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = "الإجمالي: ${patients.size}",
                        fontSize = 12.sp,
                        color = NavyDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(QueueFilter.values()) { filter ->
                    val isSelected = selectedFilter == filter
                    val count = when (filter) {
                        QueueFilter.ALL -> patients.size
                        QueueFilter.WAITING -> waitingCount
                        QueueFilter.POSTPONED -> postponedCount
                        QueueFilter.CALLED -> calledCount
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NavyDark else Color.White)
                            .border(
                                1.dp,
                                if (isSelected) NavyDark else Color(0xFFE2E8F0),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedFilter = filter }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = filter.label,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (isSelected) Color.White.copy(alpha = 0.2f) else Color(0xFFF1F5F9))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "$count",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Patients List
            if (filteredPatients.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(NavyDark.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonOutline,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (patients.isEmpty()) "لا يوجد مراجعين حالياً" else "لا توجد نتائج في هذا التصنيف",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (patients.isEmpty()) "اضغط على زر (+) لإضافة مراجع وإصدار تذكرة دور" else "اختر تصنيفاً آخر أو أضف مراجع جديد",
                            fontSize = 13.sp,
                            color = TextMuted
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredPatients, key = { it.id }) { patient ->
                        val isCurrent = !patient.isPostponed && patient.queueNumber == (currentPatient?.queueNumber ?: -1)

                        DirectPatientListItem(
                            patient = patient,
                            isCurrent = isCurrent,
                            onCall = {
                                if (patient.isPostponed) {
                                    viewModel.onRecallPostponedPatient(patient)
                                } else {
                                    viewModel.onCallSpecificPatient(patient)
                                }
                            },
                            onPostpone = {
                                viewModel.onPostponeSpecificPatient(patient)
                            },
                            onRestore = {
                                viewModel.onRestorePostponedToQueue(patient)
                            },
                            onPreview = {
                                viewModel.onOpenTicketPreview(patient)
                            },
                            onDelete = {
                                viewModel.onDeletePatient(patient)
                            }
                        )
                    }
                }
            }

            // Bottom Navigation Bar (قائمة المراجعين + الإعدادات)
            BottomNavBar(
                activeScreen = AppScreen.QUEUE_LIST,
                onQueueClick = { /* Already here */ },
                onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
            )
        }

        // Floating Action Button to add patient
        FloatingActionButton(
            onClick = { viewModel.onAddPatientClicked() },
            containerColor = NavyDark,
            contentColor = TextOnNavy,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 76.dp, end = 20.dp)
                .testTag("fab_add_patient")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة مراجع",
                modifier = Modifier.size(24.dp)
            )
        }
    }

    if (showAddDialog) {
        AddPatientDialog(
            nextQueueNumber = nextNumber,
            initialAutoPrint = settings.autoPrintOnAdd,
            onConfirm = { name, note, shouldPrint ->
                viewModel.onConfirmAddPatient(name, note, shouldPrint)
            },
            onDismiss = { viewModel.onDismissAddPatientDialog() }
        )
    }

    if (previewPatient != null) {
        TicketPreviewDialog(
            patient = previewPatient!!,
            settings = settings,
            onPrintClick = { viewModel.onPrintPreviewTicket() },
            onDismiss = { viewModel.onDismissTicketPreview() }
        )
    }

    if (showTvDialog) {
        TvDisplayDialog(
            isRunning = isTvServerRunning,
            serverUrl = tvServerUrl,
            isHotspotActive = isHotspotActive,
            hotspotSsid = hotspotSsid,
            hotspotPassword = hotspotPassword,
            hotspotStatusMessage = hotspotStatusMessage,
            isHotspotLoading = isHotspotLoading,
            isTvAudioOnly = isTvAudioOnly,
            onToggleServer = { viewModel.onToggleTvServer(it) },
            onToggleHotspot = { viewModel.onToggleLocalHotspot(it) },
            onToggleTvAudioOnly = { viewModel.onToggleTvAudioOnly(it) },
            onRefreshIp = { viewModel.onRefreshTvIp() },
            onDismiss = { viewModel.onDismissTvDialog() }
        )
    }
}

/**
 * Top Header Bar for Queue List Screen
 */
@Composable
fun QueueScreenHeader(
    clinicName: String,
    doctorName: String,
    isPrinterConnected: Boolean,
    isSpeakerConnected: Boolean,
    isTvServerRunning: Boolean,
    onAddPatient: () -> Unit,
    onSettingsClick: () -> Unit,
    onTvClick: () -> Unit,
    onResetClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .border(1.dp, Color(0xFFF1F5F9))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Clinic Title & Subtitle
            Column {
                Text(
                    text = clinicName,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )
                if (doctorName.isNotBlank()) {
                    Text(
                        text = "د. $doctorName",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }

            // Quick Status & Actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // TV Connection Chip
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isTvServerRunning) Color(0xFFEFF6FF) else Color(0xFFF1F5F9))
                        .clickable { onTvClick() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tv,
                        contentDescription = "شاشة التلفزيون",
                        tint = if (isTvServerRunning) Color(0xFF2563EB) else TextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isTvServerRunning) "شاشة TV" else "TV",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isTvServerRunning) Color(0xFF2563EB) else TextMuted
                    )
                }

                // Device connection chips
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isPrinterConnected || isSpeakerConnected) GreenContainer else Color(0xFFF1F5F9))
                        .clickable { onSettingsClick() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Bluetooth,
                        contentDescription = null,
                        tint = if (isPrinterConnected || isSpeakerConnected) GreenText else TextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isPrinterConnected && isSpeakerConnected) "متصل بالكل"
                        else if (isPrinterConnected) "طابعة متصلة"
                        else if (isSpeakerConnected) "سماعة متصلة"
                        else "الأجهزة",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isPrinterConnected || isSpeakerConnected) GreenText else TextMuted
                    )
                }

                // Reset Queue Button
                IconButton(
                    onClick = onResetClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "تصفير الدور",
                        tint = RedDestructive,
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }
    }
}

/**
 * Direct Patient List Item - clicking on name or item immediately calls the patient!
 * Includes clear Postpone button, preview/print, and delete options.
 */
@Composable
fun DirectPatientListItem(
    patient: Patient,
    isCurrent: Boolean,
    onCall: () -> Unit,
    onPostpone: () -> Unit,
    onRestore: () -> Unit,
    onPreview: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White)
            .border(
                width = if (isCurrent) 1.5.dp else 1.dp,
                color = if (isCurrent) Color(0xFF2563EB) else if (patient.isPostponed) AmberBorder else Color(0xFFE2E8F0),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onCall() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("patient_item_${patient.queueNumber}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Queue Number Badge (Right / Start)
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isCurrent) Color(0xFF2563EB)
                        else if (patient.isPostponed) AmberContainer
                        else if (patient.isCalled) Color(0xFFF1F5F9)
                        else NavyDark
                    )
                    .border(
                        1.dp,
                        if (isCurrent) Color(0xFF2563EB) else if (patient.isPostponed) AmberBorder else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = patient.formattedNumber,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (patient.isPostponed) AmberText else if (patient.isCalled && !isCurrent) NavyDark else Color.White
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Patient Name, Status & Note (Middle Content)
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (patient.name.isNotBlank()) patient.name else "المراجع رقم ${patient.formattedNumber}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCurrent) Color(0xFF2563EB) else TextPrimary,
                        maxLines = 1
                    )

                    // Status Badge
                    if (isCurrent) {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(GreenContainer)
                                .border(1.dp, GreenBorder, CircleShape)
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "نشط الآن",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = GreenText
                            )
                        }
                    } else if (patient.isPostponed) {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(AmberContainer)
                                .border(1.dp, AmberBorder, CircleShape)
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "مؤجل",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AmberText
                            )
                        }
                    } else if (patient.isCalled) {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color(0xFFF1F5F9))
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "تم الاستدعاء",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextSecondary
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color(0xFFF1F5F9))
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "في الانتظار",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextMuted
                            )
                        }
                    }
                }

                if (patient.note.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = patient.note,
                        fontSize = 11.sp,
                        color = TextMuted,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Action Buttons Row (Clean, perfectly proportioned, no overlap)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Postpone / Restore Button
                if (patient.isPostponed) {
                    IconButton(
                        onClick = onRestore,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF1F5F9))
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "إعادة للدور",
                            tint = TextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                } else {
                    IconButton(
                        onClick = onPostpone,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AmberContainer)
                            .border(1.dp, AmberBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = "تأجيل",
                            tint = AmberText,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                // Print / Preview Ticket Icon
                IconButton(
                    onClick = onPreview,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = "معاينة الوصل",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Delete Button
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
