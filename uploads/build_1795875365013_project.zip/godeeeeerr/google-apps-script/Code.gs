const SUB_SHEET = "المشتركين";
const SESS_SHEET = "الجلسات";
const ADMIN_PROP = "ADMIN_PASS_HASH";
const SUB_TTL = 30 * 86400000;
const ADM_TTL = 12 * 3600000;

function doGet(e) {
  const route = String((e && e.parameter && e.parameter.route) || "health");
  if (route === "health") return out({ ok: true, configured: true, backend: "google_sheets" });
  if (route === "admin_status") {
    ensureSheets();
    return out({ ok: true, hasAdminPassword: Boolean(getProp(ADMIN_PROP)) });
  }
  return errOut(404, "المسار غير موجود");
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    ensureSheets();
    const b = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    const r = String(b.route || "");

    if (r === "auth_login") return handleLogin(b);
    if (r === "auth_me") return handleMe(b);
    if (r === "auth_logout") { delSession(b.token); return out({ ok: true }); }
    if (r === "admin_status") return out({ ok: true, hasAdminPassword: Boolean(getProp(ADMIN_PROP)) });
    if (r === "admin_setup") return handleAdminSetup(b);
    if (r === "admin_login") return handleAdminLogin(b);

    if (!verifyAdminToken(b.token)) return errOut(401, "انتهت جلسة الإدارة أو رمز الدخول غير صالح");
    if (r === "admin_change_password") return handleChangeAdminPass(b);
    if (r === "admin_list_subscribers") return out({ ok: true, subscribers: readAllSubs() });
    if (r === "admin_create_subscriber") return handleCreateSub(b);
    if (r === "admin_update_subscriber") return handleUpdateSub(b);
    if (r === "admin_delete_subscriber") return handleDeleteSub(b);
    return errOut(404, "الإجراء غير معروف");
  } catch (ex) {
    return errOut(500, "حدث خطأ في السكربت: " + ex.message);
  } finally {
    lock.releaseLock();
  }
}

function handleLogin(b) {
  const phone = normPhone(b.phone), pass = String(b.password || "");
  if (!phone || !pass) return errOut(400, "يرجى إدخال رقم الهاتف وكلمة المرور");
  const found = findSubByPhone(phone);
  if (!found || !checkAndUpgradePw(found.rowIdx, pass, found.rawPass)) {
    return errOut(401, "رقم الهاتف أو كلمة المرور غير صحيحة");
  }
  const sub = found.sub, now = Date.now();
  if (!sub.isActive) return errOut(403, "تم إيقاف هذا الاشتراك من قِبل الإدارة");
  if (sub.expiresAt && now > sub.expiresAt) return errOut(403, "انتهت صلاحية الاشتراك، يرجى التواصل مع الإدارة لتجديده");
  const exp = sub.expiresAt ? Math.min(sub.expiresAt, now + SUB_TTL) : now + SUB_TTL;
  return out({ ok: true, token: createSession("sub", sub.id, exp), subscriber: sub });
}

function handleMe(b) {
  const sess = findSession(b.token, "sub");
  if (!sess) return errOut(401, "انتهت الجلسة، يرجى تسجيل الدخول مجدداً");
  const found = findSubById(sess.refId);
  if (!found) return errOut(401, "لم يعد هذا الحساب متاحاً، يرجى تسجيل الدخول مجدداً");
  const sub = found.sub, now = Date.now();
  if (!sub.isActive) return errOut(403, "تم إيقاف اشتراكك من قِبل الإدارة");
  if (sub.expiresAt && now > sub.expiresAt) return errOut(403, "انتهت صلاحية اشتراكك، يرجى التواصل مع الإدارة لتجديده");
  return out({ ok: true, subscriber: sub });
}

function handleAdminSetup(b) {
  const pass = String(b.password || "");
  if (pass.length < 4) return errOut(400, "كلمة المرور يجب أن تكون 4 أحرف على الأقل");
  if (getProp(ADMIN_PROP)) return errOut(409, "تم تعيين كلمة مرور الإدارة مسبقاً");
  PropertiesService.getScriptProperties().setProperty(ADMIN_PROP, hashPw(pass));
  return out({ ok: true, token: createSession("admin", 0, Date.now() + ADM_TTL) });
}

function handleAdminLogin(b) {
  const pass = String(b.password || ""), stored = getProp(ADMIN_PROP);
  if (!stored) return errOut(400, "لم يتم إعداد كلمة مرور الإدارة بعد");
  if (!pass || !verifyPw(pass, stored)) return errOut(401, "كلمة مرور الإدارة غير صحيحة");
  return out({ ok: true, token: createSession("admin", 0, Date.now() + ADM_TTL) });
}

function handleChangeAdminPass(b) {
  const cur = String(b.currentPassword || ""), nxt = String(b.newPassword || ""), stored = getProp(ADMIN_PROP);
  if (nxt.length < 4) return errOut(400, "كلمة المرور الجديدة يجب أن تكون 4 أحرف على الأقل");
  if (!stored || !verifyPw(cur, stored)) return errOut(401, "كلمة المرور الحالية غير صحيحة");
  PropertiesService.getScriptProperties().setProperty(ADMIN_PROP, hashPw(nxt));
  return out({ ok: true });
}

function handleCreateSub(b) {
  const fullName = String(b.fullName || "").trim(), officeName = String(b.officeName || "").trim();
  const phone = normPhone(b.phone), pass = String(b.password || ""), notes = String(b.notes || "").trim();
  const days = b.durationDays == null ? null : Number(b.durationDays);
  if (!fullName) return errOut(400, "يرجى إدخال اسم المشترك");
  if (!phone) return errOut(400, "يرجى إدخال رقم الهاتف");
  if (pass.length < 4) return errOut(400, "كلمة المرور يجب أن تكون 4 أحرف على الأقل");
  if (findSubByPhone(phone)) return errOut(409, "رقم الهاتف مسجل مسبقاً لمشترك آخر");

  const sh = sheet(SUB_SHEET), now = Date.now(), id = nextId(sh);
  const exp = days && days > 0 ? now + Math.round(days) * 86400000 : null;
  const rowNum = sh.getLastRow() + 1;
  sh.getRange(rowNum, 4, 1, 2).setNumberFormat("@");
  sh.getRange(rowNum, 7, 1, 1).setNumberFormat("@");
  sh.getRange(rowNum, 1, 1, 9).setValues([[
    id, fullName, officeName, phone, hashPw(pass), "نعم", formatExp(exp), notes, formatDate(now)
  ]]);
  return out({
    ok: true,
    subscriber: { id, fullName, officeName, phone, isActive: true, expiresAt: exp, notes, createdAt: now }
  });
}

function handleUpdateSub(b) {
  const found = findSubById(Number(b.id));
  if (!found) return errOut(404, "المشترك غير موجود");
  const sh = sheet(SUB_SHEET), r = found.rowIdx;
  if (b.action === "toggle_active") {
    const active = Boolean(b.isActive);
    sh.getRange(r, 6).setValue(active ? "نعم" : "لا");
    if (!active) delSubSessions(found.sub.id);
    return out({ ok: true });
  }
  if (b.action === "extend") {
    const days = b.durationDays == null ? null : Number(b.durationDays);
    const now = Date.now(), cur = found.sub.expiresAt || 0;
    const nextExp = days && days > 0 ? Math.max(now, cur) + Math.round(days) * 86400000 : null;
    sh.getRange(r, 7).setNumberFormat("@").setValue(formatExp(nextExp));
    sh.getRange(r, 6).setValue("نعم");
    return out({ ok: true, expiresAt: nextExp });
  }
  if (b.action === "reset_password") {
    const np = String(b.newPassword || "");
    if (np.length < 4) return errOut(400, "كلمة المرور يجب أن تكون 4 أحرف على الأقل");
    sh.getRange(r, 5).setNumberFormat("@").setValue(hashPw(np));
    delSubSessions(found.sub.id);
    return out({ ok: true });
  }
  return errOut(400, "إجراء غير مدعوم");
}

function handleDeleteSub(b) {
  const found = findSubById(Number(b.id));
  if (found) {
    delSubSessions(found.sub.id);
    sheet(SUB_SHEET).deleteRow(found.rowIdx);
  }
  return out({ ok: true });
}

function ensureSheets() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss.getSheetByName(SUB_SHEET)) {
    const s = ss.getSheets()[0];
    s.setName(SUB_SHEET);
    if (s.getLastRow() === 0) {
      s.appendRow(["المعرف", "الاسم الكامل", "اسم المكتب", "رقم الهاتف", "كلمة المرور", "نشط", "تاريخ الانتهاء", "ملاحظات", "تاريخ الإنشاء"]);
      s.setFrozenRows(1);
    }
  }
  if (!ss.getSheetByName(SESS_SHEET)) {
    const ss2 = ss.insertSheet(SESS_SHEET);
    ss2.appendRow(["token_hash", "kind", "ref_id", "expires_at"]);
    ss2.hideSheet();
  }
}

const sheet = (name) => SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
const getProp = (k) => PropertiesService.getScriptProperties().getProperty(k);

function readAllSubs() {
  const sh = sheet(SUB_SHEET), last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, 9).getValues().map(rowToSub).filter(Boolean).reverse();
}

function findSubByPhone(phone) {
  const sh = sheet(SUB_SHEET), last = sh.getLastRow();
  if (last < 2) return null;
  const rows = sh.getRange(2, 1, last - 1, 9).getValues();
  for (let i = 0; i < rows.length; i++) {
    if (normPhone(rows[i][3]) === phone) return { rowIdx: i + 2, rawPass: String(rows[i][4] || ""), sub: rowToSub(rows[i]) };
  }
  return null;
}

function findSubById(id) {
  const sh = sheet(SUB_SHEET), last = sh.getLastRow();
  if (last < 2) return null;
  const rows = sh.getRange(2, 1, last - 1, 9).getValues();
  for (let i = 0; i < rows.length; i++) {
    if (Number(rows[i][0]) === id) return { rowIdx: i + 2, rawPass: String(rows[i][4] || ""), sub: rowToSub(rows[i]) };
  }
  return null;
}

function rowToSub(r) {
  const phone = normPhone(r[3]);
  if (!phone) return null;
  const activeVal = String(r[5] == null ? "" : r[5]).trim().toLowerCase();
  const isActive = activeVal === "true" || activeVal === "1" || activeVal === "نعم" || activeVal === "yes";
  return {
    id: Number(r[0] || 0),
    fullName: String(r[1] || ""),
    officeName: String(r[2] || ""),
    phone,
    isActive,
    expiresAt: parseExp(r[6]),
    notes: String(r[7] || ""),
    createdAt: parseExp(r[8]) || 0
  };
}

function nextId(sh) {
  const last = sh.getLastRow();
  if (last < 2) return 1;
  const ids = sh.getRange(2, 1, last - 1, 1).getValues().map((r) => Number(r[0] || 0));
  return Math.max(0, ...ids) + 1;
}

function createSession(kind, refId, exp) {
  const tok = Utilities.getUuid().replace(/-/g, "") + Utilities.getUuid().replace(/-/g, "");
  sheet(SESS_SHEET).appendRow([sha256Hex(tok), kind, Number(refId), Number(exp)]);
  return tok;
}

function findSession(tok, kind) {
  if (!tok) return null;
  const sh = sheet(SESS_SHEET), last = sh.getLastRow(), h = sha256Hex(String(tok).trim());
  if (last < 2) return null;
  const rows = sh.getRange(2, 1, last - 1, 4).getValues();
  for (let i = rows.length - 1; i >= 0; i--) {
    if (String(rows[i][0]) === h && String(rows[i][1]) === kind) {
      const exp = Number(rows[i][3] || 0);
      if (exp > 0 && Date.now() > exp) { sh.deleteRow(i + 2); return null; }
      return { rowIdx: i + 2, refId: Number(rows[i][2]) };
    }
  }
  return null;
}

function verifyAdminToken(tok) { return Boolean(findSession(tok, "admin")); }

function delSession(tok) {
  if (!tok) return;
  const sh = sheet(SESS_SHEET), last = sh.getLastRow(), h = sha256Hex(String(tok).trim());
  if (last < 2) return;
  const rows = sh.getRange(2, 1, last - 1, 1).getValues();
  for (let i = rows.length - 1; i >= 0; i--) {
    if (String(rows[i][0]) === h) sh.deleteRow(i + 2);
  }
}

function delSubSessions(subId) {
  const sh = sheet(SESS_SHEET), last = sh.getLastRow();
  if (last < 2) return;
  const rows = sh.getRange(2, 1, last - 1, 3).getValues();
  for (let i = rows.length - 1; i >= 0; i--) {
    if (String(rows[i][1]) === "sub" && Number(rows[i][2]) === subId) sh.deleteRow(i + 2);
  }
}

function checkAndUpgradePw(rowIdx, plain, stored) {
  if (!stored) return false;
  if (stored.startsWith("s2:")) return verifyPw(plain, stored);
  if (safeEq(plain, stored)) {
    sheet(SUB_SHEET).getRange(rowIdx, 5).setNumberFormat("@").setValue(hashPw(plain));
    return true;
  }
  return false;
}

function hashPw(pw) {
  const salt = Utilities.getUuid().replace(/-/g, "").slice(0, 16);
  let cur = salt + ":" + pw;
  for (let i = 0; i < 200; i++) cur = sha256Hex(cur);
  return "s2:" + salt + ":" + cur;
}

function verifyPw(pw, stored) {
  const p = String(stored || "").split(":");
  if (p.length !== 3 || p[0] !== "s2") return false;
  let cur = p[1] + ":" + pw;
  for (let i = 0; i < 200; i++) cur = sha256Hex(cur);
  return safeEq(cur, p[2]);
}

function sha256Hex(s) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(s), Utilities.Charset.UTF_8)
    .map((b) => (b < 0 ? b + 256 : b).toString(16).padStart(2, "0")).join("");
}

function safeEq(a, b) {
  const sa = String(a), sb = String(b);
  if (sa.length !== sb.length) return false;
  let d = 0;
  for (let i = 0; i < sa.length; i++) d |= sa.charCodeAt(i) ^ sb.charCodeAt(i);
  return d === 0;
}

function normPhone(raw) {
  return String(raw || "").trim().replace(/\s+/g, "")
    .replace(/[٠-٩]/g, (c) => "٠١٢٣٤٥٦٧٨٩".indexOf(c))
    .replace(/[۰-۹]/g, (c) => "۰۱۲۳۴۵۶۷۸۹".indexOf(c));
}

function parseExp(v) {
  if (v == null || v === "" || String(v).trim() === "مفتوح") return null;
  if (v instanceof Date) return v.getTime();
  if (typeof v === "number") return v > 0 ? v : null;
  const s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return new Date(s + "T23:59:59Z").getTime();
  const t = Date.parse(s);
  return Number.isNaN(t) ? null : t;
}

const formatDate = (ms) => Utilities.formatDate(new Date(ms), "UTC", "yyyy-MM-dd");
const formatExp = (ms) => (ms == null ? "مفتوح" : formatDate(ms));
const out = (obj) => ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
const errOut = (status, error) => out({ ok: false, status, error });
