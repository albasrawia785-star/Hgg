package com.example

/**
 * نموذج بيانات المكتب/المعرض للترويسة الرسمية
 * يحتوي على اسم المكتب وأرقام الهواتف (الأول والثاني) ورقم الإجازة والعنوان
 */
data class OfficeInfo(
    val officeName: String = "",
    val phone: String = "",
    val phone2: String = "",
    val licenseNo: String = "",
    val address: String = ""
) {
    /**
     * إرجاع أرقام الهواتف منسقة بصيغة موحدة (مثال: 07700000000 - 07800000000)
     */
    fun formattedPhones(): String {
        val p1 = phone.trim()
        val p2 = phone2.trim()
        return when {
            p1.isNotBlank() && p2.isNotBlank() -> "$p1 - $p2"
            p1.isNotBlank() -> p1
            p2.isNotBlank() -> p2
            else -> ""
        }
    }

    /**
     * تحقق مما إذا كانت بيانات المكتب فارغة بالكامل
     */
    fun isBlank(): Boolean = officeName.isBlank() && phone.isBlank() && phone2.isBlank() && licenseNo.isBlank() && address.isBlank()
}

