package com.example

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupData(
    val version: Int = BackupManager.CURRENT_VERSION,
    val exportedAt: Long = System.currentTimeMillis(),
    val officeInfo: OfficeInfo = OfficeInfo(),
    val contractCounters: Map<String, Int> = emptyMap(),
    val selectedTemplateId: String? = null,
    val templateOptions: TemplateCustomizationOptions? = null,
    val contracts: List<ContractEntity> = emptyList()
)

object BackupManager {

    const val CURRENT_VERSION = 1
    private const val APP_IDENTIFIER = "AqoodPro"
    private const val MAX_BACKUP_BYTES = 50 * 1024 * 1024 // 50 MB

    fun defaultBackupFileName(nowMillis: Long = System.currentTimeMillis()): String {
        val formatter = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US)
        return "aqood_pro_backup_${formatter.format(Date(nowMillis))}.json"
    }

    fun formatExportDate(timestamp: Long): String {
        val formatter = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale.getDefault())
        return formatter.format(Date(timestamp))
    }

    fun buildBackupJson(
        officeInfo: OfficeInfo,
        contracts: List<ContractEntity>,
        contractCounters: Map<String, Int>,
        selectedTemplateId: String? = null,
        templateOptions: TemplateCustomizationOptions? = null,
        exportedAt: Long = System.currentTimeMillis()
    ): String {
        val root = JSONObject().apply {
            put("app", APP_IDENTIFIER)
            put("version", CURRENT_VERSION)
            put("exportedAt", exportedAt)

            put("officeSettings", JSONObject().apply {
                put("officeName", officeInfo.officeName)
                put("phone", officeInfo.phone)
                put("phone2", officeInfo.phone2)
                put("licenseNo", officeInfo.licenseNo)
                put("address", officeInfo.address)
            })

            put("contractCounters", JSONObject().apply {
                contractCounters.forEach { (key, value) ->
                    put(key, value.coerceAtLeast(1))
                }
            })

            if (selectedTemplateId != null || templateOptions != null) {
                put("templateSettings", JSONObject().apply {
                    put("selectedTemplateId", selectedTemplateId ?: JSONObject.NULL)
                    if (templateOptions != null) {
                        put("options", JSONObject().apply {
                            put("customHeaderColorHex", templateOptions.customHeaderColorHex ?: JSONObject.NULL)
                            put("customTitleColorHex", templateOptions.customTitleColorHex ?: JSONObject.NULL)
                            put("customFrameColorHex", templateOptions.customFrameColorHex ?: JSONObject.NULL)
                            put("customTextColorHex", templateOptions.customTextColorHex ?: JSONObject.NULL)
                            put("fontSizeScale", templateOptions.fontSizeScale.toDouble())
                            put("headerSizeScale", templateOptions.headerSizeScale.toDouble())
                            put("borderThicknessScale", templateOptions.borderThicknessScale.toDouble())
                            put("showLogo", templateOptions.showLogo)
                            put("showFrame", templateOptions.showFrame)
                            put("showPageNumber", templateOptions.showPageNumber)
                            put("marginScale", templateOptions.marginScale.toDouble())
                            put("paragraphSpacingScale", templateOptions.paragraphSpacingScale.toDouble())
                        })
                    }
                })
            }

            val contractsArray = JSONArray()
            contracts.forEach { contract ->
                contractsArray.put(JSONObject().apply {
                    put("id", contract.id)
                    put("contractType", contract.contractType)
                    put("title", contract.title)
                    put("primaryPartyName", contract.primaryPartyName)
                    put("secondaryPartyName", contract.secondaryPartyName)
                    put("dateCreated", contract.dateCreated)
                    put("jsonContent", contract.jsonContent)
                })
            }
            put("contracts", contractsArray)
        }
        return root.toString(2)
    }

    fun parseBackupJson(rawJson: String): Result<BackupData> {
        val cleaned = rawJson.removePrefix("\uFEFF").trim()
        if (cleaned.isBlank() || !cleaned.startsWith("{")) {
            return Result.failure(IllegalArgumentException("الملف المحدد فارغ أو ليس ملف نسخة احتياطية صالح"))
        }

        return try {
            val root = JSONObject(cleaned)
            val appTag = root.optString("app", "")
            val hasCoreSections = root.has("officeSettings") || root.has("contracts")
            if (!hasCoreSections || (appTag.isNotEmpty() && appTag != APP_IDENTIFIER)) {
                return Result.failure(
                    IllegalArgumentException("الملف المحدد لا يخص النسخ الاحتياطي لتطبيق عقود برو")
                )
            }

            val version = root.optInt("version", 1)
            if (version < 1 || version > CURRENT_VERSION) {
                return Result.failure(
                    IllegalArgumentException("إصدار النسخة الاحتياطية غير مدعوم في هذا الإصدار من التطبيق")
                )
            }

            val exportedAt = root.optLong("exportedAt", System.currentTimeMillis())

            val officeJson = root.optJSONObject("officeSettings")
            val officeInfo = if (officeJson != null) {
                OfficeInfo(
                    officeName = officeJson.optString("officeName", ""),
                    phone = officeJson.optString("phone", ""),
                    phone2 = officeJson.optString("phone2", ""),
                    licenseNo = officeJson.optString("licenseNo", ""),
                    address = officeJson.optString("address", "")
                )
            } else {
                OfficeInfo()
            }

            val countersMap = mutableMapOf<String, Int>()
            val countersJson = root.optJSONObject("contractCounters")
            if (countersJson != null) {
                val keys = countersJson.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = countersJson.optInt(key, 1).coerceAtLeast(1)
                    countersMap[key] = value
                }
            }

            var selectedTemplateId: String? = null
            var templateOptions: TemplateCustomizationOptions? = null
            val templateJson = root.optJSONObject("templateSettings")
            if (templateJson != null) {
                selectedTemplateId = templateJson.optNullableString("selectedTemplateId")
                val optJson = templateJson.optJSONObject("options")
                if (optJson != null) {
                    templateOptions = TemplateCustomizationOptions(
                        customHeaderColorHex = optJson.optNullableString("customHeaderColorHex"),
                        customTitleColorHex = optJson.optNullableString("customTitleColorHex"),
                        customFrameColorHex = optJson.optNullableString("customFrameColorHex"),
                        customTextColorHex = optJson.optNullableString("customTextColorHex"),
                        fontSizeScale = optJson.optDouble("fontSizeScale", 1.0).toFloat(),
                        headerSizeScale = optJson.optDouble("headerSizeScale", 1.0).toFloat(),
                        borderThicknessScale = optJson.optDouble("borderThicknessScale", 1.0).toFloat(),
                        showLogo = optJson.optBoolean("showLogo", true),
                        showFrame = optJson.optBoolean("showFrame", true),
                        showPageNumber = optJson.optBoolean("showPageNumber", true),
                        marginScale = optJson.optDouble("marginScale", 1.0).toFloat(),
                        paragraphSpacingScale = optJson.optDouble("paragraphSpacingScale", 1.0).toFloat()
                    )
                }
            }

            val contractsList = mutableListOf<ContractEntity>()
            val contractsArray = root.optJSONArray("contracts")
            if (contractsArray != null) {
                for (i in 0 until contractsArray.length()) {
                    val item = contractsArray.optJSONObject(i) ?: continue
                    val contractType = item.optString("contractType", "").trim()
                    if (contractType.isEmpty()) continue
                    contractsList.add(
                        ContractEntity(
                            id = 0, // يُعاد توليده تلقائياً لتجنب تعارض المعرفات بين الأجهزة
                            contractType = contractType,
                            title = item.optString("title", ""),
                            primaryPartyName = item.optString("primaryPartyName", ""),
                            secondaryPartyName = item.optString("secondaryPartyName", ""),
                            dateCreated = item.optLong("dateCreated", System.currentTimeMillis()),
                            jsonContent = item.optString("jsonContent", "{}")
                        )
                    )
                }
            }

            Result.success(
                BackupData(
                    version = version,
                    exportedAt = exportedAt,
                    officeInfo = officeInfo,
                    contractCounters = countersMap,
                    selectedTemplateId = selectedTemplateId,
                    templateOptions = templateOptions,
                    contracts = contractsList
                )
            )
        } catch (e: Exception) {
            Result.failure(
                IllegalArgumentException("تعذر قراءة ملف النسخة الاحتياطية: الملف تالف أو غير صالح")
            )
        }
    }

    fun filterNonDuplicateContracts(
        incoming: List<ContractEntity>,
        existing: List<ContractEntity>
    ): Pair<List<ContractEntity>, Int> {
        val existingSignatures = existing.map { contractSignature(it) }.toMutableSet()
        val toInsert = mutableListOf<ContractEntity>()
        var skipped = 0

        incoming.forEach { entity ->
            val normalized = entity.copy(id = 0)
            val sig = contractSignature(normalized)
            if (existingSignatures.add(sig)) {
                toInsert.add(normalized)
            } else {
                skipped++
            }
        }
        return toInsert to skipped
    }

    private fun contractSignature(contract: ContractEntity): String {
        return "${contract.contractType}|${contract.title.trim()}|${contract.dateCreated}|${contract.jsonContent}"
    }

    suspend fun writeBackupToUri(
        context: Context,
        uri: Uri,
        jsonContent: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            val outputStream = try {
                resolver.openOutputStream(uri, "wt")
            } catch (_: Exception) {
                resolver.openOutputStream(uri)
            } ?: return@withContext Result.failure(IllegalStateException("تعذر فتح موقع الحفظ المحدد"))

            outputStream.use { stream ->
                OutputStreamWriter(stream, StandardCharsets.UTF_8).use { writer ->
                    writer.write(jsonContent)
                    writer.flush()
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("فشل حفظ النسخة الاحتياطية: ${e.localizedMessage ?: "خطأ غير متوقع"}")
            )
        }
    }

    suspend fun readBackupFromUri(
        context: Context,
        uri: Uri
    ): Result<BackupData> = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            val inputStream = resolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalStateException("تعذر فتح الملف المحدد"))

            val content = inputStream.use { stream ->
                val buffer = StringBuilder()
                BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use { reader ->
                    val chars = CharArray(8192)
                    var totalChars = 0
                    var read = reader.read(chars)
                    while (read != -1) {
                        totalChars += read
                        if (totalChars > MAX_BACKUP_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("حجم الملف المحدد كبير جداً ولا يطابق ملف نسخ احتياطي")
                            )
                        }
                        buffer.append(chars, 0, read)
                        read = reader.read(chars)
                    }
                }
                buffer.toString()
            }

            parseBackupJson(content)
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("تعذر قراءة الملف المحدد: ${e.localizedMessage ?: "خطأ غير متوقع"}")
            )
        }
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val value = optString(key, "")
        return if (value.isBlank() || value == "null") null else value
    }
}
