package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface

/**
 * HeaderRenderer: مسؤول عن رسم رأس العقد الاحترافي الموحد (Header Area) لجميع أنواع العقود.
 * يحتوي حصراً على:
 * - اسم المكتب
 * - رقم الهاتف
 * - عنوان العقد
 * - رقم العقد
 * - التاريخ
 *
 * بدون أي صور أو أيقونات أو شعارات نهائياً، مع معالجة حركية لديناميكية النص لمنع التداخل.
 */
object HeaderRenderer {

    /**
     * رسم رأس العقد الموحد
     *
     * @param canvas القماش المراد الرسم عليه
     * @param officeInfo بيانات المكتب (الاسم، الهاتف)
     * @param contractTitle عنوان العقد (مثال: عقد بيع وشراء سيارة)
     * @param contractNo رقم العقد
     * @param contractDate التاريخ
     * @param context السياق
     * @param pageWidth عرض الصفحة (A4_WIDTH = 1240)
     * @param pageHeight ارتفاع الصفحة (A4_HEIGHT = 1754)
     * @param startY موضع البدء العمودي
     * @return الموضع السفلي النهائي للـ Header لإكمال العناصر بمرونة
     */
    fun renderHeader(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        contractTitle: String,
        contractNo: String,
        contractDate: String,
        context: Context? = null,
        pageWidth: Float = 1240f,
        pageHeight: Float = 1754f,
        startY: Float = 45f
    ): Float {
        val isBitmapScale = pageWidth > 800f
        val scale = if (isBitmapScale) 1.0f else (pageWidth / 1240f)

        val name = officeInfo.officeName.trim().ifEmpty { "المكتب العقاري / التجاري" }
        val phone = officeInfo.phone.trim()
        val address = officeInfo.address.trim()

        val centerX = pageWidth / 2f
        val margin = 50f * scale
        var currentY = startY

        // 1. الشريط الأعلى: رقم العقد (يمين) | التاريخ (يسار)
        val metaPaintRight = Paint().apply {
            color = Color.parseColor("#991B1B") // أحمر داكن عالي التباين لرقم العقد
            textSize = 22f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        val metaPaintLeft = Paint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 20f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
            isAntiAlias = true
        }

        canvas.drawText("رقم العقد: $contractNo", pageWidth - margin, currentY + (22f * scale), metaPaintRight)
        canvas.drawText("التاريخ: $contractDate", margin, currentY + (22f * scale), metaPaintLeft)

        currentY += 35f * scale

        // 2. اسم المكتب الرئيسي (مع ضابط الحجم التلقائي يمنع أي تداخل)
        val officeNamePaint = Paint().apply {
            color = Color.parseColor("#0F172A") // كحلي داكن فاخر
            textSize = 38f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val maxAllowedWidth = pageWidth - (300f * scale)
        var textWidth = officeNamePaint.measureText(name)
        while (textWidth > maxAllowedWidth && officeNamePaint.textSize > (18f * scale)) {
            officeNamePaint.textSize -= 1f * scale
            textWidth = officeNamePaint.measureText(name)
        }

        canvas.drawText(name, centerX, currentY + (30f * scale), officeNamePaint)
        currentY += 38f * scale

        // 3. أرقام الهواتف والعنوان
        val phonesFormatted = officeInfo.formattedPhones()
        val phoneText = buildString {
            if (phonesFormatted.isNotBlank()) append("هاتف: $phonesFormatted")
            if (address.isNotBlank()) {
                if (isNotEmpty()) append("  |  ")
                append("العنوان: $address")
            }
        }.ifEmpty { "العنوان الرسمي المعتمد" }

        val phonePaint = Paint().apply {
            color = Color.parseColor("#334155")
            textSize = 18f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(phoneText, centerX, currentY + (18f * scale), phonePaint)
        currentY += 26f * scale

        // 3.1 رقم الإجازة / الترخيص (إن وجد - اختياري) يطبع بشكل مرتب أسفل أرقام الهواتف
        val licenseNo = officeInfo.licenseNo.trim()
        if (licenseNo.isNotBlank()) {
            val licensePaint = Paint().apply {
                color = Color.parseColor("#1E40AF") // أزرق رسمي مميز
                textSize = 16f * scale
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("رقم الإجازة: $licenseNo", centerX, currentY + (16f * scale), licensePaint)
            currentY += 24f * scale
        } else {
            currentY += 6f * scale
        }

        // 4. بنر عنوان العقد الرئيسي (Banner)
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 26f * scale
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val bannerWidth = (titlePaint.measureText(contractTitle) + (80f * scale)).coerceAtLeast(360f * scale)
        val bannerHeight = 44f * scale
        val bannerRect = RectF(
            centerX - (bannerWidth / 2f),
            currentY + (6f * scale),
            centerX + (bannerWidth / 2f),
            currentY + (6f * scale) + bannerHeight
        )

        val bannerBgPaint = Paint().apply {
            color = Color.parseColor("#0F172A") // كحلي داكن رسميي
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        canvas.drawRoundRect(bannerRect, 10f * scale, 10f * scale, bannerBgPaint)
        canvas.drawText(contractTitle, centerX, bannerRect.centerY() + (9f * scale), titlePaint)

        currentY += bannerHeight + (20f * scale)

        return currentY
    }

    /**
     * Overload متوافق يستقبل ContractType مباشرة
     */
    fun renderHeader(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        contractType: ContractType,
        context: Context? = null,
        pageWidth: Float = 1240f,
        pageHeight: Float = 1754f,
        startY: Float = 45f
    ): Float {
        val template = ContractTemplateLibrary.getTemplateForType(contractType)
        return renderHeader(
            canvas = canvas,
            officeInfo = officeInfo,
            contractTitle = template.title,
            contractNo = "0000",
            contractDate = "____/____/2026",
            context = context,
            pageWidth = pageWidth,
            pageHeight = pageHeight,
            startY = startY
        )
    }
}
