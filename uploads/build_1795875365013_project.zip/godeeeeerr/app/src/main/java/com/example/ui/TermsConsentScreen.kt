package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class PolicyClause(
    val number: String,
    val title: String,
    val intro: String? = null,
    val bullets: List<String> = emptyList(),
    val body: String? = null
)

/**
 * شاشة الموافقة على شروط الاستخدام وسياسة الخصوصية عند فتح البرنامج لأول مرة قبل تسجيل الدخول.
 */
@Composable
fun TermsConsentScreen(
    onAccepted: () -> Unit,
    isReadOnlyViewer: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (isReadOnlyViewer) {
        BackHandler { onAccepted() }
    }
    var isAgreed by remember { mutableStateOf(false) }

    val navyDark = Color(0xFF061E55)
    val royalBlue = Color(0xFF1E40AF)
    val primaryBlue = Color(0xFF2563EB)
    val pageBg = Color(0xFFF8FAFC)
    val borderSlate = Color(0xFFE2E8F0)
    val titleSlate = Color(0xFF0F172A)
    val bodySlate = Color(0xFF334155)
    val mutedSlate = Color(0xFF64748B)

    val termsClauses = remember {
        listOf(
            PolicyClause(
                number = "1",
                title = "الغرض من البرنامج",
                bullets = listOf(
                    "البرنامج أداة مساعدة لإنشاء وتحرير وطباعة العقود والمستندات.",
                    "يوفر نماذج متعددة تشمل عقود البيع والشراء والإيجار والتعهدات والاتفاقيات وغيرها.",
                    "يهدف إلى تسهيل تنظيم البيانات وإعداد المستندات وتوفير الوقت والجهد."
                )
            ),
            PolicyClause(
                number = "2",
                title = "مسؤولية المستخدم",
                bullets = listOf(
                    "يتحمل المستخدم المسؤولية الكاملة عن صحة البيانات والمعلومات التي يقوم بإدخالها.",
                    "يجب التأكد من صحة أسماء الأطراف وأرقام الهويات والعناوين والمبالغ المالية والتواريخ.",
                    "يتحمل المستخدم مسؤولية مراجعة جميع بنود العقد قبل طباعته وتوقيعه.",
                    "يجب التأكد من موافقة جميع الأطراف المعنية على محتوى العقد."
                )
            ),
            PolicyClause(
                number = "3",
                title = "المسؤولية القانونية",
                bullets = listOf(
                    "البرنامج وسيلة لإنشاء وتحرير وطباعة المستندات، ولا يُعد جهة قانونية أو مكتب محاماة أو جهة توثيق رسمية.",
                    "لا يضمن البرنامج صلاحية جميع النماذج لكل المعاملات أو الحالات القانونية.",
                    "لا تغني النماذج عن الاستعانة بمحامٍ أو مراجعة الجهات المختصة عند الحاجة.",
                    "لا يُعد إنشاء أو طباعة العقد بحد ذاته بديلاً عن التسجيل أو التصديق أو الإجراءات الرسمية التي يتطلبها القانون.",
                    "يتحمل المستخدم مسؤولية استكمال الإجراءات القانونية والرسمية المتعلقة بالعقود التي ينشئها."
                )
            ),
            PolicyClause(
                number = "4",
                title = "صحة المستندات والاستخدام المشروع",
                bullets = listOf(
                    "يمنع استخدام البرنامج لإنشاء مستندات مزورة أو مضللة أو مخالفة للقوانين.",
                    "يتحمل المستخدم المسؤولية عن أي تعديل أو إضافة أو حذف يجريه على المستندات.",
                    "يجب استخدام البرنامج للأغراض المشروعة فقط."
                )
            ),
            PolicyClause(
                number = "5",
                title = "حقوق الملكية الفكرية",
                bullets = listOf(
                    "حقوق تصميم البرنامج وواجهاته وأسلوبه البرمجي محفوظة لمطور البرنامج.",
                    "يمنع نسخ البرنامج أو إعادة بيعه أو توزيعه أو التعديل عليه دون إذن مسبق.",
                    "يمنع إزالة حقوق الملكية أو نسب البرنامج إلى جهة أخرى دون موافقة المطور."
                )
            ),
            PolicyClause(
                number = "6",
                title = "التحديثات والتطوير",
                bullets = listOf(
                    "يحق للمطور إجراء تحديثات وتحسينات وإضافة نماذج وميزات جديدة.",
                    "قد تتغير بعض الخصائص أو طريقة عمل البرنامج نتيجة التحديثات.",
                    "قد تتطلب بعض التحديثات إجراءات إضافية من المستخدم."
                )
            ),
            PolicyClause(
                number = "7",
                title = "إخلاء المسؤولية",
                body = "يُقدم البرنامج كأداة مساعدة لإنشاء وطباعة العقود، ولا يتحمل المطور مسؤولية النزاعات أو الخلافات الناتجة عن العقود التي ينشئها المستخدمون، أو الأخطاء في البيانات المدخلة، أو سوء الاستخدام، أو فقدان البيانات نتيجة ظروف خارجة عن سيطرته، وذلك في حدود ما يسمح به القانون."
            )
        )
    }

    val privacyClauses = remember {
        listOf(
            PolicyClause(
                number = "1",
                title = "البيانات التي يتم إدخالها",
                intro = "قد يتعامل البرنامج مع المعلومات التالية:",
                bullets = listOf(
                    "أسماء الأطراف المتعاقدة.",
                    "أرقام الهويات والبطاقات الشخصية.",
                    "أرقام الهواتف والعناوين.",
                    "تفاصيل العقارات والممتلكات.",
                    "المبالغ المالية والتواريخ.",
                    "بيانات العقود والاتفاقيات والمستندات."
                )
            ),
            PolicyClause(
                number = "2",
                title = "تخزين البيانات",
                bullets = listOf(
                    "يتم حفظ بيانات العقود والمعلومات المدخلة محلياً على جهاز المستخدم.",
                    "لا يتم رفع بيانات العقود إلى خوادم المطور أو مساحات التخزين السحابي التابعة له.",
                    "لا يمتلك المطور وصولاً مباشراً إلى العقود والبيانات المحفوظة محلياً على جهاز المستخدم.",
                    "تبقى البيانات تحت سيطرة المستخدم ومسؤوليته."
                )
            ),
            PolicyClause(
                number = "3",
                title = "استخدام البيانات",
                intro = "تُستخدم البيانات المدخلة داخل البرنامج للأغراض المرتبطة بوظائفه، ومنها:",
                bullets = listOf(
                    "إنشاء العقود والمستندات.",
                    "حفظ العقود والرجوع إليها.",
                    "تعديل البيانات وإعادة طباعة المستندات.",
                    "إدارة وتنظيم سجلات العقود."
                )
            ),
            PolicyClause(
                number = "4",
                title = "مشاركة البيانات",
                bullets = listOf(
                    "لا يقوم البرنامج بمشاركة بيانات العقود المحفوظة محلياً مع جهات خارجية.",
                    "لا يتم بيع البيانات الشخصية أو تأجيرها لأغراض تجارية أو إعلانية.",
                    "يتحمل المستخدم مسؤولية أي مشاركة يقوم بها بنفسه من خلال تصدير المستندات أو إرسالها أو طباعتها."
                )
            ),
            PolicyClause(
                number = "5",
                title = "حماية البيانات",
                bullets = listOf(
                    "يتحمل المستخدم مسؤولية حماية جهازه من الوصول غير المصرح به.",
                    "يُنصح باستخدام قفل الشاشة وكلمات المرور لحماية الجهاز.",
                    "يُنصح بإنشاء نسخ احتياطية دورية للعقود والبيانات المهمة.",
                    "لا يتحمل المطور مسؤولية وصول الآخرين إلى البيانات نتيجة إهمال حماية الجهاز أو اختراقه أو فقدانه."
                )
            ),
            PolicyClause(
                number = "6",
                title = "حذف البيانات وفقدانها",
                bullets = listOf(
                    "تبقى البيانات محفوظة على جهاز المستخدم إلى حين حذفها أو حذف بيانات التطبيق.",
                    "قد يؤدي حذف التطبيق أو مسح بياناته أو إعادة ضبط الجهاز إلى فقدان العقود والمعلومات المحفوظة.",
                    "يتحمل المستخدم مسؤولية الاحتفاظ بنسخ احتياطية من بياناته المهمة."
                )
            ),
            PolicyClause(
                number = "7",
                title = "الاتصال بالإنترنت",
                bullets = listOf(
                    "يمكن استخدام الوظائف المحلية للبرنامج دون الحاجة إلى الإنترنت متى كانت متاحة دون اتصال.",
                    "لا يتم إرسال بيانات العقود إلى خوادم المطور.",
                    "قد تتطلب بعض الخدمات أو التحديثات اتصالاً بالإنترنت، إن توفرت."
                )
            ),
            PolicyClause(
                number = "8",
                title = "تحديث سياسة الخصوصية",
                body = "قد يتم تحديث سياسة الخصوصية عند تطوير البرنامج أو إضافة ميزات جديدة. وسيتم توضيح أي تغييرات جوهرية للمستخدمين من خلال الوسائل المتاحة."
            )
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            containerColor = pageBg,
            topBar = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(navyDark, royalBlue)
                            )
                        )
                        .statusBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 600.dp)
                            .align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f)),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "شروط الاستخدام وسياسة الخصوصية",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "برنامج طباعة العقود والاتفاقيات",
                                fontSize = 13.sp,
                                color = Color(0xFFCBD5E1)
                            )
                        }

                        if (isReadOnlyViewer) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.16f)
                            ) {
                                IconButton(
                                    onClick = onAccepted,
                                    modifier = Modifier.testTag("btn_close_terms_viewer")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "إغلاق",
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            },
            bottomBar = {
                val consentRowBg by animateColorAsState(
                    targetValue = if (isAgreed) Color(0xFFEFF6FF) else Color(0xFFF8FAFC),
                    label = "consentRowBg"
                )
                val consentRowBorder by animateColorAsState(
                    targetValue = if (isAgreed) primaryBlue else borderSlate,
                    label = "consentRowBorder"
                )

                Surface(
                    color = Color.White,
                    shadowElevation = 10.dp,
                    border = BorderStroke(1.dp, borderSlate),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 600.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                        if (isReadOnlyViewer) {
                            Button(
                                onClick = onAccepted,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = primaryBlue,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("btn_back_from_terms")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "العودة لتسجيل الدخول",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        } else {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = consentRowBg,
                                border = BorderStroke(1.dp, consentRowBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { isAgreed = !isAgreed }
                                    .testTag("terms_consent_row")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .minimumInteractiveComponentSize()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Checkbox(
                                        checked = isAgreed,
                                        onCheckedChange = { isAgreed = it },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = primaryBlue,
                                            uncheckedColor = mutedSlate,
                                            checkmarkColor = Color.White
                                        ),
                                        modifier = Modifier.testTag("terms_consent_checkbox")
                                    )
                                    Text(
                                        text = "أوافق على شروط الاستخدام وسياسة الخصوصية",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = titleSlate
                                    )
                                }
                            }

                            Button(
                                onClick = onAccepted,
                                enabled = isAgreed,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = primaryBlue,
                                    contentColor = Color.White,
                                    disabledContainerColor = Color(0xFFCBD5E1),
                                    disabledContentColor = Color(0xFF64748B)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("btn_accept_terms")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "موافق ومتابعة",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        }
                    }
                }
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // أولاً: شروط الاستخدام
                item(key = "terms_section") {
                    PolicySectionCard(
                        icon = Icons.Default.Gavel,
                        sectionTitle = "أولاً: شروط الاستخدام",
                        accentColor = primaryBlue,
                        introParagraphs = listOf(
                            "مرحباً بك في برنامج طباعة العقود والاتفاقيات، الذي يهدف إلى تسهيل إنشاء العقود والمستندات وتنظيم بيانات الأطراف وطباعتها بصورة احترافية.",
                            "باستخدامك للبرنامج، فإنك توافق على الشروط والأحكام التالية:"
                        ),
                        clauses = termsClauses,
                        titleColor = titleSlate,
                        bodyColor = bodySlate,
                        borderColor = borderSlate
                    )
                }

                // ثانياً: سياسة الخصوصية وحماية البيانات
                item(key = "privacy_section") {
                    PolicySectionCard(
                        icon = Icons.Default.PrivacyTip,
                        sectionTitle = "ثانياً: سياسة الخصوصية وحماية البيانات",
                        accentColor = Color(0xFF059669),
                        introParagraphs = listOf(
                            "نحن نحترم خصوصية مستخدمي البرنامج ونحرص على حماية بياناتهم، ونعتمد مبدأ التخزين المحلي للبيانات على جهاز المستخدم."
                        ),
                        clauses = privacyClauses,
                        titleColor = titleSlate,
                        bodyColor = bodySlate,
                        borderColor = borderSlate
                    )
                }

                // ثالثاً: الموافقة على الشروط
                item(key = "agreement_section") {
                    SimplePolicyCard(
                        icon = Icons.Default.VerifiedUser,
                        accentColor = primaryBlue,
                        title = "ثالثاً: الموافقة على الشروط",
                        body = "باستخدام البرنامج، يقر المستخدم بأنه اطلع على شروط الاستخدام وسياسة الخصوصية وفهم محتواهما ووافق عليهما، ويتعهد باستخدام البرنامج بصورة مشروعة وتحمل مسؤولية البيانات والمستندات التي يقوم بإنشائها وإدارتها.",
                        titleColor = titleSlate,
                        bodyColor = bodySlate,
                        borderColor = borderSlate
                    )
                }

                // رابعاً: التواصل والدعم الفني
                item(key = "support_section") {
                    SimplePolicyCard(
                        icon = Icons.Default.SupportAgent,
                        accentColor = Color(0xFF0F3996),
                        title = "رابعاً: التواصل والدعم الفني",
                        body = "للاستفسارات أو الملاحظات أو طلب المساعدة الفنية، يمكن للمستخدم التواصل مع مطور البرنامج عبر وسائل التواصل والدعم الفني المعتمدة.",
                        titleColor = titleSlate,
                        bodyColor = bodySlate,
                        borderColor = borderSlate
                    )
                }

                item(key = "last_updated") {
                    Text(
                        text = "آخر تحديث: 2026",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = mutedSlate,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PolicySectionCard(
    icon: ImageVector,
    sectionTitle: String,
    accentColor: Color,
    introParagraphs: List<String>,
    clauses: List<PolicyClause>,
    titleColor: Color,
    bodyColor: Color,
    borderColor: Color
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 600.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = accentColor.copy(alpha = 0.1f),
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Text(
                    text = sectionTitle,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = titleColor
                )
            }

            introParagraphs.forEach { paragraph ->
                Text(
                    text = paragraph,
                    fontSize = 13.5.sp,
                    lineHeight = 22.sp,
                    color = bodyColor
                )
            }

            HorizontalDivider(color = borderColor)

            clauses.forEachIndexed { index, clause ->
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(accentColor.copy(alpha = 0.12f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = clause.number,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = accentColor
                            )
                        }
                        Text(
                            text = clause.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = titleColor
                        )
                    }

                    if (!clause.intro.isNullOrBlank()) {
                        Text(
                            text = clause.intro,
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = bodyColor,
                            modifier = Modifier.padding(start = 32.dp)
                        )
                    }

                    clause.bullets.forEach { bullet ->
                        Row(
                            modifier = Modifier.padding(start = 32.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 8.dp)
                                    .size(5.dp)
                                    .background(accentColor, CircleShape)
                            )
                            Text(
                                text = bullet,
                                fontSize = 13.sp,
                                lineHeight = 20.sp,
                                color = bodyColor
                            )
                        }
                    }

                    if (!clause.body.isNullOrBlank()) {
                        Text(
                            text = clause.body,
                            fontSize = 13.sp,
                            lineHeight = 21.sp,
                            color = bodyColor,
                            modifier = Modifier.padding(start = 32.dp)
                        )
                    }
                }

                if (index < clauses.lastIndex) {
                    HorizontalDivider(
                        color = borderColor.copy(alpha = 0.6f),
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SimplePolicyCard(
    icon: ImageVector,
    accentColor: Color,
    title: String,
    body: String,
    titleColor: Color,
    bodyColor: Color,
    borderColor: Color
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 600.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = accentColor.copy(alpha = 0.1f),
                    modifier = Modifier.size(34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = titleColor
                )
            }

            Text(
                text = body,
                fontSize = 13.5.sp,
                lineHeight = 22.sp,
                color = bodyColor
            )
        }
    }
}
