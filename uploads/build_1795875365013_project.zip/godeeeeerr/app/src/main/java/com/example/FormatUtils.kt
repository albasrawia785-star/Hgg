package com.example

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

/**
 * أدوات تنسيق الأرقام والتواريخ لعقود A4 الرسمية
 */
object FormatUtils {

    /**
     * تحويل الأرقام العربية/الفارسية إلى أرقام إنجليزية للحساب والتحقق البرمجي
     */
    fun toWesternDigits(input: String): String {
        if (input.isEmpty()) return ""
        val sb = StringBuilder(input.length)
        for (ch in input) {
            sb.append(
                when (ch) {
                    in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
                    in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
                    '٬' -> ','
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    /**
     * تحويل الأرقام الإنجليزية (0-9) إلى أرقام عربية شرقية (٠-٩)
     */
    fun toArabicDigits(input: String): String {
        if (input.isEmpty()) return ""
        val sb = StringBuilder(input.length)
        for (ch in input) {
            sb.append(
                when (ch) {
                    in '0'..'9' -> ('٠'.code + (ch.code - '0'.code)).toChar()
                    in '۰'..'۹' -> ('٠'.code + (ch.code - '۰'.code)).toChar()
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    /**
     * تحويل الأرقام إلى العربية إذا لم يكن النص رمزاً أو رقماً لاتينياً (مثل رقم الشاصي VIN الإنجليزي)
     */
    fun toArabicDigitsIfNotLatin(input: String): String {
        if (input.isEmpty()) return ""
        val hasLatinLetters = input.any { it in 'A'..'Z' || it in 'a'..'z' }
        return if (hasLatinLetters) input else toArabicDigits(input)
    }

    /**
     * إرجاع تاريخ اليوم الحالي بتنسيق YYYY/MM/DD بالأرقام الإنجليزية (مثال: 2026/11/27)
     */
    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.US)
        return sdf.format(Date())
    }

    /**
     * تنسيق المبالغ المالية بإضافة فوارز الآلاف بالأرقام الإنجليزية (مثال: 1000000 -> 1,000,000)
     * مع دعم الإدخال بالكيبورد العربي أو الإنجليزي
     */
    fun formatMoneyInput(rawInput: String): String {
        if (rawInput.isBlank()) return ""

        val westernDigitsStr = toWesternDigits(rawInput)

        // إذا كان المدخل يتكون فقط من أرقام وفوارز ومسافات
        val digitsOnly = westernDigitsStr.replace(",", "").replace("،", "").replace(" ", "").trim()
        val parsedNumber = digitsOnly.toLongOrNull()

        if (parsedNumber != null) {
            return String.format(Locale.US, "%,d", parsedNumber)
        }

        // إذا كان النص يحتوي على مزيج من أرقام وكلمات (مثل: 1000000 دينار)
        val numberBlockRegex = Regex("[0-9][0-9,]*[0-9]|[0-9]")
        return numberBlockRegex.replace(westernDigitsStr) { match ->
            val rawNum = match.value.replace(",", "")
            val parsed = rawNum.toLongOrNull()
            if (parsed != null) {
                String.format(Locale.US, "%,d", parsed)
            } else {
                match.value
            }
        }
    }

    /**
     * استخراج القيمة الرقمية الصافية من حقل المبلغ المالي (يدعم الأرقام العربية والإنجليزية والفوارز)
     */
    fun parseMoneyLong(input: String): Long? {
        val clean = toWesternDigits(input)
            .replace(",", "")
            .replace("،", "")
            .replace(" ", "")
            .trim()
        if (clean.isEmpty()) return null
        return clean.toLongOrNull()
    }

    /**
     * حساب المبلغ المتبقي تلقائياً (السعر الكلي - المبلغ المستلم/العربون)
     * يعيد نصاً فارغاً إذا كان أحد الحقلين فارغاً، أو "0" إذا تم سداد المبلغ بالكامل
     */
    fun calculateRemainingAmount(totalRaw: String, paidRaw: String): String {
        val total = parseMoneyLong(totalRaw) ?: return ""
        val paid = parseMoneyLong(paidRaw) ?: return ""
        val remaining = (total - paid).coerceAtLeast(0L)
        return remaining.toString()
    }

    /**
     * تحويل الأرقام المالية إلى كلمات عربية فصحى حسب العملة المختارة (دينار عراقي / دولار أمريكي)
     * مع دعم الملايين والمليارات والتريليونات
     */
    fun convertNumberToArabicWords(
        input: String,
        currency: ContractCurrency = ContractCurrency.IQD
    ): String {
        val clean = toWesternDigits(input)
            .replace(",", "")
            .replace("،", "")
            .replace(" ", "")
            .trim()
        val num = clean.toLongOrNull() ?: return ""
        if (num <= 0L) return ""

        val trillions = num / 1_000_000_000_000L
        val remAfterTrillions = num % 1_000_000_000_000L
        val billions = remAfterTrillions / 1_000_000_000L
        val remAfterBillions = remAfterTrillions % 1_000_000_000L
        val millions = remAfterBillions / 1_000_000L
        val remAfterMillions = remAfterBillions % 1_000_000L
        val thousands = remAfterMillions / 1_000L
        val units = remAfterMillions % 1_000L

        val sb = StringBuilder()

        if (trillions > 0L) {
            appendScaleGroup(
                sb = sb,
                groupValue = trillions,
                singular = "تريليون",
                dual = "تريليونان",
                plural = "تريليونات"
            )
        }
        if (billions > 0L) {
            appendScaleGroup(
                sb = sb,
                groupValue = billions,
                singular = "مليار",
                dual = "ملياران",
                plural = "مليارات"
            )
        }
        if (millions > 0L) {
            appendScaleGroup(
                sb = sb,
                groupValue = millions,
                singular = "مليون",
                dual = "مليونان",
                plural = "ملايين"
            )
        }
        if (thousands > 0L) {
            appendScaleGroup(
                sb = sb,
                groupValue = thousands,
                singular = "ألف",
                dual = "ألفان",
                plural = "آلاف"
            )
        }
        if (units > 0L) {
            if (sb.isNotEmpty()) sb.append(" و")
            sb.append(convertUnderThousand(units))
        }
        if (sb.isNotEmpty()) {
            sb.append(" ")
            sb.append(currency.fullLabelAr)
        }
        return sb.toString()
    }

    private fun appendScaleGroup(
        sb: StringBuilder,
        groupValue: Long,
        singular: String,
        dual: String,
        plural: String
    ) {
        if (groupValue <= 0L) return
        if (sb.isNotEmpty()) sb.append(" و")
        when (groupValue) {
            1L -> sb.append(singular)
            2L -> sb.append(dual)
            in 3L..10L -> {
                sb.append(convertUnderThousand(groupValue))
                sb.append(" ")
                sb.append(plural)
            }
            else -> {
                sb.append(convertUnderThousand(groupValue))
                sb.append(" ")
                val mod100 = groupValue % 100L
                sb.append(if (mod100 in 3L..10L) plural else singular)
            }
        }
    }

    private fun convertUnderThousand(n: Long): String {
        val safeN = n.coerceIn(0L, 999L)
        if (safeN == 0L) return ""
        val hundreds = (safeN / 100L).toInt()
        val remainder = (safeN % 100L).toInt()
        val tens = remainder / 10
        val units = remainder % 10

        val unitsMap = arrayOf("", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة")
        val tensMap = arrayOf("", "عشرة", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون")
        val teensMap = arrayOf("عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر")
        val hundredsMap = arrayOf("", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة")

        val sb = StringBuilder()
        if (hundreds in 1..9) {
            sb.append(hundredsMap[hundreds])
        }
        if (remainder > 0) {
            if (sb.isNotEmpty()) sb.append(" و")
            if (remainder in 11..19) {
                sb.append(teensMap[remainder - 10])
            } else {
                if (units in 1..9) {
                    sb.append(unitsMap[units])
                }
                if (tens in 1..9) {
                    if (units > 0) sb.append(" و")
                    sb.append(tensMap[tens])
                }
            }
        }
        return sb.toString()
    }
}

/**
 * زر مسح سريع للحقول النصية
 */
@Composable
fun ClearIconButton(
    value: String,
    onClear: () -> Unit
) {
    if (value.isNotEmpty()) {
        IconButton(
            onClick = onClear,
            modifier = Modifier.testTag("btn_clear_input")
        ) {
            Icon(
                imageVector = Icons.Default.Clear,
                contentDescription = "مسح النص",
                tint = MaterialTheme.colorScheme.outline
            )
        }
    }
}

/**
 * حقل نصي قياسي معتمد لجميع استمارات المخرجات بتصميم Material 3 الموحد المطابق للتصميم المرفق
 */
@Composable
fun ClearableOutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    readOnly: Boolean = false,
    textStyle: TextStyle = TextStyle.Default,
    label: @Composable (() -> Unit)? = null,
    placeholder: @Composable (() -> Unit)? = null,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = { ClearIconButton(value = value, onClear = { onValueChange("") }) },
    supportingText: @Composable (() -> Unit)? = null,
    isError: Boolean = false,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    singleLine: Boolean = false,
    maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE,
    minLines: Int = 1,
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    shape: Shape = RoundedCornerShape(12.dp),
    colors: TextFieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = Color(0xFF1E65FF),
        unfocusedBorderColor = Color(0xFFCBD5E1),
        disabledBorderColor = Color(0xFFE2E8F0),
        errorBorderColor = Color(0xFFEF4444),
        focusedTextColor = Color(0xFF0F172A),
        unfocusedTextColor = Color(0xFF0F172A),
        disabledTextColor = Color(0xFF64748B),
        errorTextColor = Color(0xFF0F172A),
        focusedPlaceholderColor = Color(0xFF94A3B8),
        unfocusedPlaceholderColor = Color(0xFF94A3B8),
        focusedLeadingIconColor = Color(0xFF091E42),
        unfocusedLeadingIconColor = Color(0xFF091E42),
        focusedTrailingIconColor = Color(0xFF1E65FF),
        unfocusedTrailingIconColor = Color(0xFF64748B),
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White
    )
) {
    val unifiedTextStyle = TextStyle(
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        lineHeight = 24.sp,
        color = Color(0xFF0F172A),
        textAlign = TextAlign.Start
    ).merge(textStyle)

    val styledLeadingIcon: @Composable (() -> Unit) = {
        Surface(
            shape = CircleShape,
            color = Color(0xFFEFF6FF),
            modifier = Modifier
                .padding(start = 8.dp, end = 4.dp)
                .size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                CompositionLocalProvider(LocalContentColor provides Color(0xFF091E42)) {
                    if (leadingIcon != null) {
                        leadingIcon()
                    } else {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.Start
    ) {
        if (label != null) {
            CompositionLocalProvider(
                LocalTextStyle provides TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    textAlign = TextAlign.Start
                )
            ) {
                Box(modifier = Modifier.padding(bottom = 6.dp)) {
                    label()
                }
            }
        }

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 54.dp),
            enabled = enabled,
            readOnly = readOnly,
            textStyle = unifiedTextStyle,
            label = null,
            placeholder = placeholder,
            leadingIcon = styledLeadingIcon,
            trailingIcon = trailingIcon,
            supportingText = supportingText,
            isError = isError,
            visualTransformation = visualTransformation,
            keyboardOptions = keyboardOptions,
            keyboardActions = keyboardActions,
            singleLine = singleLine,
            maxLines = maxLines,
            minLines = minLines,
            interactionSource = interactionSource,
            shape = shape,
            colors = colors
        )
    }
}

/**
 * بطاقة مقطع هيدر مع الحقول بتصميم منظم مثل الصورة المرفقة
 */
@Composable
fun FormSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector = Icons.Default.Description,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF091E42),
                    modifier = Modifier.size(34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF091E42)
                )
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(20.dp)
                        .background(Color(0xFF091E42), RoundedCornerShape(2.dp))
                )
            }
            HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)

            content()
        }
    }
}

/**
 * مكون حقل تاريخ تفاعلي مع تقويم لاختيار التاريخ بسهولة
 */
@Composable
fun DatePickerTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val formattedDate = String.format(Locale.US, "%04d/%02d/%02d", year, month + 1, dayOfMonth)
            onValueChange(formattedDate)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    ClearableOutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier.testTag(testTag),
        singleLine = true,
        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = "التاريخ") },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ClearIconButton(value = value, onClear = { onValueChange("") })
                IconButton(onClick = { datePickerDialog.show() }) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "اختر من التقويم",
                        tint = Color(0xFF1E65FF)
                    )
                }
            }
        }
    )
}

/**
 * تحويل بصرى لإظهار الفوارز التلقائية للمبالغ المالية بدون تعديل نص IME لمنع تبديل لوحة المفاتيح
 */
class MoneyVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val originalText = text.text
        if (originalText.isBlank()) {
            return TransformedText(text, OffsetMapping.Identity)
        }

        val transformedText = FormatUtils.formatMoneyInput(originalText)
        if (transformedText == originalText) {
            return TransformedText(text, OffsetMapping.Identity)
        }

        val origToTrans = IntArray(originalText.length + 1)
        val transToOrig = IntArray(transformedText.length + 1)

        var origIdx = 0
        var transIdx = 0

        while (origIdx < originalText.length && transIdx < transformedText.length) {
            transToOrig[transIdx] = origIdx
            val origChar = originalText[origIdx]
            val transChar = transformedText[transIdx]

            if (origChar == transChar) {
                origToTrans[origIdx] = transIdx
                origIdx++
                transIdx++
            } else if (transChar == ',') {
                transIdx++
            } else {
                origToTrans[origIdx] = transIdx
                origIdx++
                transIdx++
            }
        }

        while (origIdx <= originalText.length) {
            origToTrans[origIdx] = transformedText.length
            origIdx++
        }

        while (transIdx <= transformedText.length) {
            transToOrig[transIdx] = originalText.length
            transIdx++
        }

        val offsetMapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                val clamped = offset.coerceIn(0, originalText.length)
                return origToTrans[clamped].coerceIn(0, transformedText.length)
            }

            override fun transformedToOriginal(offset: Int): Int {
                val clamped = offset.coerceIn(0, transformedText.length)
                return transToOrig[clamped].coerceIn(0, originalText.length)
            }
        }

        return TransformedText(AnnotatedString(transformedText), offsetMapping)
    }
}

/**
 * مربع اختيار وتبديل العملة (دينار عراقي / دولار أمريكي) داخل قسم المبالغ المالية
 */
@Composable
fun ContractCurrencySelector(
    selectedCurrency: ContractCurrency,
    onCurrencySelected: (ContractCurrency) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "نوع العملة",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ContractCurrency.entries.forEach { currency ->
                val isSelected = currency == selectedCurrency
                val borderColor = if (isSelected) Color(0xFF1E65FF) else Color(0xFFCBD5E1)
                val containerColor = if (isSelected) Color(0xFFEFF6FF) else Color.White
                val contentColor = if (isSelected) Color(0xFF091E42) else Color(0xFF475569)
                val icon = if (currency == ContractCurrency.USD) Icons.Default.AttachMoney else Icons.Default.Payments

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = containerColor,
                    border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag(if (currency == ContractCurrency.USD) "currency_usd" else "currency_iqd")
                        .clickable { onCurrencySelected(currency) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (isSelected) Icons.Default.CheckCircle else icon,
                            contentDescription = currency.selectorLabelAr,
                            tint = if (isSelected) Color(0xFF1E65FF) else Color(0xFF64748B),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = currency.selectorLabelAr,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = contentColor,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
