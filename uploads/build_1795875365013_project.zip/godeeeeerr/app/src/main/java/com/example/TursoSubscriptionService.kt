package com.example

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URI
import java.util.concurrent.TimeUnit

/**
 * إعدادات الاتصال بقاعدة بيانات Turso (مباشرة عبر Secrets أو عبر خادم وسيط اختياري)
 */
object TursoConfig {
    private const val PLACEHOLDER_PROXY = "YOUR_CLOUDFLARE_WORKER_URL"
    const val PLACEHOLDER_URL = "YOUR_TURSO_DATABASE_URL"
    const val PLACEHOLDER_TOKEN = "YOUR_TURSO_AUTH_TOKEN"

    val rawProxyUrl: String
        get() = BuildConfig.TURSO_PROXY_URL.trim()

    val rawTursoUrl: String
        get() = BuildConfig.TURSO_DATABASE_URL.trim()

    val rawTursoToken: String
        get() = BuildConfig.TURSO_AUTH_TOKEN.trim()

    fun cleanSecret(raw: String): String {
        var c = raw.trim()
        if ((c.startsWith("\"") && c.endsWith("\"")) || (c.startsWith("'") && c.endsWith("'"))) {
            c = c.substring(1, c.length - 1).trim()
        }
        return c.replace(Regex("[\\r\\n\\t]+"), "")
    }

    fun toTursoPipelineUrl(rawUrl: String): String? {
        val trimmed = cleanSecret(rawUrl).trimEnd('/')
        if (trimmed.isBlank() || trimmed == PLACEHOLDER_URL || trimmed.equals("null", ignoreCase = true)) {
            return null
        }
        val httpsBase = when {
            trimmed.startsWith("libsql://", ignoreCase = true) -> "https://" + trimmed.substring(9)
            trimmed.startsWith("https://", ignoreCase = true) || trimmed.startsWith("http://", ignoreCase = true) -> trimmed
            else -> "https://$trimmed"
        }.replace(Regex("/v2/pipeline$", RegexOption.IGNORE_CASE), "").trimEnd('/')
        return try {
            val uri = URI(httpsBase)
            val scheme = uri.scheme?.lowercase() ?: return null
            val host = uri.host?.lowercase() ?: return null
            if (host.isBlank()) return null
            val isLocalDev = host == "localhost" || host == "127.0.0.1" || host == "10.0.2.2"
            if (scheme != "https" && !(scheme == "http" && isLocalDev)) return null
            "$httpsBase/v2/pipeline"
        } catch (_: Exception) {
            null
        }
    }

    val isDirectConfigured: Boolean
        get() {
            val token = cleanSecret(rawTursoToken)
            return toTursoPipelineUrl(rawTursoUrl) != null &&
                token.isNotBlank() &&
                token != PLACEHOLDER_TOKEN &&
                !token.equals("null", ignoreCase = true)
        }

    val isProxyConfigured: Boolean
        get() = normalizeProxyBaseUrl(rawProxyUrl) != null

    val isConfigured: Boolean
        get() = isDirectConfigured || isProxyConfigured

    /**
     * التحقق من رابط الخادم الوسيط وتوحيده (يتطلب https:// أو localhost للتجربة)
     */
    fun normalizeProxyBaseUrl(rawUrl: String): String? {
        val trimmed = cleanSecret(rawUrl).trimEnd('/')
        if (trimmed.isBlank() || trimmed == PLACEHOLDER_PROXY) return null
        val withScheme = when {
            trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.startsWith("http://", ignoreCase = true) -> trimmed
            else -> "https://$trimmed"
        }
        return try {
            val uri = URI(withScheme)
            val scheme = uri.scheme?.lowercase() ?: return null
            val host = uri.host?.lowercase() ?: return null
            if (host.isBlank()) return null
            val isLocalDev = host == "localhost" || host == "127.0.0.1" || host == "10.0.2.2"
            if (scheme != "https" && !(scheme == "http" && isLocalDev)) {
                return null
            }
            withScheme.trimEnd('/')
        } catch (_: Exception) {
            null
        }
    }
}

/**
 * نموذج بيانات المشترك
 */
data class SubscriberAccount(
    val id: Long,
    val fullName: String,
    val officeName: String,
    val phone: String,
    val isActive: Boolean,
    val expiresAt: Long?,
    val notes: String = "",
    val createdAt: Long = 0L
) {
    fun isExpired(nowMillis: Long = System.currentTimeMillis()): Boolean {
        return expiresAt != null && expiresAt > 0L && nowMillis > expiresAt
    }

    fun isValidForLogin(nowMillis: Long = System.currentTimeMillis()): Boolean {
        return isActive && !isExpired(nowMillis)
    }
}

enum class SubscriptionDurationOption(val labelAr: String, val days: Int?) {
    DAYS_30("شهر واحد (30 يوم)", 30),
    DAYS_90("3 أشهر (90 يوم)", 90),
    DAYS_365("سنة كاملة (365 يوم)", 365),
    UNLIMITED("مفتوح (بدون انتهاء)", null)
}

sealed class SubscriberAuthOutcome {
    data class Success(val subscriber: SubscriberAccount, val sessionToken: String) : SubscriberAuthOutcome()
    data class Rejected(val message: String) : SubscriberAuthOutcome()
    data class NetworkOrConfigError(val message: String) : SubscriberAuthOutcome()
}

class ProxyUnauthorizedException(message: String) : IllegalStateException(message)

/**
 * عميل REST للاتصال بخادم Cloudflare Worker الوسيط الذي يتحدث مع Turso على الخادم
 */
class TursoSubscriptionService(
    private val httpClient: OkHttpClient = defaultHttpClient()
) {
    private val directClient = DirectTursoClient(httpClient)

    private fun shouldUseDirect(): Boolean = TursoConfig.isDirectConfigured

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        fun defaultHttpClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()

        fun normalizePhone(raw: String): String {
            return FormatUtils.toWesternDigits(raw.trim()).filter { !it.isWhitespace() }
        }

        fun parseSubscriber(obj: JSONObject): SubscriberAccount? {
            val id = obj.optLong("id", -1L)
            val phone = obj.optString("phone", "")
            if (id < 0L || phone.isBlank()) return null
            val expiresAt: Long? = if (obj.isNull("expiresAt")) {
                null
            } else {
                val raw = obj.optLong("expiresAt", -1L)
                if (raw > 0L) raw else null
            }
            return SubscriberAccount(
                id = id,
                fullName = obj.optString("fullName", ""),
                officeName = obj.optString("officeName", ""),
                phone = phone,
                isActive = obj.optBoolean("isActive", false),
                expiresAt = expiresAt,
                notes = obj.optString("notes", ""),
                createdAt = obj.optLong("createdAt", 0L)
            )
        }

        fun parseErrorMessage(bodyStr: String, statusCode: Int): String {
            val parsed = try {
                JSONObject(bodyStr).optString("error", "").takeIf { it.isNotBlank() }
            } catch (_: Exception) {
                null
            }
            if (parsed != null) return parsed
            return when (statusCode) {
                401 -> "بيانات الدخول غير صحيحة أو انتهت الجلسة"
                403 -> "الحساب موقوف أو غير مصرح له"
                404 -> "الخادم أو المسار غير موجود"
                409 -> "البيانات مسجلة مسبقاً"
                else -> "خطأ اتصال بالخادم ($statusCode)"
            }
        }
    }

    private data class HttpCallResult(
        val statusCode: Int,
        val body: String
    )

    private fun isAppsScriptBackend(baseUrl: String): Boolean {
        return baseUrl.contains("script.google.com", ignoreCase = true) ||
            baseUrl.contains("script.googleusercontent.com", ignoreCase = true)
    }

    private fun buildAppsScriptRequest(
        baseUrl: String,
        method: String,
        path: String,
        bodyJson: JSONObject?,
        bearerToken: String?
    ): Request {
        val cleanMethod = method.uppercase()
        if (cleanMethod == "GET" && path == "/api/admin/status") {
            return Request.Builder()
                .url("$baseUrl?route=admin_status")
                .addHeader("Accept", "application/json")
                .get()
                .build()
        }

        val payload = JSONObject(bodyJson?.toString() ?: "{}")
        if (!bearerToken.isNullOrBlank()) {
            payload.put("token", bearerToken)
        }

        val subMatch = Regex("^/api/admin/subscribers/(\\d+)$").matchEntire(path)
        val route = when {
            path == "/api/auth/login" -> "auth_login"
            path == "/api/auth/me" -> "auth_me"
            path == "/api/auth/logout" -> "auth_logout"
            path == "/api/admin/status" -> "admin_status"
            path == "/api/admin/setup" -> "admin_setup"
            path == "/api/admin/login" -> "admin_login"
            path == "/api/admin/change-password" -> "admin_change_password"
            path == "/api/admin/subscribers" && cleanMethod == "GET" -> "admin_list_subscribers"
            path == "/api/admin/subscribers" && cleanMethod == "POST" -> "admin_create_subscriber"
            subMatch != null && cleanMethod == "PATCH" -> {
                payload.put("id", subMatch.groupValues[1].toLongOrNull() ?: 0L)
                "admin_update_subscriber"
            }
            subMatch != null && cleanMethod == "DELETE" -> {
                payload.put("id", subMatch.groupValues[1].toLongOrNull() ?: 0L)
                "admin_delete_subscriber"
            }
            else -> path.trimStart('/')
        }
        payload.put("route", route)

        return Request.Builder()
            .url(baseUrl)
            .addHeader("Accept", "application/json")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()
    }

    private suspend fun requestJson(
        method: String,
        path: String,
        bodyJson: JSONObject? = null,
        bearerToken: String? = null
    ): Result<HttpCallResult> {
        val baseUrl = TursoConfig.normalizeProxyBaseUrl(TursoConfig.rawProxyUrl)
            ?: return Result.failure(
                IllegalStateException("خادم الاشتراكات غير مربوط بعد في التطبيق.")
            )

        val appsScript = isAppsScriptBackend(baseUrl)
        return withContext(Dispatchers.IO) {
            try {
                val request = if (appsScript) {
                    buildAppsScriptRequest(baseUrl, method, path, bodyJson, bearerToken)
                } else {
                    val builder = Request.Builder()
                        .url("$baseUrl$path")
                        .addHeader("Accept", "application/json")
                    if (!bearerToken.isNullOrBlank()) {
                        builder.addHeader("Authorization", "Bearer $bearerToken")
                    }
                    when (method.uppercase()) {
                        "GET" -> builder.get()
                        "DELETE" -> builder.delete()
                        "POST" -> builder.post((bodyJson?.toString() ?: "{}").toRequestBody(JSON_MEDIA_TYPE))
                        "PATCH" -> builder.patch((bodyJson?.toString() ?: "{}").toRequestBody(JSON_MEDIA_TYPE))
                        else -> return@withContext Result.failure(IllegalArgumentException("Unsupported method"))
                    }
                    builder.build()
                }

                httpClient.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string().orEmpty()
                    if (appsScript && response.code in 200..299) {
                        val trimmed = bodyStr.trimStart()
                        if (!trimmed.startsWith("{")) {
                            return@withContext Result.success(
                                HttpCallResult(
                                    502,
                                    """{"error":"تأكد أن صلاحية الوصول في Google Apps Script مضبوطة على (Anyone)."}"""
                                )
                            )
                        }
                        val parsed = runCatching { JSONObject(trimmed) }.getOrNull()
                        if (parsed != null && !parsed.optBoolean("ok", true)) {
                            val effectiveCode = parsed.optInt("status", 400).takeIf { it in 400..599 } ?: 400
                            return@withContext Result.success(HttpCallResult(effectiveCode, bodyStr))
                        }
                    }
                    Result.success(HttpCallResult(response.code, bodyStr))
                }
            } catch (e: Exception) {
                Result.failure(
                    IllegalStateException("تعذر الاتصال بالإنترنت أو الخادم: ${e.localizedMessage ?: "خطأ شبكة"}")
                )
            }
        }
    }

    suspend fun authenticateSubscriber(rawPhone: String, password: String): SubscriberAuthOutcome {
        val phone = normalizePhone(rawPhone)
        if (phone.isBlank() || password.isBlank()) {
            return SubscriberAuthOutcome.Rejected("يرجى إدخال رقم الهاتف وكلمة المرور")
        }
        if (shouldUseDirect()) {
            return directClient.authenticateSubscriber(phone, password)
        }

        val payload = JSONObject()
            .put("phone", phone)
            .put("password", password)

        val callRes = requestJson("POST", "/api/auth/login", payload)
        if (callRes.isFailure) {
            return SubscriberAuthOutcome.NetworkOrConfigError(
                callRes.exceptionOrNull()?.message ?: "تعذر الاتصال بالخادم"
            )
        }

        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode !in 200..299) {
            val msg = parseErrorMessage(httpRes.body, httpRes.statusCode)
            return if (httpRes.statusCode in 400..499 && httpRes.statusCode != 404) {
                SubscriberAuthOutcome.Rejected(msg)
            } else {
                SubscriberAuthOutcome.NetworkOrConfigError(msg)
            }
        }

        return try {
            val root = JSONObject(httpRes.body)
            val token = root.optString("token", "")
            val subObj = root.optJSONObject("subscriber")
            val subscriber = subObj?.let { parseSubscriber(it) }
            if (token.isBlank() || subscriber == null) {
                SubscriberAuthOutcome.NetworkOrConfigError("استجابة غير مكتملة من الخادم")
            } else {
                SubscriberAuthOutcome.Success(subscriber, token)
            }
        } catch (_: Exception) {
            SubscriberAuthOutcome.NetworkOrConfigError("تعذر قراءة بيانات الاشتراك")
        }
    }

    suspend fun verifySubscriberSession(sessionToken: String): SubscriberAuthOutcome {
        if (sessionToken.isBlank()) {
            return SubscriberAuthOutcome.Rejected("يرجى تسجيل الدخول مجدداً")
        }
        if (shouldUseDirect()) {
            return directClient.verifySubscriberSession(sessionToken)
        }
        val callRes = requestJson("GET", "/api/auth/me", bearerToken = sessionToken)
        if (callRes.isFailure) {
            return SubscriberAuthOutcome.NetworkOrConfigError(
                callRes.exceptionOrNull()?.message ?: "تعذر التحقق من الجلسة"
            )
        }
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode !in 200..299) {
            val msg = parseErrorMessage(httpRes.body, httpRes.statusCode)
            return if (httpRes.statusCode == 401 || httpRes.statusCode == 403) {
                SubscriberAuthOutcome.Rejected(msg)
            } else {
                SubscriberAuthOutcome.NetworkOrConfigError(msg)
            }
        }
        return try {
            val root = JSONObject(httpRes.body)
            val subscriber = root.optJSONObject("subscriber")?.let { parseSubscriber(it) }
                ?: return SubscriberAuthOutcome.NetworkOrConfigError("استجابة غير صالحة")
            SubscriberAuthOutcome.Success(subscriber, sessionToken)
        } catch (_: Exception) {
            SubscriberAuthOutcome.NetworkOrConfigError("تعذر قراءة بيانات الحساب")
        }
    }

    suspend fun logoutSubscriber(sessionToken: String): Result<Unit> {
        if (sessionToken.isBlank()) return Result.success(Unit)
        if (shouldUseDirect()) return directClient.logoutSubscriber(sessionToken)
        return requestJson("POST", "/api/auth/logout", bearerToken = sessionToken).map { }
    }

    suspend fun fetchAdminStatus(): Result<Boolean> {
        if (shouldUseDirect()) return directClient.fetchAdminStatus()
        val callRes = requestJson("GET", "/api/admin/status")
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return try {
            val hasSet = JSONObject(httpRes.body).optBoolean("hasAdminPassword", false)
            Result.success(hasSet)
        } catch (_: Exception) {
            Result.failure(IllegalStateException("استجابة غير صالحة من الخادم"))
        }
    }

    suspend fun setupAdminPassword(password: String): Result<String> {
        if (shouldUseDirect()) return directClient.setupAdminPassword(password)
        val payload = JSONObject().put("password", password)
        val callRes = requestJson("POST", "/api/admin/setup", payload)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return try {
            val token = JSONObject(httpRes.body).optString("token", "")
            if (token.isBlank()) {
                Result.failure(IllegalStateException("لم يُرجع الخادم رمز جلسة الإدارة"))
            } else {
                Result.success(token)
            }
        } catch (_: Exception) {
            Result.failure(IllegalStateException("تعذر قراءة رد الخادم"))
        }
    }

    suspend fun loginAdmin(password: String): Result<String> {
        if (shouldUseDirect()) return directClient.loginAdmin(password)
        val payload = JSONObject().put("password", password)
        val callRes = requestJson("POST", "/api/admin/login", payload)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return try {
            val token = JSONObject(httpRes.body).optString("token", "")
            if (token.isBlank()) {
                Result.failure(IllegalStateException("لم يُرجع الخادم رمز جلسة الإدارة"))
            } else {
                Result.success(token)
            }
        } catch (_: Exception) {
            Result.failure(IllegalStateException("تعذر قراءة رد الخادم"))
        }
    }

    suspend fun changeAdminPassword(
        adminToken: String,
        currentPassword: String,
        newPassword: String
    ): Result<Unit> {
        if (shouldUseDirect()) return directClient.changeAdminPassword(adminToken, currentPassword, newPassword)
        val payload = JSONObject()
            .put("currentPassword", currentPassword)
            .put("newPassword", newPassword)
        val callRes = requestJson("POST", "/api/admin/change-password", payload, bearerToken = adminToken)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode == 401) {
            return Result.failure(ProxyUnauthorizedException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return Result.success(Unit)
    }

    suspend fun listSubscribers(adminToken: String): Result<List<SubscriberAccount>> {
        if (shouldUseDirect()) return directClient.listSubscribers(adminToken)
        val callRes = requestJson("GET", "/api/admin/subscribers", bearerToken = adminToken)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode == 401) {
            return Result.failure(ProxyUnauthorizedException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return try {
            val arr = JSONObject(httpRes.body).optJSONArray("subscribers")
            val list = ArrayList<SubscriberAccount>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    parseSubscriber(arr.getJSONObject(i))?.let { list.add(it) }
                }
            }
            Result.success(list)
        } catch (_: Exception) {
            Result.failure(IllegalStateException("تعذر قراءة قائمة المشتركين"))
        }
    }

    suspend fun createSubscriber(
        adminToken: String,
        fullName: String,
        officeName: String,
        rawPhone: String,
        password: String,
        durationDays: Int?,
        notes: String = ""
    ): Result<SubscriberAccount> {
        val phone = normalizePhone(rawPhone)
        if (fullName.isBlank()) return Result.failure(IllegalArgumentException("يرجى إدخال اسم المشترك"))
        if (phone.isBlank()) return Result.failure(IllegalArgumentException("يرجى إدخال رقم الهاتف"))
        if (password.length < 4) return Result.failure(IllegalArgumentException("كلمة المرور يجب أن تكون 4 أحرف على الأقل"))
        if (shouldUseDirect()) {
            return directClient.createSubscriber(adminToken, fullName, officeName, phone, password, durationDays, notes)
        }

        val payload = JSONObject()
            .put("fullName", fullName.trim())
            .put("officeName", officeName.trim())
            .put("phone", phone)
            .put("password", password)
            .put("notes", notes.trim())
        if (durationDays != null) {
            payload.put("durationDays", durationDays)
        } else {
            payload.put("durationDays", JSONObject.NULL)
        }

        val callRes = requestJson("POST", "/api/admin/subscribers", payload, bearerToken = adminToken)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode == 401) {
            return Result.failure(ProxyUnauthorizedException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return try {
            val sub = JSONObject(httpRes.body).optJSONObject("subscriber")?.let { parseSubscriber(it) }
                ?: return Result.failure(IllegalStateException("استجابة غير مكتملة من الخادم"))
            Result.success(sub)
        } catch (_: Exception) {
            Result.failure(IllegalStateException("تعذر قراءة بيانات المشترك الجديد"))
        }
    }

    suspend fun updateSubscriberActive(adminToken: String, id: Long, isActive: Boolean): Result<Unit> {
        if (shouldUseDirect()) return directClient.updateSubscriberActive(adminToken, id, isActive)
        val payload = JSONObject()
            .put("action", "toggle_active")
            .put("isActive", isActive)
        val callRes = requestJson("PATCH", "/api/admin/subscribers/$id", payload, bearerToken = adminToken)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode == 401) {
            return Result.failure(ProxyUnauthorizedException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return Result.success(Unit)
    }

    suspend fun extendSubscriber(adminToken: String, id: Long, durationDays: Int?): Result<Long?> {
        if (shouldUseDirect()) return directClient.extendSubscriber(adminToken, id, durationDays)
        val payload = JSONObject().put("action", "extend")
        if (durationDays != null) {
            payload.put("durationDays", durationDays)
        } else {
            payload.put("durationDays", JSONObject.NULL)
        }
        val callRes = requestJson("PATCH", "/api/admin/subscribers/$id", payload, bearerToken = adminToken)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode == 401) {
            return Result.failure(ProxyUnauthorizedException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return try {
            val obj = JSONObject(httpRes.body)
            val exp = if (obj.isNull("expiresAt")) null else obj.optLong("expiresAt", -1L).takeIf { it > 0L }
            Result.success(exp)
        } catch (_: Exception) {
            Result.success(null)
        }
    }

    suspend fun resetSubscriberPassword(adminToken: String, id: Long, newPassword: String): Result<Unit> {
        if (newPassword.length < 4) {
            return Result.failure(IllegalArgumentException("كلمة المرور يجب أن تكون 4 أحرف على الأقل"))
        }
        if (shouldUseDirect()) return directClient.resetSubscriberPassword(adminToken, id, newPassword)
        val payload = JSONObject()
            .put("action", "reset_password")
            .put("newPassword", newPassword)
        val callRes = requestJson("PATCH", "/api/admin/subscribers/$id", payload, bearerToken = adminToken)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode == 401) {
            return Result.failure(ProxyUnauthorizedException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return Result.success(Unit)
    }

    suspend fun deleteSubscriber(adminToken: String, id: Long): Result<Unit> {
        if (shouldUseDirect()) return directClient.deleteSubscriber(adminToken, id)
        val callRes = requestJson("DELETE", "/api/admin/subscribers/$id", bearerToken = adminToken)
        if (callRes.isFailure) return Result.failure(callRes.exceptionOrNull()!!)
        val httpRes = callRes.getOrThrow()
        if (httpRes.statusCode == 401) {
            return Result.failure(ProxyUnauthorizedException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        if (httpRes.statusCode !in 200..299) {
            return Result.failure(IllegalStateException(parseErrorMessage(httpRes.body, httpRes.statusCode)))
        }
        return Result.success(Unit)
    }
}
