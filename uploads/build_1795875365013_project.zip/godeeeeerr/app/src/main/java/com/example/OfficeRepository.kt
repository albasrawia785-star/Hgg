package com.example

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Repository لإدارة واسترجاع بيانات المكتب (Clean Architecture)
 */
interface OfficeRepository {
    fun getOfficeInfo(): OfficeInfo
    fun getOfficeInfoFlow(): Flow<OfficeInfo>
    fun saveOfficeInfo(officeInfo: OfficeInfo)
}

/**
 * التطبيق العملي لـ OfficeRepository باستخدام SettingsManager
 */
class OfficeRepositoryImpl(
    private val settingsManager: SettingsManager
) : OfficeRepository {

    private val _officeInfoFlow = MutableStateFlow(
        settingsManager.getOfficeInfo()
    )

    override fun getOfficeInfo(): OfficeInfo {
        val info = settingsManager.getOfficeInfo()
        _officeInfoFlow.value = info
        return info
    }

    override fun getOfficeInfoFlow(): Flow<OfficeInfo> = _officeInfoFlow.asStateFlow()

    override fun saveOfficeInfo(officeInfo: OfficeInfo) {
        settingsManager.saveOfficeDetails(
            name = officeInfo.officeName,
            phone = officeInfo.phone,
            phone2 = officeInfo.phone2,
            licenseNo = officeInfo.licenseNo,
            address = officeInfo.address
        )
        _officeInfoFlow.value = officeInfo
    }
}

