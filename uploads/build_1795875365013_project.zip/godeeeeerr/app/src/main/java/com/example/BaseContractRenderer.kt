package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.annotation.ColorInt
import androidx.core.content.res.ResourcesCompat
import java.security.MessageDigest
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin

/**
 * BaseContractRenderer: المحرك الأساسي الموحد لرسم العقود العراقية الرسمية على ورقة A4.
 * يوفر:
 * 1. خط أميري (Amiri) للعناوين الرسمية وخط النسخ (Noto Naskh Arabic) للنصوص القانونية.
 * 2. إطار عراقي رسمي مزدوج بزوايا هندسية كلاسيكية.
 * 3. ترويسة ثلاثية الأعمدة تتضمن البسملة وبيانات المكتب ورقم الإجازة والهواتف بدون إيموجي.
 * 4. جداول رسمية وخطوط منقطة متصلة (Vector Dash) ومربعات بصمة الإبهام وختم المكتب.
 * 5. علامة مائية خفيفة في منتصف الورقة تحترم ألوان القالب المختار.
 */
abstract class BaseContractRenderer {

    companion object {
        const val A4_WIDTH = 1240f
        const val A4_HEIGHT = 1754f

        @ColorInt val COLOR_PRIMARY = Color.parseColor("#0F172A")
        @ColorInt val COLOR_SECONDARY = Color.parseColor("#1E3A8A")
        @ColorInt val COLOR_TEXT = Color.parseColor("#111827")
        @ColorInt val COLOR_LABEL = Color.parseColor("#334155")
        @ColorInt val COLOR_BORDER = Color.parseColor("#64748B")
        @ColorInt val COLOR_BG_LIGHT = Color.parseColor("#F8FAFC")
        @ColorInt val COLOR_RED_ACCENT = Color.parseColor("#991B1B")
    }

    protected var displayTypeface: Typeface = Typeface.SERIF
    protected var displayBoldTypeface: Typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    protected var bodyTypeface: Typeface = Typeface.DEFAULT
    protected var bodyBoldTypeface: Typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

    protected val framePaint = Paint().apply {
        color = COLOR_PRIMARY
        style = Paint.Style.STROKE
        strokeWidth = 3.2f
        isAntiAlias = true
    }

    protected val innerFramePaint = Paint().apply {
        color = COLOR_BORDER
        style = Paint.Style.STROKE
        strokeWidth = 1.1f
        isAntiAlias = true
    }

    protected val titlePaint = Paint().apply {
        color = COLOR_PRIMARY
        textSize = 32f
        typeface = displayBoldTypeface
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    protected val subtitlePaint = Paint().apply {
        color = COLOR_LABEL
        textSize = 18f
        typeface = bodyBoldTypeface
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    protected val labelPaint = Paint().apply {
        color = COLOR_LABEL
        textSize = 17f
        typeface = bodyBoldTypeface
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val valuePaint = Paint().apply {
        color = COLOR_TEXT
        textSize = 18f
        typeface = bodyBoldTypeface
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val bodyTextPaint = Paint().apply {
        color = COLOR_TEXT
        textSize = 17f
        typeface = bodyTypeface
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val dotPaint = Paint().apply {
        color = COLOR_BORDER
        style = Paint.Style.STROKE
        strokeWidth = 1.0f
        pathEffect = DashPathEffect(floatArrayOf(2.0f, 4.5f), 0f)
        isAntiAlias = true
    }

    protected var activeTemplate: ContractTemplate = ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE

    protected val outerMargin: Float
        get() = activeTemplate.marginDp.coerceIn(36f, 56f)

    protected val innerMargin: Float
        get() = outerMargin + 22f

    protected val contentLeft: Float
        get() = innerMargin + 16f

    protected val contentRight: Float
        get() = A4_WIDTH - innerMargin - 16f

    protected val contentWidth: Float
        get() = contentRight - contentLeft

    protected val footerBottomY: Float
        get() = A4_HEIGHT - innerMargin - 18f

    protected val footerTopY: Float
        get() = footerBottomY - 126f

    protected fun primaryColorInt(): Int = parseColorSafe(activeTemplate.primaryColorHex, COLOR_PRIMARY)
    protected fun secondaryColorInt(): Int = parseColorSafe(activeTemplate.secondaryColorHex, COLOR_SECONDARY)
    protected fun textColorInt(): Int = parseColorSafe(activeTemplate.textColorHex, COLOR_TEXT)
    protected fun borderColorInt(): Int = parseColorSafe(activeTemplate.borderColorHex, COLOR_BORDER)
    protected fun titleColorInt(): Int = parseColorSafe(activeTemplate.titleColorHex, primaryColorInt())

    protected fun parseColorSafe(hex: String, fallback: Int): Int {
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }

    protected fun tintColor(baseColor: Int, alpha: Int): Int {
        return Color.argb(
            alpha.coerceIn(0, 255),
            Color.red(baseColor),
            Color.green(baseColor),
            Color.blue(baseColor)
        )
    }

    private fun loadFonts(context: Context?) {
        val loadedAmiri = if (context != null) {
            try {
                ResourcesCompat.getFont(context, R.font.amiri)
            } catch (_: Exception) {
                null
            }
        } else null

        val loadedNaskh = if (context != null) {
            try {
                ResourcesCompat.getFont(context, R.font.noto_naskh_arabic)
            } catch (_: Exception) {
                null
            }
        } else null

        displayTypeface = loadedAmiri ?: Typeface.SERIF
        displayBoldTypeface = Typeface.create(displayTypeface, Typeface.BOLD)
        bodyTypeface = loadedNaskh ?: Typeface.DEFAULT
        bodyBoldTypeface = Typeface.create(bodyTypeface, Typeface.BOLD)
    }

    data class WatermarkLogoConfig(
        val enabled: Boolean = false,
        val logoBitmap: Bitmap? = null,
        val sizePercent: Float = 45f,
        val opacityPercent: Float = 15f
    )

    protected var activeWatermarkLogo: WatermarkLogoConfig? = null
    protected var activeSecurityMeta: ContractSecurityMetadata? = null

    fun renderBitmap(
        contractData: Any,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null,
        overrideTemplate: ContractTemplate? = null,
        overrideWatermarkLogo: WatermarkLogoConfig? = null
    ): Bitmap {
        activeTemplate = overrideTemplate ?: (
            context?.let { TemplateSettingsManager.getInstance(it).getEffectiveTemplate() }
                ?: ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE
        )

        var decodedLogoForRender: Bitmap? = null
        activeWatermarkLogo = if (overrideWatermarkLogo != null) {
            overrideWatermarkLogo
        } else if (context != null) {
            val sm = SettingsManager.getInstance(context)
            if (sm.watermarkLogoEnabled) {
                decodedLogoForRender = sm.loadWatermarkLogoBitmap()
                if (decodedLogoForRender != null) {
                    WatermarkLogoConfig(
                        enabled = true,
                        logoBitmap = decodedLogoForRender,
                        sizePercent = sm.watermarkLogoSizePercent,
                        opacityPercent = sm.watermarkLogoOpacityPercent
                    )
                } else null
            } else null
        } else null

        loadFonts(context)
        applyTemplatePaints(activeTemplate)

        val bitmap = Bitmap.createBitmap(A4_WIDTH.toInt(), A4_HEIGHT.toInt(), Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)

            val bgColor = parseColorSafe(activeTemplate.backgroundColorHex, Color.WHITE)
            canvas.drawColor(bgColor)

            val securityMeta = extractSecurityMetadata(contractData, officeInfo)
            activeSecurityMeta = securityMeta

            // 1. خلفية خطوط غيوشي الأمنية الهندسية (شبكة تموجات متداخلة + وردة هندسية مركزية)
            drawPageGuillocheBackground(canvas, securityMeta)

            // 2. علامة مائية مخصصة (صورة الشعار + اسم المكتب وبيانات العقد) خلف المحتوى
            drawContractWatermark(canvas, officeInfo, securityMeta)

            // 3. شريط الحاشية الأمني الديناميكي حول محيط الورقة
            drawMarginSecurityStrip(canvas, securityMeta)

            // 4. الإطار العراقي الرسمي المزدوج
            if (activeTemplate.hasFrame) {
                drawA4Borders(canvas)
            }

            // 5. محتوى العقد
            drawContractContent(canvas, contractData, officeInfo, context)

            // 6. التذييل السفلي
            if (activeTemplate.showPageNumber) {
                drawFooterPageNumber(canvas)
            }
        } finally {
            activeWatermarkLogo = null
            activeSecurityMeta = null
            decodedLogoForRender?.recycle()
        }

        return bitmap
    }

    protected fun applyTemplatePaints(template: ContractTemplate) {
        val primary = primaryColorInt()
        val secondary = secondaryColorInt()
        val textColor = textColorInt()
        val borderColor = borderColorInt()
        val titleColor = titleColorInt()

        framePaint.color = primary
        framePaint.strokeWidth = (3.2f * template.borderWidth).coerceAtLeast(1.2f)

        innerFramePaint.color = if (borderColor == Color.WHITE) primary else borderColor
        innerFramePaint.strokeWidth = (1.1f * template.borderWidth).coerceAtLeast(0.8f)

        titlePaint.color = titleColor
        titlePaint.typeface = displayBoldTypeface
        titlePaint.textSize = template.headerTextSize * template.fontScale

        subtitlePaint.color = secondary
        subtitlePaint.typeface = bodyBoldTypeface
        subtitlePaint.textSize = 18f * template.fontScale

        labelPaint.color = if (template.id == "monochrome_bw") textColor else primary
        labelPaint.typeface = bodyTypeface
        labelPaint.textSize = 17f * template.fontScale

        valuePaint.color = textColor
        valuePaint.typeface = bodyBoldTypeface
        valuePaint.textSize = 17.5f * template.fontScale

        bodyTextPaint.color = textColor
        bodyTextPaint.typeface = bodyTypeface
        bodyTextPaint.textSize = 17.5f * template.fontScale

        dotPaint.color = if (template.id == "monochrome_bw") tintColor(textColor, 150) else borderColor
    }

    protected fun drawCenteredSingleLine(
        canvas: Canvas,
        text: String,
        cx: Float,
        centerY: Float,
        paint: Paint
    ) {
        val fm = paint.fontMetrics
        val baseline = centerY - ((fm.ascent + fm.descent) / 2f)
        canvas.drawText(text, cx, baseline, paint)
    }

    protected data class ContractSecurityMetadata(
        val contractNo: String,
        val contractDate: String,
        val party1Name: String,
        val party2Name: String,
        val amountDisplay: String,
        val officeName: String,
        val licenseNo: String,
        val verificationCode: String
    )

    protected fun extractSecurityMetadata(contractData: Any, officeInfo: OfficeInfo): ContractSecurityMetadata {
        val defaultOffice = officeInfo.officeName.trim()
        var contractNo = "0001"
        var contractDate = ""
        var party1Name = ""
        var party2Name = ""
        var amountDisplay = ""
        var officeName = defaultOffice

        when (contractData) {
            is RealEstateContract -> {
                contractNo = contractData.contractNo.trim().ifEmpty { "0001" }
                contractDate = contractData.contractDate.trim()
                party1Name = contractData.sellerName.trim()
                party2Name = contractData.buyerName.trim()
                val fmt = FormatUtils.formatMoneyInput(contractData.totalPrice)
                amountDisplay = if (fmt.isNotBlank()) "$fmt د.ع" else contractData.totalPrice.trim()
                officeName = defaultOffice.ifEmpty { "مكتب الدلالية العقاري" }
            }
            is CarSaleContract -> {
                contractNo = contractData.contractNo.trim().ifEmpty { "0001" }
                contractDate = contractData.contractDate.trim()
                party1Name = contractData.sellerName.trim()
                party2Name = contractData.buyerName.trim()
                val fmt = FormatUtils.formatMoneyInput(contractData.totalPrice)
                amountDisplay = if (fmt.isNotBlank()) "$fmt ${contractData.currency.shortLabelAr}" else contractData.totalPrice.trim()
                officeName = contractData.galleryName.trim().ifEmpty {
                    defaultOffice.ifEmpty { "معرض بيع وشراء السيارات" }
                }
            }
            is RentalContract -> {
                contractNo = contractData.contractNo.trim().ifEmpty { "0001" }
                contractDate = contractData.signDate.trim()
                party1Name = contractData.lessorName.trim()
                party2Name = contractData.lesseeName.trim()
                val fmt = FormatUtils.formatMoneyInput(contractData.rentAmountNumber)
                amountDisplay = if (fmt.isNotBlank()) "$fmt د.ع" else contractData.rentAmountNumber.trim()
                officeName = defaultOffice.ifEmpty { "مكتب العقارات" }
            }
            is MotorcycleContract -> {
                contractNo = contractData.contractNo.trim().ifEmpty { "0001" }
                contractDate = contractData.contractDate.trim()
                party1Name = contractData.sellerName.trim()
                party2Name = contractData.buyerName.trim()
                val fmt = FormatUtils.formatMoneyInput(contractData.totalPrice)
                amountDisplay = if (fmt.isNotBlank()) "$fmt ${contractData.currency.shortLabelAr}" else contractData.totalPrice.trim()
                officeName = defaultOffice.ifEmpty { "معرض بيع الدراجات والتكتك" }
            }
            else -> {
                officeName = defaultOffice.ifEmpty { "وثيقة عقد رسمي" }
            }
        }

        val licenseNo = officeInfo.licenseNo.trim()
        val rawSeed = "$contractNo|$contractDate|$party1Name|$party2Name|$amountDisplay|$officeName|$licenseNo"
        val code = computeShortSecurityCode(rawSeed)

        return ContractSecurityMetadata(
            contractNo = contractNo,
            contractDate = contractDate,
            party1Name = party1Name,
            party2Name = party2Name,
            amountDisplay = amountDisplay,
            officeName = officeName,
            licenseNo = licenseNo,
            verificationCode = code
        )
    }

    private fun computeShortSecurityCode(seed: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray(Charsets.UTF_8))
            val hex = digest.take(4).joinToString("") { "%02X".format(it) }
            "${hex.substring(0, 4)}-${hex.substring(4, 8)}"
        } catch (_: Exception) {
            seed.hashCode().toUInt().toString(16).uppercase().padStart(8, '0').let {
                "${it.substring(0, 4)}-${it.substring(4, 8)}"
            }
        }
    }

    /**
     * رسم خلفية خطوط غيوشي (Guilloché) الأمنية الهندسية بترتيب مطبعي نظيف:
     * 1. شريطا جدائل موجية دقيقة في المنطقة العلوية والسفلية فقط (بعيداً عن متن النصوص لصفاء القراءة).
     * 2. وردة هندسية مركزية خفيفة ومتزنة مرتبط طورها برقم العقد.
     */
    protected open fun drawPageGuillocheBackground(
        canvas: Canvas,
        meta: ContractSecurityMetadata
    ) {
        val isMonochrome = activeTemplate.id == "monochrome_bw"
        val baseColor = if (isMonochrome) textColorInt() else primaryColorInt()
        val clipPad = innerMargin + 4f
        val phaseSeed = ((meta.contractNo.hashCode() and 0xFF) / 255.0) * (2.0 * PI)

        canvas.save()
        canvas.clipRect(clipPad, clipPad, A4_WIDTH - clipPad, A4_HEIGHT - clipPad)

        // 1. أشرطة الجدائل الموجية الأفقية الدقيقة في أعلى وأسفل الصفحة فقط
        val wavePaint = Paint().apply {
            color = tintColor(baseColor, if (isMonochrome) 18 else 16)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
            isAntiAlias = true
        }
        val leftX = clipPad
        val rightX = A4_WIDTH - clipPad
        val stepX = 6f
        val periodPx = 88.0
        val ampPx = 9.0
        val bandRows = listOf(0.055f, 0.945f)

        for ((rowIdx, fracY) in bandRows.withIndex()) {
            val baseY = A4_HEIGHT * fracY
            for (strand in 0 until 2) {
                val strandPhase = phaseSeed + (rowIdx * 0.7) + (strand * PI)
                val path = Path()
                var x = leftX
                var first = true
                while (x <= rightX + stepX) {
                    val clampedX = x.coerceAtMost(rightX)
                    val angle = ((clampedX - leftX) / periodPx) * (2.0 * PI) + strandPhase
                    val y = baseY + (sin(angle) * ampPx).toFloat()
                    if (first) {
                        path.moveTo(clampedX, y)
                        first = false
                    } else {
                        path.lineTo(clampedX, y)
                    }
                    x += stepX
                }
                canvas.drawPath(path, wavePaint)
            }
        }

        // 2. الوردة الهندسية المركزية (Guilloché Rosette) من 4 حلقات متشابكة بنعومة
        val cx = A4_WIDTH / 2f
        val cy = A4_HEIGHT * 0.50f
        val rosettePaint = Paint().apply {
            color = tintColor(baseColor, if (isMonochrome) 17 else 15)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
            isAntiAlias = true
        }
        val petals = 18.0
        val steps = 360
        for (ringIdx in 0 until 4) {
            val baseR = 130.0 + (ringIdx * 34.0)
            val waveAmp = 13.0 + (ringIdx * 2.2)
            val ringPhase = phaseSeed + (ringIdx * (PI / 2.0))
            val path = Path()
            for (deg in 0..steps) {
                val theta = Math.toRadians(deg.toDouble())
                val r = baseR + waveAmp * sin((petals * theta) + ringPhase)
                val px = cx + (r * cos(theta)).toFloat()
                val py = cy + (r * sin(theta)).toFloat()
                if (deg == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            canvas.drawPath(path, rosettePaint)
        }

        canvas.restore()
    }

    /**
     * أداة رسم شريط موجات غيوشي داخل مستطيل محدد (مثل الجداول المالية أو خانة التواقيع)
     */
    protected fun drawGuillocheWaveRibbon(
        canvas: Canvas,
        rect: RectF,
        alpha: Int = 18,
        strandCount: Int = 3,
        amplitude: Float = 5.5f,
        cornerRadius: Float = 0f
    ) {
        if (rect.width() <= 20f || rect.height() <= 10f) return
        val isMonochrome = activeTemplate.id == "monochrome_bw"
        val baseColor = if (isMonochrome) textColorInt() else primaryColorInt()
        val seed = ((activeSecurityMeta?.contractNo?.hashCode() ?: 1) and 0xFF) / 255.0 * (2.0 * PI)

        val paint = Paint().apply {
            color = tintColor(baseColor, alpha)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
            isAntiAlias = true
        }

        canvas.save()
        if (cornerRadius > 0f) {
            val clipPath = Path().apply {
                addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)
            }
            canvas.clipPath(clipPath)
        } else {
            canvas.clipRect(rect)
        }

        val centerY = rect.centerY()
        val period = 46.0
        val stepX = 4f
        for (strand in 0 until strandCount) {
            val phase = seed + (strand * (2.0 * PI / strandCount.coerceAtLeast(1)))
            val path = Path()
            var x = rect.left
            var first = true
            while (x <= rect.right + stepX) {
                val clampedX = x.coerceAtMost(rect.right)
                val theta = ((clampedX - rect.left) / period) * (2.0 * PI) + phase
                val y = centerY + (sin(theta) * amplitude).toFloat()
                if (first) {
                    path.moveTo(clampedX, y)
                    first = false
                } else {
                    path.lineTo(clampedX, y)
                }
                x += stepX
            }
            canvas.drawPath(path, paint)
        }
        canvas.restore()
    }

    protected open fun drawContractWatermark(canvas: Canvas, officeInfo: OfficeInfo) {
        drawContractWatermark(canvas, officeInfo, extractSecurityMetadata(Unit, officeInfo))
    }

    protected open fun drawContractWatermark(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        meta: ContractSecurityMetadata
    ) {
        val isMonochrome = activeTemplate.id == "monochrome_bw"
        val baseColor = if (isMonochrome) textColorInt() else primaryColorInt()
        val clipPad = innerMargin + 4f

        canvas.save()
        canvas.clipRect(clipPad, clipPad, A4_WIDTH - clipPad, A4_HEIGHT - clipPad)

        val centerX = A4_WIDTH / 2f
        val mainTitle = meta.officeName.ifBlank { "وثيقة عقد رسمي" }
        val mainPaint = Paint().apply {
            color = tintColor(baseColor, if (isMonochrome) 22 else 20)
            textSize = 56f
            typeface = displayBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val maxMainW = A4_WIDTH * 0.68f
        while (mainPaint.measureText(mainTitle) > maxMainW && mainPaint.textSize > 28f) {
            mainPaint.textSize -= 2f
        }

        val subLine1 = buildList {
            add("عقد رقم: ${meta.contractNo}")
            if (meta.contractDate.isNotBlank()) add(meta.contractDate)
            if (meta.licenseNo.isNotBlank()) add("إجازة: ${meta.licenseNo}")
        }.joinToString("  •  ")

        val subLine2 = buildList {
            if (meta.party1Name.isNotBlank() || meta.party2Name.isNotBlank()) {
                add("${meta.party1Name.ifBlank { "الطرف الأول" }} / ${meta.party2Name.ifBlank { "الطرف الثاني" }}")
            }
            if (meta.amountDisplay.isNotBlank()) add(meta.amountDisplay)
            add(meta.verificationCode)
        }.joinToString("  •  ")

        val subPaint = Paint().apply {
            color = tintColor(baseColor, if (isMonochrome) 19 else 17)
            textSize = 21f
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        while (subPaint.measureText(subLine2) > maxMainW && subPaint.textSize > 14f) {
            subPaint.textSize -= 1f
        }

        val logoCfg = activeWatermarkLogo
        val logoBmp = if (logoCfg?.enabled == true) logoCfg.logoBitmap else null
        val hasLogo = logoBmp != null && !logoBmp.isRecycled && logoBmp.width > 0 && logoBmp.height > 0

        if (hasLogo) {
            val availW = A4_WIDTH - (2f * clipPad)
            val availH = A4_HEIGHT - (2f * clipPad)
            val scaleFrac = logoCfg!!.sizePercent.coerceIn(15f, 85f) / 100f
            val targetMaxW = availW * scaleFrac
            val targetMaxH = availH * (scaleFrac * 0.85f)

            val aspect = logoBmp!!.width.toFloat() / logoBmp.height.toFloat()
            var drawW = targetMaxW
            var drawH = drawW / aspect
            if (drawH > targetMaxH) {
                drawH = targetMaxH
                drawW = drawH * aspect
            }
            val left = (A4_WIDTH - drawW) / 2f
            val top = (A4_HEIGHT - drawH) / 2f
            val destRect = RectF(left, top, left + drawW, top + drawH)

            val alphaInt = ((logoCfg.opacityPercent.coerceIn(5f, 60f) / 100f) * 255f)
                .toInt()
                .coerceIn(12, 165)

            val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = alphaInt
                if (isMonochrome) {
                    val cm = ColorMatrix().apply { setSaturation(0f) }
                    colorFilter = ColorMatrixColorFilter(cm)
                }
            }
            canvas.drawBitmap(logoBmp, null, destRect, logoPaint)
        }

        // علامة مائية مركزية واحدة نظيفة ومتزنة (تظهر دائماً سواء مع الشعار أو بدونه دون إزدحام على الفقرات)
        if (hasLogo) {
            mainPaint.color = tintColor(baseColor, if (isMonochrome) 30 else 28)
            subPaint.color = tintColor(baseColor, if (isMonochrome) 25 else 23)
        } else {
            mainPaint.color = tintColor(baseColor, if (isMonochrome) 26 else 24)
            subPaint.color = tintColor(baseColor, if (isMonochrome) 21 else 19)
        }
        val centerY = A4_HEIGHT * 0.50f
        canvas.save()
        canvas.rotate(-26f, centerX, centerY)
        canvas.drawText(mainTitle, centerX, centerY, mainPaint)
        canvas.drawText(subLine1, centerX, centerY + 32f, subPaint)
        canvas.drawText(subLine2, centerX, centerY + 58f, subPaint)
        canvas.restore()

        canvas.restore()
    }

    /**
     * شريط الحاشية الأمني الديناميكي حول محيط الورقة بين الإطار الخارجي والداخلي:
     * يرسم وحدات أمنية كاملة متباعدة بوضوح ودون قص أو تداخل مع الخطوط.
     */
    protected open fun drawMarginSecurityStrip(canvas: Canvas, meta: ContractSecurityMetadata) {
        val outer = outerMargin
        val inner = innerMargin
        val stripW = (inner - outer).coerceAtLeast(18f)
        val isMonochrome = activeTemplate.id == "monochrome_bw"
        val primary = primaryColorInt()
        val dark = textColorInt()

        val unitParts = buildList {
            add("وثيقة رسمية")
            add(meta.officeName)
            add("عقد ${meta.contractNo}")
            if (meta.contractDate.isNotBlank()) add(meta.contractDate)
            if (meta.party1Name.isNotBlank() || meta.party2Name.isNotBlank()) {
                add("${meta.party1Name.ifBlank { "الأول" }} / ${meta.party2Name.ifBlank { "الثاني" }}")
            }
            if (meta.amountDisplay.isNotBlank()) add(meta.amountDisplay)
            add("تحقق ${meta.verificationCode}")
        }
        val unitText = unitParts.joinToString("  |  ")

        val stripTp = TextPaint().apply {
            color = if (isMonochrome) tintColor(dark, 210) else tintColor(primary, 200)
            textSize = 10.5f
            typeface = bodyBoldTypeface
            isAntiAlias = true
        }

        val maxSingleUnitW = (A4_WIDTH - (2f * inner) - 48f).coerceAtLeast(220f)
        while (stripTp.measureText(unitText) > maxSingleUnitW && stripTp.textSize > 8.5f) {
            stripTp.textSize -= 0.5f
        }

        val unitWidth = ceil(stripTp.measureText(unitText)).toInt().coerceAtLeast(120) + 16
        val unitLayout = StaticLayout.Builder
            .obtain(unitText, 0, unitText.length, stripTp, unitWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setMaxLines(1)
            .setIncludePad(false)
            .build()

        val fm = stripTp.fontMetrics
        val glyphHeight = fm.descent - fm.ascent
        val baselineInLayout = unitLayout.getLineBaseline(0).toFloat()
        val verticalOffsetInStrip = ((stripW - glyphHeight) / 2f) - (baselineInLayout + fm.ascent)

        val sepPaint = Paint().apply {
            color = if (isMonochrome) tintColor(dark, 180) else tintColor(primary, 175)
            style = Paint.Style.STROKE
            strokeWidth = 1.1f
            isAntiAlias = true
        }
        fun drawHairlineSep(cx: Float, cy: Float, isVerticalAxis: Boolean) {
            if (isVerticalAxis) {
                canvas.drawLine(cx - 4f, cy, cx + 4f, cy, sepPaint)
            } else {
                canvas.drawLine(cx, cy - 4f, cx, cy + 4f, sepPaint)
            }
        }

        val horizSpan = (A4_WIDTH - (2f * inner) - 24f).coerceAtLeast(120f)
        val horizCount = (horizSpan / (unitWidth + 44f)).toInt().coerceIn(1, 2)
        val horizStep = horizSpan / horizCount
        val horizStart = inner + 12f

        val topCenterY = outer + (stripW / 2f)
        val bottomCenterY = A4_HEIGHT - outer - (stripW / 2f)

        for (i in 0 until horizCount) {
            val segCenterX = horizStart + (i + 0.5f) * horizStep
            val drawX = segCenterX - (unitLayout.width / 2f)

            canvas.save()
            canvas.translate(drawX, outer + verticalOffsetInStrip)
            unitLayout.draw(canvas)
            canvas.restore()

            canvas.save()
            canvas.translate(drawX, A4_HEIGHT - inner + verticalOffsetInStrip)
            unitLayout.draw(canvas)
            canvas.restore()

            if (i < horizCount - 1) {
                val sepX = horizStart + (i + 1) * horizStep
                drawHairlineSep(sepX, topCenterY, isVerticalAxis = false)
                drawHairlineSep(sepX, bottomCenterY, isVerticalAxis = false)
            }
        }

        val vertSpan = (A4_HEIGHT - (2f * inner) - 36f).coerceAtLeast(160f)
        val vertCount = (vertSpan / (unitWidth + 56f)).toInt().coerceIn(1, 3)
        val vertStep = vertSpan / vertCount
        val vertStart = inner + 18f

        val rightCenterX = A4_WIDTH - outer - (stripW / 2f)
        val leftCenterX = outer + (stripW / 2f)

        for (i in 0 until vertCount) {
            val segCenterY = vertStart + (i + 0.5f) * vertStep

            canvas.save()
            canvas.rotate(90f, rightCenterX, segCenterY)
            canvas.translate(
                rightCenterX - (unitLayout.width / 2f),
                segCenterY - (stripW / 2f) + verticalOffsetInStrip
            )
            unitLayout.draw(canvas)
            canvas.restore()

            canvas.save()
            canvas.rotate(-90f, leftCenterX, segCenterY)
            canvas.translate(
                leftCenterX - (unitLayout.width / 2f),
                segCenterY - (stripW / 2f) + verticalOffsetInStrip
            )
            unitLayout.draw(canvas)
            canvas.restore()

            if (i < vertCount - 1) {
                val sepY = vertStart + (i + 1) * vertStep
                drawHairlineSep(rightCenterX, sepY, isVerticalAxis = true)
                drawHairlineSep(leftCenterX, sepY, isVerticalAxis = true)
            }
        }
    }

    /**
     * إطار عراقي هندسي كلاسيكي حاد الزوايا ومضبوط السماكة للطباعة النظيفة
     */
    protected open fun drawA4Borders(canvas: Canvas) {
        val outer = outerMargin
        val outerRect = RectF(outer, outer, A4_WIDTH - outer, A4_HEIGHT - outer)
        canvas.drawRect(outerRect, framePaint)

        if (activeTemplate.isDoubleFrame) {
            val inner = innerMargin
            val innerRect = RectF(inner, inner, A4_WIDTH - inner, A4_HEIGHT - inner)
            val darkInnerPaint = Paint(innerFramePaint).apply {
                color = primaryColorInt()
                strokeWidth = (1.25f * activeTemplate.borderWidth).coerceAtLeast(1.0f)
            }
            canvas.drawRect(innerRect, darkInnerPaint)

            // علامات زوايا هندسية كلاسيكية نقية بدون زخرفة زائدة
            val cornerSize = 14f
            val cornerPaint = Paint().apply {
                color = primaryColorInt()
                style = Paint.Style.STROKE
                strokeWidth = 2.0f
                isAntiAlias = true
            }
            val corners = listOf(
                Pair(inner, inner) to Pair(1f, 1f),
                Pair(A4_WIDTH - inner, inner) to Pair(-1f, 1f),
                Pair(inner, A4_HEIGHT - inner) to Pair(1f, -1f),
                Pair(A4_WIDTH - inner, A4_HEIGHT - inner) to Pair(-1f, -1f)
            )
            for ((pt, dir) in corners) {
                val (cx, cy) = pt
                val (dx, dy) = dir
                canvas.drawLine(cx, cy + (cornerSize * dy), cx + (cornerSize * dx), cy + (cornerSize * dy), cornerPaint)
                canvas.drawLine(cx + (cornerSize * dx), cy, cx + (cornerSize * dx), cy + (cornerSize * dy), cornerPaint)
            }
        }
    }

    protected open fun drawFooterPageNumber(canvas: Canvas) {
        val footerPaint = Paint().apply {
            color = tintColor(textColorInt(), 200)
            textSize = 12.5f * activeTemplate.fontScale
            typeface = bodyTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val y = A4_HEIGHT - outerMargin + 17f
        val safeY = y.coerceAtMost(A4_HEIGHT - 16f)
        canvas.drawText(
            "حُرر هذا العقد على نسختين أصليتين بيد كل طرف نسخة للعمل بموجبها  —  صفحة ١ من ١",
            A4_WIDTH / 2f,
            safeY,
            footerPaint
        )
    }

    protected abstract fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    )

    /**
     * الترويسة العراقية الرسمية الموحدة (ثلاثية الأعمدة + البسملة + رقم الإجازة + الهواتف بدون إيموجي)
     */
    protected fun drawIraqiOfficialHeader(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        defaultOfficeName: String,
        specialtyText: String,
        contractTitle: String,
        contractSubtitle: String,
        contractNo: String,
        contractDate: String,
        extraMetaLabel: String = "",
        extraMetaValue: String = "",
        overrideOfficeName: String = "",
        overrideOfficePhone: String = "",
        overrideOfficeAddress: String = ""
    ): Float {
        val primary = primaryColorInt()
        val secondary = secondaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale
        val isMonochrome = activeTemplate.id == "monochrome_bw"

        var curY = innerMargin + 32f

        // 1. البسملة في أعلى المنتصف بخط مريح وخط فاصل مطبعي مزدوج نقي بدون نقاط زخرفية
        val bismillahPaint = Paint().apply {
            color = primary
            textSize = 24.5f * scale
            typeface = displayBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", A4_WIDTH / 2f, curY + 4f, bismillahPaint)

        curY += 20f
        val rulePrimary = Paint().apply {
            color = tintColor(primary, 165)
            strokeWidth = 1.4f
            isAntiAlias = true
        }
        val ruleThin = Paint().apply {
            color = tintColor(primary, 110)
            strokeWidth = 0.7f
            isAntiAlias = true
        }
        canvas.drawLine(A4_WIDTH / 2f - 135f, curY, A4_WIDTH / 2f + 135f, curY, rulePrimary)
        canvas.drawLine(A4_WIDTH / 2f - 105f, curY + 3.5f, A4_WIDTH / 2f + 105f, curY + 3.5f, ruleThin)

        curY += 10f

        val headerTop = curY + 8f
        val headerHeight = 152f
        val headerBottom = headerTop + headerHeight

        val rightColW = contentWidth * 0.31f
        val centerColW = contentWidth * 0.34f
        val leftColW = contentWidth * 0.31f

        val rightColRight = contentRight
        val centerCenterX = A4_WIDTH / 2f
        val leftColLeft = contentLeft
        val leftColRight = leftColLeft + leftColW

        // ==================== العمود الأيمن: ترويسة المكتب / المعرض ====================
        val effectiveName = overrideOfficeName.trim().ifEmpty {
            officeInfo.officeName.trim().ifEmpty { defaultOfficeName }
        }
        val effectiveAddress = overrideOfficeAddress.trim().ifEmpty {
            officeInfo.address.trim().ifEmpty { "العراق" }
        }
        val licenseNo = officeInfo.licenseNo.trim()
        val p1 = officeInfo.phone.trim()
        val p2 = officeInfo.phone2.trim()
        val phonesDisplay = overrideOfficePhone.trim().ifEmpty {
            officeInfo.formattedPhones()
        }

        var rY = headerTop + 26f
        val officeNamePaint = Paint().apply {
            color = primary
            textSize = 26f * scale
            typeface = displayBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        fitTextToWidth(officeNamePaint, effectiveName, rightColW - 8f, 16f)
        canvas.drawText(effectiveName, rightColRight, rY, officeNamePaint)

        rY += 26f
        val specPaint = Paint().apply {
            color = if (isMonochrome) dark else secondary
            textSize = 14.5f * scale
            typeface = bodyTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        fitTextToWidth(specPaint, specialtyText, rightColW - 8f, 11.5f)
        canvas.drawText(specialtyText, rightColRight, rY, specPaint)

        val metaRightPaint = Paint().apply {
            color = dark
            textSize = 14f * scale
            typeface = bodyTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        if (licenseNo.isNotBlank()) {
            rY += 22f
            val licText = "إجازة ممارسة المهنة: $licenseNo"
            fitTextToWidth(metaRightPaint, licText, rightColW - 8f, 11f)
            canvas.drawText(licText, rightColRight, rY, metaRightPaint)
        }

        rY += 22f
        val addrText = "العنوان: $effectiveAddress"
        val addrPaint = Paint(metaRightPaint)
        fitTextToWidth(addrPaint, addrText, rightColW - 8f, 11f)
        canvas.drawText(addrText, rightColRight, rY, addrPaint)

        if (overrideOfficePhone.isBlank() && p1.isNotBlank() && p2.isNotBlank()) {
            rY += 22f
            val dualPhonesText = "هاتف: $p1  |  $p2"
            val phonePaint = Paint(metaRightPaint)
            if (phonePaint.measureText(dualPhonesText) <= rightColW - 8f) {
                canvas.drawText(dualPhonesText, rightColRight, rY, phonePaint)
            } else {
                canvas.drawText("هاتف ١: $p1", rightColRight, rY, phonePaint)
                rY += 19f
                canvas.drawText("هاتف ٢: $p2", rightColRight, rY, phonePaint)
            }
        } else if (phonesDisplay.isNotBlank()) {
            rY += 22f
            val phoneText = "هاتف: $phonesDisplay"
            val phonePaint = Paint(metaRightPaint)
            fitTextToWidth(phonePaint, phoneText, rightColW - 8f, 11f)
            canvas.drawText(phoneText, rightColRight, rY, phonePaint)
        }

        // ==================== العمود الأوسط: عنوان العقد الرسمي بنقاء مطبعي ====================
        val plaqueTop = headerTop + 14f
        val plaqueHalfW = (centerColW / 2f) - 8f
        val plaqueHeight = 76f
        val plaqueRect = RectF(
            centerCenterX - plaqueHalfW,
            plaqueTop,
            centerCenterX + plaqueHalfW,
            plaqueTop + plaqueHeight
        )
        val plaqueBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 2.0f
            isAntiAlias = true
        }
        val plaqueInnerBorder = Paint().apply {
            color = tintColor(primary, 175)
            style = Paint.Style.STROKE
            strokeWidth = 0.85f
            isAntiAlias = true
        }
        canvas.drawRect(plaqueRect, plaqueBorder)
        canvas.drawRect(
            RectF(plaqueRect.left + 4.5f, plaqueRect.top + 4.5f, plaqueRect.right - 4.5f, plaqueRect.bottom - 4.5f),
            plaqueInnerBorder
        )

        val mainTitlePaint = Paint().apply {
            color = titleColorInt()
            textSize = 28.5f * scale
            typeface = displayBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        fitTextToWidth(mainTitlePaint, contractTitle, plaqueRect.width() - 22f, 18f)
        drawCenteredSingleLine(canvas, contractTitle, centerCenterX, plaqueRect.centerY(), mainTitlePaint)

        val subPaint = Paint().apply {
            color = if (isMonochrome) dark else secondary
            textSize = 15f * scale
            typeface = bodyTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        fitTextToWidth(subPaint, contractSubtitle, centerColW - 12f, 11.5f)
        canvas.drawText(contractSubtitle, centerCenterX, plaqueRect.bottom + 24f, subPaint)

        // ==================== العمود الأيسر: جدول التوثيق (الرقم والتاريخ) ====================
        val metaRows = mutableListOf(
            "رقم العقد" to contractNo.ifBlank { "—" },
            "التاريخ" to contractDate.ifBlank { "—/—/2026" }
        )
        if (extraMetaLabel.isNotBlank()) {
            metaRows.add(extraMetaLabel to extraMetaValue.ifBlank { "—" })
        }
        val rowH = if (metaRows.size == 3) 40f else 48f
        val metaTableTop = headerTop + 14f
        val metaTableH = rowH * metaRows.size
        val metaRect = RectF(leftColLeft, metaTableTop, leftColRight, metaTableTop + metaTableH)

        val metaBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.6f
            isAntiAlias = true
        }
        val metaThin = Paint().apply {
            color = tintColor(primary, 170)
            style = Paint.Style.STROKE
            strokeWidth = 0.9f
            isAntiAlias = true
        }
        val labelColSplit = metaRect.right - (leftColW * 0.36f)

        canvas.drawRect(metaRect, metaBorder)
        canvas.drawLine(labelColSplit, metaRect.top, labelColSplit, metaRect.bottom, metaThin)

        val mLblPaint = Paint().apply {
            color = primary
            textSize = 14.5f * scale
            typeface = bodyTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val mValPaint = Paint().apply {
            color = dark
            textSize = 15.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        metaRows.forEachIndexed { idx, (lbl, valText) ->
            val rTop = metaRect.top + (idx * rowH)
            val rowCenterY = rTop + (rowH / 2f)
            if (idx > 0) {
                canvas.drawLine(metaRect.left, rTop, metaRect.right, rTop, metaThin)
            }
            val lblP = Paint(mLblPaint)
            fitTextToWidth(lblP, lbl, (metaRect.right - labelColSplit) - 8f, 10.5f)
            drawCenteredSingleLine(canvas, lbl, (labelColSplit + metaRect.right) / 2f, rowCenterY, lblP)

            val valP = Paint(mValPaint).apply {
                color = if (idx == 0 && !isMonochrome) COLOR_RED_ACCENT else dark
            }
            fitTextToWidth(valP, valText, (labelColSplit - metaRect.left) - 10f, 10.5f)
            drawCenteredSingleLine(canvas, valText, (metaRect.left + labelColSplit) / 2f, rowCenterY, valP)
        }

        // خط فاصل مزدوج بعرض الصفحة أسفل الترويسة
        val divY = maxOf(headerBottom, rY + 12f)
        val thickDiv = Paint().apply {
            color = primary
            strokeWidth = 2.2f
            isAntiAlias = true
        }
        val thinDiv = Paint().apply {
            color = tintColor(primary, 175)
            strokeWidth = 0.9f
            isAntiAlias = true
        }
        canvas.drawLine(contentLeft, divY, contentRight, divY, thickDiv)
        canvas.drawLine(contentLeft, divY + 4.5f, contentRight, divY + 4.5f, thinDiv)

        return divY + 16f
    }

    /**
     * عنوان قسم رسمي نظيف بشريط جانبي حاد وخطوط طباعية دقيقة بدون تظليل رمادي باهت
     */
    protected fun drawIraqiSectionBanner(
        canvas: Canvas,
        title: String,
        topY: Float,
        height: Float = 32f,
        alignCenter: Boolean = false
    ): Float {
        val primary = primaryColorInt()
        val rect = RectF(contentLeft, topY, contentRight, topY + height)
        val topRule = Paint().apply {
            color = tintColor(primary, 110)
            style = Paint.Style.STROKE
            strokeWidth = 0.85f
            isAntiAlias = true
        }
        val bottomRule = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        val accentBar = Paint().apply {
            color = primary
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        canvas.drawLine(rect.left, rect.top, rect.right, rect.top, topRule)
        canvas.drawLine(rect.left, rect.bottom, rect.right, rect.bottom, bottomRule)
        if (!alignCenter) {
            canvas.drawRect(rect.right - 4.5f, rect.top, rect.right, rect.bottom, accentBar)
        }

        val textP = Paint().apply {
            color = primary
            textSize = 18f * activeTemplate.fontScale
            typeface = bodyBoldTypeface
            textAlign = if (alignCenter) Paint.Align.CENTER else Paint.Align.RIGHT
            isAntiAlias = true
        }
        val textX = if (alignCenter) rect.centerX() else rect.right - 14f
        fitTextToWidth(textP, title, rect.width() - 28f, 14f)
        drawCenteredSingleLine(canvas, title, textX, rect.centerY(), textP)
        return rect.bottom
    }

    /**
     * جدول الطرفين الرسمي (عمودان متجاوران بحدود حادة نظيفة وتنسيق مطبعي متوازن)
     */
    protected fun drawFormalPartiesTable(
        canvas: Canvas,
        topY: Float,
        rightTitle: String,
        leftTitle: String,
        rightFields: List<Pair<String, String>>,
        leftFields: List<Pair<String, String>>,
        rowSpacing: Float = 40f
    ): Float {
        val rowCount = maxOf(rightFields.size, leftFields.size)
        val headerH = 34f
        val bodyPadTop = 18f
        val bodyPadBottom = 14f
        val tableHeight = headerH + bodyPadTop + (rowCount * rowSpacing) + bodyPadBottom

        val tableRect = RectF(contentLeft, topY, contentRight, topY + tableHeight)
        val midX = tableRect.centerX()

        val primary = primaryColorInt()
        val outerBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val divider = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            isAntiAlias = true
        }
        val rowHairline = Paint().apply {
            color = tintColor(primary, 65)
            style = Paint.Style.STROKE
            strokeWidth = 0.7f
            isAntiAlias = true
        }

        canvas.drawRect(tableRect, outerBorder)
        canvas.drawLine(tableRect.left, tableRect.top + headerH, tableRect.right, tableRect.top + headerH, divider)
        canvas.drawLine(tableRect.left, tableRect.top + headerH + 3f, tableRect.right, tableRect.top + headerH + 3f, rowHairline)
        canvas.drawLine(midX, tableRect.top, midX, tableRect.bottom, divider)

        val hdrPaint = Paint().apply {
            color = primary
            textSize = 18.5f * activeTemplate.fontScale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        drawCenteredSingleLine(canvas, rightTitle, (midX + tableRect.right) / 2f, tableRect.top + (headerH / 2f), hdrPaint)
        drawCenteredSingleLine(canvas, leftTitle, (tableRect.left + midX) / 2f, tableRect.top + (headerH / 2f), hdrPaint)

        val colW = (tableRect.width() / 2f) - 24f
        val rStartX = tableRect.right - 12f
        val lStartX = midX - 12f

        for (idx in 1 until rowCount) {
            val sepY = tableRect.top + headerH + bodyPadTop + (idx * rowSpacing) - 10f
            canvas.drawLine(tableRect.left + 8f, sepY, midX - 8f, sepY, rowHairline)
            canvas.drawLine(midX + 8f, sepY, tableRect.right - 8f, sepY, rowHairline)
        }

        rightFields.forEachIndexed { idx, (label, value) ->
            val y = tableRect.top + headerH + bodyPadTop + 17f + (idx * rowSpacing)
            drawFieldWithDots(canvas, label, value, rStartX, y, colW)
        }
        leftFields.forEachIndexed { idx, (label, value) ->
            val y = tableRect.top + headerH + bodyPadTop + 17f + (idx * rowSpacing)
            drawFieldWithDots(canvas, label, value, lStartX, y, colW)
        }

        return tableRect.bottom
    }

    /**
     * رسم حقل بيانات باحترافية مطبعية:
     * - عند وجود نص: يُكتب نظيفاً مع التفاف لسطرين إذا طال بدلاً من تصغيره بشكل مشوه، وبدون نقاط تقطع الحروف الهابطة.
     * - عند فراغ الخانة: يُرسم خط منقط هادئ أسفل امتداد الحروف الهابطة لجاهزية الكتابة اليدوية.
     */
    protected fun drawFieldWithDots(
        canvas: Canvas,
        label: String,
        value: String,
        x: Float,
        y: Float,
        totalWidth: Float,
        labelWidth: Float = 0f
    ) {
        var currentX = x
        if (label.isNotEmpty()) {
            labelPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(label, currentX, y, labelPaint)
            val computedLabelWidth = if (labelWidth > 0f) labelWidth else labelPaint.measureText(label) + 10f
            currentX -= computedLabelWidth
        }

        val leftEdgeX = x - totalWidth
        val spaceWidth = (currentX - leftEdgeX).coerceAtLeast(28f)
        val cleanVal = value.trim()

        if (cleanVal.isNotEmpty()) {
            val singlePaint = Paint(valuePaint).apply { textAlign = Paint.Align.RIGHT }
            val minSingleLineSize = (valuePaint.textSize * 0.85f).coerceAtLeast(14.5f)
            while (singlePaint.measureText(cleanVal) > spaceWidth - 4f && singlePaint.textSize > minSingleLineSize) {
                singlePaint.textSize -= 0.5f
            }
            if (singlePaint.measureText(cleanVal) <= spaceWidth - 4f) {
                canvas.drawText(cleanVal, currentX - 2f, y, singlePaint)
            } else {
                val tp = TextPaint(valuePaint).apply {
                    textSize = (valuePaint.textSize * 0.80f).coerceAtLeast(13.5f)
                    isAntiAlias = true
                }
                val availW = (spaceWidth - 4f).toInt().coerceAtLeast(36)
                var layout = StaticLayout.Builder
                    .obtain(cleanVal, 0, cleanVal.length, tp, availW)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setLineSpacing(0f, 0.96f)
                    .setMaxLines(2)
                    .setIncludePad(false)
                    .build()
                while (layout.lineCount > 2 && tp.textSize > 11.5f) {
                    tp.textSize -= 0.5f
                    layout = StaticLayout.Builder
                        .obtain(cleanVal, 0, cleanVal.length, tp, availW)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setLineSpacing(0f, 0.96f)
                        .setMaxLines(2)
                        .setIncludePad(false)
                        .build()
                }
                val topY = if (layout.lineCount > 1) {
                    (y - 22f)
                } else {
                    y - layout.getLineBaseline(0).toFloat()
                }
                canvas.save()
                canvas.translate(leftEdgeX, topY)
                layout.draw(canvas)
                canvas.restore()
            }
        } else {
            canvas.drawLine(leftEdgeX + 2f, y + 8f, currentX - 4f, y + 8f, dotPaint)
        }
    }

    protected fun drawRtlText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint = valuePaint,
        align: Paint.Align = Paint.Align.RIGHT,
        maxLines: Int = 3,
        lineSpacingMultiplier: Float = 1.32f
    ) {
        if (text.isEmpty() || maxWidth <= 0f) return

        val originalSize = paint.textSize
        val currentPaint = Paint(paint).apply { textAlign = align }
        val minTextSize = (originalSize * 0.78f).coerceAtLeast(13.5f)

        while (currentPaint.measureText(text) > maxWidth && currentPaint.textSize > minTextSize) {
            currentPaint.textSize -= 0.5f
        }

        if (maxLines > 1 && currentPaint.measureText(text) > maxWidth) {
            val words = text.split(" ")
            val lines = mutableListOf<String>()
            var currentLine = ""

            for (word in words) {
                val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
                if (currentPaint.measureText(testLine) <= maxWidth) {
                    currentLine = testLine
                } else {
                    if (currentLine.isNotEmpty()) lines.add(currentLine)
                    currentLine = word
                }
                if (lines.size >= maxLines - 1) break
            }
            if (currentLine.isNotEmpty() && lines.size < maxLines) {
                lines.add(currentLine)
            }

            var currentY = y
            val lineStep = currentPaint.textSize * lineSpacingMultiplier
            for (line in lines) {
                canvas.drawText(line, x, currentY, currentPaint)
                currentY += lineStep
            }
        } else {
            canvas.drawText(text, x, y, currentPaint)
        }

        paint.textSize = originalSize
    }

    /**
     * رسم نص عربي متعدد الأسطر باستخدام StaticLayout بمحاذاة RTL حقيقية لمنع أي قص أو تداخل
     */
    protected fun drawRtlParagraph(
        canvas: Canvas,
        text: String,
        leftX: Float,
        topY: Float,
        width: Float,
        textSize: Float = 16.5f * activeTemplate.fontScale,
        color: Int = textColorInt(),
        typeface: Typeface = bodyTypeface,
        lineSpacingMult: Float = 1.18f
    ): Float {
        if (text.isBlank() || width <= 20f) return 0f
        val tp = TextPaint().apply {
            this.color = color
            this.textSize = textSize
            this.typeface = typeface
            isAntiAlias = true
        }
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, tp, width.toInt())
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setLineSpacing(0f, lineSpacingMult)
            .setIncludePad(false)
            .build()

        canvas.save()
        canvas.translate(leftX, topY)
        layout.draw(canvas)
        canvas.restore()
        return layout.height.toFloat()
    }

    /**
     * رسم قائمة البنود القانونية العراقية بخط عادي مريح للطباعة مع إبراز العناوين بالغامق
     */
    protected fun drawIraqiLegalClauses(
        canvas: Canvas,
        clauses: List<Pair<String, String>>,
        startY: Float,
        maxBottomY: Float
    ): Float {
        var curY = startY
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale
        val paragraphGap = activeTemplate.paragraphSpacingDp.coerceIn(6f, 14f)

        val dividerPaint = Paint().apply {
            color = tintColor(borderColorInt(), 90)
            strokeWidth = 0.75f
            isAntiAlias = true
        }

        val spannedClauses = clauses.map { (label, body) ->
            val prefix = "$label: "
            val full = "$prefix$body"
            SpannableString(full).apply {
                setSpan(ForegroundColorSpan(primary), 0, prefix.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(StyleSpan(Typeface.BOLD), 0, prefix.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }

        var bodySize = 18.5f * scale
        var lineSpacingMult = 1.26f
        val availHeight = (maxBottomY - startY).coerceAtLeast(120f)
        val layoutWidth = contentWidth.toInt().coerceAtLeast(100)
        while (bodySize > 14f) {
            var estHeight = 0f
            val tp = TextPaint().apply {
                this.textSize = bodySize
                this.typeface = bodyTypeface
            }
            for (spanned in spannedClauses) {
                val sl = StaticLayout.Builder
                    .obtain(spanned, 0, spanned.length, tp, layoutWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setLineSpacing(0f, lineSpacingMult)
                    .setIncludePad(false)
                    .build()
                estHeight += sl.height + paragraphGap + 4f
            }
            if (estHeight <= availHeight) break
            if (lineSpacingMult > 1.18f) {
                lineSpacingMult -= 0.04f
            } else {
                bodySize -= 0.5f
            }
        }

        val tp = TextPaint().apply {
            color = dark
            textSize = bodySize
            typeface = bodyTypeface
            isAntiAlias = true
        }

        spannedClauses.forEachIndexed { idx, spanned ->
            val layout = StaticLayout.Builder
                .obtain(spanned, 0, spanned.length, tp, layoutWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setLineSpacing(0f, lineSpacingMult)
                .setIncludePad(false)
                .build()

            canvas.save()
            canvas.translate(contentLeft, curY)
            layout.draw(canvas)
            canvas.restore()

            curY += layout.height.toFloat() + (paragraphGap * 0.5f)
            if (idx < spannedClauses.lastIndex) {
                canvas.drawLine(contentLeft, curY, contentRight, curY, dividerPaint)
            }
            curY += (paragraphGap * 0.5f) + 2f
        }

        return curY
    }

    /**
     * رسم قسم الشروط والملاحظات الإضافية أسفل البنود بخط عادي واضح القراءة
     */
    protected fun drawAdditionalNotesBlock(
        canvas: Canvas,
        notes: String,
        startY: Float,
        maxBottomY: Float = footerTopY - 12f
    ): Float {
        if (startY >= maxBottomY - 24f) return startY
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale

        val labelPaintNotes = Paint().apply {
            color = primary
            textSize = 17f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("شروط وملاحظات إضافية:", contentRight, startY + 16f, labelPaintNotes)
        var curY = startY + 25f

        val cleanNotes = notes.trim()
        if (cleanNotes.isNotBlank()) {
            val availH = (maxBottomY - curY).coerceAtLeast(24f)
            var noteSize = 17f * scale
            val tp = TextPaint().apply {
                color = dark
                typeface = bodyTypeface
                isAntiAlias = true
            }
            var layout: StaticLayout
            while (true) {
                tp.textSize = noteSize
                layout = StaticLayout.Builder
                    .obtain(cleanNotes, 0, cleanNotes.length, tp, contentWidth.toInt())
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setLineSpacing(0f, 1.24f)
                    .setIncludePad(false)
                    .build()
                if (layout.height <= availH || noteSize <= 12.5f) break
                noteSize -= 0.5f
            }
            canvas.save()
            canvas.clipRect(contentLeft, curY, contentRight, maxBottomY)
            canvas.translate(contentLeft, curY)
            layout.draw(canvas)
            canvas.restore()
            curY += layout.height.toFloat().coerceAtMost(availH) + 6f
        } else {
            if (curY + 18f < maxBottomY) {
                canvas.drawLine(contentLeft, curY + 16f, contentRight, curY + 16f, dotPaint)
                curY += 26f
            }
            if (curY + 18f < maxBottomY) {
                canvas.drawLine(contentLeft, curY + 16f, contentRight, curY + 16f, dotPaint)
                curY += 24f
            }
        }
        return curY
    }

    data class FinancialBoxItem(
        val label: String,
        val numberValue: String,
        val wordsValue: String = "",
        val accentColor: Int
    )

    /**
     * رسم الشريط المالي الرسمي (3 خانات متساوية بحدود حادة مع عرض المبالغ رقماً وكتابةً)
     */
    protected fun drawFinancialSummaryTable(
        canvas: Canvas,
        topY: Float,
        items: List<Triple<String, String, Int>>,
        wordsRowLabel: String = "",
        wordsRowValue: String = ""
    ): Float {
        return drawFinancialSummaryTableWithWords(
            canvas = canvas,
            topY = topY,
            items = items.map { (lbl, num, col) -> FinancialBoxItem(lbl, num, "", col) },
            wordsRowLabel = wordsRowLabel,
            wordsRowValue = wordsRowValue
        )
    }

    protected fun drawFinancialSummaryTableWithWords(
        canvas: Canvas,
        topY: Float,
        items: List<FinancialBoxItem>,
        wordsRowLabel: String = "",
        wordsRowValue: String = ""
    ): Float {
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale
        val isMonochrome = activeTemplate.id == "monochrome_bw"

        var curY = topY
        val outerBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val innerLine = Paint().apply {
            color = tintColor(primary, 170)
            style = Paint.Style.STROKE
            strokeWidth = 0.9f
            isAntiAlias = true
        }

        if (wordsRowLabel.isNotBlank()) {
            val cleanWords = wordsRowValue.trim()
            val rightPad = 12f
            val leftPad = 12f
            labelPaint.textAlign = Paint.Align.RIGHT
            val lblW = labelPaint.measureText(wordsRowLabel) + 12f
            val availWordsW = (contentWidth - rightPad - leftPad - lblW).toInt().coerceAtLeast(140)

            var wordsLayout: StaticLayout? = null
            var wordsTextSize = 17.5f * scale
            if (cleanWords.isNotBlank()) {
                val tp = TextPaint().apply {
                    color = dark
                    typeface = bodyBoldTypeface
                    isAntiAlias = true
                }
                while (true) {
                    tp.textSize = wordsTextSize
                    wordsLayout = StaticLayout.Builder
                        .obtain(cleanWords, 0, cleanWords.length, tp, availWordsW)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setLineSpacing(0f, 1.15f)
                        .setMaxLines(2)
                        .setIncludePad(false)
                        .build()
                    if ((wordsLayout.lineCount <= 2 && wordsLayout.height <= 48) || wordsTextSize <= 13f) break
                    wordsTextSize -= 0.5f
                }
            }

            val wordsH = if (wordsLayout != null && wordsLayout.lineCount > 1) {
                (wordsLayout.height + 22f).coerceIn(54f, 68f)
            } else {
                40f
            }

            val wordsRect = RectF(contentLeft, curY, contentRight, curY + wordsH)
            drawGuillocheWaveRibbon(canvas, wordsRect, alpha = 24, strandCount = 3, amplitude = 5.5f)
            canvas.drawRect(wordsRect, outerBorder)

            val labelX = wordsRect.right - rightPad
            drawCenteredSingleLine(canvas, wordsRowLabel, labelX, wordsRect.centerY(), labelPaint)

            val valueRightX = labelX - lblW
            val valueLeftX = wordsRect.left + leftPad

            if (wordsLayout != null) {
                val textTopY = wordsRect.top + ((wordsH - wordsLayout.height) / 2f)
                canvas.save()
                canvas.translate(valueLeftX, textTopY)
                wordsLayout.draw(canvas)
                canvas.restore()
            } else {
                canvas.drawLine(valueLeftX, wordsRect.centerY() + 10f, valueRightX, wordsRect.centerY() + 10f, dotPaint)
            }

            curY = wordsRect.bottom + 8f
        }

        val cols = items.size.coerceAtLeast(1)
        val hasAnyColumnWords = items.any { it.wordsValue.isNotBlank() }
        val lblH = 28f
        val numH = 38f
        val wordsAreaH = if (hasAnyColumnWords) 54f else 10f
        val boxH = lblH + numH + wordsAreaH

        val tableRect = RectF(contentLeft, curY, contentRight, curY + boxH)
        val colW = tableRect.width() / cols

        drawGuillocheWaveRibbon(
            canvas,
            RectF(tableRect.left, tableRect.top + lblH, tableRect.right, tableRect.top + lblH + numH),
            alpha = 24,
            strandCount = 3,
            amplitude = 6f
        )
        canvas.drawRect(tableRect, outerBorder)
        canvas.drawLine(tableRect.left, tableRect.top + lblH, tableRect.right, tableRect.top + lblH, innerLine)
        if (hasAnyColumnWords) {
            val sepY = tableRect.top + lblH + numH
            val subSepPaint = Paint().apply {
                color = tintColor(primary, 95)
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
                isAntiAlias = true
            }
            canvas.drawLine(tableRect.left, sepY, tableRect.right, sepY, subSepPaint)
        }

        val lblP = Paint().apply {
            color = primary
            textSize = 15f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        items.forEachIndexed { i, item ->
            val colRight = tableRect.right - (i * colW)
            val colLeft = colRight - colW
            val cx = (colLeft + colRight) / 2f
            if (i > 0) {
                canvas.drawLine(colRight, tableRect.top, colRight, tableRect.bottom, innerLine)
            }
            val headerPaint = Paint(lblP)
            fitTextToWidth(headerPaint, item.label, colW - 14f, 12f)
            drawCenteredSingleLine(canvas, item.label, cx, tableRect.top + (lblH / 2f), headerPaint)

            val valP = Paint().apply {
                color = if (isMonochrome) dark else item.accentColor
                textSize = 19.5f * scale
                typeface = bodyBoldTypeface
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            val numCenterY = tableRect.top + lblH + (numH / 2f)
            if (item.numberValue.isNotBlank()) {
                fitTextToWidth(valP, item.numberValue, colW - 16f, 13.5f)
                drawCenteredSingleLine(canvas, item.numberValue, cx, numCenterY, valP)
            } else {
                canvas.drawLine(colLeft + 24f, numCenterY + 8f, colRight - 24f, numCenterY + 8f, dotPaint)
            }

            if (hasAnyColumnWords && item.wordsValue.isNotBlank()) {
                val cellWords = item.wordsValue.trim()
                val availW = (colW - 16f).toInt().coerceAtLeast(80)
                val availH = wordsAreaH - 6f
                var wSize = 13.5f * scale
                val wTp = TextPaint().apply {
                    color = dark
                    typeface = bodyTypeface
                    isAntiAlias = true
                }
                var wLayout: StaticLayout
                while (true) {
                    wTp.textSize = wSize
                    wLayout = StaticLayout.Builder
                        .obtain(cellWords, 0, cellWords.length, wTp, availW)
                        .setAlignment(Layout.Alignment.ALIGN_CENTER)
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setLineSpacing(0f, 1.12f)
                        .setMaxLines(3)
                        .setIncludePad(false)
                        .build()
                    if ((wLayout.lineCount <= 3 && wLayout.height <= availH) || wSize <= 10f) break
                    wSize -= 0.5f
                }
                val wordsTopY = tableRect.top + lblH + numH + ((wordsAreaH - wLayout.height) / 2f).coerceAtLeast(2f)
                canvas.save()
                canvas.translate(colLeft + 8f, wordsTopY)
                wLayout.draw(canvas)
                canvas.restore()
            }
        }

        return tableRect.bottom
    }

    /**
     * جدول التواقيع والشهود الرسمي حاد الزوايا بـ 4 أعمدة متوازنة وموضع مخصص للتوقيع والبصمة
     */
    protected fun drawIraqiSignaturesFooter(
        canvas: Canvas,
        party1Title: String,
        party2Title: String,
        witness1Name: String = "",
        witness2Name: String = "",
        organizerName: String = "",
        stampTitle: String = "",
        topY: Float = footerTopY,
        bottomY: Float = footerBottomY
    ) {
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale

        val rect = RectF(contentLeft, topY, contentRight, bottomY)
        drawGuillocheWaveRibbon(
            canvas,
            rect,
            alpha = 20,
            strandCount = 3,
            amplitude = 6.5f,
            cornerRadius = 0f
        )
        val borderPaint = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val innerLinePaint = Paint().apply {
            color = tintColor(primary, 130)
            style = Paint.Style.STROKE
            strokeWidth = 0.9f
            isAntiAlias = true
        }
        val signRulePaint = Paint().apply {
            color = tintColor(dark, 110)
            style = Paint.Style.STROKE
            strokeWidth = 0.85f
            pathEffect = DashPathEffect(floatArrayOf(2f, 4f), 0f)
            isAntiAlias = true
        }
        val captionPaint = Paint().apply {
            color = tintColor(dark, 145)
            textSize = 11.5f * scale
            typeface = bodyTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        canvas.drawRect(rect, borderPaint)

        val headerStripH = 34f
        canvas.drawLine(rect.left, rect.top + headerStripH, rect.right, rect.top + headerStripH, innerLinePaint)

        val colW = rect.width() / 4f
        for (idx in 1..3) {
            val sepX = rect.right - (idx * colW)
            canvas.drawLine(sepX, rect.top, sepX, rect.bottom, innerLinePaint)
        }

        val p1Paint = Paint().apply {
            color = primary
            textSize = 17.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val otherPaint = Paint().apply {
            color = dark
            textSize = 17.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val items = listOf(
            Triple(party1Title, "", p1Paint),
            Triple("الشاهد الأول", witness1Name.trim(), otherPaint),
            Triple("الشاهد الثاني", witness2Name.trim(), otherPaint),
            Triple(party2Title, "", otherPaint)
        )

        val headerCenterY = rect.top + (headerStripH / 2f)
        val signLineY = rect.bottom - 18f

        items.forEachIndexed { idx, (title, nameVal, basePaint) ->
            val colRight = rect.right - (idx * colW)
            val colLeft = colRight - colW
            val cx = (colLeft + colRight) / 2f

            val titleP = Paint(basePaint)
            fitTextToWidth(titleP, title, colW - 18f, 13f)
            drawCenteredSingleLine(canvas, title, cx, headerCenterY, titleP)

            if (nameVal.isNotBlank()) {
                val availW = (colW - 18f).toInt().coerceAtLeast(80)
                var nameSize = 17f * scale
                val tp = TextPaint().apply {
                    color = dark
                    typeface = bodyBoldTypeface
                    isAntiAlias = true
                }
                var layout: StaticLayout
                while (true) {
                    tp.textSize = nameSize
                    layout = StaticLayout.Builder
                        .obtain(nameVal, 0, nameVal.length, tp, availW)
                        .setAlignment(Layout.Alignment.ALIGN_CENTER)
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setLineSpacing(0f, 1.08f)
                        .setMaxLines(2)
                        .setIncludePad(false)
                        .build()
                    if ((layout.lineCount <= 2 && layout.height <= (signLineY - rect.top - headerStripH - 12f)) || nameSize <= 12.5f) break
                    nameSize -= 0.5f
                }
                canvas.save()
                canvas.translate(colLeft + 9f, rect.top + headerStripH + 8f)
                layout.draw(canvas)
                canvas.restore()
            }

            canvas.drawLine(colLeft + 26f, signLineY, colRight - 26f, signLineY, signRulePaint)
            canvas.drawText("التوقيع / البصمة", cx, rect.bottom - 5f, captionPaint)
        }
    }

    protected fun fitTextToWidth(paint: Paint, text: String, maxWidth: Float, minSize: Float) {
        if (text.isEmpty() || maxWidth <= 0f) return
        while (paint.measureText(text) > maxWidth && paint.textSize > minSize) {
            paint.textSize -= 0.5f
        }
    }

    // دوال التوافق مع أي استدعاءات سابقة
    protected fun drawSideBySidePartyBoxes(
        canvas: Canvas,
        topY: Float,
        boxHeight: Float,
        rightTitle: String,
        leftTitle: String
    ): Pair<RectF, RectF> {
        val margin = 50f
        val boxWidth = (A4_WIDTH - (margin * 2) - 30f) / 2f
        val rightBox = RectF(A4_WIDTH - margin - boxWidth, topY, A4_WIDTH - margin, topY + boxHeight)
        val leftBox = RectF(margin, topY, margin + boxWidth, topY + boxHeight)
        return Pair(rightBox, leftBox)
    }

    protected fun drawOptionalHeaderImage(
        canvas: Canvas,
        context: Context?,
        assetOrDrawableName: String,
        destRect: RectF
    ) {
        if (context == null) return
        try {
            val resId = context.resources.getIdentifier(assetOrDrawableName, "drawable", context.packageName)
            if (resId != 0) {
                val bitmap = BitmapFactory.decodeResource(context.resources, resId)
                if (bitmap != null) {
                    canvas.drawBitmap(bitmap, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
                    return
                }
            }
            val inputStream = context.assets.open(assetOrDrawableName)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            if (bitmap != null) {
                canvas.drawBitmap(bitmap, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
            }
        } catch (_: Exception) {
        }
    }

    protected fun drawSignatures(
        canvas: Canvas,
        titles: List<String>,
        bottomY: Float = A4_HEIGHT - 185f
    ) {
        val p1 = titles.firstOrNull() ?: "الطرف الأول"
        val p2 = titles.lastOrNull() ?: "الطرف الثاني"
        drawIraqiSignaturesFooter(
            canvas = canvas,
            party1Title = p1,
            party2Title = p2,
            topY = bottomY - 130f,
            bottomY = bottomY + 50f
        )
    }
}
