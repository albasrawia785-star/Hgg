package com.example

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface ContractDao {
    @Query("SELECT * FROM saved_contracts ORDER BY dateCreated DESC")
    fun getAllContracts(): Flow<List<ContractEntity>>

    @Query("SELECT * FROM saved_contracts ORDER BY dateCreated DESC")
    suspend fun getAllContractsOnce(): List<ContractEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContract(contract: ContractEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContracts(contracts: List<ContractEntity>)

    @Query("DELETE FROM saved_contracts WHERE id = :id")
    suspend fun deleteContractById(id: Long)

    @Query("DELETE FROM saved_contracts")
    suspend fun deleteAllContracts()

    @Transaction
    suspend fun replaceAllContracts(contracts: List<ContractEntity>) {
        deleteAllContracts()
        if (contracts.isNotEmpty()) {
            insertContracts(contracts)
        }
    }

    @Query("SELECT * FROM saved_contracts WHERE id = :id LIMIT 1")
    suspend fun getContractById(id: Long): ContractEntity?
}
