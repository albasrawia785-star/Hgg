package com.example

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

internal class DirectTursoException(
    val statusCode: Int,
    override val message: String
) : IllegalStateException(message)

internal data class TursoQueryResult(
    val rows: List<Map<String, String?>>,
    val affectedRows: Int,
    val lastInsertRowId: Long?
)

/**
 * عميل مباشر لقاعدة بيانات Turso (عبر بروتوكول Hrana v2 HTTP API)
 * يقرأ رابط القاعدة والتوكن من BuildConfig (لوحة Secrets) ويستخدم استعلامات SQL معلمة وتجزئة PBKDF2.
 */
internal class DirectTursoClient(
    private val httpClient: OkHttpClient
) {
    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private const val PBKDF2_ITERATIONS = 10000
        private const val SUBSCRIBER_SESSION_TTL_MS = 30L * 24L * 60L * 60L * 1000L
        private const val ADMIN_SESSION_TTL_MS = 12L * 60L * 60L * 1000L
        private const val ADMIN_PASSWORD_KEY = "admin_password_hash"

        fun argText(value: String): JSONObject = JSONObject().put("type", "text").put("value", value)
        fun argInt(value: Long): JSONObject = JSONObject().put("type", "integer").put("value", value.toString())
        fun argNull(): JSONObject = JSONObject().put("type", "null")

        fun hashPassword(password: String): String {
            val salt = ByteArray(16)
            SecureRandom().nextBytes(salt)
            val derived = pbkdf2HmacSha256(password.toByteArray(Charsets.UTF_8), salt, PBKDF2_ITERATIONS, 32)
            return "$PBKDF2_ITERATIONS:${toHex(salt)}:${toHex(derived)}"
        }

        fun verifyPassword(password: String, storedHash: String): Boolean {
            val parts = storedHash.split(":")
            if (parts.size != 3) return false
            val iterations = parts[0].toIntOrNull() ?: return false
            if (iterations < 1000) return false
            val salt = fromHex(parts[1]) ?: return false
            val expected = fromHex(parts[2]) ?: return false
            val actual = pbkdf2HmacSha256(
                password.toByteArray(Charsets.UTF_8),
                salt,
                iterations,
                expected.size
            )
            return MessageDigest.isEqual(actual, expected)
        }

        fun sha256Hex(input: String): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
            return toHex(digest)
        }

        fun generateRandomToken(): String {
            val bytes = ByteArray(32)
            SecureRandom().nextBytes(bytes)
            return toHex(bytes)
        }

        private fun pbkdf2HmacSha256(
            password: ByteArray,
            salt: ByteArray,
            iterations: Int,
            keyLenBytes: Int
        ): ByteArray {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(password, "HmacSHA256"))
            val hashLen = mac.macLength
            val blocks = (keyLenBytes + hashLen - 1) / hashLen
            val output = ByteArray(blocks * hashLen)
            var offset = 0
            for (blockIndex in 1..blocks) {
                val intBlock = byteArrayOf(
                    (blockIndex ushr 24).toByte(),
                    (blockIndex ushr 16).toByte(),
                    (blockIndex ushr 8).toByte(),
                    blockIndex.toByte()
                )
                mac.reset()
                mac.update(salt)
                var u = mac.doFinal(intBlock)
                val t = u.copyOf()
                for (iter in 2..iterations) {
                    mac.reset()
                    u = mac.doFinal(u)
                    for (j in t.indices) {
                        t[j] = (t[j].toInt() xor u[j].toInt()).toByte()
                    }
                }
                System.arraycopy(t, 0, output, offset, hashLen)
                offset += hashLen
            }
            return output.copyOf(keyLenBytes)
        }

        private fun toHex(bytes: ByteArray): String =
            bytes.joinToString("") { "%02x".format(it) }

        private fun fromHex(hex: String): ByteArray? {
            if (hex.length % 2 != 0) return null
            return try {
                ByteArray(hex.length / 2) { i ->
                    hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
                }
            } catch (_: Exception) {
                null
            }
        }
    }

    private val schemaMutex = Mutex()
    @Volatile
    private var schemaReady = false

    private suspend fun ensureSchema() {
        if (schemaReady) return
        schemaMutex.withLock {
            if (schemaReady) return
            executeBatch(
                listOf(
                    """CREATE TABLE IF NOT EXISTS subscribers (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        full_name TEXT NOT NULL,
                        office_name TEXT NOT NULL DEFAULT '',
                        phone TEXT NOT NULL UNIQUE,
                        password_hash TEXT NOT NULL,
                        is_active INTEGER NOT NULL DEFAULT 1,
                        expires_at INTEGER,
                        notes TEXT NOT NULL DEFAULT '',
                        created_at INTEGER NOT NULL
                    )""".trimIndent() to emptyList(),
                    """CREATE TABLE IF NOT EXISTS app_admin_config (
                        config_key TEXT PRIMARY KEY,
                        config_value TEXT NOT NULL,
                        updated_at INTEGER NOT NULL
                    )""".trimIndent() to emptyList(),
                    """CREATE TABLE IF NOT EXISTS subscriber_sessions (
                        token_hash TEXT PRIMARY KEY,
                        subscriber_id INTEGER NOT NULL,
                        expires_at INTEGER NOT NULL,
                        created_at INTEGER NOT NULL
                    )""".trimIndent() to emptyList(),
                    """CREATE TABLE IF NOT EXISTS admin_sessions (
                        token_hash TEXT PRIMARY KEY,
                        expires_at INTEGER NOT NULL,
                        created_at INTEGER NOT NULL
                    )""".trimIndent() to emptyList()
                )
            )
            schemaReady = true
        }
    }

    private suspend fun query(sql: String, args: List<JSONObject> = emptyList()): TursoQueryResult {
        return executeBatch(listOf(sql to args)).first()
    }

    private suspend fun executeBatch(
        statements: List<Pair<String, List<JSONObject>>>
    ): List<TursoQueryResult> {
        val pipelineUrl = TursoConfig.toTursoPipelineUrl(TursoConfig.rawTursoUrl)
            ?: throw DirectTursoException(503, "يرجى إضافة TURSO_DATABASE_URL في لوحة Secrets.")
        val authToken = TursoConfig.cleanSecret(TursoConfig.rawTursoToken)
        if (authToken.isBlank() || authToken == TursoConfig.PLACEHOLDER_TOKEN) {
            throw DirectTursoException(503, "يرجى إضافة TURSO_AUTH_TOKEN في لوحة Secrets.")
        }

        val requestsArr = JSONArray()
        for ((sql, args) in statements) {
            val stmtObj = JSONObject()
                .put("sql", sql)
                .put("args", JSONArray(args))
            requestsArr.put(
                JSONObject()
                    .put("type", "execute")
                    .put("stmt", stmtObj)
            )
        }
        requestsArr.put(JSONObject().put("type", "close"))
        val payload = JSONObject().put("requests", requestsArr).toString()

        return withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(pipelineUrl)
                .addHeader("Authorization", "Bearer $authToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toRequestBody(JSON_MEDIA_TYPE))
                .build()

            val response = try {
                httpClient.newCall(request).execute()
            } catch (e: Exception) {
                throw DirectTursoException(
                    502,
                    "تعذر الوصول إلى قاعدة بيانات Turso: ${e.localizedMessage ?: "تحقق من الإنترنت والرابط"}"
                )
            }

            response.use { resp ->
                val bodyStr = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    val msg = when (resp.code) {
                        401 -> "رفض توكن Turso (401): تأكد من صحة TURSO_AUTH_TOKEN في لوحة Secrets."
                        403 -> "صلاحيات التوكن غير كافية (403): يجب أن يكون التوكن بصلاحية Read & Write."
                        404 -> "قاعدة بيانات Turso غير موجودة (404): تأكد من صحة TURSO_DATABASE_URL."
                        else -> "خطأ اتصال بقاعدة Turso (رمز ${resp.code})"
                    }
                    throw DirectTursoException(resp.code, msg)
                }

                val root = JSONObject(bodyStr)
                val resultsArr = root.optJSONArray("results")
                    ?: throw DirectTursoException(502, "استجابة غير متوقعة من قاعدة بيانات Turso")
                if (resultsArr.length() < statements.size) {
                    throw DirectTursoException(502, "استجابة ناقصة من قاعدة بيانات Turso")
                }

                val out = ArrayList<TursoQueryResult>(statements.size)
                for (i in 0 until statements.size) {
                    val item = resultsArr.getJSONObject(i)
                    if (item.optString("type") == "error") {
                        val errMsg = item.optJSONObject("error")?.optString("message").orEmpty()
                        if (errMsg.contains("UNIQUE", ignoreCase = true)) {
                            throw DirectTursoException(409, "رقم الهاتف مسجل مسبقاً لمشترك آخر")
                        }
                        if (errMsg.contains("readonly", ignoreCase = true)) {
                            throw DirectTursoException(403, "التوكن المستخدم للقراءة فقط، يرجى استخدام توكن Read & Write.")
                        }
                        throw DirectTursoException(500, errMsg.ifBlank { "خطأ في تنفيذ استعلام Turso" })
                    }

                    val resObj = item.optJSONObject("response")?.optJSONObject("result") ?: JSONObject()
                    val colsArr = resObj.optJSONArray("cols") ?: JSONArray()
                    val colNames = List(colsArr.length()) { idx ->
                        colsArr.optJSONObject(idx)?.optString("name").orEmpty().ifBlank { "col_$idx" }
                    }

                    val rowsArr = resObj.optJSONArray("rows") ?: JSONArray()
                    val parsedRows = ArrayList<Map<String, String?>>(rowsArr.length())
                    for (rIdx in 0 until rowsArr.length()) {
                        val rowCells = rowsArr.getJSONArray(rIdx)
                        val rowMap = HashMap<String, String?>(colNames.size)
                        for (cIdx in colNames.indices) {
                            val cell = rowCells.optJSONObject(cIdx)
                            val cellType = cell?.optString("type").orEmpty()
                            rowMap[colNames[cIdx]] = if (cell == null || cellType == "null" || cell.isNull("value")) {
                                null
                            } else {
                                cell.opt("value")?.toString()
                            }
                        }
                        parsedRows.add(rowMap)
                    }

                    val affected = resObj.optInt("affected_row_count", 0)
                    val lastId = resObj.optString("last_insert_rowid", "").toLongOrNull()
                    out.add(TursoQueryResult(parsedRows, affected, lastId))
                }
                out
            }
        }
    }

    private fun rowToSubscriber(row: Map<String, String?>): SubscriberAccount? {
        val id = row["id"]?.toLongOrNull() ?: return null
        val phone = row["phone"].orEmpty()
        if (phone.isBlank()) return null
        return SubscriberAccount(
            id = id,
            fullName = row["full_name"].orEmpty(),
            officeName = row["office_name"].orEmpty(),
            phone = phone,
            isActive = (row["is_active"]?.toIntOrNull() ?: 0) == 1,
            expiresAt = row["expires_at"]?.toLongOrNull()?.takeIf { it > 0L },
            notes = row["notes"].orEmpty(),
            createdAt = row["created_at"]?.toLongOrNull() ?: 0L
        )
    }

    suspend fun authenticateSubscriber(phone: String, password: String): SubscriberAuthOutcome {
        return try {
            ensureSchema()
            val res = query(
                """SELECT id, full_name, office_name, phone, password_hash, is_active, expires_at, notes, created_at
                   FROM subscribers WHERE phone = ? LIMIT 1""".trimIndent(),
                listOf(argText(phone))
            )
            val row = res.rows.firstOrNull()
                ?: return SubscriberAuthOutcome.Rejected("رقم الهاتف أو كلمة المرور غير صحيحة")
            val storedHash = row["password_hash"].orEmpty()
            if (!verifyPassword(password, storedHash)) {
                return SubscriberAuthOutcome.Rejected("رقم الهاتف أو كلمة المرور غير صحيحة")
            }
            val sub = rowToSubscriber(row)
                ?: return SubscriberAuthOutcome.NetworkOrConfigError("بيانات المشترك غير مكتملة")
            if (!sub.isActive) {
                return SubscriberAuthOutcome.Rejected("تم إيقاف هذا الاشتراك من قِبل الإدارة")
            }
            val now = System.currentTimeMillis()
            if (sub.isExpired(now)) {
                return SubscriberAuthOutcome.Rejected("انتهت صلاحية الاشتراك، يرجى التواصل مع الإدارة لتجديده")
            }

            val rawToken = generateRandomToken()
            val tokenHash = sha256Hex(rawToken)
            val sessionExp = if (sub.expiresAt != null && sub.expiresAt > 0L) {
                minOf(sub.expiresAt, now + SUBSCRIBER_SESSION_TTL_MS)
            } else {
                now + SUBSCRIBER_SESSION_TTL_MS
            }
            query(
                "INSERT INTO subscriber_sessions (token_hash, subscriber_id, expires_at, created_at) VALUES (?, ?, ?, ?)",
                listOf(argText(tokenHash), argInt(sub.id), argInt(sessionExp), argInt(now))
            )
            SubscriberAuthOutcome.Success(sub, rawToken)
        } catch (e: DirectTursoException) {
            SubscriberAuthOutcome.NetworkOrConfigError(e.message)
        } catch (e: Exception) {
            SubscriberAuthOutcome.NetworkOrConfigError(e.localizedMessage ?: "تعذر الاتصال بقاعدة البيانات")
        }
    }

    suspend fun verifySubscriberSession(sessionToken: String): SubscriberAuthOutcome {
        return try {
            ensureSchema()
            val tokenHash = sha256Hex(sessionToken)
            val res = query(
                """SELECT s.id, s.full_name, s.office_name, s.phone, s.is_active, s.expires_at, s.notes, s.created_at,
                          ss.expires_at AS session_expires_at
                   FROM subscriber_sessions ss
                   INNER JOIN subscribers s ON s.id = ss.subscriber_id
                   WHERE ss.token_hash = ? LIMIT 1""".trimIndent(),
                listOf(argText(tokenHash))
            )
            val row = res.rows.firstOrNull()
                ?: return SubscriberAuthOutcome.Rejected("لم يعد هذا الحساب متاحاً، يرجى تسجيل الدخول مجدداً")
            val now = System.currentTimeMillis()
            val sessionExp = row["session_expires_at"]?.toLongOrNull() ?: 0L
            if (sessionExp > 0L && now > sessionExp) {
                query("DELETE FROM subscriber_sessions WHERE token_hash = ?", listOf(argText(tokenHash)))
                return SubscriberAuthOutcome.Rejected("انتهت الجلسة، يرجى تسجيل الدخول مجدداً")
            }
            val sub = rowToSubscriber(row)
                ?: return SubscriberAuthOutcome.NetworkOrConfigError("بيانات الاشتراك غير صالحة")
            if (!sub.isActive) {
                return SubscriberAuthOutcome.Rejected("تم إيقاف اشتراكك من قِبل الإدارة")
            }
            if (sub.isExpired(now)) {
                return SubscriberAuthOutcome.Rejected("انتهت صلاحية اشتراكك، يرجى التواصل مع الإدارة لتجديده")
            }
            SubscriberAuthOutcome.Success(sub, sessionToken)
        } catch (e: DirectTursoException) {
            SubscriberAuthOutcome.NetworkOrConfigError(e.message)
        } catch (e: Exception) {
            SubscriberAuthOutcome.NetworkOrConfigError(e.localizedMessage ?: "تعذر التحقق من الجلسة")
        }
    }

    suspend fun logoutSubscriber(sessionToken: String): Result<Unit> = runCatching {
        ensureSchema()
        query("DELETE FROM subscriber_sessions WHERE token_hash = ?", listOf(argText(sha256Hex(sessionToken))))
        Unit
    }

    private suspend fun getAdminPasswordHash(): String? {
        val res = query(
            "SELECT config_value FROM app_admin_config WHERE config_key = ? LIMIT 1",
            listOf(argText(ADMIN_PASSWORD_KEY))
        )
        return res.rows.firstOrNull()?.get("config_value")?.takeIf { it.isNotBlank() }
    }

    private suspend fun issueAdminSession(): String {
        val rawToken = generateRandomToken()
        val now = System.currentTimeMillis()
        query(
            "INSERT INTO admin_sessions (token_hash, expires_at, created_at) VALUES (?, ?, ?)",
            listOf(argText(sha256Hex(rawToken)), argInt(now + ADMIN_SESSION_TTL_MS), argInt(now))
        )
        return rawToken
    }

    private suspend fun requireAdminToken(adminToken: String) {
        if (adminToken.isBlank()) throw ProxyUnauthorizedException("انتهت جلسة الإدارة، يرجى إعادة الدخول")
        val tokenHash = sha256Hex(adminToken)
        val res = query(
            "SELECT expires_at FROM admin_sessions WHERE token_hash = ? LIMIT 1",
            listOf(argText(tokenHash))
        )
        val row = res.rows.firstOrNull()
            ?: throw ProxyUnauthorizedException("انتهت جلسة الإدارة أو رمز الدخول غير صالح")
        val expiresAt = row["expires_at"]?.toLongOrNull() ?: 0L
        if (System.currentTimeMillis() > expiresAt) {
            query("DELETE FROM admin_sessions WHERE token_hash = ?", listOf(argText(tokenHash)))
            throw ProxyUnauthorizedException("انتهت جلسة الإدارة، يرجى إعادة الدخول")
        }
    }

    suspend fun fetchAdminStatus(): Result<Boolean> = runCatching {
        ensureSchema()
        getAdminPasswordHash() != null
    }

    suspend fun setupAdminPassword(password: String): Result<String> = runCatching {
        if (password.length < 4) throw IllegalArgumentException("كلمة المرور يجب أن تكون 4 أحرف على الأقل")
        ensureSchema()
        if (getAdminPasswordHash() != null) {
            throw IllegalStateException("تم تعيين كلمة مرور الإدارة مسبقاً")
        }
        val hash = hashPassword(password)
        val res = query(
            """INSERT INTO app_admin_config (config_key, config_value, updated_at)
               VALUES (?, ?, ?) ON CONFLICT(config_key) DO NOTHING""".trimIndent(),
            listOf(argText(ADMIN_PASSWORD_KEY), argText(hash), argInt(System.currentTimeMillis()))
        )
        if (res.affectedRows != 1) {
            throw IllegalStateException("تم تعيين كلمة مرور الإدارة مسبقاً")
        }
        issueAdminSession()
    }

    suspend fun loginAdmin(password: String): Result<String> = runCatching {
        if (password.isBlank()) throw IllegalArgumentException("يرجى إدخال كلمة مرور الإدارة")
        ensureSchema()
        val storedHash = getAdminPasswordHash()
            ?: throw IllegalStateException("لم يتم إعداد كلمة مرور الإدارة بعد")
        if (!verifyPassword(password, storedHash)) {
            throw IllegalArgumentException("كلمة مرور الإدارة غير صحيحة")
        }
        issueAdminSession()
    }

    suspend fun changeAdminPassword(
        adminToken: String,
        currentPassword: String,
        newPassword: String
    ): Result<Unit> = runCatching {
        if (newPassword.length < 4) throw IllegalArgumentException("كلمة المرور الجديدة يجب أن تكون 4 أحرف على الأقل")
        ensureSchema()
        requireAdminToken(adminToken)
        val storedHash = getAdminPasswordHash()
        if (storedHash == null || !verifyPassword(currentPassword, storedHash)) {
            throw IllegalArgumentException("كلمة المرور الحالية غير صحيحة")
        }
        val nextHash = hashPassword(newPassword)
        query(
            """INSERT INTO app_admin_config (config_key, config_value, updated_at)
               VALUES (?, ?, ?)
               ON CONFLICT(config_key) DO UPDATE SET
                 config_value = excluded.config_value,
                 updated_at = excluded.updated_at""".trimIndent(),
            listOf(argText(ADMIN_PASSWORD_KEY), argText(nextHash), argInt(System.currentTimeMillis()))
        )
        Unit
    }

    suspend fun listSubscribers(adminToken: String): Result<List<SubscriberAccount>> = runCatching {
        ensureSchema()
        requireAdminToken(adminToken)
        val res = query(
            "SELECT id, full_name, office_name, phone, is_active, expires_at, notes, created_at FROM subscribers ORDER BY id DESC"
        )
        res.rows.mapNotNull { rowToSubscriber(it) }
    }

    suspend fun createSubscriber(
        adminToken: String,
        fullName: String,
        officeName: String,
        phone: String,
        password: String,
        durationDays: Int?,
        notes: String
    ): Result<SubscriberAccount> = runCatching {
        ensureSchema()
        requireAdminToken(adminToken)
        val now = System.currentTimeMillis()
        val expiresAt = durationDays?.takeIf { it > 0 }?.let { now + it.toLong() * 86400000L }
        val passwordHash = hashPassword(password)
        val res = query(
            """INSERT INTO subscribers (full_name, office_name, phone, password_hash, is_active, expires_at, notes, created_at)
               VALUES (?, ?, ?, ?, 1, ?, ?, ?)""".trimIndent(),
            listOf(
                argText(fullName.trim()),
                argText(officeName.trim()),
                argText(phone),
                argText(passwordHash),
                expiresAt?.let { argInt(it) } ?: argNull(),
                argText(notes.trim()),
                argInt(now)
            )
        )
        SubscriberAccount(
            id = res.lastInsertRowId ?: 0L,
            fullName = fullName.trim(),
            officeName = officeName.trim(),
            phone = phone,
            isActive = true,
            expiresAt = expiresAt,
            notes = notes.trim(),
            createdAt = now
        )
    }

    suspend fun updateSubscriberActive(adminToken: String, id: Long, isActive: Boolean): Result<Unit> = runCatching {
        ensureSchema()
        requireAdminToken(adminToken)
        query("UPDATE subscribers SET is_active = ? WHERE id = ?", listOf(argInt(if (isActive) 1L else 0L), argInt(id)))
        if (!isActive) {
            query("DELETE FROM subscriber_sessions WHERE subscriber_id = ?", listOf(argInt(id)))
        }
        Unit
    }

    suspend fun extendSubscriber(adminToken: String, id: Long, durationDays: Int?): Result<Long?> = runCatching {
        ensureSchema()
        requireAdminToken(adminToken)
        val curRes = query("SELECT expires_at FROM subscribers WHERE id = ? LIMIT 1", listOf(argInt(id)))
        val row = curRes.rows.firstOrNull() ?: throw IllegalStateException("المشترك غير موجود")
        val now = System.currentTimeMillis()
        val currentExp = row["expires_at"]?.toLongOrNull() ?: 0L
        val newExpiresAt = durationDays?.takeIf { it > 0 }?.let {
            maxOf(now, currentExp) + it.toLong() * 86400000L
        }
        query(
            "UPDATE subscribers SET expires_at = ?, is_active = 1 WHERE id = ?",
            listOf(newExpiresAt?.let { argInt(it) } ?: argNull(), argInt(id))
        )
        newExpiresAt
    }

    suspend fun resetSubscriberPassword(adminToken: String, id: Long, newPassword: String): Result<Unit> = runCatching {
        ensureSchema()
        requireAdminToken(adminToken)
        val hash = hashPassword(newPassword)
        query("UPDATE subscribers SET password_hash = ? WHERE id = ?", listOf(argText(hash), argInt(id)))
        query("DELETE FROM subscriber_sessions WHERE subscriber_id = ?", listOf(argInt(id)))
        Unit
    }

    suspend fun deleteSubscriber(adminToken: String, id: Long): Result<Unit> = runCatching {
        ensureSchema()
        requireAdminToken(adminToken)
        query("DELETE FROM subscriber_sessions WHERE subscriber_id = ?", listOf(argInt(id)))
        query("DELETE FROM subscribers WHERE id = ?", listOf(argInt(id)))
        Unit
    }
}
