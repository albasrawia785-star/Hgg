package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/**
 * RentalContractRenderer: محرك رسم عقد إيجار العقارات والدور والمحلات
 * تصميم عراقي رسمي كلاسيكي موحد مع خط أميري/نسخ، جداول حادة، بصمة الإبهام، وختم المكتب.
 */
class RentalContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? RentalContract ?: RentalContract()
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale

        val extraLbl = when {
            data.sequenceNumber.isNotBlank() -> "التسلسل"
            data.doorsNumber.isNotBlank() -> "رقم الأبواب"
            else -> ""
        }
        val extraVal = when {
            data.sequenceNumber.isNotBlank() -> data.sequenceNumber
            data.doorsNumber.isNotBlank() -> data.doorsNumber
            else -> ""
        }

        // ==================== 1. الترويسة العراقية الرسمية ====================
        var curY = drawIraqiOfficialHeader(
            canvas = canvas,
            officeInfo = officeInfo,
            defaultOfficeName = "مكتب الدلالية للعقارات",
            specialtyText = "لتأجير العقارات والدور السكنية والمحلات التجارية",
            contractTitle = "عقد إيجار عقار",
            contractSubtitle = "عقد إيجار رسمي بالتراضي",
            contractNo = data.contractNo.ifBlank { "0001" },
            contractDate = data.signDate,
            extraMetaLabel = extraLbl,
            extraMetaValue = extraVal
        )

        // ==================== 2. شريط المقدمة الإقرارية ====================
        val seqText = if (data.sequenceNumber.isNotBlank()) "التسلسل: ${data.sequenceNumber}" else ""
        val doorText = if (data.doorsNumber.isNotBlank()) "أبواب رقم: ${data.doorsNumber}" else ""
        val barDesc = listOf(seqText, doorText).filter { it.isNotBlank() }.joinToString("  |  ")
        val introText = if (barDesc.isNotBlank()) {
            "عقد إيجار رسمي ($barDesc) — تم الاتفاق بالتراضي التام بين المؤجر والمستأجر على ما يلي:"
        } else {
            "تم الاتفاق بالتراضي التام بين الطرفين المؤجر والمستأجر على إيجار العين المبينة أدناه بالشروط الآتية:"
        }

        val introBarH = 34f
        val introRect = RectF(contentLeft, curY, contentRight, curY + introBarH)
        val barTopRule = Paint().apply {
            color = tintColor(primary, 100)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
            isAntiAlias = true
        }
        val barBottomRule = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.3f
            isAntiAlias = true
        }
        canvas.drawLine(introRect.left, introRect.top, introRect.right, introRect.top, barTopRule)
        canvas.drawLine(introRect.left, introRect.bottom, introRect.right, introRect.bottom, barBottomRule)

        val introPaint = Paint().apply {
            color = primary
            textSize = 15.5f * scale
            typeface = bodyTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        fitTextToWidth(introPaint, introText, introRect.width() - 20f, 12f)
        drawCenteredSingleLine(canvas, introText, introRect.centerX(), introRect.centerY(), introPaint)

        curY = introRect.bottom + 12f

        // ==================== 3. جدول الطرفين ====================
        curY = drawFormalPartiesTable(
            canvas = canvas,
            topY = curY,
            rightTitle = "الطرف الأول (المؤجر)",
            leftTitle = "الطرف الثاني (المستأجر)",
            rightFields = listOf(
                "المؤجر السيد:" to data.lessorName,
                "العنوان والواقع:" to data.propertyLocation,
                "المحلة:" to data.neighborhood,
                "زقاق / دار:" to data.alleyNumber
            ),
            leftFields = listOf(
                "المستأجر السيد:" to data.lesseeName,
                "حق السكن والصفة:" to data.dwellingRightDetails,
                "مدة الإيجار:" to data.leaseDuration,
                "العائد للمستأجر:" to data.returnToLesseeText
            )
        )

        // ==================== 4. جدول مواصفات العين المؤجرة ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "أولاً: إيجار منفعة العين المؤجرة بالخواص والمواصفات الآتية:",
            topY = curY
        )

        curY += 8f
        val gridH = 96f
        val gridRect = RectF(contentLeft, curY, contentRight, curY + gridH)
        val gridOuter = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val gridInner = Paint().apply {
            color = tintColor(primary, 155)
            style = Paint.Style.STROKE
            strokeWidth = 0.9f
            isAntiAlias = true
        }
        canvas.drawRect(gridRect, gridOuter)
        val rowH = gridH / 2f
        val midX = gridRect.centerX()
        canvas.drawLine(gridRect.left, gridRect.top + rowH, gridRect.right, gridRect.top + rowH, gridInner)
        canvas.drawLine(midX, gridRect.top, midX, gridRect.bottom, gridInner)

        val cellW = (gridRect.width() / 2f) - 24f
        val locStr = listOf(data.propertyLocation, data.neighborhood).filter { it.isNotBlank() }.joinToString(" - ")
        val periodStr = listOfNotNull(
            data.startDate.takeIf { it.isNotBlank() }?.let { "من $it" },
            data.endDate.takeIf { it.isNotBlank() }?.let { "إلى $it" }
        ).joinToString(" ")

        drawFieldWithDots(canvas, "العين المؤجرة:", data.rentedPropertyDescription, gridRect.right - 12f, gridRect.top + 31f, cellW)
        drawFieldWithDots(canvas, "الموقع والمحلة:", locStr, midX - 12f, gridRect.top + 31f, cellW)
        drawFieldWithDots(canvas, "مدة الإيجار:", data.leaseDuration, gridRect.right - 12f, gridRect.top + rowH + 31f, cellW)
        drawFieldWithDots(canvas, "الفترة الزمنية:", periodStr, midX - 12f, gridRect.top + rowH + 31f, cellW)

        curY = gridRect.bottom + 12f

        // ==================== 5. المبالغ المالية ====================
        val fmtRent = FormatUtils.formatMoneyInput(data.rentAmountNumber)
        val rentDisp = if (fmtRent.isNotBlank()) "$fmtRent دينار" else data.rentAmountNumber
        val rentWords = data.rentAmountWords.trim().ifBlank { FormatUtils.convertNumberToArabicWords(data.rentAmountNumber) }

        val fmtDelay = FormatUtils.formatMoneyInput(data.dailyDelayFee)
        val delayWords = FormatUtils.convertNumberToArabicWords(data.dailyDelayFee)
        val delayDisp = when {
            fmtDelay.isNotBlank() -> "$fmtDelay دينار"
            data.dailyDelayFee.isNotBlank() -> "${data.dailyDelayFee} دينار"
            else -> "حسب الاتفاق"
        }

        curY = drawFinancialSummaryTableWithWords(
            canvas = canvas,
            topY = curY,
            items = listOf(
                FinancialBoxItem("بدل الإيجار الشهري (رقماً)", rentDisp, rentWords, dark),
                FinancialBoxItem("غرامة التأخير اليومية", delayDisp, delayWords, primary),
                FinancialBoxItem("ضريبة الأملاك على", data.propertyTaxOwner.ifBlank { "المؤجر" }, "", COLOR_RED_ACCENT)
            ),
            wordsRowLabel = "بدل الإيجار (كتابةً):",
            wordsRowValue = rentWords
        )

        // ==================== 6. البنود والشروط القانونية ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "ثانياً: الشروط القانونية والتزامات المؤجر والمستأجر",
            topY = curY
        )

        curY += 10f
        val delayFeeClause = when {
            delayWords.isNotBlank() -> "غرامة يومية قدرها ($delayDisp - $delayWords)"
            data.dailyDelayFee.isNotBlank() -> "غرامة يومية قدرها ($delayDisp)"
            else -> "غرامة يومية متفق عليها"
        }
        val taxOwnerText = data.propertyTaxOwner.ifBlank { "المؤجر" }

        val clauses = listOf(
            "١- التخلية والتسليم" to "عند انتهاء مدة الإيجار المحددة، يلتزم الطرف الثاني (المستأجر) بتخلية المأجور وتسليمه إلى المؤجر خالياً من الشواغل وبحالة جيدة.",
            "٢- غرامة التأخير" to "إذا تأخر المستأجر عن التخلية بعد انتهاء المدة يكون ملزماً بدفع $delayFeeClause عن كل يوم تأخير من غير إنذار.",
            "٣- الضرائب والخدمات" to "تقع ضريبة الأملاك على ($taxOwnerText)، أما أجور الماء والكهرباء والخدمات والتنظيفات فيلتزم المستأجر بدفعها بانتظام طيلة مدة الإيجار.",
            "٤- حق السكن والمحافظة" to "للمستأجر حق السكن والانتفاع بالمأجور طيلة مدة الإيجار المتفق عليها مع التعهد بالمحافظة على العين المؤجرة وعدم إجراء أي تغيير جوهري دون موافقة تحريرية.",
            "٥- نسخ العقد" to "حرر هذا العقد على نسختين بيد كل من الطرفين نسخة واحدة للعمل بموجبها بعد التوقيع."
        )

        curY = drawIraqiLegalClauses(
            canvas = canvas,
            clauses = clauses,
            startY = curY,
            maxBottomY = footerTopY - 120f
        )

        val dateP = Paint().apply {
            color = primary
            textSize = 15.5f * scale
            typeface = bodyTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val dateY = (curY + 14f).coerceAtMost(footerTopY - 88f)
        canvas.drawText("حرر بالتراضي بتاريخ: ${data.signDate}", contentRight, dateY, dateP)

        drawAdditionalNotesBlock(
            canvas = canvas,
            notes = data.additionalClauses,
            startY = dateY + 12f
        )

        // ==================== 7. التواقيع والشهود ====================
        drawIraqiSignaturesFooter(
            canvas = canvas,
            party1Title = "الطرف الأول/المؤجر",
            party2Title = "الطرف الثاني/المستأجر",
            witness1Name = data.witness1Name,
            witness2Name = data.witness2Name
        )
    }
}
