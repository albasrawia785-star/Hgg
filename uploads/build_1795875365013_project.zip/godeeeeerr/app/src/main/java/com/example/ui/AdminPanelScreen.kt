package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.FormatUtils
import com.example.SubscriberAccount
import com.example.SubscriptionDurationOption
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AdminPanelUiState(
    val isCheckingSetup: Boolean = false,
    val statusCheckFailed: Boolean = false,
    val hasAdminPasscodeSet: Boolean = false,
    val isAdminUnlocked: Boolean = false,
    val isAuthenticating: Boolean = false,
    val authError: String? = null,
    val isTursoConfigured: Boolean = false,
    val isLoadingSubscribers: Boolean = false,
    val isProcessingAction: Boolean = false,
    val subscribers: List<SubscriberAccount> = emptyList(),
    val actionError: String? = null,
    val actionSuccess: String? = null
)

/**
 * لوحة الإدارة المخفية (تُفتح بالضغط 10 مرات على شعار التطبيق)
 * محمية بكلمة مرور مجزأة بـ PBKDF2 وتُدار عبر قاعدة بيانات Turso
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    uiState: AdminPanelUiState,
    onRetryStatusCheck: () -> Unit,
    onSetupAdminPassword: (password: String, confirmPassword: String) -> Unit,
    onUnlockAdmin: (password: String) -> Unit,
    onChangeAdminPassword: (currentPassword: String, newPassword: String, confirmPassword: String) -> Unit,
    onRefreshSubscribers: () -> Unit,
    onAddSubscriber: (
        fullName: String,
        officeName: String,
        phone: String,
        password: String,
        durationDays: Int?,
        notes: String
    ) -> Unit,
    onToggleActive: (SubscriberAccount) -> Unit,
    onExtendSubscriber: (SubscriberAccount, Int?) -> Unit,
    onResetPassword: (SubscriberAccount, String) -> Unit,
    onDeleteSubscriber: (SubscriberAccount) -> Unit,
    onClearMessages: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val navyBrand = Color(0xFF091E42)
    val primaryBlue = Color(0xFF1E65FF)
    val pageBg = Color(0xFFF7F9FC)

    var showAddDialog by remember { mutableStateOf(false) }
    var showChangeAdminPassDialog by remember { mutableStateOf(false) }
    var extendTarget by remember { mutableStateOf<SubscriberAccount?>(null) }
    var resetPassTarget by remember { mutableStateOf<SubscriberAccount?>(null) }
    var deleteTarget by remember { mutableStateOf<SubscriberAccount?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "لوحة إدارة المشتركين",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("admin_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    if (uiState.isAdminUnlocked) {
                        IconButton(
                            onClick = { showChangeAdminPassDialog = true },
                            modifier = Modifier.testTag("admin_change_passcode_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = "تغيير كلمة مرور الإدارة",
                                tint = Color.White
                            )
                        }
                        IconButton(
                            onClick = onRefreshSubscribers,
                            enabled = !uiState.isLoadingSubscribers,
                            modifier = Modifier.testTag("admin_refresh_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث القائمة",
                                tint = Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = navyBrand)
            )
        },
        floatingActionButton = {
            if (uiState.isAdminUnlocked && uiState.isTursoConfigured) {
                ExtendedFloatingActionButton(
                    onClick = {
                        onClearMessages()
                        showAddDialog = true
                    },
                    containerColor = primaryBlue,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                    text = { Text("إضافة مشترك", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("btn_add_subscriber")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(pageBg)
                .padding(innerPadding)
        ) {
            when {
                uiState.isCheckingSetup -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = primaryBlue)
                        Text("جاري فحص إعدادات لوحة الإدارة...", fontSize = 14.sp, color = Color(0xFF475569))
                    }
                }

                !uiState.isAdminUnlocked -> {
                    AdminPasscodeGate(
                        statusCheckFailed = uiState.statusCheckFailed,
                        hasAdminPasscodeSet = uiState.hasAdminPasscodeSet,
                        isAuthenticating = uiState.isAuthenticating,
                        authError = uiState.authError,
                        isTursoConfigured = uiState.isTursoConfigured,
                        onRetryStatusCheck = onRetryStatusCheck,
                        onSetupPassword = onSetupAdminPassword,
                        onUnlock = onUnlockAdmin
                    )
                }

                else -> {
                    val filteredSubscribers = remember(uiState.subscribers, searchQuery) {
                        val q = FormatUtils.toWesternDigits(searchQuery.trim()).lowercase()
                        if (q.isBlank()) {
                            uiState.subscribers
                        } else {
                            uiState.subscribers.filter { sub ->
                                sub.fullName.lowercase().contains(q) ||
                                    sub.officeName.lowercase().contains(q) ||
                                    sub.phone.lowercase().contains(q)
                            }
                        }
                    }

                    val activeCount = remember(uiState.subscribers) {
                        uiState.subscribers.count { it.isValidForLogin() }
                    }
                    val inactiveOrExpiredCount = uiState.subscribers.size - activeCount

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 88.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (!uiState.isTursoConfigured) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFFFEF3C7),
                                    border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFFB45309))
                                        Text(
                                            text = "قاعدة بيانات Turso غير مربوطة بعد. أضف TURSO_DATABASE_URL و TURSO_AUTH_TOKEN في لوحة Secrets.",
                                            fontSize = 13.sp,
                                            color = Color(0xFF78350F)
                                        )
                                    }
                                }
                            }
                        }

                        if (!uiState.actionError.isNullOrBlank()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFFEE2E2),
                                    border = BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFDC2626))
                                            Text(uiState.actionError, fontSize = 13.sp, color = Color(0xFF991B1B))
                                        }
                                        IconButton(onClick = onClearMessages) {
                                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFF991B1B))
                                        }
                                    }
                                }
                            }
                        }

                        if (!uiState.actionSuccess.isNullOrBlank()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFD1FAE5),
                                    border = BorderStroke(1.dp, Color(0xFF059669).copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669))
                                            Text(uiState.actionSuccess, fontSize = 13.sp, color = Color(0xFF065F46))
                                        }
                                        IconButton(onClick = onClearMessages) {
                                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFF065F46))
                                        }
                                    }
                                }
                            }
                        }

                        // بطاقات الإحصائيات
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                AdminStatCard(
                                    label = "الكل",
                                    count = uiState.subscribers.size,
                                    accentColor = navyBrand,
                                    modifier = Modifier.weight(1f)
                                )
                                AdminStatCard(
                                    label = "النشطون",
                                    count = activeCount,
                                    accentColor = Color(0xFF059669),
                                    modifier = Modifier.weight(1f)
                                )
                                AdminStatCard(
                                    label = "موقوف/منتهي",
                                    count = inactiveOrExpiredCount,
                                    accentColor = Color(0xFFDC2626),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        // حقل البحث
                        item {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                label = { Text("بحث بالاسم أو المكتب أو الهاتف") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(Icons.Default.Clear, contentDescription = "مسح البحث")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("admin_search_input")
                            )
                        }

                        if (uiState.isLoadingSubscribers) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(color = primaryBlue)
                                }
                            }
                        } else if (filteredSubscribers.isEmpty()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(28.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PeopleOutline,
                                            contentDescription = null,
                                            tint = Color(0xFF94A3B8),
                                            modifier = Modifier.size(40.dp)
                                        )
                                        Text(
                                            text = if (searchQuery.isBlank()) "لا يوجد مشتركون مسجلون بعد" else "لا توجد نتائج مطابقة للبحث",
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF334155)
                                        )
                                        Text(
                                            text = "اضغط على زر (إضافة مشترك) لتفعيل اشتراك جديد.",
                                            fontSize = 12.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }
                            }
                        } else {
                            items(filteredSubscribers, key = { it.id }) { subscriber ->
                                SubscriberCard(
                                    subscriber = subscriber,
                                    isBusy = uiState.isProcessingAction,
                                    onToggleActive = { onToggleActive(subscriber) },
                                    onExtend = { extendTarget = subscriber },
                                    onResetPassword = { resetPassTarget = subscriber },
                                    onDelete = { deleteTarget = subscriber }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddSubscriberDialog(
            isProcessing = uiState.isProcessingAction,
            onDismiss = { showAddDialog = false },
            onConfirm = { fullName, officeName, phone, password, durationDays, notes ->
                onAddSubscriber(fullName, officeName, phone, password, durationDays, notes)
                showAddDialog = false
            }
        )
    }

    extendTarget?.let { target ->
        ExtendSubscriptionDialog(
            subscriber = target,
            onDismiss = { extendTarget = null },
            onSelectDuration = { days ->
                onExtendSubscriber(target, days)
                extendTarget = null
            }
        )
    }

    resetPassTarget?.let { target ->
        ResetSubscriberPasswordDialog(
            subscriber = target,
            onDismiss = { resetPassTarget = null },
            onConfirm = { newPass ->
                onResetPassword(target, newPass)
                resetPassTarget = null
            }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            icon = {
                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            },
            title = { Text("حذف المشترك", fontWeight = FontWeight.Bold) },
            text = {
                Text("هل أنت متأكد من حذف اشتراك (${target.fullName} - ${target.phone}) نهائياً؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteSubscriber(target)
                        deleteTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف نهائي")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { deleteTarget = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showChangeAdminPassDialog) {
        ChangeAdminPasscodeDialog(
            onDismiss = { showChangeAdminPassDialog = false },
            onConfirm = { curr, newPass, confirm ->
                onChangeAdminPassword(curr, newPass, confirm)
                showChangeAdminPassDialog = false
            }
        )
    }
}

@Composable
private fun AdminPasscodeGate(
    statusCheckFailed: Boolean,
    hasAdminPasscodeSet: Boolean,
    isAuthenticating: Boolean,
    authError: String?,
    isTursoConfigured: Boolean,
    onRetryStatusCheck: () -> Unit,
    onSetupPassword: (String, String) -> Unit,
    onUnlock: (String) -> Unit
) {
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            shadowElevation = 2.dp,
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF091E42).copy(alpha = 0.08f),
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (statusCheckFailed) Icons.Default.CloudOff else Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = Color(0xFF091E42),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Text(
                    text = when {
                        statusCheckFailed -> "تعذر الاتصال بخادم الإدارة"
                        hasAdminPasscodeSet -> "دخول لوحة الإدارة"
                        else -> "إعداد كلمة مرور الإدارة"
                    },
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF091E42)
                )

                Text(
                    text = when {
                        statusCheckFailed -> "تحقق من نشر كود الـ Worker ومن صحة TURSO_DATABASE_URL و TURSO_AUTH_TOKEN في إعدادات Cloudflare."
                        hasAdminPasscodeSet -> "أدخل كلمة مرور الإدارة لفتح إدارة المشتركين والاشتراكات."
                        else -> "لا توجد كلمة مرور مُعدّة للإدارة حالياً. أنشئ كلمة مرور قوية لحماية لوحة التحكم."
                    },
                    fontSize = 13.sp,
                    color = Color(0xFF475569)
                )

                if (!isTursoConfigured) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFFEF3C7),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "قاعدة بيانات Turso غير مربوطة بعد:",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF78350F)
                            )
                            Text(
                                text = "1. افتح لوحة الأسرار (Secrets) في AI Studio.\n2. أضف TURSO_DATABASE_URL (رابط libsql://).\n3. أضف TURSO_AUTH_TOKEN (توكن Read & Write) ثم أعد البناء.",
                                fontSize = 12.sp,
                                color = Color(0xFF92400E)
                            )
                        }
                    }
                }

                if (!statusCheckFailed) {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text(if (hasAdminPasscodeSet) "كلمة مرور الإدارة" else "كلمة المرور الجديدة") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "إظهار/إخفاء"
                                )
                            }
                        },
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = if (hasAdminPasscodeSet) ImeAction.Done else ImeAction.Next
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("admin_passcode_input")
                    )

                    if (!hasAdminPasscodeSet) {
                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it },
                            label = { Text("تأكيد كلمة المرور") },
                            leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null) },
                            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_passcode_confirm_input")
                        )
                    }
                }

                if (!authError.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFFEE2E2),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = authError,
                            color = Color(0xFF991B1B),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Button(
                    onClick = {
                        when {
                            statusCheckFailed -> onRetryStatusCheck()
                            hasAdminPasscodeSet -> onUnlock(password)
                            else -> onSetupPassword(password, confirmPassword)
                        }
                    },
                    enabled = !isAuthenticating && isTursoConfigured,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E65FF)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_admin_unlock")
                ) {
                    if (isAuthenticating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        Text(
                            text = when {
                                statusCheckFailed -> "إعادة فحص الاتصال"
                                hasAdminPasscodeSet -> "فتح لوحة الإدارة"
                                else -> "حفظ كلمة المرور والدخول"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(
    label: String,
    count: Int,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = accentColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 12.sp,
                color = Color(0xFF475569),
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun SubscriberCard(
    subscriber: SubscriberAccount,
    isBusy: Boolean,
    onToggleActive: () -> Unit,
    onExtend: () -> Unit,
    onResetPassword: () -> Unit,
    onDelete: () -> Unit
) {
    val isExpired = subscriber.isExpired()
    val statusText: String
    val statusColor: Color
    val statusBg: Color
    val statusIcon = when {
        !subscriber.isActive -> {
            statusText = "موقوف"
            statusColor = Color(0xFFDC2626)
            statusBg = Color(0xFFFEE2E2)
            Icons.Default.Block
        }
        isExpired -> {
            statusText = "منتهي"
            statusColor = Color(0xFFD97706)
            statusBg = Color(0xFFFEF3C7)
            Icons.Default.EventBusy
        }
        else -> {
            statusText = "نشط"
            statusColor = Color(0xFF059669)
            statusBg = Color(0xFFD1FAE5)
            Icons.Default.CheckCircle
        }
    }

    val expiryLabel = remember(subscriber.expiresAt) {
        val exp = subscriber.expiresAt
        if (exp == null || exp <= 0L) {
            "غير محدد (مفتوح)"
        } else {
            SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH).format(Date(exp))
        }
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = subscriber.fullName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    if (subscriber.officeName.isNotBlank()) {
                        Text(
                            text = subscriber.officeName,
                            fontSize = 13.sp,
                            color = Color(0xFF475569)
                        )
                    }
                    Text(
                        text = "الهاتف: ${subscriber.phone}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF1E65FF)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusBg
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(statusIcon, contentDescription = null, tint = statusColor, modifier = Modifier.size(14.dp))
                        Text(
                            text = statusText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "الانتهاء: $expiryLabel",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
                if (subscriber.notes.isNotBlank()) {
                    Text(
                        text = subscriber.notes,
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleActive,
                    enabled = !isBusy,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(40.dp)
                ) {
                    Text(
                        text = if (subscriber.isActive) "إيقاف" else "تفعيل",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (subscriber.isActive) Color(0xFFD97706) else Color(0xFF059669)
                    )
                }

                OutlinedButton(
                    onClick = onExtend,
                    enabled = !isBusy,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(40.dp)
                ) {
                    Text("تمديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onResetPassword,
                    enabled = !isBusy,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(40.dp)
                ) {
                    Text("كلمة السر", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                IconButton(
                    onClick = onDelete,
                    enabled = !isBusy,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف المشترك",
                        tint = Color(0xFFDC2626)
                    )
                }
            }
        }
    }
}

@Composable
private fun AddSubscriberDialog(
    isProcessing: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (
        fullName: String,
        officeName: String,
        phone: String,
        password: String,
        durationDays: Int?,
        notes: String
    ) -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var officeName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var selectedDuration by remember { mutableStateOf(SubscriptionDurationOption.DAYS_30) }
    var localError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مشترك جديد", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it; localError = null },
                    label = { Text("اسم المشترك الكامل *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_sub_name")
                )
                OutlinedTextField(
                    value = officeName,
                    onValueChange = { officeName = it },
                    label = { Text("اسم المكتب / المعرض") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_sub_office")
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = FormatUtils.toWesternDigits(it); localError = null },
                    label = { Text("رقم الهاتف للدخول *") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().testTag("add_sub_phone")
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; localError = null },
                    label = { Text("كلمة المرور (4 أحرف فأكثر) *") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth().testTag("add_sub_password")
                )

                Text(
                    text = "مدة الاشتراك:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF334155)
                )
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SubscriptionDurationOption.entries.forEach { option ->
                        val selected = selectedDuration == option
                        Surface(
                            onClick = { selectedDuration = option },
                            shape = RoundedCornerShape(8.dp),
                            color = if (selected) Color(0xFF1E65FF).copy(alpha = 0.1f) else Color(0xFFF8FAFC),
                            border = BorderStroke(
                                width = if (selected) 1.5.dp else 1.dp,
                                color = if (selected) Color(0xFF1E65FF) else Color(0xFFE2E8F0)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                RadioButton(selected = selected, onClick = null)
                                Text(option.labelAr, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (localError != null) {
                    Text(localError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !isProcessing,
                onClick = {
                    when {
                        fullName.isBlank() -> localError = "يرجى إدخال اسم المشترك"
                        phone.isBlank() -> localError = "يرجى إدخال رقم الهاتف"
                        password.length < 4 -> localError = "كلمة المرور يجب أن تكون 4 أحرف على الأقل"
                        else -> onConfirm(fullName, officeName, phone, password, selectedDuration.days, notes)
                    }
                },
                modifier = Modifier.testTag("btn_confirm_add_subscriber")
            ) {
                Text("حفظ وتفعيل")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun ExtendSubscriptionDialog(
    subscriber: SubscriberAccount,
    onDismiss: () -> Unit,
    onSelectDuration: (Int?) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تمديد الاشتراك", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("اختر مدة التمديد للمشترك (${subscriber.fullName}):", fontSize = 13.sp)
                SubscriptionDurationOption.entries.forEach { option ->
                    OutlinedButton(
                        onClick = { onSelectDuration(option.days) },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Text(option.labelAr, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun ResetSubscriberPasswordDialog(
    subscriber: SubscriberAccount,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newPassword by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تغيير كلمة مرور المشترك", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المشترك: ${subscriber.fullName} (${subscriber.phone})", fontSize = 13.sp)
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it; error = null },
                    label = { Text("كلمة المرور الجديدة") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPassword.length < 4) {
                        error = "كلمة المرور يجب أن تكون 4 أحرف على الأقل"
                    } else {
                        onConfirm(newPassword)
                    }
                }
            ) {
                Text("تحديث")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun ChangeAdminPasscodeDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var currentPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var confirmPass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تغيير كلمة مرور الإدارة", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = currentPass,
                    onValueChange = { currentPass = it; error = null },
                    label = { Text("كلمة المرور الحالية") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newPass,
                    onValueChange = { newPass = it; error = null },
                    label = { Text("كلمة المرور الجديدة") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = confirmPass,
                    onValueChange = { confirmPass = it; error = null },
                    label = { Text("تأكيد كلمة المرور الجديدة") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) {
                    Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when {
                        currentPass.isBlank() -> error = "يرجى إدخال كلمة المرور الحالية"
                        newPass.length < 4 -> error = "كلمة المرور الجديدة يجب أن تكون 4 أحرف على الأقل"
                        newPass != confirmPass -> error = "كلمتا المرور غير متطابقتين"
                        else -> onConfirm(currentPass, newPass, confirmPass)
                    }
                }
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
