package com.example

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

class SettingsManager private constructor(context: Context) {
    private val appContext: Context = context.applicationContext
    private val prefs: SharedPreferences = appContext.getSharedPreferences("office_settings", Context.MODE_PRIVATE)

    var officeName: String
        get() = prefs.getString("office_name", "") ?: ""
        set(value) = prefs.edit().putString("office_name", value).apply()

    var officePhone: String
        get() = prefs.getString("office_phone", "") ?: ""
        set(value) = prefs.edit().putString("office_phone", value).apply()

    var officePhone2: String
        get() = prefs.getString("office_phone2", "") ?: ""
        set(value) = prefs.edit().putString("office_phone2", value).apply()

    var officeLicenseNo: String
        get() = prefs.getString("office_license_no", "") ?: ""
        set(value) = prefs.edit().putString("office_license_no", value).apply()

    var officeAddress: String
        get() = prefs.getString("office_address", "") ?: ""
        set(value) = prefs.edit().putString("office_address", value).apply()

    var hasAcceptedTerms: Boolean
        get() = prefs.getBoolean("has_accepted_terms_v1", false)
        set(value) = prefs.edit().putBoolean("has_accepted_terms_v1", value).apply()

    var watermarkLogoEnabled: Boolean
        get() = prefs.getBoolean("watermark_logo_enabled", false)
        set(value) = prefs.edit().putBoolean("watermark_logo_enabled", value).apply()

    var watermarkLogoSizePercent: Float
        get() = prefs.getFloat("watermark_logo_size_percent", 45f).coerceIn(15f, 85f)
        set(value) = prefs.edit().putFloat("watermark_logo_size_percent", value.coerceIn(15f, 85f)).apply()

    var watermarkLogoOpacityPercent: Float
        get() = prefs.getFloat("watermark_logo_opacity_percent", 15f).coerceIn(5f, 60f)
        set(value) = prefs.edit().putFloat("watermark_logo_opacity_percent", value.coerceIn(5f, 60f)).apply()

    private fun watermarkLogoFile(): File = File(appContext.filesDir, "office_watermark_logo.png")

    fun hasWatermarkLogo(): Boolean {
        val file = watermarkLogoFile()
        return file.exists() && file.length() > 0L
    }

    fun loadWatermarkLogoBitmap(): Bitmap? {
        val file = watermarkLogoFile()
        if (!file.exists() || file.length() == 0L) return null
        return try {
            BitmapFactory.decodeFile(file.absolutePath)
        } catch (_: Exception) {
            null
        }
    }

    fun saveWatermarkLogoFromUri(uri: Uri): Boolean {
        return try {
            val resolver = appContext.contentResolver
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            }
            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) return false

            val maxDim = 900
            var sampleSize = 1
            while (boundsOpts.outWidth / sampleSize > maxDim * 2 || boundsOpts.outHeight / sampleSize > maxDim * 2) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decoded = resolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return false

            val largest = max(decoded.width, decoded.height)
            val finalBitmap = if (largest > maxDim) {
                val ratio = maxDim.toFloat() / largest.toFloat()
                val targetW = (decoded.width * ratio).roundToInt().coerceAtLeast(1)
                val targetH = (decoded.height * ratio).roundToInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(decoded, targetW, targetH, true).also {
                    if (it !== decoded) decoded.recycle()
                }
            } else {
                decoded
            }

            val outFile = watermarkLogoFile()
            FileOutputStream(outFile).use { fos ->
                finalBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            finalBitmap.recycle()
            watermarkLogoEnabled = true
            true
        } catch (_: Exception) {
            false
        }
    }

    fun clearWatermarkLogo() {
        try {
            val file = watermarkLogoFile()
            if (file.exists()) file.delete()
        } catch (_: Exception) {
        }
        watermarkLogoEnabled = false
    }

    fun saveOfficeDetails(name: String, phone: String, phone2: String = "", licenseNo: String = "", address: String) {
        prefs.edit()
            .putString("office_name", name)
            .putString("office_phone", phone)
            .putString("office_phone2", phone2)
            .putString("office_license_no", licenseNo)
            .putString("office_address", address)
            .apply()
    }

    fun getOfficeInfo(): OfficeInfo {
        return OfficeInfo(
            officeName = officeName,
            phone = officePhone,
            phone2 = officePhone2,
            licenseNo = officeLicenseNo,
            address = officeAddress
        )
    }

    fun getOfficeDetails(): Triple<String, String, String> {
        return Triple(officeName, officePhone, officeAddress)
    }

    companion object {
        @Volatile
        private var instance: SettingsManager? = null

        fun getInstance(context: Context): SettingsManager {
            return instance ?: synchronized(this) {
                instance ?: SettingsManager(context.applicationContext).also { instance = it }
            }
        }
    }
}

