package com.example

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.nio.charset.StandardCharsets

/**
 * محول صور العقود إلى صيغة PWG-Raster 1.0 القياسية (PWG 5102.4 / Mopria / IPP Everywhere)
 * يدعم أغلب طابعات Wi-Fi الحديثة (HP, Canon, Epson, Brother) التي لا تقبل PDF مباشرة عبر IPP.
 */
internal object PwgRasterEncoder {

    private const val CUPS_CSPACE_SW = 18
    private const val CUPS_CSPACE_SRGB = 19

    fun encodeA4(
        sourceBitmap: Bitmap,
        dpiX: Int = 300,
        dpiY: Int = 300,
        copies: Int = 1,
        grayscale: Boolean = false
    ): ByteArray {
        val safeCopies = copies.coerceIn(1, 20)
        val safeDpiX = dpiX.coerceIn(72, 600)
        val safeDpiY = dpiY.coerceIn(72, 600)

        // أبعاد A4 (210mm x 297mm = 8.2677" x 11.6929")
        val targetWidth = maxOf(1, (8.2677f * safeDpiX).toInt())
        val targetHeight = maxOf(1, (11.6929f * safeDpiY).toInt())

        val scaledBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(scaledBitmap)
            canvas.drawColor(Color.WHITE)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(
                sourceBitmap,
                Rect(0, 0, sourceBitmap.width, sourceBitmap.height),
                Rect(0, 0, targetWidth, targetHeight),
                paint
            )

            val bpp = if (grayscale) 1 else 3
            val bytesPerLine = targetWidth * bpp
            val header = buildPwgHeader(
                width = targetWidth,
                height = targetHeight,
                dpiX = safeDpiX,
                dpiY = safeDpiY,
                grayscale = grayscale,
                bytesPerLine = bytesPerLine
            )

            val pixels = IntArray(targetWidth)
            val currentRow = ByteArray(bytesPerLine)
            var previousRow: ByteArray? = null
            var pendingRepeatCount = 0

            val compressedPage = ByteArrayOutputStream(64 * 1024)
            val out = ByteArrayOutputStream(128 * 1024)

            // RaS2 sync word
            out.write('R'.code)
            out.write('a'.code)
            out.write('S'.code)
            out.write('2'.code)

            for (y in 0 until targetHeight) {
                scaledBitmap.getPixels(pixels, 0, targetWidth, 0, y, targetWidth, 1)
                if (grayscale) {
                    for (x in 0 until targetWidth) {
                        val c = pixels[x]
                        val r = (c ushr 16) and 0xFF
                        val g = (c ushr 8) and 0xFF
                        val b = c and 0xFF
                        val lum = ((299 * r + 587 * g + 114 * b) / 1000).coerceIn(0, 255)
                        currentRow[x] = lum.toByte()
                    }
                } else {
                    var idx = 0
                    for (x in 0 until targetWidth) {
                        val c = pixels[x]
                        currentRow[idx++] = ((c ushr 16) and 0xFF).toByte()
                        currentRow[idx++] = ((c ushr 8) and 0xFF).toByte()
                        currentRow[idx++] = (c and 0xFF).toByte()
                    }
                }

                if (previousRow != null && currentRow.contentEquals(previousRow) && pendingRepeatCount < 255) {
                    pendingRepeatCount++
                } else {
                    if (previousRow != null) {
                        compressedPage.write(pendingRepeatCount and 0xFF)
                        encodePackBitsRow(previousRow, targetWidth, bpp, compressedPage)
                    }
                    previousRow = currentRow.copyOf()
                    pendingRepeatCount = 0
                }
            }

            if (previousRow != null) {
                compressedPage.write(pendingRepeatCount and 0xFF)
                encodePackBitsRow(previousRow, targetWidth, bpp, compressedPage)
            }

            val pageBytes = compressedPage.toByteArray()
            for (copy in 1..safeCopies) {
                out.write(header)
                out.write(pageBytes)
            }
            return out.toByteArray()
        } finally {
            scaledBitmap.recycle()
        }
    }

    /**
     * ضغط PackBits على مستوى البكسل وفق مواصفة PWG 5102.4 Section 4.4.2
     */
    private fun encodePackBitsRow(
        row: ByteArray,
        pixelCount: Int,
        bpp: Int,
        out: ByteArrayOutputStream
    ) {
        var i = 0
        while (i < pixelCount) {
            // فحص تكرار البكسل المتطابق
            var repeatLen = 1
            while (i + repeatLen < pixelCount &&
                repeatLen < 128 &&
                pixelsEqual(row, i * bpp, (i + repeatLen) * bpp, bpp)
            ) {
                repeatLen++
            }

            if (repeatLen >= 2) {
                out.write(repeatLen - 1) // 0..127 => repeat (count + 1) times
                out.write(row, i * bpp, bpp)
                i += repeatLen
            } else {
                // تجميع البكسلات غير المتطابقة
                val literalStart = i
                var literalLen = 1
                i++
                while (i < pixelCount && literalLen < 128) {
                    val hasUpcomingRepeat = (i + 1 < pixelCount) &&
                        pixelsEqual(row, i * bpp, (i + 1) * bpp, bpp)
                    if (hasUpcomingRepeat) break
                    literalLen++
                    i++
                }

                if (literalLen == 1) {
                    out.write(0) // repeat 1 time == 1 literal pixel
                    out.write(row, literalStart * bpp, bpp)
                } else {
                    out.write((-(literalLen - 1)) and 0xFF) // -(N - 1) => N literal pixels
                    out.write(row, literalStart * bpp, literalLen * bpp)
                }
            }
        }
    }

    private fun pixelsEqual(row: ByteArray, offA: Int, offB: Int, bpp: Int): Boolean {
        for (k in 0 until bpp) {
            if (row[offA + k] != row[offB + k]) return false
        }
        return true
    }

    private fun buildPwgHeader(
        width: Int,
        height: Int,
        dpiX: Int,
        dpiY: Int,
        grayscale: Boolean,
        bytesPerLine: Int
    ): ByteArray {
        val baos = ByteArrayOutputStream(1796)
        DataOutputStream(baos).use { dos ->
            // 0..63: MediaClass
            writeFixedCString(dos, "PwgRaster", 64)
            // 64..127: MediaColor
            writeFixedCString(dos, "", 64)
            // 128..191: MediaType
            writeFixedCString(dos, "", 64)
            // 192..255: OutputType
            writeFixedCString(dos, "", 64)
            // 256..275: AdvanceDistance, AdvanceMedia, Collate, CutMedia, Duplex
            repeat(5) { dos.writeInt(0) }
            // 276..283: HWResolution[2]
            dos.writeInt(dpiX)
            dos.writeInt(dpiY)
            // 284..299: ImagingBoundingBox[4]
            repeat(4) { dos.writeInt(0) }
            // 300..339: InsertSheet, Jog, LeadingEdge, Margins[2], ManualFeed, MediaPosition, MediaWeight, MirrorPrint, NegativePrint
            repeat(10) { dos.writeInt(0) }
            // 340..343: NumCopies
            dos.writeInt(1)
            // 344..351: Orientation, OutputFaceUp
            dos.writeInt(0)
            dos.writeInt(0)
            // 352..359: PageSize[2] (points)
            dos.writeInt(595)
            dos.writeInt(842)
            // 360..371: Separations, TraySwitch, Tumble
            repeat(3) { dos.writeInt(0) }
            // 372..379: cupsWidth, cupsHeight
            dos.writeInt(width)
            dos.writeInt(height)
            // 380..383: cupsMediaType
            dos.writeInt(0)
            // 384..387: cupsBitsPerColor
            dos.writeInt(8)
            // 388..391: cupsBitsPerPixel
            dos.writeInt(if (grayscale) 8 else 24)
            // 392..395: cupsBytesPerLine
            dos.writeInt(bytesPerLine)
            // 396..399: cupsColorOrder (0 = Chunky)
            dos.writeInt(0)
            // 400..403: cupsColorSpace
            dos.writeInt(if (grayscale) CUPS_CSPACE_SW else CUPS_CSPACE_SRGB)
            // 404..419: cupsCompression, cupsRowCount, cupsRowFeed, cupsRowStep
            repeat(4) { dos.writeInt(0) }
            // 420..423: cupsNumColors
            dos.writeInt(if (grayscale) 1 else 3)
            // 424..427: cupsBorderlessScalingFactor (float)
            dos.writeInt(java.lang.Float.floatToRawIntBits(1.0f))
            // 428..435: cupsPageSize[2] (floats)
            dos.writeInt(java.lang.Float.floatToRawIntBits(595.28f))
            dos.writeInt(java.lang.Float.floatToRawIntBits(841.89f))
            // 436..451: cupsImagingBBox[4] (floats)
            repeat(4) { dos.writeInt(0) }
            // 452..515: cupsInteger[16]
            repeat(16) { dos.writeInt(0) }
            // 516..579: cupsReal[16]
            repeat(16) { dos.writeInt(0) }
            // 580..1603: cupsString[16][64]
            repeat(16 * 64) { dos.writeByte(0) }
            // 1604..1667: cupsMarkerType[64]
            writeFixedCString(dos, "", 64)
            // 1668..1731: cupsRenderingIntent[64]
            writeFixedCString(dos, "", 64)
            // 1732..1795: cupsPageSizeName[64]
            writeFixedCString(dos, "iso_a4_210x297mm", 64)
        }
        return baos.toByteArray()
    }

    private fun writeFixedCString(dos: DataOutputStream, text: String, length: Int) {
        val bytes = text.toByteArray(StandardCharsets.US_ASCII)
        val count = minOf(bytes.size, length - 1)
        if (count > 0) {
            dos.write(bytes, 0, count)
        }
        repeat(length - count) {
            dos.writeByte(0)
        }
    }
}
