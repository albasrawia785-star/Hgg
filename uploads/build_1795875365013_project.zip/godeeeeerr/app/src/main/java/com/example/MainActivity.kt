package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RestorePage
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

enum class AppScreen {
    HOME,
    REAL_ESTATE_FORM,
    CAR_SALE_FORM,
    RENTAL_FORM,
    MOTORCYCLE_FORM,
    SAVED_CONTRACTS,
    CONTRACT_TEMPLATES,
    SETTINGS,
    ADMIN_PANEL
}

class MainActivity : ComponentActivity() {

    private val viewModel: ContractViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainContractAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContractAppScreen(viewModel: ContractViewModel) {
    val context = LocalContext.current

    val selectedType by viewModel.selectedContractType.collectAsStateWithLifecycle()
    val realEstateData by viewModel.realEstateContract.collectAsStateWithLifecycle()
    val carSaleData by viewModel.carSaleContract.collectAsStateWithLifecycle()
    val rentalData by viewModel.rentalContract.collectAsStateWithLifecycle()
    val motorcycleData by viewModel.motorcycleContract.collectAsStateWithLifecycle()

    val previewBitmap by viewModel.previewBitmap.collectAsStateWithLifecycle()
    val showPreviewDialog by viewModel.showPreviewDialog.collectAsStateWithLifecycle()

    val printerState by viewModel.printerState.collectAsStateWithLifecycle()
    val selectedPrinterTab by viewModel.selectedPrinterTab.collectAsStateWithLifecycle()
    val wifiPrinters by viewModel.wifiPrinters.collectAsStateWithLifecycle()
    val isScanningWifi by viewModel.isScanningWifi.collectAsStateWithLifecycle()
    val pairedDevices by viewModel.pairedDevices.collectAsStateWithLifecycle()
    val hasBluetoothPermission by viewModel.hasBluetoothPermission.collectAsStateWithLifecycle()
    val isBluetoothEnabled by viewModel.isBluetoothEnabled.collectAsStateWithLifecycle()
    val usbPrinters by viewModel.usbPrinters.collectAsStateWithLifecycle()
    val showPrinterDialog by viewModel.showPrinterDialog.collectAsStateWithLifecycle()
    val printCopies by viewModel.printCopies.collectAsStateWithLifecycle()

    val savedContractsList by viewModel.savedContractsList.collectAsStateWithLifecycle()
    val backupUiState by viewModel.backupUiState.collectAsStateWithLifecycle()
    val restoreRevision by viewModel.restoreRevision.collectAsStateWithLifecycle()

    val authSessionState by viewModel.authSessionState.collectAsStateWithLifecycle()
    val isLoggingIn by viewModel.isLoggingIn.collectAsStateWithLifecycle()
    val loginErrorMessage by viewModel.loginErrorMessage.collectAsStateWithLifecycle()
    val sessionNoticeMessage by viewModel.sessionNoticeMessage.collectAsStateWithLifecycle()
    val adminUiState by viewModel.adminUiState.collectAsStateWithLifecycle()
    val hasAcceptedTerms by viewModel.hasAcceptedTerms.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
    var showLoginAdminPanel by remember { mutableStateOf(false) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }

    var validationErrors by remember { mutableStateOf<List<String>?>(null) }
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    // اختيار موقع حفظ النسخة الاحتياطية (بدون أي صلاحيات تخزين)
    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            viewModel.exportBackupToUri(uri)
        }
    }

    // اختيار ملف النسخة الاحتياطية للاستعادة (بدون أي صلاحيات تخزين)
    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.inspectBackupUri(uri)
        }
    }

    val launchExportBackup: () -> Unit = {
        exportBackupLauncher.launch(BackupManager.defaultBackupFileName())
    }
    val launchImportBackup: () -> Unit = {
        importBackupLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
    }

    fun runWithValidation(action: () -> Unit) {
        val result = when (selectedType) {
            ContractType.REAL_ESTATE -> ContractValidation.validateRealEstateContract(realEstateData)
            ContractType.CAR_SALE -> ContractValidation.validateCarSaleContract(carSaleData)
            ContractType.RENTAL -> ContractValidation.validateRentalContract(rentalData)
            ContractType.MOTORCYCLE -> ContractValidation.validateMotorcycleContract(motorcycleData)
        }
        if (result.isValid) {
            action()
        } else {
            validationErrors = result.errors.values.toList()
            pendingAction = action
        }
    }

    // إذن البلوتوث بنظام أندرويد 12+ (يُطلب فقط عند الحاجة من تبويب البلوتوث)
    val bluetoothPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        viewModel.refreshPairedDevices()
        if (!allGranted) {
            Toast.makeText(context, "يرجى منح إذن البلوتوث لعرض طابعات البلوتوث", Toast.LENGTH_SHORT).show()
        }
    }

    fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val connectGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
            val scanGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED

            if (connectGranted && scanGranted) {
                viewModel.refreshPairedDevices()
            } else {
                bluetoothPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_SCAN
                    )
                )
            }
        } else {
            viewModel.refreshPairedDevices()
        }
    }

    fun checkAndOpenBluetoothPrinter() {
        viewModel.openBluetoothPrinterDialog()
    }

    if (!hasAcceptedTerms) {
        TermsConsentScreen(
            onAccepted = { viewModel.acceptTermsAndPrivacyPolicy() }
        )
        return
    }

    if (authSessionState is AuthSessionState.LoggedOut) {
        if (showLoginAdminPanel) {
            BackHandler {
                viewModel.lockAdminPanel()
                showLoginAdminPanel = false
            }
            AdminPanelScreen(
                uiState = adminUiState,
                onRetryStatusCheck = { viewModel.prepareAdminPanel() },
                onSetupAdminPassword = { pass, confirm -> viewModel.setupAdminPassword(pass, confirm) },
                onUnlockAdmin = { pass -> viewModel.unlockAdminPanel(pass) },
                onChangeAdminPassword = { curr, newPass, confirm ->
                    viewModel.changeAdminPassword(curr, newPass, confirm)
                },
                onRefreshSubscribers = { viewModel.refreshSubscribers() },
                onAddSubscriber = { name, office, phone, pass, days, notes ->
                    viewModel.addSubscriber(name, office, phone, pass, days, notes)
                },
                onToggleActive = { sub -> viewModel.toggleSubscriberActive(sub) },
                onExtendSubscriber = { sub, days -> viewModel.extendSubscriber(sub, days) },
                onResetPassword = { sub, newPass -> viewModel.resetSubscriberPassword(sub, newPass) },
                onDeleteSubscriber = { sub -> viewModel.deleteSubscriber(sub) },
                onClearMessages = { viewModel.clearAdminMessages() },
                onBack = {
                    viewModel.lockAdminPanel()
                    showLoginAdminPanel = false
                }
            )
        } else {
            LoginScreen(
                isLoggingIn = isLoggingIn,
                errorMessage = loginErrorMessage,
                noticeMessage = sessionNoticeMessage,
                onSubscriberLogin = { phone, password ->
                    viewModel.loginWithSubscriberCredentials(phone, password)
                },
                onTrialLogin = {
                    currentScreen = AppScreen.HOME
                    viewModel.startTrialSession()
                },
                onAdminAccessTriggered = {
                    viewModel.prepareAdminPanel()
                    showLoginAdminPanel = true
                },
                onClearError = { viewModel.clearLoginError() }
            )
        }
        return
    }

    // معالجة زر الرجوع في النظام للعودة للشاشة الرئيسية بدلاً من إغلاق التطبيق
    BackHandler(enabled = currentScreen != AppScreen.HOME) {
        if (currentScreen == AppScreen.ADMIN_PANEL) {
            viewModel.lockAdminPanel()
        }
        currentScreen = AppScreen.HOME
    }

    val isFormScreen = currentScreen == AppScreen.REAL_ESTATE_FORM ||
        currentScreen == AppScreen.CAR_SALE_FORM ||
        currentScreen == AppScreen.RENTAL_FORM ||
        currentScreen == AppScreen.MOTORCYCLE_FORM

    Scaffold(
        topBar = {
            if (currentScreen != AppScreen.HOME &&
                currentScreen != AppScreen.CONTRACT_TEMPLATES &&
                currentScreen != AppScreen.ADMIN_PANEL
            ) {
                TopAppBar(
                    title = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val screenTitle = when (currentScreen) {
                                AppScreen.REAL_ESTATE_FORM -> "عقد بيع عقار"
                                AppScreen.CAR_SALE_FORM -> "عقد بيع سيارة"
                                AppScreen.RENTAL_FORM -> "عقد إيجار"
                                AppScreen.MOTORCYCLE_FORM -> "عقد بيع دراجة/تكتك/ستوتة"
                                AppScreen.SAVED_CONTRACTS -> "سجل العقود المحفوظة"
                                AppScreen.SETTINGS -> "إعدادات المكتب والترويسة"
                                else -> "عقود برو"
                            }
                            Text(
                                text = screenTitle,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 19.sp
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(top = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height(1.dp)
                                        .background(Color(0xFF60A5FA))
                                )
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 4.dp)
                                        .size(5.dp)
                                        .background(Color(0xFF60A5FA), CircleShape)
                                )
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height(1.dp)
                                        .background(Color(0xFF60A5FA))
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.15f),
                            modifier = Modifier.padding(start = 8.dp)
                        ) {
                            IconButton(onClick = { currentScreen = AppScreen.HOME }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "الرجوع للرئيسية",
                                    tint = Color.White
                                )
                            }
                        }
                    },
                    actions = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            // مؤشر حالة الطابعة المباشر في شريط العنوان
                            val printerDotColor = when (printerState) {
                                is PrinterState.Success -> Color(0xFF10B981)
                                is PrinterState.Connecting, is PrinterState.Printing, is PrinterState.Scanning -> Color(0xFFF59E0B)
                                is PrinterState.Error -> Color(0xFFEF4444)
                                else -> Color(0xFF94A3B8)
                            }

                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.15f)
                            ) {
                                IconButton(
                                    onClick = { checkAndOpenBluetoothPrinter() },
                                    modifier = Modifier.size(36.dp).testTag("top_bar_bluetooth_btn")
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Print,
                                            contentDescription = "حالة الطابعة",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .size(7.dp)
                                                .align(Alignment.TopEnd)
                                                .background(printerDotColor, CircleShape)
                                        )
                                    }
                                }
                            }

                            if (currentScreen == AppScreen.REAL_ESTATE_FORM ||
                                currentScreen == AppScreen.CAR_SALE_FORM ||
                                currentScreen == AppScreen.RENTAL_FORM ||
                                currentScreen == AppScreen.MOTORCYCLE_FORM) {
                                // 1. زر إفراغ جميع الحقول
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFEF4444).copy(alpha = 0.25f)
                                ) {
                                    TextButton(
                                        onClick = { showClearConfirmDialog = true },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.testTag("btn_clear_fields_top")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteSweep,
                                            contentDescription = "إفراغ الحقول",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("إفراغ الحقول", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }

                                // 2. زر معاينة العقد
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFF1E65FF)
                                ) {
                                    TextButton(
                                        onClick = { runWithValidation { viewModel.openPreviewDialog() } },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                        modifier = Modifier.testTag("btn_preview_contract_top")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Visibility,
                                            contentDescription = "معاينة",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("معاينة العقد", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF091E42)
                    )
                )
            }
        },
        bottomBar = {
            if (isFormScreen) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 6.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                runWithValidation {
                                    viewModel.saveContractToArchive()
                                    Toast.makeText(context, "تم حفظ العقد في الأرشيف", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("btn_save_contract_bottom")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("حفظ", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { runWithValidation { viewModel.openPreviewDialog() } },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("btn_preview_contract_bottom")
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("معاينة", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                runWithValidation {
                                    viewModel.saveContractToArchive()
                                    checkAndOpenBluetoothPrinter()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E65FF)),
                            modifier = Modifier
                                .weight(1.2f)
                                .height(48.dp)
                                .testTag("btn_print_contract_bottom")
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("طباعة", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> {
                    HomeScreenUi(
                        onSelectRealEstate = {
                            viewModel.setContractType(ContractType.REAL_ESTATE)
                            currentScreen = AppScreen.REAL_ESTATE_FORM
                        },
                        onSelectCarSale = {
                            viewModel.setContractType(ContractType.CAR_SALE)
                            currentScreen = AppScreen.CAR_SALE_FORM
                        },
                        onSelectRental = {
                            viewModel.setContractType(ContractType.RENTAL)
                            currentScreen = AppScreen.RENTAL_FORM
                        },
                        onSelectMotorcycle = {
                            viewModel.setContractType(ContractType.MOTORCYCLE)
                            currentScreen = AppScreen.MOTORCYCLE_FORM
                        },
                        onSelectSavedContracts = {
                            currentScreen = AppScreen.SAVED_CONTRACTS
                        },
                        onSelectPrinter = {
                            checkAndOpenBluetoothPrinter()
                        },
                        onSelectSettings = {
                            currentScreen = AppScreen.SETTINGS
                        },
                        onSelectContractTemplates = {
                            currentScreen = AppScreen.CONTRACT_TEMPLATES
                        },
                        onMenuClick = {
                            Toast.makeText(context, "منظومة عقود برو للطباعة الرسمية A4", Toast.LENGTH_SHORT).show()
                        },
                        onNotificationClick = {
                            Toast.makeText(context, "الطابعة متصلة وجاهزة لطباعة العقود", Toast.LENGTH_SHORT).show()
                        },
                        savedContractsCount = savedContractsList.size,
                        printerState = printerState,
                        sessionLabel = when (val s = authSessionState) {
                            is AuthSessionState.Trial -> "حساب تجريبي • مكتب تجريبي"
                            is AuthSessionState.Subscriber -> "مشترك: ${s.account.fullName.ifBlank { s.account.phone }}"
                            AuthSessionState.LoggedOut -> ""
                        },
                        isTrialMode = authSessionState is AuthSessionState.Trial,
                        onLogoutClick = {
                            currentScreen = AppScreen.HOME
                            viewModel.logout()
                        },
                        onAdminAccessTriggered = {
                            viewModel.prepareAdminPanel()
                            currentScreen = AppScreen.ADMIN_PANEL
                        }
                    )
                }

                AppScreen.REAL_ESTATE_FORM -> {
                    RealEstateFormUi(
                        contract = realEstateData,
                        onContractChange = { update -> viewModel.updateRealEstateContract(update) }
                    )
                }

                AppScreen.CAR_SALE_FORM -> {
                    CarSaleFormUi(
                        contract = carSaleData,
                        onContractChange = { update -> viewModel.updateCarSaleContract(update) }
                    )
                }

                AppScreen.RENTAL_FORM -> {
                    RentalFormUi(
                        contract = rentalData,
                        onContractChange = { update -> viewModel.updateRentalContract(update) }
                    )
                }

                AppScreen.MOTORCYCLE_FORM -> {
                    MotorcycleFormUi(
                        contract = motorcycleData,
                        onContractChange = { update -> viewModel.updateMotorcycleContract(update) }
                    )
                }

                AppScreen.SAVED_CONTRACTS -> {
                    SavedContractsScreen(
                        contracts = savedContractsList,
                        onDeleteContract = { id -> viewModel.deleteSavedContract(id) },
                        onReprintContract = { entity ->
                            viewModel.loadContractFromArchive(entity)
                        },
                        onEditContract = { entity ->
                            val type = viewModel.populateContractFromEntity(entity)
                            currentScreen = when (type) {
                                ContractType.REAL_ESTATE -> AppScreen.REAL_ESTATE_FORM
                                ContractType.CAR_SALE -> AppScreen.CAR_SALE_FORM
                                ContractType.RENTAL -> AppScreen.RENTAL_FORM
                                ContractType.MOTORCYCLE -> AppScreen.MOTORCYCLE_FORM
                            }
                        },
                        onExportBackup = launchExportBackup,
                        onImportBackup = launchImportBackup
                    )
                }

                AppScreen.CONTRACT_TEMPLATES -> {
                    ContractTemplatesScreen(
                        onBack = { currentScreen = AppScreen.HOME },
                        onTemplateChanged = { viewModel.refreshOfficeInfo() }
                    )
                }

                AppScreen.SETTINGS -> {
                    SettingsScreen(
                        onBack = { currentScreen = AppScreen.HOME },
                        onOpenPrinterDialog = { checkAndOpenBluetoothPrinter() },
                        onSettingsSaved = { viewModel.refreshOfficeInfo() },
                        restoreRevision = restoreRevision,
                        savedContractsCount = savedContractsList.size,
                        onExportBackup = launchExportBackup,
                        onImportBackup = launchImportBackup,
                        isTrialMode = authSessionState is AuthSessionState.Trial,
                        onSwitchToSubscriberLogin = {
                            currentScreen = AppScreen.HOME
                            viewModel.logout()
                        }
                    )
                }

                AppScreen.ADMIN_PANEL -> {
                    AdminPanelScreen(
                        uiState = adminUiState,
                        onRetryStatusCheck = { viewModel.prepareAdminPanel() },
                        onSetupAdminPassword = { pass, confirm -> viewModel.setupAdminPassword(pass, confirm) },
                        onUnlockAdmin = { pass -> viewModel.unlockAdminPanel(pass) },
                        onChangeAdminPassword = { curr, newPass, confirm ->
                            viewModel.changeAdminPassword(curr, newPass, confirm)
                        },
                        onRefreshSubscribers = { viewModel.refreshSubscribers() },
                        onAddSubscriber = { name, office, phone, pass, days, notes ->
                            viewModel.addSubscriber(name, office, phone, pass, days, notes)
                        },
                        onToggleActive = { sub -> viewModel.toggleSubscriberActive(sub) },
                        onExtendSubscriber = { sub, days -> viewModel.extendSubscriber(sub, days) },
                        onResetPassword = { sub, newPass -> viewModel.resetSubscriberPassword(sub, newPass) },
                        onDeleteSubscriber = { sub -> viewModel.deleteSubscriber(sub) },
                        onClearMessages = { viewModel.clearAdminMessages() },
                        onBack = {
                            viewModel.lockAdminPanel()
                            currentScreen = AppScreen.HOME
                        }
                    )
                }
            }
        }
    }

    // 1. حوار معاينة العقد والطباعة
    if (showPreviewDialog && previewBitmap != null) {
        ContractPreviewDialog(
            bitmap = previewBitmap!!,
            onDismiss = { viewModel.closePreviewDialog() },
            onPrint = {
                viewModel.saveContractToArchive()
                viewModel.closePreviewDialog()
                checkAndOpenBluetoothPrinter()
            }
        )
    }

    // حوار تأكيد إفراغ جميع الحقول
    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = {
                Text(
                    text = "إفراغ جميع الحقول",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من مسح وإفراغ جميع البيانات والحقول المكتوبة حالياً للعقد؟",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showClearConfirmDialog = false
                        viewModel.clearCurrentContractFields()
                        Toast.makeText(context, "تم إفراغ جميع الحقول بنجاح!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("مسح وإفراغ")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 2. نافذة الطابعات الموحدة (Wi-Fi / Bluetooth / USB / PDF)
    if (showPrinterDialog) {
        UnifiedPrinterDialog(
            selectedTab = selectedPrinterTab,
            printerState = printerState,
            wifiPrinters = wifiPrinters,
            isScanningWifi = isScanningWifi,
            bluetoothDevices = pairedDevices,
            hasBluetoothPermission = hasBluetoothPermission,
            isBluetoothEnabled = isBluetoothEnabled,
            usbPrinters = usbPrinters,
            printCopies = printCopies,
            onPrintCopiesChange = { viewModel.setPrintCopies(it) },
            onSelectTab = { tab -> viewModel.selectPrinterTab(tab) },
            onRefresh = { viewModel.refreshPairedDevices() },
            onSystemPrintOrPdf = {
                viewModel.closeBluetoothPrinterDialog()
                viewModel.printViaSystemManager(context)
            },
            onSelectWifiPrinter = { wifiPrinter ->
                viewModel.printToWifiDevice(wifiPrinter) {
                    viewModel.closeBluetoothPrinterDialog()
                    viewModel.printViaSystemManager(context)
                }
            },
            onAddManualWifiPrinter = { name, host, port ->
                if (viewModel.addManualWifiPrinter(name, host, port)) {
                    Toast.makeText(context, "تمت إضافة الطابعة بنجاح", Toast.LENGTH_SHORT).show()
                }
            },
            onRemoveManualWifiPrinter = { wifiPrinter ->
                viewModel.removeManualWifiPrinter(wifiPrinter)
            },
            onRequestBluetoothPermission = { requestBluetoothPermissionIfNeeded() },
            onSelectBluetoothDevice = { device ->
                viewModel.printToBluetoothDevice(device)
            },
            onSelectUsbDevice = { usbDevice ->
                viewModel.printToUsbDevice(usbDevice)
            },
            onDismiss = { viewModel.closeBluetoothPrinterDialog() }
        )
    }

    // 4. حوار التحقق من صحة البيانات (Form Validation)
    if (validationErrors != null) {
        AlertDialog(
            onDismissRequest = {
                validationErrors = null
                pendingAction = null
            },
            title = {
                Text(
                    "تنبيه: تدقيق البيانات قبل الطباعة",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("يرجى التأكد من الحقول التالية للحفاظ على رسمية واحترافية العقد:", fontSize = 14.sp)
                    validationErrors?.forEach { err ->
                        Text("• $err", color = MaterialTheme.colorScheme.error, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val act = pendingAction
                        validationErrors = null
                        pendingAction = null
                        act?.invoke()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("متابعة على أي حال")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        validationErrors = null
                        pendingAction = null
                    }
                ) {
                    Text("تعديل البيانات")
                }
            }
        )
    }

    // 5. حوارات النسخ الاحتياطي والاستعادة
    when (val state = backupUiState) {
        is BackupUiState.Processing -> {
            AlertDialog(
                onDismissRequest = {},
                title = {
                    Text("النسخ الاحتياطي", fontWeight = FontWeight.Bold)
                },
                text = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp))
                        Text(state.message, fontSize = 14.sp)
                    }
                },
                confirmButton = {}
            )
        }

        is BackupUiState.ConfirmRestore -> {
            val data = state.backupData
            val officeTitle = data.officeInfo.officeName.ifBlank { "غير محدد" }
            val exportDate = remember(data.exportedAt) {
                BackupManager.formatExportDate(data.exportedAt)
            }
            AlertDialog(
                onDismissRequest = { viewModel.clearBackupUiState() },
                icon = {
                    Icon(
                        imageVector = Icons.Default.RestorePage,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                title = {
                    Text(
                        text = "تأكيد استعادة النسخة الاحتياطية",
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "تم العثور على نسخة احتياطية صالحة تحتوي على البيانات التالية:",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "عدد العقود: ${data.contracts.size} عقد",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "اسم المكتب: $officeTitle",
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "تاريخ النسخة: $exportDate",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                        Text(
                            text = "اختر طريقة الاستعادة:",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Button(
                            onClick = { viewModel.confirmRestoreBackup(data, replaceExisting = false) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_restore_merge"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("دمج مع العقود الحالية", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { viewModel.confirmRestoreBackup(data, replaceExisting = true) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_restore_replace"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = "استبدال جميع العقود الحالية",
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(
                        onClick = { viewModel.clearBackupUiState() },
                        modifier = Modifier.testTag("btn_restore_cancel")
                    ) {
                        Text("إلغاء")
                    }
                }
            )
        }

        is BackupUiState.Success -> {
            AlertDialog(
                onDismissRequest = { viewModel.clearBackupUiState() },
                icon = {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF059669)
                    )
                },
                title = {
                    Text("تمت العملية بنجاح", fontWeight = FontWeight.Bold)
                },
                text = {
                    Text(state.message, fontSize = 14.sp)
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.clearBackupUiState() },
                        modifier = Modifier.testTag("btn_backup_result_ok")
                    ) {
                        Text("حسناً")
                    }
                }
            )
        }

        is BackupUiState.Error -> {
            AlertDialog(
                onDismissRequest = { viewModel.clearBackupUiState() },
                icon = {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                },
                title = {
                    Text(
                        text = "تعذر إتمام العملية",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                },
                text = {
                    Text(state.message, fontSize = 14.sp)
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.clearBackupUiState() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("btn_backup_error_ok")
                    ) {
                        Text("إغلاق")
                    }
                }
            )
        }

        BackupUiState.Idle -> Unit
    }
}
