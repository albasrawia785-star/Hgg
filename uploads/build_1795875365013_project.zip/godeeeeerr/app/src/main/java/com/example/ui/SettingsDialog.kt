package com.example.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AuthManager
import com.example.ClearableOutlinedTextField
import com.example.FormSectionCard
import com.example.SettingsManager
import kotlin.math.roundToInt

/**
 * شاشة إعدادات المكتب والترويسة بصفحة كاملة
 * تتيح إدخال اسم المكتب، رقمي الهاتف، رقم الإجازة، والعنوان بحقول واسعة بدون تلميحات
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenPrinterDialog: () -> Unit = {},
    onSettingsSaved: () -> Unit = {},
    restoreRevision: Int = 0,
    savedContractsCount: Int = 0,
    onExportBackup: () -> Unit = {},
    onImportBackup: () -> Unit = {},
    isTrialMode: Boolean = false,
    onSwitchToSubscriberLogin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager.getInstance(context) }

    var officeName by remember(isTrialMode) {
        mutableStateOf(if (isTrialMode) AuthManager.TRIAL_OFFICE_INFO.officeName else settingsManager.officeName)
    }
    var officePhone by remember(isTrialMode) {
        mutableStateOf(if (isTrialMode) AuthManager.TRIAL_OFFICE_INFO.phone else settingsManager.officePhone)
    }
    var officePhone2 by remember(isTrialMode) {
        mutableStateOf(if (isTrialMode) AuthManager.TRIAL_OFFICE_INFO.phone2 else settingsManager.officePhone2)
    }
    var officeLicenseNo by remember(isTrialMode) {
        mutableStateOf(if (isTrialMode) AuthManager.TRIAL_OFFICE_INFO.licenseNo else settingsManager.officeLicenseNo)
    }
    var officeAddress by remember(isTrialMode) {
        mutableStateOf(if (isTrialMode) AuthManager.TRIAL_OFFICE_INFO.address else settingsManager.officeAddress)
    }

    var watermarkLogoEnabled by remember {
        mutableStateOf(settingsManager.watermarkLogoEnabled)
    }
    var watermarkLogoSizePercent by remember {
        mutableFloatStateOf(settingsManager.watermarkLogoSizePercent)
    }
    var watermarkLogoOpacityPercent by remember {
        mutableFloatStateOf(settingsManager.watermarkLogoOpacityPercent)
    }
    var watermarkLogoBitmap by remember {
        mutableStateOf<Bitmap?>(settingsManager.loadWatermarkLogoBitmap())
    }

    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val saved = settingsManager.saveWatermarkLogoFromUri(uri)
            if (saved) {
                watermarkLogoBitmap = settingsManager.loadWatermarkLogoBitmap()
                watermarkLogoEnabled = true
                onSettingsSaved()
                Toast.makeText(context, "تم حفظ صورة الشعار وتفعيلها بنجاح", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "تعذر قراءة الصورة المختارة، يرجى اختيار صورة أخرى", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(restoreRevision, isTrialMode) {
        if (restoreRevision > 0 && !isTrialMode) {
            officeName = settingsManager.officeName
            officePhone = settingsManager.officePhone
            officePhone2 = settingsManager.officePhone2
            officeLicenseNo = settingsManager.officeLicenseNo
            officeAddress = settingsManager.officeAddress
        }
        watermarkLogoEnabled = settingsManager.watermarkLogoEnabled
        watermarkLogoSizePercent = settingsManager.watermarkLogoSizePercent
        watermarkLogoOpacityPercent = settingsManager.watermarkLogoOpacityPercent
        watermarkLogoBitmap = settingsManager.loadWatermarkLogoBitmap()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                FormSectionCard(
                    title = "بيانات المكتب / المعرض",
                    icon = Icons.Default.Business
                ) {
                    if (isTrialMode) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFEF3C7),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("trial_settings_locked_banner")
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = Color(0xFFB45309),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "الوضع التجريبي: بيانات المكتب ثابتة ولا يمكن تعديلها.",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF78350F)
                                    )
                                }
                                Text(
                                    text = "لإدخال اسم مكتبك وأرقامك الخاصة على العقود، يرجى تسجيل الدخول بحساب مشترك مفعّل.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF92400E)
                                )
                                Button(
                                    onClick = onSwitchToSubscriberLogin,
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF091E42)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .testTag("btn_trial_switch_to_login")
                                ) {
                                    Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تسجيل الدخول بحساب مشترك", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    ClearableOutlinedTextField(
                        value = officeName,
                        onValueChange = {},
                        enabled = false,
                        readOnly = true,
                        trailingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = "اسم المكتب مقفل من الإدارة", modifier = Modifier.size(18.dp))
                        },
                        label = { Text("اسم المكتب / المعرض (محدد من الإدارة)") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Store,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_name"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )

                    ClearableOutlinedTextField(
                        value = officePhone,
                        onValueChange = { if (!isTrialMode) officePhone = it },
                        enabled = !isTrialMode,
                        readOnly = isTrialMode,
                        trailingIcon = if (isTrialMode) {
                            { Icon(Icons.Default.Lock, contentDescription = "مقفل", modifier = Modifier.size(18.dp)) }
                        } else null,
                        label = { Text("رقم الهاتف الأول") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Phone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_phone"),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next
                        )
                    )

                    ClearableOutlinedTextField(
                        value = officePhone2,
                        onValueChange = { if (!isTrialMode) officePhone2 = it },
                        enabled = !isTrialMode,
                        readOnly = isTrialMode,
                        trailingIcon = if (isTrialMode) {
                            { Icon(Icons.Default.Lock, contentDescription = "مقفل", modifier = Modifier.size(18.dp)) }
                        } else null,
                        label = { Text("رقم الهاتف الثاني") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_phone2"),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next
                        )
                    )

                    ClearableOutlinedTextField(
                        value = officeLicenseNo,
                        onValueChange = { if (!isTrialMode) officeLicenseNo = it },
                        enabled = !isTrialMode,
                        readOnly = isTrialMode,
                        trailingIcon = if (isTrialMode) {
                            { Icon(Icons.Default.Lock, contentDescription = "مقفل", modifier = Modifier.size(18.dp)) }
                        } else null,
                        label = { Text("رقم الإجازة / الترخيص") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.AssignmentInd,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_license_no"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )

                    ClearableOutlinedTextField(
                        value = officeAddress,
                        onValueChange = { if (!isTrialMode) officeAddress = it },
                        enabled = !isTrialMode,
                        readOnly = isTrialMode,
                        trailingIcon = if (isTrialMode) {
                            { Icon(Icons.Default.Lock, contentDescription = "مقفل", modifier = Modifier.size(18.dp)) }
                        } else null,
                        label = { Text("عنوان المكتب") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_address"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
                    )
                }

                FormSectionCard(
                    title = "شعار العلامة المائية",
                    icon = Icons.Default.BrandingWatermark
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "تفعيل شعار العلامة المائية",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "إظهار صورة شعار المكتب في خلفية جميع العقود المطبوعة",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = watermarkLogoEnabled,
                            onCheckedChange = { checked ->
                                watermarkLogoEnabled = checked
                                settingsManager.watermarkLogoEnabled = checked
                                onSettingsSaved()
                            },
                            modifier = Modifier.testTag("switch_watermark_logo")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                logoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("btn_pick_watermark_logo"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (watermarkLogoBitmap != null) "تغيير صورة الشعار" else "اختيار صورة الشعار",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        if (watermarkLogoBitmap != null) {
                            OutlinedButton(
                                onClick = {
                                    settingsManager.clearWatermarkLogo()
                                    watermarkLogoBitmap = null
                                    watermarkLogoEnabled = false
                                    onSettingsSaved()
                                    Toast.makeText(context, "تم حذف صورة الشعار", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("btn_remove_watermark_logo"),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.7f)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "حذف صورة الشعار",
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    AnimatedVisibility(visible = watermarkLogoEnabled) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            val bmp = watermarkLogoBitmap
                            if (bmp == null) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "لم يتم اختيار صورة بعد. اضغط على «اختيار صورة الشعار» لإضافة شعار المكتب أو المعرض.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                ) {
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        val sizeFrac = (watermarkLogoSizePercent / 100f).coerceIn(0.15f, 0.85f)
                                        Image(
                                            bitmap = bmp.asImageBitmap(),
                                            contentDescription = "معاينة شعار العلامة المائية",
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier
                                                .fillMaxWidth(sizeFrac)
                                                .fillMaxHeight(sizeFrac)
                                                .alpha((watermarkLogoOpacityPercent / 100f).coerceIn(0.05f, 0.60f))
                                        )
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 20.dp),
                                            verticalArrangement = Arrangement.spacedBy(10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = "معاينة شكل الشعار خلف نصوص العقد",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF0F172A).copy(alpha = 0.8f)
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth(0.75f)
                                                    .height(2.dp)
                                                    .background(Color(0xFF334155).copy(alpha = 0.25f))
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth(0.55f)
                                                    .height(2.dp)
                                                    .background(Color(0xFF334155).copy(alpha = 0.25f))
                                            )
                                        }
                                    }
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "مقاس الشعار",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${watermarkLogoSizePercent.roundToInt()}%",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Slider(
                                    value = watermarkLogoSizePercent,
                                    onValueChange = { watermarkLogoSizePercent = it },
                                    valueRange = 15f..85f,
                                    onValueChangeFinished = {
                                        settingsManager.watermarkLogoSizePercent = watermarkLogoSizePercent
                                        onSettingsSaved()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("slider_watermark_size")
                                )
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "درجة الشفافية (الوضوح)",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${watermarkLogoOpacityPercent.roundToInt()}%",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Slider(
                                    value = watermarkLogoOpacityPercent,
                                    onValueChange = { watermarkLogoOpacityPercent = it },
                                    valueRange = 5f..60f,
                                    onValueChangeFinished = {
                                        settingsManager.watermarkLogoOpacityPercent = watermarkLogoOpacityPercent
                                        onSettingsSaved()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("slider_watermark_opacity")
                                )
                                Text(
                                    text = "يُفضل إبقاء الشفافية بين 10% و20% لضمان وضوح نصوص العقد عند الطباعة.",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                FormSectionCard(
                    title = "النسخ الاحتياطي والاستعادة",
                    icon = Icons.Default.Backup
                ) {
                    Text(
                        text = "احفظ نسخة احتياطية محلية تشمل العقود المحفوظة ($savedContractsCount) وإعدادات المكتب والترقيم التسلسلي لنقلها عند تغيير الهاتف.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = onExportBackup,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_export_backup"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.UploadFile,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إنشاء نسخة احتياطية (تصدير)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onImportBackup,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_import_backup"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestorePage,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "استعادة نسخة احتياطية (استيراد)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                FormSectionCard(
                    title = "الطابعات والاتصال",
                    icon = Icons.Default.Print
                ) {
                    OutlinedButton(
                        onClick = onOpenPrinterDialog,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_open_printer_from_settings"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إدارة الطابعات والاتصال",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // شريط حفظ ثابت أسفل الصفحة
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 6.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onBack,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("btn_cancel_office_settings")
                ) {
                    Text("إلغاء", fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        if (!isTrialMode) {
                            settingsManager.saveOfficeDetails(
                                name = officeName,
                                phone = officePhone,
                                phone2 = officePhone2,
                                licenseNo = officeLicenseNo,
                                address = officeAddress
                            )
                            settingsManager.watermarkLogoEnabled = watermarkLogoEnabled
                            settingsManager.watermarkLogoSizePercent = watermarkLogoSizePercent
                            settingsManager.watermarkLogoOpacityPercent = watermarkLogoOpacityPercent
                            onSettingsSaved()
                            Toast.makeText(context, "تم حفظ بيانات المكتب بنجاح", Toast.LENGTH_SHORT).show()
                            onBack()
                        }
                    },
                    enabled = !isTrialMode,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_save_office_settings")
                ) {
                    Icon(
                        imageVector = if (isTrialMode) Icons.Default.Lock else Icons.Default.Save,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isTrialMode) "مقفل في الوضع التجريبي" else "حفظ التغييرات",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

