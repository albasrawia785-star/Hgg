package com.example

import android.content.Context
import android.content.SharedPreferences

/**
 * حالة الجلسة الحالية للمستخدم
 */
sealed class AuthSessionState {
    data object LoggedOut : AuthSessionState()
    data object Trial : AuthSessionState()
    data class Subscriber(val account: SubscriberAccount, val sessionToken: String) : AuthSessionState()
}

/**
 * إدارة جلسة تسجيل الدخول والحساب التجريبي محلياً (بدون تخزين أي كلمات مرور أو أسرار قاعدة البيانات)
 */
class AuthManager private constructor(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("auth_session_prefs", Context.MODE_PRIVATE)

    fun getCurrentSession(): AuthSessionState {
        return when (prefs.getString(KEY_MODE, MODE_LOGGED_OUT)) {
            MODE_TRIAL -> AuthSessionState.Trial
            MODE_SUBSCRIBER -> {
                val id = prefs.getLong(KEY_SUB_ID, -1L)
                val phone = prefs.getString(KEY_SUB_PHONE, "").orEmpty()
                val token = prefs.getString(KEY_SUB_TOKEN, "").orEmpty()
                if (id < 0L || phone.isBlank() || token.isBlank()) {
                    clearSession()
                    AuthSessionState.LoggedOut
                } else {
                    val expiresRaw = prefs.getLong(KEY_SUB_EXPIRES_AT, -1L)
                    val account = SubscriberAccount(
                        id = id,
                        fullName = prefs.getString(KEY_SUB_NAME, "").orEmpty(),
                        officeName = prefs.getString(KEY_SUB_OFFICE, "").orEmpty(),
                        phone = phone,
                        isActive = prefs.getBoolean(KEY_SUB_ACTIVE, true),
                        expiresAt = if (expiresRaw > 0L) expiresRaw else null,
                        notes = prefs.getString(KEY_SUB_NOTES, "").orEmpty(),
                        createdAt = prefs.getLong(KEY_SUB_CREATED_AT, 0L)
                    )
                    if (account.isValidForLogin()) {
                        AuthSessionState.Subscriber(account, token)
                    } else {
                        clearSession()
                        AuthSessionState.LoggedOut
                    }
                }
            }
            else -> AuthSessionState.LoggedOut
        }
    }

    fun startTrialSession() {
        prefs.edit()
            .putString(KEY_MODE, MODE_TRIAL)
            .apply()
    }

    fun saveSubscriberSession(account: SubscriberAccount, sessionToken: String) {
        prefs.edit()
            .putString(KEY_MODE, MODE_SUBSCRIBER)
            .putLong(KEY_SUB_ID, account.id)
            .putString(KEY_SUB_NAME, account.fullName)
            .putString(KEY_SUB_OFFICE, account.officeName)
            .putString(KEY_SUB_PHONE, account.phone)
            .putBoolean(KEY_SUB_ACTIVE, account.isActive)
            .putLong(KEY_SUB_EXPIRES_AT, account.expiresAt ?: -1L)
            .putString(KEY_SUB_NOTES, account.notes)
            .putLong(KEY_SUB_CREATED_AT, account.createdAt)
            .putString(KEY_SUB_TOKEN, sessionToken)
            .apply()
    }

    fun clearSession() {
        prefs.edit()
            .putString(KEY_MODE, MODE_LOGGED_OUT)
            .remove(KEY_SUB_ID)
            .remove(KEY_SUB_NAME)
            .remove(KEY_SUB_OFFICE)
            .remove(KEY_SUB_PHONE)
            .remove(KEY_SUB_ACTIVE)
            .remove(KEY_SUB_EXPIRES_AT)
            .remove(KEY_SUB_NOTES)
            .remove(KEY_SUB_CREATED_AT)
            .remove(KEY_SUB_TOKEN)
            .apply()
    }

    companion object {
        val TRIAL_OFFICE_INFO = OfficeInfo(
            officeName = "مكتب تجريبي",
            phone = "070000000",
            phone2 = "",
            licenseNo = "نسخة تجريبية",
            address = ""
        )

        private const val KEY_MODE = "session_mode"
        private const val MODE_LOGGED_OUT = "logged_out"
        private const val MODE_TRIAL = "trial"
        private const val MODE_SUBSCRIBER = "subscriber"

        private const val KEY_SUB_ID = "sub_id"
        private const val KEY_SUB_NAME = "sub_name"
        private const val KEY_SUB_OFFICE = "sub_office"
        private const val KEY_SUB_PHONE = "sub_phone"
        private const val KEY_SUB_ACTIVE = "sub_active"
        private const val KEY_SUB_EXPIRES_AT = "sub_expires_at"
        private const val KEY_SUB_NOTES = "sub_notes"
        private const val KEY_SUB_CREATED_AT = "sub_created_at"
        private const val KEY_SUB_TOKEN = "sub_session_token"

        @Volatile
        private var instance: AuthManager? = null

        fun getInstance(context: Context): AuthManager {
            return instance ?: synchronized(this) {
                instance ?: AuthManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
