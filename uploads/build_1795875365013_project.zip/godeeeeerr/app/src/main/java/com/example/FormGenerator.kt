package com.example

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

/**
 * FormGenerator: المحرك الموحد الأساسي لرسم ومعاينة وطباعة كافة استمارات العقود الـ A4
 *
 * يعتمد على معمارية Clean Architecture بواسطة ContractTemplateManager ورسامات العقود (BaseContractRenderer):
 * - رسم احترافي عالي الجودة مطابق للصورة الأصلية تماماً لكل عقد.
 * - توزيع حركي متناسب يضمن استغلال كامل ورقة الـ A4 بدون فراغات بيضاء كبيرة أو ازدحام.
 * - مطابقة 100% بين المعاينة والطباعة الـ PDF.
 * - أداء عالي ودعم إضافة أي أنواع عقود جديدة تلقائياً.
 */
object FormGenerator {

    const val A4_WIDTH = 1240
    const val A4_HEIGHT = 1754

    /**
     * 1. إنشاء صورة A4 لعقد بيع وشراء العقارات
     */
    fun renderRealEstateContractBitmap(
        data: RealEstateContract,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        val template = context?.let { TemplateSettingsManager.getInstance(it).getEffectiveTemplateForType(ContractType.REAL_ESTATE) }
        return RealEstateContractRenderer().renderBitmap(data, officeInfo, context, overrideTemplate = template)
    }

    /**
     * 2. إنشاء صورة A4 لعقد بيع وشراء السيارات
     */
    fun renderCarSaleContractBitmap(
        data: CarSaleContract,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        val template = context?.let { TemplateSettingsManager.getInstance(it).getEffectiveTemplateForType(ContractType.CAR_SALE) }
        return CarSaleContractRenderer().renderBitmap(data, officeInfo, context, overrideTemplate = template)
    }

    /**
     * 3. إنشاء صورة A4 لعقد إيجار الدور والأراضي
     */
    fun renderRentalContractBitmap(
        data: RentalContract,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        val template = context?.let { TemplateSettingsManager.getInstance(it).getEffectiveTemplateForType(ContractType.RENTAL) }
        return RentalContractRenderer().renderBitmap(data, officeInfo, context, overrideTemplate = template)
    }

    /**
     * 4. إنشاء صورة A4 لعقد بيع وشراء الدراجات والتكتك والستوتات
     */
    fun renderMotorcycleContractBitmap(
        data: MotorcycleContract,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        val template = context?.let { TemplateSettingsManager.getInstance(it).getEffectiveTemplateForType(ContractType.MOTORCYCLE) }
        return MotorcycleContractRenderer().renderBitmap(data, officeInfo, context, overrideTemplate = template)
    }

    /**
     * دالة عامة موحدة لتوليد صورة أي عقد (Bitmap) حسب نوعه وبياناته
     */
    fun renderContractBitmap(
        contractData: Any,
        contractType: ContractType,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null
    ): Bitmap {
        return when (contractType) {
            ContractType.REAL_ESTATE -> renderRealEstateContractBitmap(contractData as RealEstateContract, officeInfo, context)
            ContractType.CAR_SALE -> renderCarSaleContractBitmap(contractData as CarSaleContract, officeInfo, context)
            ContractType.RENTAL -> renderRentalContractBitmap(contractData as RentalContract, officeInfo, context)
            ContractType.MOTORCYCLE -> renderMotorcycleContractBitmap(contractData as MotorcycleContract, officeInfo, context)
        }
    }

    /**
     * تحويل صورة Bitmap إلى ملف PDF عالي الجودة للطباعة والتصدير
     */
    fun generatePdfFromBitmap(bitmap: Bitmap, context: Context, fileName: String = "contract_print.pdf"): File {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
        val destRect = Rect(0, 0, 595, 842)
        canvas.drawBitmap(bitmap, srcRect, destRect, Paint(Paint.FILTER_BITMAP_FLAG))

        pdfDocument.finishPage(page)

        val outputFile = File(context.cacheDir, fileName)
        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return outputFile
    }

    /**
     * توليد وحفظ ملف PDF للعقد تلقائياً باقتطاع ومحاذاة مثالية
     */
    fun generateContractPdf(
        contractData: Any,
        contractType: ContractType,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context
    ): File {
        val bitmap = renderContractBitmap(contractData, contractType, officeInfo, context)
        return generatePdfFromBitmap(bitmap, context, "contract_${contractType.name.lowercase()}.pdf")
    }

    /**
     * طباعة مستند A4 مباشرة عبر Android PrintManager (طباعة النظام والـ PDF)
     */
    fun printViaAndroidPrintManager(
        context: Context,
        bitmap: Bitmap,
        jobName: String = "عقد A4 رسمي",
        copies: Int = 1
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? android.print.PrintManager ?: return
        val safeCopies = copies.coerceIn(1, 20)

        printManager.print(
            jobName,
            object : android.print.PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: android.print.PrintAttributes?,
                    newAttributes: android.print.PrintAttributes?,
                    cancellationSignal: android.os.CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: android.os.Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = android.print.PrintDocumentInfo.Builder("$jobName.pdf")
                        .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(safeCopies)
                        .build()
                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out android.print.PageRange>?,
                    destination: android.os.ParcelFileDescriptor?,
                    cancellationSignal: android.os.CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    val pdfDocument = PdfDocument()
                    val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
                    val destRect = Rect(0, 0, 595, 842)
                    val paint = Paint(Paint.FILTER_BITMAP_FLAG)

                    for (pageIndex in 1..safeCopies) {
                        if (cancellationSignal?.isCanceled == true) {
                            pdfDocument.close()
                            callback?.onWriteCancelled()
                            return
                        }
                        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageIndex).create()
                        val page = pdfDocument.startPage(pageInfo)
                        page.canvas.drawBitmap(bitmap, srcRect, destRect, paint)
                        pdfDocument.finishPage(page)
                    }

                    val pfd = destination ?: run {
                        pdfDocument.close()
                        callback?.onWriteFailed("تعذر فتح ملف الطباعة")
                        return
                    }
                    try {
                        FileOutputStream(pfd.fileDescriptor).use { out ->
                            pdfDocument.writeTo(out)
                        }
                        callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    } finally {
                        pdfDocument.close()
                    }
                }
            },
            android.print.PrintAttributes.Builder()
                .setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4)
                .setColorMode(android.print.PrintAttributes.COLOR_MODE_COLOR)
                .setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS)
                .build()
        )
    }
}
