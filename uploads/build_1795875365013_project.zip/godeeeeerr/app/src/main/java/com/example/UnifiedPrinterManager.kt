package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

enum class PrinterConnectionTab {
    WIFI,
    BLUETOOTH,
    USB
}

data class WifiPrinterDevice(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val serviceType: String,
    val isManual: Boolean = false,
    val resourcePath: String? = null,
    val alternatePorts: List<Int> = emptyList()
) {
    val displaySubtitle: String
        get() = "${host.substringBefore('%')}:$port"
}

data class UsbPrinterDevice(
    val deviceId: Int,
    val name: String,
    val vendorId: Int,
    val productId: Int,
    val usbDevice: UsbDevice
) {
    val displaySubtitle: String
        get() = "USB ID ${vendorId.toString(16).uppercase()}:${productId.toString(16).uppercase()}"
}

private data class IppPrinterCapabilities(
    val scheme: String,
    val port: Int,
    val resourcePath: String,
    val supportedFormats: Set<String>,
    val pwgResolutions: List<Pair<Int, Int>>,
    val pwgTypes: Set<String>
)

private sealed class IppSendResult {
    data object Success : IppSendResult()
    data class Rejected(val statusCode: Int?, val httpCode: Int, val reason: String) : IppSendResult()
    data class TransportError(val message: String, val requiresTls: Boolean = false) : IppSendResult()
}

class UnifiedPrinterManager(
    private val context: Context,
    val bluetoothManager: BluetoothPrinterManager
) {
    companion object {
        private const val PREFS_NAME = "unified_printer_prefs"
        private const val KEY_MANUAL_WIFI_PRINTERS = "manual_wifi_printers"
        private const val ACTION_USB_PERMISSION = "com.example.USB_PRINTER_PERMISSION"
        private val NSD_SERVICE_TYPES = listOf(
            "_ipp._tcp.",
            "_ipps._tcp.",
            "_pdl-datastream._tcp.",
            "_printer._tcp."
        )
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val nsdManager: NsdManager? = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private val usbManager: UsbManager? = context.getSystemService(Context.USB_SERVICE) as? UsbManager
    private val wifiManager: WifiManager? = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private val resolveMutex = Mutex()
    private var multicastLock: WifiManager.MulticastLock? = null
    private val activeDiscoveryListeners = mutableListOf<NsdManager.DiscoveryListener>()
    private val isDiscoveringWifi = AtomicBoolean(false)

    private val _selectedTab = MutableStateFlow(PrinterConnectionTab.WIFI)
    val selectedTab: StateFlow<PrinterConnectionTab> = _selectedTab.asStateFlow()

    private val _wifiPrinters = MutableStateFlow<List<WifiPrinterDevice>>(emptyList())
    val wifiPrinters: StateFlow<List<WifiPrinterDevice>> = _wifiPrinters.asStateFlow()

    private val _isScanningWifi = MutableStateFlow(false)
    val isScanningWifi: StateFlow<Boolean> = _isScanningWifi.asStateFlow()

    private val _bluetoothDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val bluetoothDevices: StateFlow<List<BluetoothDevice>> = _bluetoothDevices.asStateFlow()

    private val _hasBluetoothPermission = MutableStateFlow(checkBluetoothPermission())
    val hasBluetoothPermission: StateFlow<Boolean> = _hasBluetoothPermission.asStateFlow()

    private val _isBluetoothEnabled = MutableStateFlow(bluetoothManager.isBluetoothEnabled())
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val _usbPrinters = MutableStateFlow<List<UsbPrinterDevice>>(emptyList())
    val usbPrinters: StateFlow<List<UsbPrinterDevice>> = _usbPrinters.asStateFlow()

    private var pendingUsbDeviceForPrint: UsbPrinterDevice? = null
    private var pendingUsbBitmap: Bitmap? = null
    private var pendingUsbCopies: Int = 1
    private var usbReceiverRegistered = false

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action != ACTION_USB_PERMISSION) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val device = pendingUsbDeviceForPrint
            val bitmap = pendingUsbBitmap
            val copies = pendingUsbCopies
            pendingUsbDeviceForPrint = null
            pendingUsbBitmap = null
            pendingUsbCopies = 1

            if (granted && device != null && bitmap != null) {
                scope.launch {
                    executeUsbPrint(device, bitmap, copies)
                }
            } else {
                bluetoothManager.updateExternalState(
                    PrinterState.Error("لم يتم منح إذن الوصول إلى طابعة USB")
                )
            }
        }
    }

    fun selectTab(tab: PrinterConnectionTab) {
        _selectedTab.value = tab
    }

    fun checkBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    /**
     * العثور على شبكة Wi-Fi أو Ethernet النشطة لربط الاتصالات بها مباشرة وتجاوز تعارض بيانات الهاتف أو Wi-Fi Direct
     */
    @Suppress("DEPRECATION")
    private fun findWifiNetwork(): Network? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
        val active = cm.activeNetwork
        val activeCaps = active?.let { cm.getNetworkCapabilities(it) }
        if (active != null && activeCaps != null &&
            (activeCaps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                activeCaps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
        ) {
            return active
        }
        return cm.allNetworks.firstOrNull { net ->
            val caps = cm.getNetworkCapabilities(net) ?: return@firstOrNull false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        }
    }

    fun isWifiConnected(): Boolean = findWifiNetwork() != null

    /**
     * فحص تلقائي شامل لجميع المنافذ (Wi-Fi، Bluetooth، USB) وتحديد التبويب الأنسب تلقائياً
     */
    fun scanAllPrinters(autoSelectBestTab: Boolean = true) {
        refreshBluetoothDevices()
        refreshUsbPrinters()
        startWifiDiscovery()

        if (autoSelectBestTab) {
            scope.launch {
                delay(450)
                val wifiCount = _wifiPrinters.value.size
                val btCount = _bluetoothDevices.value.size
                val usbCount = _usbPrinters.value.size

                val bestTab = when {
                    wifiCount > 0 -> PrinterConnectionTab.WIFI
                    usbCount > 0 -> PrinterConnectionTab.USB
                    btCount > 0 -> PrinterConnectionTab.BLUETOOTH
                    else -> PrinterConnectionTab.WIFI
                }
                _selectedTab.value = bestTab
            }
        }
    }

    fun refreshBluetoothDevices() {
        val granted = checkBluetoothPermission()
        _hasBluetoothPermission.value = granted
        _isBluetoothEnabled.value = bluetoothManager.isBluetoothEnabled()
        _bluetoothDevices.value = if (granted) {
            bluetoothManager.getPairedDevices()
        } else {
            emptyList()
        }
    }

    fun refreshUsbPrinters() {
        val manager = usbManager
        if (manager == null) {
            _usbPrinters.value = emptyList()
            return
        }
        val printers = manager.deviceList.values.mapNotNull { device ->
            val isPrinterClass = device.deviceClass == UsbConstants.USB_CLASS_PRINTER ||
                (0 until device.interfaceCount).any { idx ->
                    device.getInterface(idx).interfaceClass == UsbConstants.USB_CLASS_PRINTER
                }
            if (isPrinterClass) {
                val label = listOfNotNull(
                    device.manufacturerName?.takeIf { it.isNotBlank() },
                    device.productName?.takeIf { it.isNotBlank() }
                ).joinToString(" ").ifBlank { "طابعة USB OTG" }

                UsbPrinterDevice(
                    deviceId = device.deviceId,
                    name = label,
                    vendorId = device.vendorId,
                    productId = device.productId,
                    usbDevice = device
                )
            } else {
                null
            }
        }
        _usbPrinters.value = printers
    }

    fun startWifiDiscovery() {
        stopWifiDiscovery()
        val manualList = loadManualWifiPrinters()
        _wifiPrinters.value = manualList

        val manager = nsdManager ?: return
        if (!isWifiConnected()) {
            _isScanningWifi.value = false
            return
        }

        _isScanningWifi.value = true
        isDiscoveringWifi.set(true)

        try {
            multicastLock = wifiManager?.createMulticastLock("contract_printer_nsd")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (_: Exception) {
        }

        NSD_SERVICE_TYPES.forEach { serviceType ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String) {}

                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    if (!isDiscoveringWifi.get()) return
                    scope.launch {
                        resolveServiceSequentially(manager, serviceInfo)
                    }
                }

                override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
                override fun onDiscoveryStopped(serviceType: String) {}
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            }

            try {
                activeDiscoveryListeners.add(listener)
                manager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener)
            } catch (_: Exception) {
            }
        }

        scope.launch {
            delay(6000)
            _isScanningWifi.value = false
        }
    }

    @Suppress("DEPRECATION")
    private suspend fun resolveServiceSequentially(manager: NsdManager, serviceInfo: NsdServiceInfo) {
        resolveMutex.withLock {
            val resolved = withTimeoutOrNull(2500L) {
                kotlinx.coroutines.suspendCancellableCoroutine<NsdServiceInfo?> { cont ->
                    try {
                        manager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                                if (cont.isActive) cont.resume(null)
                            }

                            override fun onServiceResolved(info: NsdServiceInfo) {
                                if (cont.isActive) cont.resume(info)
                            }
                        })
                    } catch (_: Exception) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
            } ?: return@withLock

            val hostObj = resolved.host ?: return@withLock
            val wifiNet = findWifiNetwork()

            // محاولة استخراج عنوان IPv4 أولاً إذا أعاد mDNS عنوان IPv6
            val preferredHostObj: InetAddress = if (hostObj is Inet4Address) {
                hostObj
            } else {
                val hostName = hostObj.hostName?.takeIf { it.isNotBlank() }
                val resolvedV4 = if (hostName != null) {
                    try {
                        val candidates = wifiNet?.getAllByName(hostName) ?: InetAddress.getAllByName(hostName)
                        candidates.firstOrNull { it is Inet4Address }
                    } catch (_: Exception) {
                        null
                    }
                } else null
                resolvedV4 ?: hostObj
            }

            // الحفاظ على نطاق IPv6 (%wlan0) وعدم قصّه إلا للعرض فقط
            val hostAddress = preferredHostObj.hostAddress?.takeIf { it.isNotBlank() } ?: return@withLock
            val isIpv4 = preferredHostObj is Inet4Address
            val port = resolved.port.takeIf { it > 0 } ?: 631
            val name = resolved.serviceName?.trim()?.ifBlank { "طابعة Wi-Fi" } ?: "طابعة Wi-Fi"
            val serviceType = resolved.serviceType ?: "_ipp._tcp."
            val rpAttr = try {
                resolved.attributes?.get("rp")?.toString(StandardCharsets.UTF_8)?.trim()?.takeIf { it.isNotBlank() }
            } catch (_: Exception) {
                null
            }
            val id = "${hostAddress.substringBefore('%')}:$port"

            val discovered = WifiPrinterDevice(
                id = id,
                name = name,
                host = hostAddress,
                port = port,
                serviceType = serviceType,
                isManual = false,
                resourcePath = rpAttr,
                alternatePorts = emptyList()
            )

            val current = _wifiPrinters.value
            val existingIndex = current.indexOfFirst {
                it.host.substringBefore('%') == discovered.host.substringBefore('%') ||
                    it.name.equals(discovered.name, ignoreCase = true)
            }

            if (existingIndex < 0) {
                _wifiPrinters.value = current + discovered
            } else {
                val existing = current[existingIndex]
                if (!existing.isManual) {
                    val existingIsIpp = existing.port == 631 || existing.serviceType.contains("_ipp", ignoreCase = true)
                    val newIsIpp = discovered.port == 631 || discovered.serviceType.contains("_ipp", ignoreCase = true)
                    val existingIsIpv4 = !existing.host.contains(':')
                    val mergedAltPorts = (existing.alternatePorts + existing.port + discovered.port).distinct()

                    // نفضل عنوان IPv4 دائماً؛ ولا نستبدل عنوان IPv4 أبداً بعنوان IPv6
                    val bestHost = when {
                        isIpv4 -> discovered.host
                        existingIsIpv4 -> existing.host
                        else -> discovered.host
                    }
                    val bestPort = when {
                        newIsIpp -> discovered.port
                        existingIsIpp -> existing.port
                        else -> existing.port
                    }
                    val bestServiceType = when {
                        newIsIpp -> discovered.serviceType
                        existingIsIpp -> existing.serviceType
                        else -> existing.serviceType
                    }
                    val updated = existing.copy(
                        id = "${bestHost.substringBefore('%')}:$bestPort",
                        host = bestHost,
                        port = bestPort,
                        serviceType = bestServiceType,
                        resourcePath = discovered.resourcePath ?: existing.resourcePath,
                        alternatePorts = (mergedAltPorts - bestPort)
                    )
                    val mutable = current.toMutableList()
                    mutable[existingIndex] = updated
                    _wifiPrinters.value = mutable
                }
            }
        }
    }

    fun stopWifiDiscovery() {
        isDiscoveringWifi.set(false)
        _isScanningWifi.value = false
        val manager = nsdManager
        if (manager != null) {
            activeDiscoveryListeners.forEach { listener ->
                try {
                    manager.stopServiceDiscovery(listener)
                } catch (_: Exception) {
                }
            }
        }
        activeDiscoveryListeners.clear()
        try {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        } catch (_: Exception) {
        }
        multicastLock = null
    }

    fun addManualWifiPrinter(name: String, host: String, port: Int = 631): Boolean {
        val cleanHost = host.trim()
        if (cleanHost.isBlank()) return false
        val cleanName = name.trim().ifBlank { "طابعة شبكة ($cleanHost)" }
        val validPort = if (port in 1..65535) port else 631
        val newDevice = WifiPrinterDevice(
            id = "manual_$cleanHost:$validPort",
            name = cleanName,
            host = cleanHost,
            port = validPort,
            serviceType = if (validPort == 631 || validPort == 443) "_ipp._tcp." else "_pdl-datastream._tcp.",
            isManual = true
        )
        val updatedManual = (loadManualWifiPrinters().filterNot {
            it.host == cleanHost && it.port == validPort
        }) + newDevice
        saveManualWifiPrinters(updatedManual)

        val current = _wifiPrinters.value.filterNot { it.host == cleanHost && it.port == validPort }
        _wifiPrinters.value = listOf(newDevice) + current
        return true
    }

    fun removeManualWifiPrinter(device: WifiPrinterDevice) {
        val updatedManual = loadManualWifiPrinters().filterNot {
            it.host == device.host && it.port == device.port
        }
        saveManualWifiPrinters(updatedManual)
        _wifiPrinters.value = _wifiPrinters.value.filterNot {
            it.isManual && it.host == device.host && it.port == device.port
        }
    }

    private fun loadManualWifiPrinters(): List<WifiPrinterDevice> {
        val raw = prefs.getString(KEY_MANUAL_WIFI_PRINTERS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.getJSONObject(i)
                val host = obj.optString("host", "")
                if (host.isBlank()) null
                else WifiPrinterDevice(
                    id = obj.optString("id", "manual_$host"),
                    name = obj.optString("name", host),
                    host = host,
                    port = obj.optInt("port", 631),
                    serviceType = obj.optString("serviceType", "_ipp._tcp."),
                    isManual = true
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveManualWifiPrinters(list: List<WifiPrinterDevice>) {
        val arr = JSONArray()
        list.forEach { dev ->
            arr.put(JSONObject().apply {
                put("id", dev.id)
                put("name", dev.name)
                put("host", dev.host)
                put("port", dev.port)
                put("serviceType", dev.serviceType)
            })
        }
        prefs.edit().putString(KEY_MANUAL_WIFI_PRINTERS, arr.toString()).apply()
    }

    /**
     * الطباعة المباشرة إلى طابعة Wi-Fi:
     * 1. ربط الاتصال مباشرة بشبكة الواي فاي (يحل مشكلة Wi-Fi Direct وتعارض بيانات الهاتف).
     * 2. استعلام قدرات الطابعة عبر IPP (Get-Printer-Attributes) لتحديد الصيغة المدعومة فعلياً.
     * 3. الإرسال بصيغة PDF أو PWG-Raster (المعيار العالمي Mopria) أو JPEG.
     * 4. عدم التحويل الصامت لطباعة الهاتف، بل عرض سبب الخطأ الدقيق للمستخدم عند التعذر.
     */
    suspend fun printToWifiPrinter(
        device: WifiPrinterDevice,
        bitmap: Bitmap,
        copies: Int = 1,
        @Suppress("UNUSED_PARAMETER") onNeedSystemPrintFallback: () -> Unit = {}
    ) {
        val safeCopies = copies.coerceIn(1, 20)
        withContext(Dispatchers.IO) {
            bluetoothManager.updateExternalState(PrinterState.Connecting(device.name))

            val wifiNetwork = findWifiNetwork()
            if (wifiNetwork == null) {
                bluetoothManager.updateExternalState(
                    PrinterState.Error("الهاتف غير متصل بشبكة Wi-Fi حالياً. تأكد من الاتصال بنفس شبكة الطابعة.")
                )
                return@withContext
            }

            try {
                bluetoothManager.updateExternalState(PrinterState.Printing(15))

                val candidatePorts = buildList {
                    if (device.port == 631 || device.serviceType.contains("_ipp", ignoreCase = true)) {
                        add(device.port)
                    }
                    if (631 in device.alternatePorts || !device.isManual) {
                        add(631)
                    }
                    // حتى مع الإضافة اليدوية بمنفذ 9100 نفحص IPP على 631 أولاً لدعم طابعات الواي فاي القياسية
                    if (device.isManual && device.port != 631) {
                        add(631)
                    }
                }.distinct()

                val candidatePaths = buildList {
                    device.resourcePath?.trim()?.takeIf { it.isNotEmpty() }?.let { raw ->
                        add(if (raw.startsWith("/")) raw else "/$raw")
                    }
                    add("/ipp/print")
                    add("/ipp/printer")
                    add("/ipp")
                    add("/")
                }.distinct()

                var lastFailureReason: String? = null
                var printed = false

                // المرحلة 1: الاستعلام الذكي عن قدرات الطابعة والطباعة عبر IPP / IPPS
                for (ippPort in candidatePorts) {
                    val outcome = tryDirectIppPrinting(
                        host = device.host,
                        port = ippPort,
                        candidatePaths = candidatePaths,
                        bitmap = bitmap,
                        copies = safeCopies,
                        wifiNetwork = wifiNetwork,
                        preferHttps = device.serviceType.contains("_ipps", ignoreCase = true) || ippPort == 443
                    )
                    if (outcome == null) {
                        printed = true
                        break
                    } else {
                        lastFailureReason = outcome
                    }
                }

                // المرحلة 2: الإرسال عبر منفذ الشبكة الخام (مثل 9100) فقط إذا لم ينجح IPP وطلب المستخدم منفذاً غير 631/515
                if (!printed && device.isManual && device.port != 631 && device.port != 515) {
                    bluetoothManager.updateExternalState(PrinterState.Printing(40))
                    val pdfBytes = buildA4PdfBytes(bitmap, safeCopies)
                    val rawResult = sendPdfViaRawSocket(device.host, device.port, pdfBytes, wifiNetwork)
                    if (rawResult == null) {
                        printed = true
                    } else {
                        lastFailureReason = rawResult
                    }
                }

                if (printed) {
                    val copySuffix = if (safeCopies > 1) " ($safeCopies نسخ)" else ""
                    bluetoothManager.updateExternalState(
                        PrinterState.Success("تم إرسال العقد بنجاح$copySuffix إلى ${device.name}")
                    )
                } else {
                    bluetoothManager.updateExternalState(
                        PrinterState.Error(
                            lastFailureReason
                                ?: "تعذر الإرسال المباشر إلى ${device.name}. تأكد من تشغيل الطابعة أو استخدم خيار طباعة النظام."
                        )
                    )
                }
            } catch (e: Exception) {
                bluetoothManager.updateExternalState(
                    PrinterState.Error("تعذر الاتصال بالطابعة: ${e.localizedMessage ?: "تحقق من اتصال Wi-Fi"}")
                )
            }
        }
    }

    private fun formatHostForUrl(rawHost: String): String {
        val trimmed = rawHost.trim()
        if (trimmed.contains(':') && !trimmed.startsWith("[")) {
            val encoded = trimmed.replace("%", "%25")
            return "[$encoded]"
        }
        return trimmed
    }

    private fun openNetworkConnection(url: URL, wifiNetwork: Network): HttpURLConnection {
        val conn = try {
            wifiNetwork.openConnection(url)
        } catch (_: Exception) {
            url.openConnection()
        }
        return conn as HttpURLConnection
    }

    /**
     * الاستعلام عن قدرات الطابعة عبر IPP Get-Printer-Attributes (0x000B)
     * ثم إرسال الوظيفة بالصيغة المناسبة (PDF -> PWG-Raster -> JPEG) مع إظهار نسبة التقدم
     * @return null عند النجاح، أو رسالة الخطأ بالعربية عند الفشل
     */
    private fun tryDirectIppPrinting(
        host: String,
        port: Int,
        candidatePaths: List<String>,
        bitmap: Bitmap,
        copies: Int,
        wifiNetwork: Network,
        preferHttps: Boolean
    ): String? {
        val schemes = if (preferHttps) listOf("https", "http") else listOf("http", "https")
        var discoveredCaps: IppPrinterCapabilities? = null
        var transportFailure: String? = null

        // 1. الاستعلام عن قدرات الطابعة أولاً
        outer@ for (scheme in schemes) {
            for (path in candidatePaths) {
                val (caps, err) = queryPrinterAttributes(scheme, host, port, path, wifiNetwork)
                if (caps != null) {
                    discoveredCaps = caps
                    break@outer
                }
                if (err != null) {
                    transportFailure = err
                }
            }
        }

        val targetScheme = discoveredCaps?.scheme ?: schemes.first()
        val targetPaths = if (discoveredCaps != null) {
            listOf(discoveredCaps.resourcePath)
        } else {
            candidatePaths
        }

        // تحديد الصيغ المدعومة بالترتيب: PDF -> PWG-Raster -> JPEG
        val supported = discoveredCaps?.supportedFormats ?: emptySet()
        val formatsToTry = buildList {
            if (supported.isEmpty() || "application/pdf" in supported) add("application/pdf")
            if (supported.isEmpty() || "image/pwg-raster" in supported) add("image/pwg-raster")
            if (supported.isEmpty() || "image/jpeg" in supported) add("image/jpeg")
        }

        var lastRejectedMsg: String? = null
        var pdfBytesCache: ByteArray? = null

        for (format in formatsToTry) {
            when (format) {
                "application/pdf" -> {
                    bluetoothManager.updateExternalState(PrinterState.Printing(35))
                    val pdfBytes = pdfBytesCache ?: buildA4PdfBytes(bitmap, copies).also { pdfBytesCache = it }
                    for (path in targetPaths) {
                        when (val res = sendIppPrintJob(targetScheme, host, port, path, "application/pdf", pdfBytes, wifiNetwork)) {
                            is IppSendResult.Success -> {
                                bluetoothManager.updateExternalState(PrinterState.Printing(100))
                                return null
                            }
                            is IppSendResult.Rejected -> {
                                lastRejectedMsg = res.reason
                                // إذا كان المسار خاطئاً (404 / 0x0406) جرب المسار التالي؛ أما رفض الصيغة فانتقل للصيغة التالية
                                if (res.httpCode != 404 && res.statusCode != 0x0406) break
                            }
                            is IppSendResult.TransportError -> {
                                transportFailure = res.message
                                if (res.requiresTls && targetScheme == "http") {
                                    // إعادة المحاولة عبر HTTPS إذا طلبت الطابعة TLS
                                    val tlsRes = sendIppPrintJob("https", host, port, path, "application/pdf", pdfBytes, wifiNetwork)
                                    if (tlsRes is IppSendResult.Success) {
                                        bluetoothManager.updateExternalState(PrinterState.Printing(100))
                                        return null
                                    }
                                }
                            }
                        }
                    }
                }

                "image/pwg-raster" -> {
                    bluetoothManager.updateExternalState(PrinterState.Printing(55))
                    val (dpiX, dpiY) = pickBestPwgResolution(discoveredCaps?.pwgResolutions.orEmpty())
                    val preferGray = discoveredCaps != null &&
                        discoveredCaps.pwgTypes.isNotEmpty() &&
                        "srgb_8" !in discoveredCaps.pwgTypes &&
                        "sgray_8" in discoveredCaps.pwgTypes

                    val pwgBytes = PwgRasterEncoder.encodeA4(
                        sourceBitmap = bitmap,
                        dpiX = dpiX,
                        dpiY = dpiY,
                        copies = copies,
                        grayscale = preferGray
                    )
                    bluetoothManager.updateExternalState(PrinterState.Printing(75))

                    for (path in targetPaths) {
                        when (val res = sendIppPrintJob(targetScheme, host, port, path, "image/pwg-raster", pwgBytes, wifiNetwork)) {
                            is IppSendResult.Success -> {
                                bluetoothManager.updateExternalState(PrinterState.Printing(100))
                                return null
                            }
                            is IppSendResult.Rejected -> {
                                lastRejectedMsg = res.reason
                                if (res.httpCode != 404 && res.statusCode != 0x0406) break
                            }
                            is IppSendResult.TransportError -> {
                                transportFailure = res.message
                            }
                        }
                    }
                }

                "image/jpeg" -> {
                    bluetoothManager.updateExternalState(PrinterState.Printing(70))
                    val jpegBytes = buildA4JpegBytes(bitmap)
                    val path = targetPaths.first()
                    var allCopiesOk = true
                    for (copyIdx in 1..copies) {
                        when (val res = sendIppPrintJob(targetScheme, host, port, path, "image/jpeg", jpegBytes, wifiNetwork)) {
                            is IppSendResult.Success -> {
                                val pct = 70 + (copyIdx * 30 / copies)
                                bluetoothManager.updateExternalState(PrinterState.Printing(pct))
                            }
                            is IppSendResult.Rejected -> {
                                lastRejectedMsg = res.reason
                                allCopiesOk = false
                                break
                            }
                            is IppSendResult.TransportError -> {
                                transportFailure = res.message
                                allCopiesOk = false
                                break
                            }
                        }
                    }
                    if (allCopiesOk) return null
                }
            }
        }

        return lastRejectedMsg ?: transportFailure
    }

    private fun pickBestPwgResolution(supported: List<Pair<Int, Int>>): Pair<Int, Int> {
        if (supported.isEmpty()) return 300 to 300
        return supported.firstOrNull { it.first == 300 && it.second == 300 }
            ?: supported.firstOrNull { it.first in 200..300 && it.second in 200..300 }
            ?: supported.firstOrNull { it.first in 150..600 && it.second in 150..600 }
            ?: supported.first()
    }

    private fun queryPrinterAttributes(
        scheme: String,
        host: String,
        port: Int,
        resourcePath: String,
        wifiNetwork: Network
    ): Pair<IppPrinterCapabilities?, String?> {
        return try {
            val formattedHost = formatHostForUrl(host)
            val url = URL("$scheme://$formattedHost:$port$resourcePath")
            val conn = openNetworkConnection(url, wifiNetwork).apply {
                requestMethod = "POST"
                connectTimeout = 3500
                readTimeout = 5000
                doOutput = true
                doInput = true
                setRequestProperty("Content-Type", "application/ipp")
            }

            val printerUri = "ipp://$formattedHost:$port$resourcePath"
            val reqBytes = ByteArrayOutputStream().apply {
                DataOutputStream(this).use { dos ->
                    // IPP 2.0, Get-Printer-Attributes (0x000B), request-id 1
                    dos.writeByte(0x02)
                    dos.writeByte(0x00)
                    dos.writeShort(0x000B)
                    dos.writeInt(1)
                    dos.writeByte(0x01) // operation-attributes-tag
                    writeIppAttr(dos, 0x47, "attributes-charset", "utf-8")
                    writeIppAttr(dos, 0x48, "attributes-natural-language", "en")
                    writeIppAttr(dos, 0x45, "printer-uri", printerUri)
                    writeIppAttr(dos, 0x44, "requested-attributes", "document-format-supported")
                    writeIppAttr(dos, 0x44, "", "pwg-raster-document-resolution-supported")
                    writeIppAttr(dos, 0x44, "", "pwg-raster-document-type-supported")
                    dos.writeByte(0x03) // end-of-attributes-tag
                }
            }.toByteArray()

            conn.outputStream.use { os ->
                os.write(reqBytes)
                os.flush()
            }

            val httpCode = conn.responseCode
            val responseBytes = try {
                val stream = if (httpCode in 200..299) conn.inputStream else conn.errorStream
                stream?.readBytes() ?: ByteArray(0)
            } finally {
                conn.disconnect()
            }

            if (httpCode == 426) {
                return null to "الطابعة تطلب اتصالاً مشفراً (IPPS / HTTPS)."
            }
            if (httpCode !in 200..299 || responseBytes.size < 8) {
                return null to null
            }

            val ippStatus = ((responseBytes[2].toInt() and 0xFF) shl 8) or (responseBytes[3].toInt() and 0xFF)
            if (ippStatus !in 0x0000..0x02FF) {
                return null to null
            }

            val parsed = parseIppAttributesResponse(responseBytes)
            IppPrinterCapabilities(
                scheme = scheme,
                port = port,
                resourcePath = resourcePath,
                supportedFormats = parsed.formats,
                pwgResolutions = parsed.resolutions,
                pwgTypes = parsed.pwgTypes
            ) to null
        } catch (e: ConnectException) {
            null to "تعذر الاتصال بالطابعة (${host.substringBefore('%')}:$port) — تأكد من تشغيل الطابعة واتصالها بنفس شبكة Wi-Fi."
        } catch (e: SocketTimeoutException) {
            null to "انتهت مهلة الاتصال بالطابعة (${host.substringBefore('%')}) — تحقق من قرب الطابعة من الراوتر."
        } catch (e: Exception) {
            null to "فشل الاتصال بالطابعة: ${e.localizedMessage ?: "خطأ شبكة"}"
        }
    }

    private data class ParsedIppAttrs(
        val formats: Set<String>,
        val resolutions: List<Pair<Int, Int>>,
        val pwgTypes: Set<String>
    )

    private fun parseIppAttributesResponse(data: ByteArray): ParsedIppAttrs {
        val formats = linkedSetOf<String>()
        val resolutions = mutableListOf<Pair<Int, Int>>()
        val pwgTypes = linkedSetOf<String>()

        var pos = 8 // تخطي version(2) + status(2) + request-id(4)
        var currentAttrName = ""

        try {
            while (pos < data.size) {
                val tag = data[pos++].toInt() and 0xFF
                if (tag == 0x03) break // end-of-attributes-tag
                if (tag <= 0x0F) {
                    currentAttrName = ""
                    continue // delimiter tag
                }

                if (pos + 2 > data.size) break
                val nameLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                pos += 2
                if (pos + nameLen > data.size) break
                if (nameLen > 0) {
                    currentAttrName = String(data, pos, nameLen, StandardCharsets.UTF_8)
                    pos += nameLen
                }

                if (pos + 2 > data.size) break
                val valLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                pos += 2
                if (pos + valLen > data.size) break

                when (currentAttrName) {
                    "document-format-supported" -> {
                        if (valLen > 0) {
                            formats.add(String(data, pos, valLen, StandardCharsets.UTF_8).lowercase())
                        }
                    }
                    "pwg-raster-document-type-supported" -> {
                        if (valLen > 0) {
                            pwgTypes.add(String(data, pos, valLen, StandardCharsets.UTF_8).lowercase())
                        }
                    }
                    "pwg-raster-document-resolution-supported" -> {
                        if (tag == 0x32 && valLen == 9) {
                            val rx = readIntBE(data, pos)
                            val ry = readIntBE(data, pos + 4)
                            val unit = data[pos + 8].toInt() and 0xFF
                            // unit 3 = DPI, unit 4 = DPCM
                            if (unit == 3 && rx > 0 && ry > 0) {
                                resolutions.add(rx to ry)
                            } else if (unit == 4 && rx > 0 && ry > 0) {
                                resolutions.add((rx * 2.54f).toInt() to (ry * 2.54f).toInt())
                            }
                        }
                    }
                }
                pos += valLen
            }
        } catch (_: Exception) {
        }

        return ParsedIppAttrs(formats, resolutions, pwgTypes)
    }

    private fun readIntBE(data: ByteArray, offset: Int): Int {
        return ((data[offset].toInt() and 0xFF) shl 24) or
            ((data[offset + 1].toInt() and 0xFF) shl 16) or
            ((data[offset + 2].toInt() and 0xFF) shl 8) or
            (data[offset + 3].toInt() and 0xFF)
    }

    private fun buildA4PdfBytes(bitmap: Bitmap, copies: Int = 1): ByteArray {
        val safeCopies = copies.coerceIn(1, 20)
        val pdfDocument = PdfDocument()
        val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
        val destRect = Rect(0, 0, 595, 842)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)

        for (pageNumber in 1..safeCopies) {
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
            val page = pdfDocument.startPage(pageInfo)
            page.canvas.drawBitmap(bitmap, srcRect, destRect, paint)
            pdfDocument.finishPage(page)
        }

        return ByteArrayOutputStream().use { baos ->
            pdfDocument.writeTo(baos)
            pdfDocument.close()
            baos.toByteArray()
        }
    }

    private fun buildA4JpegBytes(bitmap: Bitmap): ByteArray {
        return ByteArrayOutputStream().use { baos ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, baos)
            baos.toByteArray()
        }
    }

    private fun sendPdfViaRawSocket(
        host: String,
        port: Int,
        pdfBytes: ByteArray,
        wifiNetwork: Network
    ): String? {
        return try {
            val addr = try {
                wifiNetwork.getAllByName(host).firstOrNull() ?: InetAddress.getByName(host)
            } catch (_: Exception) {
                InetAddress.getByName(host)
            }
            val socket = try {
                wifiNetwork.socketFactory.createSocket()
            } catch (_: Exception) {
                Socket()
            }
            socket.use { s ->
                s.connect(InetSocketAddress(addr, port), 4000)
                s.soTimeout = 6000
                val out = s.getOutputStream()
                val chunkSize = 4096
                var offset = 0
                while (offset < pdfBytes.size) {
                    val len = minOf(chunkSize, pdfBytes.size - offset)
                    out.write(pdfBytes, offset, len)
                    offset += len
                    val pct = 40 + (offset.toFloat() / pdfBytes.size * 55).toInt()
                    bluetoothManager.updateExternalState(PrinterState.Printing(pct))
                }
                out.flush()
            }
            null
        } catch (e: ConnectException) {
            "تعذر الاتصال بمنفذ الطابعة ($host:$port) — تأكد أن الطابعة مفتوحة وتدعم المنفذ $port أو استخدم المنفذ 631."
        } catch (e: SocketTimeoutException) {
            "انتهت مهلة الاتصال بالطابعة ($host:$port)."
        } catch (e: Exception) {
            "فشل الإرسال للمنفذ $port: ${e.localizedMessage ?: "خطأ اتصال"}"
        }
    }

    private fun sendIppPrintJob(
        scheme: String,
        host: String,
        port: Int,
        resourcePath: String,
        documentFormat: String,
        docBytes: ByteArray,
        wifiNetwork: Network
    ): IppSendResult {
        return try {
            val formattedHost = formatHostForUrl(host)
            val url = URL("$scheme://$formattedHost:$port$resourcePath")
            val conn = openNetworkConnection(url, wifiNetwork).apply {
                requestMethod = "POST"
                connectTimeout = 4000
                readTimeout = 15000
                doOutput = true
                doInput = true
                setRequestProperty("Content-Type", "application/ipp")
            }

            val printerUri = "ipp://$formattedHost:$port$resourcePath"
            val ippHeader = ByteArrayOutputStream().apply {
                DataOutputStream(this).use { dos ->
                    // IPP version 2.0, operation Print-Job (0x0002), request-id 1
                    dos.writeByte(0x02)
                    dos.writeByte(0x00)
                    dos.writeShort(0x0002)
                    dos.writeInt(1)
                    // operation-attributes-tag
                    dos.writeByte(0x01)
                    writeIppAttr(dos, 0x47, "attributes-charset", "utf-8")
                    writeIppAttr(dos, 0x48, "attributes-natural-language", "ar")
                    writeIppAttr(dos, 0x45, "printer-uri", printerUri)
                    writeIppAttr(dos, 0x42, "requesting-user-name", "AqoodPro")
                    writeIppAttr(dos, 0x42, "job-name", "Contract_A4")
                    writeIppAttr(dos, 0x49, "document-format", documentFormat)
                    // end-of-attributes-tag
                    dos.writeByte(0x03)
                }
            }.toByteArray()

            conn.outputStream.use { os ->
                os.write(ippHeader)
                os.write(docBytes)
                os.flush()
            }

            val httpCode = conn.responseCode
            val responseBytes = try {
                val stream = if (httpCode in 200..299) conn.inputStream else conn.errorStream
                stream?.readBytes() ?: ByteArray(0)
            } finally {
                conn.disconnect()
            }

            if (httpCode == 426) {
                return IppSendResult.TransportError("الطابعة تطلب اتصالاً مشفراً (IPPS).", requiresTls = true)
            }
            if (httpCode !in 200..299) {
                val reason = when (httpCode) {
                    401, 403 -> "الطابعة تتطلب كلمة مرور أو تصريح وصول (HTTP $httpCode)."
                    404 -> "مسار الطباعة غير موجود على الطابعة ($resourcePath)."
                    else -> "رفضت الطابعة الطلب (رمز HTTP $httpCode)."
                }
                return IppSendResult.Rejected(null, httpCode, reason)
            }
            if (responseBytes.size < 4) {
                return IppSendResult.Rejected(null, httpCode, "استجابة غير مكتملة من الطابعة.")
            }

            val ippStatus = ((responseBytes[2].toInt() and 0xFF) shl 8) or (responseBytes[3].toInt() and 0xFF)
            if (ippStatus in 0x0000..0x02FF) {
                IppSendResult.Success
            } else {
                val reason = when (ippStatus) {
                    0x040A -> "الطابعة لا تدعم صيغة الملف ($documentFormat)."
                    0x040B -> "بعض خصائص الطباعة غير مدعومة على هذا الطراز."
                    0x0500, 0x0503 -> "الطابعة مشغولة أو غير جاهزة حالياً، تأكد من وجود ورق وعدم وجود خطأ على شاشتها."
                    else -> "رفضت الطابعة مهمة الطباعة (رمز IPP 0x${ippStatus.toString(16).uppercase()})."
                }
                IppSendResult.Rejected(ippStatus, httpCode, reason)
            }
        } catch (e: ConnectException) {
            IppSendResult.TransportError(
                "تعذر الاتصال بالطابعة (${host.substringBefore('%')}:$port) — تأكد من تشغيلها واتصالها بنفس الشبكة."
            )
        } catch (_: SocketTimeoutException) {
            IppSendResult.TransportError("انتهت مهلة إرسال العقد للطابعة (${host.substringBefore('%')}).")
        } catch (e: Exception) {
            IppSendResult.TransportError("خطأ اتصال بالطابعة: ${e.localizedMessage ?: "تحقق من الشبكة"}")
        }
    }

    private fun writeIppAttr(dos: DataOutputStream, tag: Int, name: String, value: String) {
        val nameBytes = name.toByteArray(StandardCharsets.UTF_8)
        val valBytes = value.toByteArray(StandardCharsets.UTF_8)
        dos.writeByte(tag)
        dos.writeShort(nameBytes.size)
        dos.write(nameBytes)
        dos.writeShort(valBytes.size)
        dos.write(valBytes)
    }

    /**
     * الطباعة عبر كابل USB OTG
     */
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    fun printToUsbPrinter(device: UsbPrinterDevice, bitmap: Bitmap, copies: Int = 1) {
        val safeCopies = copies.coerceIn(1, 20)
        val manager = usbManager ?: run {
            bluetoothManager.updateExternalState(PrinterState.Error("خدمة USB غير متوفرة على هذا الجهاز"))
            return
        }

        if (manager.hasPermission(device.usbDevice)) {
            scope.launch {
                executeUsbPrint(device, bitmap, safeCopies)
            }
        } else {
            ensureUsbReceiverRegistered()
            pendingUsbDeviceForPrint = device
            pendingUsbBitmap = bitmap
            pendingUsbCopies = safeCopies

            val intent = Intent(ACTION_USB_PERMISSION).apply {
                setPackage(context.packageName)
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, flags)
            manager.requestPermission(device.usbDevice, pendingIntent)
        }
    }

    private fun ensureUsbReceiverRegistered() {
        if (usbReceiverRegistered) return
        val filter = IntentFilter(ACTION_USB_PERMISSION)
        ContextCompat.registerReceiver(
            context,
            usbPermissionReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        usbReceiverRegistered = true
    }

    private suspend fun executeUsbPrint(device: UsbPrinterDevice, bitmap: Bitmap, copies: Int = 1) {
        val safeCopies = copies.coerceIn(1, 20)
        withContext(Dispatchers.IO) {
            val manager = usbManager ?: return@withContext
            bluetoothManager.updateExternalState(PrinterState.Connecting(device.name))

            var connection: android.hardware.usb.UsbDeviceConnection? = null
            var claimedInterface: UsbInterface? = null

            try {
                val usbDevice = device.usbDevice
                var targetInterface: UsbInterface? = null
                var outEndpoint: UsbEndpoint? = null

                for (i in 0 until usbDevice.interfaceCount) {
                    val iface = usbDevice.getInterface(i)
                    for (j in 0 until iface.endpointCount) {
                        val ep = iface.getEndpoint(j)
                        if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK &&
                            ep.direction == UsbConstants.USB_DIR_OUT
                        ) {
                            targetInterface = iface
                            outEndpoint = ep
                            break
                        }
                    }
                    if (outEndpoint != null) break
                }

                if (targetInterface == null || outEndpoint == null) {
                    throw IOException("لم يتم العثور على قناة إخراج صالحة في طابعة USB")
                }

                connection = manager.openDevice(usbDevice)
                    ?: throw IOException("تعذر فتح اتصال USB بالطابعة")

                if (!connection.claimInterface(targetInterface, true)) {
                    throw IOException("تعذر حجز واجهة طابعة USB")
                }
                claimedInterface = targetInterface

                bluetoothManager.updateExternalState(PrinterState.Printing(15))

                val rasterBytes = bluetoothManager.convertBitmapToEscPosRaster(
                    bitmap,
                    bluetoothManager.selectedPaperType.value.widthPx
                ) { progress ->
                    bluetoothManager.updateExternalState(PrinterState.Printing(15 + (progress * 35 / 100)))
                }

                val chunkSize = maxOf(512, minOf(4096, outEndpoint.maxPacketSize * 8))
                val initBytes = byteArrayOf(0x1B, 0x40, 0x1B, 0x61, 0x01)
                val feedCut = byteArrayOf(0x1B, 0x64, 0x05, 0x1D, 0x56, 0x00)

                for (copyIdx in 1..safeCopies) {
                    connection.bulkTransfer(outEndpoint, initBytes, initBytes.size, 3000)

                    var offset = 0
                    while (offset < rasterBytes.size) {
                        val len = minOf(chunkSize, rasterBytes.size - offset)
                        val slice = rasterBytes.copyOfRange(offset, offset + len)
                        val transferred = connection.bulkTransfer(outEndpoint, slice, len, 5000)
                        if (transferred < 0) {
                            throw IOException("انقطع إرسال البيانات عبر كابل USB")
                        }
                        offset += len
                    }

                    connection.bulkTransfer(outEndpoint, feedCut, feedCut.size, 3000)
                    bluetoothManager.updateExternalState(PrinterState.Printing(50 + (copyIdx * 50 / safeCopies)))
                }

                val copySuffix = if (safeCopies > 1) " ($safeCopies نسخ)" else ""
                bluetoothManager.updateExternalState(
                    PrinterState.Success("تمت طباعة العقد بنجاح$copySuffix عبر USB إلى ${device.name}")
                )
            } catch (e: Exception) {
                bluetoothManager.updateExternalState(
                    PrinterState.Error("فشل الطباعة عبر USB: ${e.localizedMessage ?: "خطأ غير معروف"}")
                )
            } finally {
                try {
                    if (claimedInterface != null) {
                        connection?.releaseInterface(claimedInterface)
                    }
                    connection?.close()
                } catch (_: Exception) {
                }
            }
        }
    }

    fun cleanup() {
        stopWifiDiscovery()
        if (usbReceiverRegistered) {
            try {
                context.unregisterReceiver(usbPermissionReceiver)
            } catch (_: Exception) {
            }
            usbReceiverRegistered = false
        }
    }
}
