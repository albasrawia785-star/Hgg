package com.example

import android.content.Context

class ContractTemplateManager private constructor(context: Context) {
    fun getTemplate(contractType: ContractType): ContractTemplate {
        return ContractTemplateLibrary.getTemplateForType(contractType)
    }

    companion object {
        @Volatile
        private var instance: ContractTemplateManager? = null

        fun getInstance(context: Context): ContractTemplateManager {
            return instance ?: synchronized(this) {
                instance ?: ContractTemplateManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
