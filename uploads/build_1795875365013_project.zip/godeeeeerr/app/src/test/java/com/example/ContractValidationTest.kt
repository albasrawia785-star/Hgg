package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ContractValidationTest {

    @Test
    fun officeInfo_formatsSingleAndDualPhones() {
        val single = OfficeInfo(phone = "07700000000", phone2 = "")
        assertEquals("07700000000", single.formattedPhones())

        val dual = OfficeInfo(phone = "07700000000", phone2 = "07800000000")
        assertEquals("07700000000 - 07800000000", dual.formattedPhones())
    }

    @Test
    fun formatMoneyInput_formatsEasternAndWesternDigits() {
        assertEquals("1,500,000", FormatUtils.formatMoneyInput("1500000"))
        assertEquals("250,000", FormatUtils.formatMoneyInput("٢٥٠٠٠٠"))
        assertEquals("1,250,000,000", FormatUtils.formatMoneyInput("1250000000"))
        assertEquals("1,000,000,000", FormatUtils.formatMoneyInput("١٠٠٠٠٠٠٠٠٠"))
    }

    @Test
    fun convertNumberToArabicWords_supportsBillionsAndTrillions() {
        assertEquals("مليار دينار عراقي", FormatUtils.convertNumberToArabicWords("1000000000"))
        assertEquals("مليار دينار عراقي", FormatUtils.convertNumberToArabicWords("١٠٠٠٠٠٠٠٠٠"))
        assertEquals("ملياران دينار عراقي", FormatUtils.convertNumberToArabicWords("2000000000"))
        assertEquals(
            "ثلاثة مليارات ومائتان وخمسون مليون دينار عراقي",
            FormatUtils.convertNumberToArabicWords("3,250,000,000")
        )
        assertEquals("تريليون دينار عراقي", FormatUtils.convertNumberToArabicWords("1000000000000"))
        assertEquals("ألف دينار عراقي", FormatUtils.convertNumberToArabicWords("1000"))
        assertEquals("مليون دينار عراقي", FormatUtils.convertNumberToArabicWords("1000000"))
        assertEquals(
            "خمسة عشر ألف دولار أمريكي",
            FormatUtils.convertNumberToArabicWords("15000", ContractCurrency.USD)
        )
        assertEquals(
            "مليار دولار أمريكي",
            FormatUtils.convertNumberToArabicWords("1000000000", ContractCurrency.USD)
        )
    }

    @Test
    fun calculateRemainingAmount_computesDifferenceAndHandlesEdgeCases() {
        assertEquals("600000000", FormatUtils.calculateRemainingAmount("1000000000", "400000000"))
        assertEquals("750000000", FormatUtils.calculateRemainingAmount("١٠٠٠٠٠٠٠٠٠", "250000000"))
        assertEquals("15000", FormatUtils.calculateRemainingAmount("35,000", "20,000"))
        assertEquals("0", FormatUtils.calculateRemainingAmount("15000", "15000"))
        assertEquals("0", FormatUtils.calculateRemainingAmount("15000", "20000"))
        assertEquals("", FormatUtils.calculateRemainingAmount("15000", ""))
        assertEquals("", FormatUtils.calculateRemainingAmount("", "5000"))
    }

    @Test
    fun validateRealEstateContract_detectsMissingNamesAndInvalidId() {
        val invalid = RealEstateContract(
            sellerName = "",
            buyerName = "أحمد علي",
            sellerIdNumber = "12345"
        )
        val result = ContractValidation.validateRealEstateContract(invalid)
        assertFalse(result.isValid)
        assertTrue(result.hasError("sellerName"))
        assertTrue(result.hasError("sellerIdNumber"))
        assertNull(result.getError("buyerName"))
    }

    @Test
    fun validateCarSaleContract_passesWithValidRequiredFields() {
        val valid = CarSaleContract(
            sellerName = "محمد كريم",
            buyerName = "علي حسن",
            sellerPhone = "07701234567",
            sellerIdNumber = "199012345678",
            totalPrice = "15000000"
        )
        val result = ContractValidation.validateCarSaleContract(valid)
        assertTrue(result.isValid)
    }
}
