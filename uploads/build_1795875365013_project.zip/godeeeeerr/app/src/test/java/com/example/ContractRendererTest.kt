package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ContractRendererTest {

    private val office = OfficeInfo(
        officeName = "مكتب السلام للعقارات والسيارات",
        phone = "07701234567",
        phone2 = "07809876543",
        licenseNo = "بغداد - 4582",
        address = "بغداد - المنصور - شارع الأميرات"
    )

    @Test
    fun allFourRenderers_produceA4BitmapsWithoutErrors() {
        val context: Context = ApplicationProvider.getApplicationContext()

        val realEstateBmp = RealEstateContractRenderer().renderBitmap(
            RealEstateContract(
                contractNo = "0001",
                sellerName = "علي حسين كريم",
                buyerName = "محمد جاسم عبود",
                totalPrice = "1250000000",
                totalPriceWords = "مليار ومائتان وخمسون مليون دينار عراقي",
                depositPrice = "500000000",
                remainingPrice = "750000000",
                penaltySellerAmount = "100000000",
                penaltyBuyerAmount = "100000000",
                witness1Name = "عبد الرحمن محمد علي جاسم الساعدي",
                witness2Name = "مصطفى عبد الأمير كاظم الحيدري",
                additionalNotes = "يسلم العقار خالياً من الشواغل عند التقدير."
            ),
            office,
            context
        )
        assertNotNull(realEstateBmp)
        assertEquals(1240, realEstateBmp.width)
        assertEquals(1754, realEstateBmp.height)

        val carBmp = CarSaleContractRenderer().renderBitmap(
            CarSaleContract(
                contractNo = "202",
                sellerName = "سعد طارق",
                buyerName = "أحمد فاضل",
                carBrandAndType = "تويوتا لاندكروزر",
                modelYear = "2022",
                currency = ContractCurrency.USD,
                totalPrice = "35000",
                totalPriceWords = "خمسة وثلاثون ألف دولار أمريكي",
                paidAmount = "20000",
                remainingAmount = "15000",
                organizerName = "كريم المندوب",
                notes = "السيارة خالية من الحوادث والصبغ ويتم التحويل خلال أسبوع."
            ),
            office,
            context
        )
        assertNotNull(carBmp)
        assertEquals(1240, carBmp.width)
        assertEquals(1754, carBmp.height)

        val rentalBmp = RentalContractRenderer().renderBitmap(
            RentalContract(
                contractNo = "303",
                lessorName = "حيدر عباس",
                lesseeName = "عمر صباح",
                rentAmountNumber = "1500000",
                rentAmountWords = "مليون وخمسمائة ألف دينار عراقي",
                dailyDelayFee = "100000",
                additionalClauses = "يلتزم المستأجر بدفع فواتير الكهرباء والماء شهرياً."
            ),
            office,
            context
        )
        assertNotNull(rentalBmp)
        assertEquals(1240, rentalBmp.width)
        assertEquals(1754, rentalBmp.height)

        val motoBmp = MotorcycleContractRenderer().renderBitmap(
            MotorcycleContract(
                contractNo = "404",
                sellerName = "مصطفى رضا",
                buyerName = "زين العابدين",
                vehicleType = "تكتك",
                currency = ContractCurrency.USD,
                totalPrice = "2500",
                totalPriceWords = "ألفان وخمسمائة دولار أمريكي",
                paidAmount = "1500",
                remainingAmount = "1000",
                notes = "البيع بحالتها الحاضرة مع تسليم كافة الأوليات."
            ),
            office,
            context
        )
        assertNotNull(motoBmp)
        assertEquals(1240, motoBmp.width)
        assertEquals(1754, motoBmp.height)

        assertEquals("0001", RealEstateContract().contractNo)
        assertEquals("0001", CarSaleContract().contractNo)
        assertEquals("0001", RentalContract().contractNo)
        assertEquals("0001", MotorcycleContract().contractNo)
    }

    @Test
    fun securityWatermarkAndMarginStrip_renderCleanlyAcrossTemplatesAndDetectChanges() {
        val context: Context = ApplicationProvider.getApplicationContext()
        val renderer = object : BaseContractRenderer() {
            override fun drawContractContent(
                canvas: android.graphics.Canvas,
                contractData: Any,
                officeInfo: OfficeInfo,
                context: Context?
            ) {
            }

            fun inspectCode(data: Any, officeInfo: OfficeInfo): String =
                extractSecurityMetadata(data, officeInfo).verificationCode
        }

        val c1 = RealEstateContract(contractNo = "105", sellerName = "أحمد", buyerName = "علي", totalPrice = "100000000")
        val c2 = RealEstateContract(contractNo = "105", sellerName = "أحمد", buyerName = "علي", totalPrice = "200000000")
        val code1 = renderer.inspectCode(c1, office)
        val code1Again = renderer.inspectCode(c1, office)
        val code2 = renderer.inspectCode(c2, office)

        assertEquals(code1, code1Again)
        assertEquals(9, code1.length)
        org.junit.Assert.assertNotEquals(code1, code2)

        val mono = ContractTemplateLibrary.templates.firstOrNull { it.id == "monochrome_bw" }
        val borderless = ContractTemplateLibrary.templates.firstOrNull { it.id == "borderless" }

        listOfNotNull(mono, borderless).forEach { tmpl ->
            val bmp1 = RealEstateContractRenderer().renderBitmap(c1, office, context, overrideTemplate = tmpl)
            val bmp2 = CarSaleContractRenderer().renderBitmap(CarSaleContract(sellerName = "سعد", buyerName = "طارق"), office, context, overrideTemplate = tmpl)
            val bmp3 = RentalContractRenderer().renderBitmap(RentalContract(lessorName = "حيدر", lesseeName = "عمر"), office, context, overrideTemplate = tmpl)
            val bmp4 = MotorcycleContractRenderer().renderBitmap(MotorcycleContract(sellerName = "رضا", buyerName = "زين"), office, context, overrideTemplate = tmpl)
            listOf(bmp1, bmp2, bmp3, bmp4).forEach { bmp ->
                assertNotNull(bmp)
                assertEquals(1240, bmp.width)
                assertEquals(1754, bmp.height)
            }
        }
    }

    @Test
    fun watermarkLogo_renderWithCustomSizeAndOpacity_andSettingsPersistence_succeeds() {
        val context: Context = ApplicationProvider.getApplicationContext()
        val settingsManager = SettingsManager.getInstance(context)

        settingsManager.watermarkLogoEnabled = true
        settingsManager.watermarkLogoSizePercent = 65f
        settingsManager.watermarkLogoOpacityPercent = 22f
        assertEquals(true, settingsManager.watermarkLogoEnabled)
        assertEquals(65f, settingsManager.watermarkLogoSizePercent)
        assertEquals(22f, settingsManager.watermarkLogoOpacityPercent)

        // Verify clamping bounds
        settingsManager.watermarkLogoSizePercent = 120f
        settingsManager.watermarkLogoOpacityPercent = 95f
        assertEquals(85f, settingsManager.watermarkLogoSizePercent)
        assertEquals(60f, settingsManager.watermarkLogoOpacityPercent)
        settingsManager.watermarkLogoEnabled = false

        val fakeLogo = android.graphics.Bitmap.createBitmap(200, 120, android.graphics.Bitmap.Config.ARGB_8888)
        fakeLogo.eraseColor(android.graphics.Color.BLUE)
        val logoConfig = BaseContractRenderer.WatermarkLogoConfig(
            enabled = true,
            logoBitmap = fakeLogo,
            sizePercent = 55f,
            opacityPercent = 18f
        )
        val mono = ContractTemplateLibrary.templates.firstOrNull { it.id == "monochrome_bw" }

        val bmpColor = RealEstateContractRenderer().renderBitmap(
            RealEstateContract(sellerName = "أحمد", buyerName = "علي"),
            office,
            context,
            overrideWatermarkLogo = logoConfig
        )
        val bmpMono = CarSaleContractRenderer().renderBitmap(
            CarSaleContract(sellerName = "سعد", buyerName = "طارق"),
            office,
            context,
            overrideTemplate = mono,
            overrideWatermarkLogo = logoConfig
        )
        assertEquals(1240, bmpColor.width)
        assertEquals(1754, bmpColor.height)
        assertEquals(1240, bmpMono.width)
        assertEquals(1754, bmpMono.height)
        fakeLogo.recycle()
    }
}
