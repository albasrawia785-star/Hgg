package com.example

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class PwgRasterEncoderTest {

    @Test
    fun encodeA4_producesValidRaS2HeaderAndPackBitsBody() {
        val bmp = Bitmap.createBitmap(1240, 1754, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val paint = Paint().apply { color = Color.BLUE }
        canvas.drawRect(100f, 100f, 500f, 300f, paint)

        val bytes = PwgRasterEncoder.encodeA4(
            sourceBitmap = bmp,
            dpiX = 150,
            dpiY = 150,
            copies = 1,
            grayscale = false
        )

        // التحقق من ترويسة RaS2 + رأس الصفحة 1796 بايت
        assertTrue(bytes.size > 4 + 1796)
        assertEquals('R'.code.toByte(), bytes[0])
        assertEquals('a'.code.toByte(), bytes[1])
        assertEquals('S'.code.toByte(), bytes[2])
        assertEquals('2'.code.toByte(), bytes[3])

        val headerBuf = ByteBuffer.wrap(bytes, 4, 1796).slice().order(ByteOrder.BIG_ENDIAN)
        val mediaClass = String(bytes, 4, 9, Charsets.US_ASCII)
        assertEquals("PwgRaster", mediaClass)

        val hwX = headerBuf.getInt(276)
        val hwY = headerBuf.getInt(280)
        assertEquals(150, hwX)
        assertEquals(150, hwY)

        val width = headerBuf.getInt(372)
        val height = headerBuf.getInt(376)
        assertEquals((8.2677f * 150).toInt(), width)
        assertEquals((11.6929f * 150).toInt(), height)

        val bpp = headerBuf.getInt(388)
        val colorSpace = headerBuf.getInt(400)
        assertEquals(24, bpp)
        assertEquals(19, colorSpace) // CUPS_CSPACE_SRGB

        // فك ضغط جسم PWG-Raster للتحقق من تطابق عدد الأسطر والأعمدة
        var pos = 4 + 1796
        var decodedRows = 0
        while (pos < bytes.size && decodedRows < height) {
            val lineRepeat = (bytes[pos++].toInt() and 0xFF) + 1
            var decodedPixels = 0
            while (decodedPixels < width) {
                val ctrl = bytes[pos++] // signed byte
                if (ctrl >= 0) {
                    val repeat = ctrl.toInt() + 1
                    pos += 3
                    decodedPixels += repeat
                } else {
                    val literal = (-ctrl.toInt()) + 1
                    pos += literal * 3
                    decodedPixels += literal
                }
            }
            assertEquals(width, decodedPixels)
            decodedRows += lineRepeat
        }
        assertEquals(height, decodedRows)
        assertEquals(bytes.size, pos)
    }
}
