package com.example

import android.app.Application
import android.net.Uri
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class BackupManagerTest {

    private lateinit var context: Application
    private lateinit var database: AppDatabase
    private lateinit var repository: ContractRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ContractRepository(database.contractDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun backupJson_roundTripPreservesOfficeContractsCountersAndTemplateOptions() {
        val office = OfficeInfo(
            officeName = "مكتب دجلة للعقارات",
            phone = "07701112233",
            phone2 = "07804445566",
            licenseNo = "بغداد-998",
            address = "بغداد - الكرادة"
        )
        val contracts = listOf(
            ContractEntity(
                id = 12L,
                contractType = ContractType.REAL_ESTATE.name,
                title = "عقد عقار #0007 - دار سكني",
                primaryPartyName = "علي حسن",
                secondaryPartyName = "محمد كريم",
                dateCreated = 1730000000000L,
                jsonContent = """{"contractNo":"0007","sellerName":"علي حسن","notes":"سطر 1\nسطر 2"}"""
            ),
            ContractEntity(
                id = 15L,
                contractType = ContractType.CAR_SALE.name,
                title = "عقد سيارة #0003 - تويوتا",
                primaryPartyName = "سعد طارق",
                secondaryPartyName = "أحمد فاضل",
                dateCreated = 1730000100000L,
                jsonContent = """{"contractNo":"0003","carBrandAndType":"تويوتا"}"""
            )
        )
        val counters = mapOf(
            ContractType.REAL_ESTATE.name to 8,
            ContractType.CAR_SALE.name to 4,
            ContractType.RENTAL.name to 1,
            ContractType.MOTORCYCLE.name to 2
        )
        val templateOptions = TemplateCustomizationOptions(
            customHeaderColorHex = "#1E65FF",
            fontSizeScale = 1.1f,
            showFrame = true
        )

        val json = BackupManager.buildBackupJson(
            officeInfo = office,
            contracts = contracts,
            contractCounters = counters,
            selectedTemplateId = "classic_blue",
            templateOptions = templateOptions,
            exportedAt = 1730000200000L
        )

        val parsed = BackupManager.parseBackupJson(json)
        assertTrue(parsed.isSuccess)
        val data = parsed.getOrThrow()

        assertEquals(office, data.officeInfo)
        assertEquals(2, data.contracts.size)
        assertEquals(0L, data.contracts[0].id) // id reset to 0 for collision-free Room insert
        assertEquals("عقد عقار #0007 - دار سكني", data.contracts[0].title)
        assertEquals(contracts[0].jsonContent, data.contracts[0].jsonContent)
        assertEquals(8, data.contractCounters[ContractType.REAL_ESTATE.name])
        assertEquals(4, data.contractCounters[ContractType.CAR_SALE.name])
        assertEquals("classic_blue", data.selectedTemplateId)
        assertNotNull(data.templateOptions)
        assertEquals("#1E65FF", data.templateOptions?.customHeaderColorHex)
        assertEquals(1.1f, data.templateOptions?.fontSizeScale ?: 0f, 0.001f)
    }

    @Test
    fun parseBackupJson_rejectsInvalidOrForeignJson() {
        assertTrue(BackupManager.parseBackupJson("").isFailure)
        assertTrue(BackupManager.parseBackupJson("not json").isFailure)
        assertTrue(BackupManager.parseBackupJson("""{"hello":"world"}""").isFailure)
        assertTrue(
            BackupManager.parseBackupJson("""{"app":"OtherApp","version":1,"contracts":[]}""").isFailure
        )
        assertTrue(
            BackupManager.parseBackupJson("""{"app":"AqoodPro","version":99,"contracts":[]}""").isFailure
        )
    }

    @Test
    fun filterNonDuplicateContracts_skipsExistingAndAllowsNew() {
        val existing = listOf(
            ContractEntity(
                id = 5L,
                contractType = ContractType.REAL_ESTATE.name,
                title = "عقد عقار #0001 - دار سكني",
                primaryPartyName = "علي",
                secondaryPartyName = "كريم",
                dateCreated = 1000L,
                jsonContent = """{"contractNo":"0001"}"""
            )
        )
        val incoming = listOf(
            existing[0].copy(id = 99L),
            ContractEntity(
                id = 100L,
                contractType = ContractType.RENTAL.name,
                title = "عقد إيجار #0002 - بغداد",
                primaryPartyName = "مؤجر",
                secondaryPartyName = "مستأجر",
                dateCreated = 2000L,
                jsonContent = """{"contractNo":"0002"}"""
            )
        )

        val (toInsert, skipped) = BackupManager.filterNonDuplicateContracts(incoming, existing)
        assertEquals(1, skipped)
        assertEquals(1, toInsert.size)
        assertEquals(0L, toInsert[0].id)
        assertEquals(ContractType.RENTAL.name, toInsert[0].contractType)
    }

    @Test
    fun writeAndReadBackupUri_worksWithFileUriAndRepositoryReplace() = runBlocking {
        val entity = ContractEntity(
            contractType = ContractType.MOTORCYCLE.name,
            title = "عقد دراجة/تكتك #0001 - تكتك",
            primaryPartyName = "حسين",
            secondaryPartyName = "مصطفى",
            dateCreated = 5555L,
            jsonContent = """{"contractNo":"0001","brand":"تكتك"}"""
        )
        repository.saveContract(entity)
        val savedList = repository.getAllContractsOnce()
        assertEquals(1, savedList.size)

        val office = OfficeInfo(officeName = "مكتب النور", phone = "07712345678")
        val json = BackupManager.buildBackupJson(
            officeInfo = office,
            contracts = savedList,
            contractCounters = mapOf(ContractType.MOTORCYCLE.name to 2)
        )

        val tempFile = File.createTempFile("aqood_backup_test", ".json", context.cacheDir)
        try {
            val uri = Uri.fromFile(tempFile)
            val writeRes = BackupManager.writeBackupToUri(context, uri, json)
            assertTrue(writeRes.isSuccess)

            // Clear DB to simulate switching to a new phone
            repository.replaceAllContracts(emptyList())
            assertEquals(0, repository.getAllContractsOnce().size)

            val readRes = BackupManager.readBackupFromUri(context, uri)
            assertTrue(readRes.isSuccess)
            val backupData = readRes.getOrThrow()

            repository.replaceAllContracts(backupData.contracts)
            val restored = repository.getAllContractsOnce()
            assertEquals(1, restored.size)
            assertEquals("عقد دراجة/تكتك #0001 - تكتك", restored[0].title)
            assertEquals("مكتب النور", backupData.officeInfo.officeName)
        } finally {
            tempFile.delete()
        }
    }
}
