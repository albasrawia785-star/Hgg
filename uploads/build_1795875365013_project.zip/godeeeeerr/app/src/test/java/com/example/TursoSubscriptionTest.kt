package com.example

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class TursoSubscriptionTest {

    @Test
    fun tursoConfig_validatesAndNormalizesProxyUrls() {
        assertEquals(
            "https://uqud-pro-api.example.workers.dev",
            TursoConfig.normalizeProxyBaseUrl("https://uqud-pro-api.example.workers.dev/")
        )
        assertEquals(
            "https://uqud-pro-api.example.workers.dev",
            TursoConfig.normalizeProxyBaseUrl("uqud-pro-api.example.workers.dev")
        )
        assertEquals(
            "http://localhost:8787",
            TursoConfig.normalizeProxyBaseUrl("http://localhost:8787/")
        )
        assertEquals(
            "https://script.google.com/macros/s/AKfycb123/exec",
            TursoConfig.normalizeProxyBaseUrl("https://script.google.com/macros/s/AKfycb123/exec/")
        )
        // Rejects insecure plain http for remote servers
        assertNull(TursoConfig.normalizeProxyBaseUrl("http://uqud-pro-api.example.workers.dev"))
        assertNull(TursoConfig.normalizeProxyBaseUrl("YOUR_CLOUDFLARE_WORKER_URL"))
        assertNull(TursoConfig.normalizeProxyBaseUrl("   "))
    }

    @Test
    fun parseSubscriber_readsProxyJsonCleanly() {
        val json = JSONObject(
            """
            {
              "id": 7,
              "fullName": "أحمد علي",
              "officeName": "مكتب النور",
              "phone": "07701234567",
              "isActive": true,
              "expiresAt": null,
              "notes": "ملاحظة",
              "createdAt": 1700000000000
            }
            """.trimIndent()
        )
        val subscriber = TursoSubscriptionService.parseSubscriber(json)
        assertNotNull(subscriber)
        assertEquals(7L, subscriber?.id)
        assertEquals("أحمد علي", subscriber?.fullName)
        assertEquals("مكتب النور", subscriber?.officeName)
        assertEquals("07701234567", subscriber?.phone)
        assertTrue(subscriber?.isActive == true)
        assertNull(subscriber?.expiresAt)
    }

    @Test
    fun parseErrorMessage_extractsServerArabicMessage() {
        val body = """{"error":"تم إيقاف هذا الاشتراك من قِبل الإدارة"}"""
        assertEquals(
            "تم إيقاف هذا الاشتراك من قِبل الإدارة",
            TursoSubscriptionService.parseErrorMessage(body, 403)
        )
        assertEquals(
            "بيانات الدخول غير صحيحة أو انتهت الجلسة",
            TursoSubscriptionService.parseErrorMessage("not-json", 401)
        )
    }

    @Test
    fun subscriberAccount_validatesActiveAndExpiration() {
        val now = 2_000_000_000L
        val activeUnlimited = SubscriberAccount(1, "أحمد", "مكتب", "0770", isActive = true, expiresAt = null)
        val activeFuture = SubscriberAccount(2, "علي", "مكتب", "0771", isActive = true, expiresAt = now + 10_000L)
        val expired = SubscriberAccount(3, "سعد", "مكتب", "0772", isActive = true, expiresAt = now - 10_000L)
        val disabled = SubscriberAccount(4, "حسن", "مكتب", "0773", isActive = false, expiresAt = now + 10_000L)

        assertTrue(activeUnlimited.isValidForLogin(now))
        assertTrue(activeFuture.isValidForLogin(now))
        assertFalse(expired.isValidForLogin(now))
        assertTrue(expired.isExpired(now))
        assertFalse(disabled.isValidForLogin(now))
    }

    @Test
    fun normalizePhone_convertsArabicDigitsAndTrimsSpaces() {
        assertEquals("07701234567", TursoSubscriptionService.normalizePhone(" ٠٧٧٠ ١٢٣ ٤٥٦٧ "))
    }

    @Test
    fun trialOfficeInfo_matchesRequiredConstants() {
        assertEquals("مكتب تجريبي", AuthManager.TRIAL_OFFICE_INFO.officeName)
        assertEquals("070000000", AuthManager.TRIAL_OFFICE_INFO.phone)
    }

    @Test
    fun toTursoPipelineUrl_convertsLibsqlAndRejectsPlaceholders() {
        assertEquals(
            "https://my-db.turso.io/v2/pipeline",
            TursoConfig.toTursoPipelineUrl(" \"libsql://my-db.turso.io/\" ")
        )
        assertEquals(
            "https://my-db.turso.io/v2/pipeline",
            TursoConfig.toTursoPipelineUrl("https://my-db.turso.io/v2/pipeline")
        )
        assertNull(TursoConfig.toTursoPipelineUrl("YOUR_TURSO_DATABASE_URL"))
        assertNull(TursoConfig.toTursoPipelineUrl("http://my-db.turso.io"))
        assertNull(TursoConfig.toTursoPipelineUrl(""))
    }

    @Test
    fun directTursoClient_hashesAndVerifiesPasswordsSafely() {
        val hash1 = DirectTursoClient.hashPassword("Pass1234")
        val hash2 = DirectTursoClient.hashPassword("Pass1234")
        assertTrue(hash1.startsWith("10000:"))
        assertFalse(hash1 == hash2) // unique salt per hash
        assertTrue(DirectTursoClient.verifyPassword("Pass1234", hash1))
        assertTrue(DirectTursoClient.verifyPassword("Pass1234", hash2))
        assertFalse(DirectTursoClient.verifyPassword("WrongPass", hash1))
    }
}
