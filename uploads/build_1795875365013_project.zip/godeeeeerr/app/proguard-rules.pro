# ProGuard rules for advanced obfuscation and protection against reverse engineering (JADX, APKtool, etc.)

# Obfuscate and shrink code
-repackageclasses 'com.example.secure'
-allowaccessmodification

# Keep OkHttp & Network classes
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**
-keepattributes Signature, InnerClasses, EnclosingMethod

# Keep JSON / Org.json
-keep class org.json.** { *; }
-dontwarn org.json.**

# Keep BuildConfig and R classes
-keep class com.example.BuildConfig { *; }
-keep class com.example.R** { *; }

# Keep DirectTursoClient and TursoConfig
-keep class com.example.DirectTursoClient { *; }
-keep class com.example.TursoConfig { *; }
-keep class com.example.TursoSubscriptionService { *; }

# Strip debugging metadata in release builds for stronger reverse engineering resistance
-optimizations !code/simplification/arithmetic,!field/*,!class/merging/*
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute CSecure
