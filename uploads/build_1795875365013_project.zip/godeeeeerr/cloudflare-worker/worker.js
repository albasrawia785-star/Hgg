/**
 * Cloudflare Worker Proxy for Turso (Secrets stay on Cloudflare: TURSO_DATABASE_URL, TURSO_AUTH_TOKEN)
 */
const TE = new TextEncoder();
const ADMIN_KEY = "admin_password_hash";
const SUB_TTL = 30 * 864e5;
const ADM_TTL = 12 * 36e5;
let schemaReady = false;

class TursoErr extends Error {
  constructor(status, msg) { super(msg); this.status = status; }
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";
    const m = req.method.toUpperCase();
    try {
      const configured = Boolean(tursoUrl(env.TURSO_DATABASE_URL) && clean(env.TURSO_AUTH_TOKEN));
      if (m === "GET" && (path === "/" || path === "/health")) {
        if (url.searchParams.get("check") === "db" && configured) {
          try { await q(env, "SELECT 1"); return json({ ok: true, configured: true, dbConnected: true }); }
          catch (e) { return json({ ok: false, configured: true, dbConnected: false, dbError: e.message }, 502); }
        }
        return json({ ok: true, configured });
      }
      if (!configured) return err(503, "يرجى إضافة TURSO_DATABASE_URL و TURSO_AUTH_TOKEN في إعدادات Cloudflare.");

      await initDb(env);

      if (m === "POST" && path === "/api/auth/login") return await subLogin(req, env);
      if (m === "GET" && path === "/api/auth/me") return await subMe(req, env);
      if (m === "POST" && path === "/api/auth/logout") {
        const b = bearer(req);
        if (b) await q(env, "DELETE FROM subscriber_sessions WHERE token_hash=?", [tx(await sha(b))]);
        return json({ ok: true });
      }
      if (m === "GET" && path === "/api/admin/status") {
        return json({ hasAdminPassword: Boolean(env.ADMIN_PASSCODE || await adminHash(env)) });
      }
      if (m === "POST" && path === "/api/admin/setup") return await adminSetup(req, env);
      if (m === "POST" && path === "/api/admin/login") return await adminLogin(req, env);

      if (path.startsWith("/api/admin/")) {
        if (!(await checkAdmin(req, env))) return err(401, "انتهت جلسة الإدارة أو رمز الدخول غير صالح");
        if (m === "POST" && path === "/api/admin/change-password") return await changeAdminPass(req, env);
        if (m === "GET" && path === "/api/admin/subscribers") {
          const r = await q(env, "SELECT id,full_name,office_name,phone,is_active,expires_at,notes,created_at FROM subscribers ORDER BY id DESC");
          return json({ subscribers: r.rows.map(toSub) });
        }
        if (m === "POST" && path === "/api/admin/subscribers") return await addSub(req, env);
        const match = path.match(/^\/api\/admin\/subscribers\/(\d+)$/);
        if (match) {
          const id = Number(match[1]);
          if (m === "PATCH") return await patchSub(req, env, id);
          if (m === "DELETE") {
            await q(env, "DELETE FROM subscriber_sessions WHERE subscriber_id=?", [nm(id)]);
            await q(env, "DELETE FROM subscribers WHERE id=?", [nm(id)]);
            return json({ ok: true });
          }
        }
      }
      return err(404, "المسار غير موجود");
    } catch (e) {
      return e instanceof TursoErr ? err(e.status, e.message) : err(500, "حدث خطأ داخلي في الخادم");
    }
  }
};

async function subLogin(req, env) {
  const b = await bodyJson(req);
  if (!b) return err(400, "بيانات الطلب غير صالحة");
  const phone = normPhone(b.phone), pass = typeof b.password === "string" ? b.password : "";
  if (!phone || !pass) return err(400, "يرجى إدخال رقم الهاتف وكلمة المرور");
  const row = (await q(env, "SELECT * FROM subscribers WHERE phone=? LIMIT 1", [tx(phone)])).rows[0];
  if (!row || !(await verifyPw(pass, row.password_hash))) return err(401, "رقم الهاتف أو كلمة المرور غير صحيحة");
  const sub = toSub(row), now = Date.now();
  if (!sub.isActive) return err(403, "تم إيقاف هذا الاشتراك من قِبل الإدارة");
  if (sub.expiresAt && now > sub.expiresAt) return err(403, "انتهت صلاحية الاشتراك، يرجى التواصل مع الإدارة لتجديده");
  const tok = randTok(), exp = sub.expiresAt ? Math.min(sub.expiresAt, now + SUB_TTL) : now + SUB_TTL;
  await q(env, "INSERT INTO subscriber_sessions(token_hash,subscriber_id,expires_at,created_at) VALUES(?,?,?,?)", [tx(await sha(tok)), nm(sub.id), nm(exp), nm(now)]);
  return json({ token: tok, subscriber: sub });
}

async function subMe(req, env) {
  const b = bearer(req);
  if (!b) return err(401, "يرجى تسجيل الدخول مجدداً");
  const th = await sha(b), now = Date.now();
  const row = (await q(env, "SELECT s.*,ss.expires_at AS sess_exp FROM subscriber_sessions ss JOIN subscribers s ON s.id=ss.subscriber_id WHERE ss.token_hash=? LIMIT 1", [tx(th)])).rows[0];
  if (!row) return err(401, "لم يعد هذا الحساب متاحاً، يرجى تسجيل الدخول مجدداً");
  if (Number(row.sess_exp || 0) > 0 && now > Number(row.sess_exp)) {
    await q(env, "DELETE FROM subscriber_sessions WHERE token_hash=?", [tx(th)]);
    return err(401, "انتهت الجلسة، يرجى تسجيل الدخول مجدداً");
  }
  const sub = toSub(row);
  if (!sub.isActive) return err(403, "تم إيقاف اشتراكك من قِبل الإدارة");
  if (sub.expiresAt && now > sub.expiresAt) return err(403, "انتهت صلاحية اشتراكك، يرجى التواصل مع الإدارة لتجديده");
  return json({ subscriber: sub });
}

async function adminSetup(req, env) {
  if (env.ADMIN_PASSCODE) return err(409, "كلمة مرور الإدارة مهيأة مسبقاً");
  const b = await bodyJson(req), pass = typeof b?.password === "string" ? b.password : "";
  if (pass.length < 4) return err(400, "كلمة المرور يجب أن تكون 4 أحرف على الأقل");
  if (await adminHash(env)) return err(409, "تم تعيين كلمة مرور الإدارة مسبقاً");
  const res = await q(env, "INSERT INTO app_admin_config(config_key,config_value,updated_at) VALUES(?,?,?) ON CONFLICT(config_key) DO NOTHING", [tx(ADMIN_KEY), tx(await hashPw(pass)), nm(Date.now())]);
  if (res.affectedRows !== 1) return err(409, "تم تعيين كلمة مرور الإدارة مسبقاً");
  return json({ token: await newAdminSess(env) });
}

async function adminLogin(req, env) {
  const b = await bodyJson(req), pass = typeof b?.password === "string" ? b.password : "";
  if (!pass) return err(400, "يرجى إدخال كلمة مرور الإدارة");
  let ok = false;
  if (env.ADMIN_PASSCODE) ok = eqBytes(TE.encode(pass), TE.encode(env.ADMIN_PASSCODE));
  else {
    const h = await adminHash(env);
    if (!h) return err(400, "لم يتم إعداد كلمة مرور الإدارة بعد");
    ok = await verifyPw(pass, h);
  }
  return ok ? json({ token: await newAdminSess(env) }) : err(401, "كلمة مرور الإدارة غير صحيحة");
}

async function changeAdminPass(req, env) {
  if (env.ADMIN_PASSCODE) return err(400, "كلمة مرور الإدارة مضبوطة عبر الخادم ولا تتغير من التطبيق");
  const b = await bodyJson(req);
  const cur = typeof b?.currentPassword === "string" ? b.currentPassword : "";
  const nxt = typeof b?.newPassword === "string" ? b.newPassword : "";
  if (nxt.length < 4) return err(400, "كلمة المرور الجديدة يجب أن تكون 4 أحرف على الأقل");
  const h = await adminHash(env);
  if (!h || !(await verifyPw(cur, h))) return err(401, "كلمة المرور الحالية غير صحيحة");
  await q(env, "INSERT INTO app_admin_config(config_key,config_value,updated_at) VALUES(?,?,?) ON CONFLICT(config_key) DO UPDATE SET config_value=excluded.config_value,updated_at=excluded.updated_at", [tx(ADMIN_KEY), tx(await hashPw(nxt)), nm(Date.now())]);
  return json({ ok: true });
}

async function addSub(req, env) {
  const b = await bodyJson(req);
  if (!b) return err(400, "بيانات الطلب غير صالحة");
  const fullName = String(b.fullName || "").trim(), officeName = String(b.officeName || "").trim();
  const phone = normPhone(b.phone), pass = typeof b.password === "string" ? b.password : "", notes = String(b.notes || "").trim();
  const days = b.durationDays == null ? null : Number(b.durationDays);
  if (!fullName) return err(400, "يرجى إدخال اسم المشترك");
  if (!phone) return err(400, "يرجى إدخال رقم الهاتف");
  if (pass.length < 4) return err(400, "كلمة المرور يجب أن تكون 4 أحرف على الأقل");
  if (days !== null && (!Number.isFinite(days) || days <= 0)) return err(400, "مدة الاشتراك غير صالحة");
  const now = Date.now(), exp = days !== null ? now + Math.round(days) * 864e5 : null;
  try {
    const r = await q(env, "INSERT INTO subscribers(full_name,office_name,phone,password_hash,is_active,expires_at,notes,created_at) VALUES(?,?,?,?,1,?,?,?)",
      [tx(fullName), tx(officeName), tx(phone), tx(await hashPw(pass)), exp !== null ? nm(exp) : { type: "null" }, tx(notes), nm(now)]);
    return json({ subscriber: { id: r.lastInsertRowId || 0, fullName, officeName, phone, isActive: true, expiresAt: exp, notes, createdAt: now } }, 201);
  } catch (e) {
    return String(e?.message || "").toUpperCase().includes("UNIQUE") ? err(409, "رقم الهاتف مسجل مسبقاً لمشترك آخر") : err(500, "تعذر إضافة المشترك");
  }
}

async function patchSub(req, env, id) {
  const b = await bodyJson(req);
  if (!b) return err(400, "بيانات الطلب غير صالحة");
  if (b.action === "toggle_active") {
    const active = Boolean(b.isActive);
    await q(env, "UPDATE subscribers SET is_active=? WHERE id=?", [nm(active ? 1 : 0), nm(id)]);
    if (!active) await q(env, "DELETE FROM subscriber_sessions WHERE subscriber_id=?", [nm(id)]);
    return json({ ok: true });
  }
  if (b.action === "extend") {
    const days = b.durationDays == null ? null : Number(b.durationDays);
    if (days !== null && (!Number.isFinite(days) || days <= 0)) return err(400, "مدة التمديد غير صالحة");
    const row = (await q(env, "SELECT expires_at FROM subscribers WHERE id=? LIMIT 1", [nm(id)])).rows[0];
    if (!row) return err(404, "المشترك غير موجود");
    const now = Date.now(), curExp = Number(row.expires_at || 0);
    const nextExp = days !== null ? Math.max(now, curExp) + Math.round(days) * 864e5 : null;
    await q(env, "UPDATE subscribers SET expires_at=?,is_active=1 WHERE id=?", [nextExp !== null ? nm(nextExp) : { type: "null" }, nm(id)]);
    return json({ ok: true, expiresAt: nextExp });
  }
  if (b.action === "reset_password") {
    const np = typeof b.newPassword === "string" ? b.newPassword : "";
    if (np.length < 4) return err(400, "كلمة المرور يجب أن تكون 4 أحرف على الأقل");
    await q(env, "UPDATE subscribers SET password_hash=? WHERE id=?", [tx(await hashPw(np)), nm(id)]);
    await q(env, "DELETE FROM subscriber_sessions WHERE subscriber_id=?", [nm(id)]);
    return json({ ok: true });
  }
  return err(400, "إجراء غير مدعوم");
}

async function initDb(env) {
  if (schemaReady) return;
  await qBatch(env, [
    "CREATE TABLE IF NOT EXISTS subscribers(id INTEGER PRIMARY KEY AUTOINCREMENT,full_name TEXT NOT NULL,office_name TEXT NOT NULL DEFAULT '',phone TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,is_active INTEGER NOT NULL DEFAULT 1,expires_at INTEGER,notes TEXT NOT NULL DEFAULT '',created_at INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS app_admin_config(config_key TEXT PRIMARY KEY,config_value TEXT NOT NULL,updated_at INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS subscriber_sessions(token_hash TEXT PRIMARY KEY,subscriber_id INTEGER NOT NULL,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS admin_sessions(token_hash TEXT PRIMARY KEY,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL)"
  ]);
  schemaReady = true;
}

const q = (env, sql, args = []) => qBatch(env, [{ sql, args }]).then((a) => a[0]);

async function qBatch(env, stmts) {
  const u = tursoUrl(env.TURSO_DATABASE_URL), tok = clean(env.TURSO_AUTH_TOKEN);
  if (!u || !tok) throw new TursoErr(503, "إعدادات TURSO_DATABASE_URL أو TURSO_AUTH_TOKEN غير صالحة");
  let resp;
  try {
    resp = await fetch(u, {
      method: "POST",
      headers: { Authorization: `Bearer ${tok}`, "Content-Type": "application/json" },
      body: JSON.stringify({ requests: [...stmts.map((s) => typeof s === "string" ? { type: "execute", stmt: { sql: s, args: [] } } : { type: "execute", stmt: s }), { type: "close" }] })
    });
  } catch { throw new TursoErr(502, "تعذر الوصول إلى خادم Turso: تأكد من TURSO_DATABASE_URL"); }
  if (!resp.ok) {
    if (resp.status === 401) throw new TursoErr(502, "رفض توكن Turso (401): تأكد من TURSO_AUTH_TOKEN أو ولّد توكن Read & Write جديد.");
    if (resp.status === 403) throw new TursoErr(502, "صلاحيات Turso غير كافية (403): التوكن يحتاج Read & Write.");
    if (resp.status === 404) throw new TursoErr(502, "قاعدة Turso غير موجودة (404): تأكد من TURSO_DATABASE_URL.");
    throw new TursoErr(502, `خطأ من خادم Turso (${resp.status})`);
  }
  const data = await resp.json();
  if (!Array.isArray(data.results) || data.results.length < stmts.length) {
    throw new TursoErr(502, "استجابة فارغة أو ناقصة من قاعدة بيانات Turso");
  }
  return data.results.slice(0, stmts.length).map((r) => {
    if (r.type === "error") {
      const m = String(r.error?.message || "");
      if (m.toLowerCase().includes("readonly")) throw new TursoErr(502, "توكن Turso للقراءة فقط: استخدم توكن Read & Write.");
      throw new Error(m || "Turso query error");
    }
    const res = r.response?.result || {}, cols = (res.cols || []).map((c, i) => c.name || `c${i}`);
    const rows = (res.rows || []).map((arr) => Object.fromEntries(cols.map((c, i) => [c, !arr[i] || arr[i].type === "null" ? null : arr[i].value ?? null])));
    return { rows, affectedRows: Number(res.affected_row_count || 0), lastInsertRowId: res.last_insert_rowid ? Number(res.last_insert_rowid) : null };
  });
}

function clean(s) {
  if (typeof s !== "string") return "";
  let c = s.trim();
  if ((c.startsWith('"') && c.endsWith('"')) || (c.startsWith("'") && c.endsWith("'"))) c = c.slice(1, -1).trim();
  return c.replace(/[\r\n\t]+/g, "");
}

function tursoUrl(raw) {
  let s = clean(raw).replace(/\/+$/, "");
  if (!s) return null;
  s = /^libsql:\/\//i.test(s) ? "https://" + s.slice(9) : (!/^https?:\/\//i.test(s) ? "https://" + s : s);
  s = s.replace(/\/v2\/pipeline$/i, "").replace(/\/+$/, "");
  try { return new URL(`${s}/v2/pipeline`).toString(); } catch { return null; }
}

const tx = (v) => ({ type: "text", value: String(v) });
const nm = (v) => ({ type: "integer", value: String(Math.trunc(Number(v))) });
const adminHash = async (env) => (await q(env, "SELECT config_value FROM app_admin_config WHERE config_key=? LIMIT 1", [tx(ADMIN_KEY)])).rows[0]?.config_value || null;

async function newAdminSess(env) {
  const t = randTok(), now = Date.now();
  await q(env, "INSERT INTO admin_sessions(token_hash,expires_at,created_at) VALUES(?,?,?)", [tx(await sha(t)), nm(now + ADM_TTL), nm(now)]);
  return t;
}

async function checkAdmin(req, env) {
  const b = bearer(req);
  if (!b) return false;
  const h = await sha(b), row = (await q(env, "SELECT expires_at FROM admin_sessions WHERE token_hash=? LIMIT 1", [tx(h)])).rows[0];
  if (!row) return false;
  if (Date.now() > Number(row.expires_at || 0)) { await q(env, "DELETE FROM admin_sessions WHERE token_hash=?", [tx(h)]); return false; }
  return true;
}

async function hashPw(pw) {
  const s = crypto.getRandomValues(new Uint8Array(16));
  return `10000:${hex(s)}:${hex(await pbkdf2(pw, s, 10000))}`;
}

async function verifyPw(pw, stored) {
  const p = String(stored || "").split(":");
  if (p.length !== 3) return false;
  const it = Number(p[0]), s = unhex(p[1]), ex = unhex(p[2]);
  if (!Number.isInteger(it) || it < 1000 || !s || !ex) return false;
  return eqBytes(await pbkdf2(pw, s, it, ex.length * 8), ex);
}

async function pbkdf2(pw, salt, it, bits = 256) {
  const k = await crypto.subtle.importKey("raw", TE.encode(pw), "PBKDF2", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: it, hash: "SHA-256" }, k, bits));
}

const randTok = () => hex(crypto.getRandomValues(new Uint8Array(32)));
const sha = async (s) => hex(new Uint8Array(await crypto.subtle.digest("SHA-256", TE.encode(s))));
const eqBytes = (a, b) => a.length === b.length && a.reduce((d, v, i) => d | (v ^ b[i]), 0) === 0;
const hex = (b) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
const unhex = (h) => {
  if (typeof h !== "string" || h.length % 2) return null;
  const o = new Uint8Array(h.length / 2);
  for (let i = 0; i < o.length; i++) { const n = parseInt(h.slice(i * 2, i * 2 + 2), 16); if (Number.isNaN(n)) return null; o[i] = n; }
  return o;
};
const normPhone = (r) => String(r || "").trim().replace(/\s+/g, "").replace(/[٠-٩]/g, (c) => "٠١٢٣٤٥٦٧٨٩".indexOf(c)).replace(/[۰-۹]/g, (c) => "۰۱۲۳۴۵۶۷۸۹".indexOf(c));
const toSub = (r) => ({ id: Number(r.id || 0), fullName: r.full_name || "", officeName: r.office_name || "", phone: r.phone || "", isActive: Number(r.is_active || 0) === 1, expiresAt: r.expires_at != null ? Number(r.expires_at) : null, notes: r.notes || "", createdAt: Number(r.created_at || 0) });
const bearer = (req) => (req.headers.get("Authorization") || "").match(/^Bearer\s+(.+)$/i)?.[1]?.trim() || null;
const bodyJson = async (req) => { try { return await req.json(); } catch { return null; } };
const json = (d, status = 200) => new Response(JSON.stringify(d), { status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" } });
const err = (status, message) => json({ error: message }, status);
