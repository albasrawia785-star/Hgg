# خادم Cloudflare Worker المجاني لقاعدة بيانات Turso

هذا الخادم يعمل مجاناً بالكامل (حتى 100,000 طلب يومياً) ويحفظ رابط وتوكن قاعدة بيانات **Turso** على خوادم Cloudflare فقط، بحيث لا يحتوي تطبيق الأندرويد (APK) على أي توكن أو مفتاح سري نهائياً.

## خطوات التشغيل السريعة (بدون بطاقة بنكية)

1. أنشئ حساباً مجانياً على [dash.cloudflare.com](https://dash.cloudflare.com).
2. من القائمة الجانبية اختر **Workers & Pages** ثم **Create** ← **Create Worker**.
3. سمّ الـ Worker (مثلاً `uqud-pro-api`) ثم اضغط **Deploy**.
4. اضغط **Edit code**، واحذف الكود الافتراضي، والصق كامل محتوى الملف `cloudflare-worker/worker.js` ثم اضغط **Deploy**.
5. افتح تبويب **Settings** ← **Variables and Secrets** داخل الـ Worker وأضف المتغيرين التاليين كـ **Secret**:
   - `TURSO_DATABASE_URL` = رابط قاعدة البيانات (`libsql://...`)
   - `TURSO_AUTH_TOKEN` = رمز التوكن الخاص بـ Turso (`eyJ...`)
6. انسخ رابط الـ Worker الذي يظهر في أعلى الصفحة (مثل `https://uqud-pro-api.yourname.workers.dev`).
7. ضع هذا الرابط العام داخل ملف `app/build.gradle.kts` في السطر الخاص بـ `TURSO_PROXY_URL` (أو أرسله هنا ليتم ربطه وبناء التطبيق).

> ملاحظة: يُنصح بعد إتمام الربط بتوليد توكن جديد في Turso وحذف التوكن القديم الذي شاركته سابقاً في المحادثة.
