package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Patient
import com.example.ui.components.AppTopBar
import com.example.ui.theme.AmberBorder
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberText
import com.example.ui.theme.GreenBorder
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

enum class QueueFilter(val label: String) {
    ALL("الكل"),
    WAITING("في الانتظار"),
    POSTPONED("المؤجلين"),
    CALLED("تم الاستدعاء")
}

@Composable
fun QueueListScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val patients by viewModel.patients.collectAsState()
    val currentPatient by viewModel.currentPatient.collectAsState()
    val showAddDialog by viewModel.showAddPatientDialog.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val previewPatient by viewModel.previewTicketPatient.collectAsState()

    var selectedFilter by remember { mutableStateOf(QueueFilter.ALL) }

    val filteredPatients = when (selectedFilter) {
        QueueFilter.ALL -> patients
        QueueFilter.WAITING -> patients.filter { !it.isPostponed && !it.isCalled }
        QueueFilter.POSTPONED -> patients.filter { it.isPostponed }
        QueueFilter.CALLED -> patients.filter { !it.isPostponed && it.isCalled }
    }

    val nextNumber = if (patients.isEmpty()) 1 else (patients.maxOf { it.queueNumber } + 1)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Bar
            AppTopBar(
                title = "قائمة المراجعين",
                subtitle = "إجمالي المراجعين: ${patients.size}",
                showBackButton = true,
                showMenuButton = false,
                showSettingsButton = false,
                onBackClick = { viewModel.navigateBack() }
            )

            // Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(QueueFilter.values()) { filter ->
                    val isSelected = selectedFilter == filter
                    val count = when (filter) {
                        QueueFilter.ALL -> patients.size
                        QueueFilter.WAITING -> patients.count { !it.isPostponed && !it.isCalled }
                        QueueFilter.POSTPONED -> patients.count { it.isPostponed }
                        QueueFilter.CALLED -> patients.count { !it.isPostponed && it.isCalled }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NavyDark else Color.White)
                            .border(
                                1.dp,
                                if (isSelected) NavyDark else Color(0xFFE2E8F0),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedFilter = filter }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = filter.label,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (isSelected) Color.White.copy(alpha = 0.2f) else Color(0xFFF1F5F9))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "$count",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            if (filteredPatients.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(NavyDark.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonOutline,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد نتائج في هذا التصنيف",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "اضغط على تصنيف آخر أو أضف مراجع جديد",
                            fontSize = 13.sp,
                            color = TextMuted
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredPatients, key = { it.id }) { patient ->
                        val isCurrent = !patient.isPostponed && patient.queueNumber == (currentPatient?.queueNumber ?: -1)

                        PatientListItem(
                            patient = patient,
                            isCurrent = isCurrent,
                            onClick = {
                                if (patient.isPostponed) {
                                    viewModel.onRecallPostponedPatient(patient)
                                } else {
                                    viewModel.onCallSpecificPatient(patient)
                                }
                            },
                            onPreviewClick = {
                                viewModel.onOpenTicketPreview(patient)
                            },
                            onRestoreClick = {
                                viewModel.onRestorePostponedToQueue(patient)
                            }
                        )
                    }
                }
            }

            // Bottom Navigation Bar
            BottomNavBar(
                activeScreen = AppScreen.QUEUE_LIST,
                onHomeClick = { viewModel.navigateTo(AppScreen.HOME) },
                onQueueClick = { /* Already here */ },
                onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
            )
        }

        // Floating Action Button to add patient
        FloatingActionButton(
            onClick = { viewModel.onAddPatientClicked() },
            containerColor = NavyDark,
            contentColor = TextOnNavy,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 76.dp, end = 20.dp)
                .testTag("fab_add_patient")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة مراجع",
                modifier = Modifier.size(24.dp)
            )
        }
    }

    if (showAddDialog) {
        AddPatientDialog(
            nextQueueNumber = nextNumber,
            initialAutoPrint = settings.autoPrintOnAdd,
            onConfirm = { name, note, shouldPrint ->
                viewModel.onConfirmAddPatient(name, note, shouldPrint)
            },
            onDismiss = { viewModel.onDismissAddPatientDialog() }
        )
    }

    if (previewPatient != null) {
        TicketPreviewDialog(
            patient = previewPatient!!,
            settings = settings,
            onPrintClick = { viewModel.onPrintPreviewTicket() },
            onDismiss = { viewModel.onDismissTicketPreview() }
        )
    }
}

@Composable
fun PatientListItem(
    patient: Patient,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onPreviewClick: () -> Unit,
    onRestoreClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(
                width = if (isCurrent) 1.5.dp else if (patient.isPostponed) 1.dp else 1.dp,
                color = if (isCurrent) NavyDark else if (patient.isPostponed) AmberBorder else Color(0xFFF1F5F9),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("patient_item_${patient.queueNumber}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Leading Icon Box
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isCurrent) NavyDark.copy(alpha = 0.08f)
                            else if (patient.isPostponed) AmberContainer
                            else Color(0xFFF8FAFC)
                        )
                        .border(
                            1.dp,
                            if (patient.isPostponed) AmberBorder else Color(0xFFF1F5F9),
                            RoundedCornerShape(12.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (patient.isPostponed) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = AmberText,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        Icon(
                            imageVector = if (isCurrent) Icons.Default.VolumeUp else Icons.Default.PersonOutline,
                            contentDescription = null,
                            tint = if (isCurrent) NavyDark else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "المراجع رقم ${patient.formattedNumber}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        if (patient.name.isNotBlank()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "- ${patient.name}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                    }
                    if (patient.note.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ملاحظة: ${patient.note}",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (patient.isPostponed) "مؤجل (لم يحضر عند النداء)"
                        else if (isCurrent) "المراجع الحالي (نشط)"
                        else if (patient.isCalled) "تم الاستدعاء"
                        else "في الانتظار",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (patient.isPostponed) AmberText
                        else if (isCurrent) NavyDark
                        else if (patient.isCalled) GreenText
                        else TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Actions: Preview Ticket Icon & Status Badge or Re-queue
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (patient.isPostponed) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF1F5F9))
                            .clickable { onRestoreClick() }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "إعادة للدور",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        }
                    }
                } else {
                    IconButton(
                        onClick = onPreviewClick,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = "معاينة الوصل",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    if (isCurrent) {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(GreenContainer)
                                .border(1.dp, GreenBorder, CircleShape)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "نشط الآن",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GreenText
                            )
                        }
                    } else if (patient.isCalled) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF1F5F9)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "تم الاستدعاء",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
