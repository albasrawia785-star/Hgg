package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AnnouncementManager
import com.example.audio.CallingState
import com.example.bluetooth.AudioRouteManager
import com.example.bluetooth.BluetoothDeviceManager
import com.example.bluetooth.printer.PrinterManager
import com.example.data.model.BluetoothDeviceInfo
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import com.example.data.repository.QueueRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppScreen {
    HOME,
    QUEUE_LIST,
    DEVICE_SETTINGS,
    CHOOSE_PRINTER,
    CHOOSE_SPEAKER,
    CALLING_ACTIVE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = QueueRepository(application)
    val bluetoothDeviceManager = BluetoothDeviceManager(application)
    val printerManager = PrinterManager(application)
    val audioRouteManager = AudioRouteManager(application)
    val announcementManager = AnnouncementManager(application, audioRouteManager)

    private val _currentScreen = MutableStateFlow(AppScreen.QUEUE_LIST)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val backStack = mutableListOf(AppScreen.QUEUE_LIST)

    val patients: StateFlow<List<Patient>> = repository.patients
    val currentPatient: StateFlow<Patient?> = repository.currentPatient
    val settings: StateFlow<SystemSettings> = repository.settings

    val postponedPatients: StateFlow<List<Patient>> = patients
        .map { list -> list.filter { it.isPostponed } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val activeWaitingPatients: StateFlow<List<Patient>> = patients
        .map { list -> list.filter { !it.isPostponed && !it.isCalled } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val callingState: StateFlow<CallingState> = announcementManager.callingState
    val activeCallingPatient: StateFlow<Patient?> = announcementManager.activeCallingPatient

    private val _showResetDialog = MutableStateFlow(false)
    val showResetDialog: StateFlow<Boolean> = _showResetDialog.asStateFlow()

    private val _showAddPatientDialog = MutableStateFlow(false)
    val showAddPatientDialog: StateFlow<Boolean> = _showAddPatientDialog.asStateFlow()

    private val _showPostponedSheet = MutableStateFlow(false)
    val showPostponedSheet: StateFlow<Boolean> = _showPostponedSheet.asStateFlow()

    private val _previewTicketPatient = MutableStateFlow<Patient?>(null)
    val previewTicketPatient: StateFlow<Patient?> = _previewTicketPatient.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _currentTimeFormatted = MutableStateFlow("")
    val currentTimeFormatted: StateFlow<String> = _currentTimeFormatted.asStateFlow()

    private val _currentDateFormatted = MutableStateFlow("")
    val currentDateFormatted: StateFlow<String> = _currentDateFormatted.asStateFlow()

    private val _isTestingAudio = MutableStateFlow(false)
    val isTestingAudio: StateFlow<Boolean> = _isTestingAudio.asStateFlow()

    private var callingJob: Job? = null
    private var testAudioJob: Job? = null

    init {
        updateTimeAndDate()
    }

    fun updateTimeAndDate() {
        val now = Date()
        val timeFmt = SimpleDateFormat("hh:mm a", Locale.US)
        val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        _currentTimeFormatted.value = timeFmt.format(now)
        _currentDateFormatted.value = dateFmt.format(now)
    }

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            backStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (backStack.size > 1) {
            backStack.removeAt(backStack.size - 1)
            _currentScreen.value = backStack.last()
            return true
        }
        return false
    }

    fun onAddPatientClicked() {
        _showAddPatientDialog.value = true
    }

    fun onDismissAddPatientDialog() {
        _showAddPatientDialog.value = false
    }

    fun onOpenPostponedSheet() {
        _showPostponedSheet.value = true
    }

    fun onDismissPostponedSheet() {
        _showPostponedSheet.value = false
    }

    fun onConfirmAddPatient(name: String, note: String, shouldPrint: Boolean) {
        viewModelScope.launch {
            updateTimeAndDate()
            val newPatient = repository.addPatient(name = name, note = note)

            if (shouldPrint) {
                val currentSettings = settings.value
                val success = printerManager.printTicket(
                    patient = newPatient,
                    settings = currentSettings,
                    paperSize = currentSettings.paperSize
                )
                if (success) {
                    _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber} وطباعة الوصل"
                } else {
                    _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber} (لم تتم الطباعة - تأكد من اتصال الطابعة)"
                }
            } else {
                _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber}"
            }
        }
    }

    /**
     * استدعاء المراجع الحالي في نفس الشاشة دون الانتقال لشاشة منفصلة
     */
    fun onCallCurrentPatientClicked() {
        val patientToCall = repository.callCurrentPatient()
        if (patientToCall == null) {
            _toastMessage.value = "القائمة فارغة. يرجى إضافة مراجع أولاً."
            return
        }

        callingJob?.cancel()
        callingJob = viewModelScope.launch {
            announcementManager.announcePatient(patientToCall, settings.value)
        }
    }

    /**
     * استدعاء المراجع التالي والانتقال إليه مباشرة
     */
    fun onCallNextPatientClicked() {
        val nextPatient = repository.callNextPatient()
        if (nextPatient == null) {
            _toastMessage.value = "لا يوجد مراجعين حالياً"
            return
        }

        callingJob?.cancel()
        callingJob = viewModelScope.launch {
            announcementManager.announcePatient(nextPatient, settings.value)
        }
        _toastMessage.value = "تم استدعاء المراجع التالي رقم ${nextPatient.formattedNumber}"
    }

    /**
     * إعادة استدعاء المراجع الحالي
     */
    fun onRecallCurrentPatient() {
        val current = currentPatient.value ?: return
        callingJob?.cancel()
        callingJob = viewModelScope.launch {
            announcementManager.announcePatient(current, settings.value)
        }
    }

    /**
     * تأجيل المراجع الحالي وإضافته لقائمة المؤجلين ثم الانتقال للتالي تلقائياً
     */
    fun onPostponeCurrentPatient() {
        val (postponed, next) = repository.postponeCurrentPatient()
        if (postponed != null) {
            callingJob?.cancel()
            announcementManager.resetState()
            if (next != null) {
                _toastMessage.value = "تم تأجيل المراجع ${postponed.formattedNumber} وتعيين المراجع ${next.formattedNumber}"
            } else {
                _toastMessage.value = "تم نقل المراجع رقم ${postponed.formattedNumber} إلى قائمة المؤجلين"
            }
        } else {
            _toastMessage.value = "لا يوجد مراجع حالي لتأجيله"
        }
    }

    /**
     * تأجيل مراجع محدد من القائمة
     */
    fun onPostponeSpecificPatient(patient: Patient) {
        val postponed = repository.postponePatient(patient)
        callingJob?.cancel()
        announcementManager.resetState()
        _toastMessage.value = "تم تأجيل المراجع رقم ${postponed.formattedNumber}"
    }

    /**
     * استدعاء مراجع مؤجل مباشرة
     */
    fun onRecallPostponedPatient(patient: Patient) {
        val reactivated = repository.recallPostponedPatient(patient)
        callingJob?.cancel()
        callingJob = viewModelScope.launch {
            announcementManager.announcePatient(reactivated, settings.value)
        }
        _toastMessage.value = "تم استدعاء المراجع المؤجل رقم ${reactivated.formattedNumber}"
    }

    /**
     * إعادة المراجع المؤجل إلى قائمة الانتظار
     */
    fun onRestorePostponedToQueue(patient: Patient) {
        repository.restorePostponedToQueue(patient)
        _toastMessage.value = "تمت إعادة المراجع رقم ${patient.formattedNumber} إلى قائمة الانتظار"
    }

    /**
     * حذف مراجع
     */
    fun onDeletePatient(patient: Patient) {
        repository.deletePatient(patient)
        _toastMessage.value = "تم حذف المراجع رقم ${patient.formattedNumber}"
    }

    fun onCallSpecificPatient(patient: Patient) {
        repository.selectPatient(patient)
        onCallCurrentPatientClicked()
    }

    fun onCallNextPatientFromCallingScreen() {
        val nextPatient = repository.callNextPatient() ?: return
        callingJob?.cancel()
        callingJob = viewModelScope.launch {
            announcementManager.announcePatient(nextPatient, settings.value)
        }
    }

    fun onDismissCallingScreen() {
        callingJob?.cancel()
        announcementManager.resetState()
        navigateBack()
    }

    fun onOpenResetDialog() {
        _showResetDialog.value = true
    }

    fun onDismissResetDialog() {
        _showResetDialog.value = false
    }

    fun onConfirmResetQueue() {
        repository.resetQueue()
        _showResetDialog.value = false
        _toastMessage.value = "تم تصفير قائمة المراجعين بنجاح"
    }

    fun onOpenTicketPreview(patient: Patient) {
        _previewTicketPatient.value = patient
    }

    fun onDismissTicketPreview() {
        _previewTicketPatient.value = null
    }

    fun onPrintPreviewTicket() {
        val patient = _previewTicketPatient.value ?: return
        viewModelScope.launch {
            val success = printerManager.printTicket(
                patient = patient,
                settings = settings.value,
                paperSize = settings.value.paperSize
            )
            if (success) {
                _toastMessage.value = "تمت طباعة التذكرة بنجاح"
            }
        }
    }

    // Clinic and Doctor Settings
    fun onClinicNameChanged(name: String) {
        repository.updateSettings(settings.value.copy(clinicName = name))
    }

    fun onDoctorNameChanged(name: String) {
        repository.updateSettings(settings.value.copy(doctorName = name))
    }

    fun onClinicPhoneChanged(phone: String) {
        repository.updateSettings(settings.value.copy(clinicPhone = phone))
    }

    fun onFooterMessageChanged(msg: String) {
        repository.updateSettings(settings.value.copy(footerMessage = msg))
    }

    fun onPaperSizeChanged(size: PaperSize) {
        repository.updateSettings(settings.value.copy(paperSize = size))
    }

    fun onToggleAutoPrint(enabled: Boolean) {
        repository.updateSettings(settings.value.copy(autoPrintOnAdd = enabled))
    }

    // Audio Control Methods
    fun onSpeechRateChanged(rate: Float) {
        repository.updateSettings(settings.value.copy(speechRate = rate))
    }

    fun onPitchChanged(pitch: Float) {
        repository.updateSettings(settings.value.copy(pitch = pitch))
    }

    fun onVolumeChanged(volume: Float) {
        repository.updateSettings(settings.value.copy(volume = volume))
    }

    fun onToggleChime(enabled: Boolean) {
        repository.updateSettings(settings.value.copy(enableChime = enabled))
    }

    fun onCallPhraseChanged(phrase: String) {
        repository.updateSettings(settings.value.copy(callPhrase = phrase))
    }

    fun onTestAudio() {
        testAudioJob?.cancel()
        testAudioJob = viewModelScope.launch {
            _isTestingAudio.value = true
            announcementManager.testAnnouncement(settings.value)
            _isTestingAudio.value = false
        }
    }

    fun onResetAudioDefaults() {
        repository.updateSettings(
            settings.value.copy(
                speechRate = 0.85f,
                pitch = 1.0f,
                volume = 1.0f,
                enableChime = true,
                callPhrase = "المُراجِع رَقْم %s"
            )
        )
        _toastMessage.value = "تمت استعادة إعدادات الصوت الافتراضية"
    }

    fun onSelectPrinter(device: BluetoothDeviceInfo) {
        viewModelScope.launch {
            val btDevice = bluetoothDeviceManager.getDevice(device.address)
            if (btDevice != null) {
                _toastMessage.value = "جاري الاتصال بالطابعة ${device.name}..."
                val success = printerManager.connectPrinter(btDevice)
                if (success) {
                    repository.updateSettings(
                        settings.value.copy(
                            selectedPrinterName = device.name,
                            selectedPrinterAddress = device.address
                        )
                    )
                    _toastMessage.value = "تم الاتصال بالطابعة ${device.name} بنجاح"
                    navigateBack()
                } else {
                    _toastMessage.value = "فشل الاتصال بالطابعة ${device.name}. تأكد من تشغيلها واقترانها."
                }
            } else {
                _toastMessage.value = "تعذر العثور على عنوان جهاز الطابعة"
            }
        }
    }

    fun onDisconnectPrinter() {
        viewModelScope.launch {
            printerManager.disconnectPrinter()
            repository.updateSettings(
                settings.value.copy(
                    selectedPrinterName = "",
                    selectedPrinterAddress = ""
                )
            )
            _toastMessage.value = "تم قطع الاتصال بالطابعة"
        }
    }

    fun onSelectSpeaker(device: BluetoothDeviceInfo) {
        audioRouteManager.connectSpeaker(device.name, device.address)
        repository.updateSettings(
            settings.value.copy(
                selectedSpeakerName = device.name,
                selectedSpeakerAddress = device.address
            )
        )
        _toastMessage.value = "تم تحديد وتحويل الصوت إلى السماعة ${device.name}"
        navigateBack()
    }

    fun onDisconnectSpeaker() {
        audioRouteManager.disconnectSpeaker()
        repository.updateSettings(
            settings.value.copy(
                selectedSpeakerName = "",
                selectedSpeakerAddress = ""
            )
        )
        _toastMessage.value = "تم قطع الاتصال بالسماعة والتحويل إلى سماعة الهاتف"
    }

    fun clearToastMessage() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        announcementManager.shutdown()
    }
}
