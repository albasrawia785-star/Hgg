package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.example.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

class ChimePlayer(private val context: Context) {

    /**
     * Plays the embedded hospital chime alert tone from raw resource (res/raw/chime.wav)
     * using standard MediaPlayer with safety timeout.
     */
    suspend fun playChime(): Boolean = withContext(Dispatchers.IO) {
        val result = withTimeoutOrNull(2500L) {
            suspendCancellableCoroutine { continuation ->
                var mediaPlayer: MediaPlayer? = null
                try {
                    mediaPlayer = MediaPlayer().apply {
                        val audioAttributes = AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()

                        setAudioAttributes(audioAttributes)

                        val afd = context.resources.openRawResourceFd(R.raw.chime)
                        if (afd == null) {
                            release()
                            if (continuation.isActive) {
                                continuation.resume(false)
                            }
                            return@suspendCancellableCoroutine
                        }

                        setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                        afd.close()

                        setOnCompletionListener { mp ->
                            try {
                                mp.stop()
                                mp.release()
                            } catch (_: Exception) {}
                            if (continuation.isActive) {
                                continuation.resume(true)
                            }
                        }

                        setOnErrorListener { mp, _, _ ->
                            try {
                                mp.stop()
                                mp.release()
                            } catch (_: Exception) {}
                            if (continuation.isActive) {
                                continuation.resume(false)
                            }
                            true
                        }

                        setOnPreparedListener { mp ->
                            try {
                                mp.start()
                            } catch (_: Exception) {
                                if (continuation.isActive) {
                                    continuation.resume(false)
                                }
                            }
                        }

                        prepareAsync()
                    }

                    continuation.invokeOnCancellation {
                        try {
                            mediaPlayer?.let {
                                if (it.isPlaying) {
                                    it.stop()
                                }
                                it.release()
                            }
                        } catch (_: Exception) {}
                    }
                } catch (e: Exception) {
                    try {
                        mediaPlayer?.release()
                    } catch (_: Exception) {}
                    if (continuation.isActive) {
                        continuation.resume(false)
                    }
                }
            }
        }
        result ?: false
    }
}

