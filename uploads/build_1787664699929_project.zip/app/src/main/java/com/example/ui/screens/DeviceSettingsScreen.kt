package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaperSize
import com.example.ui.components.AppTopBar
import com.example.ui.theme.GreenBorder
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedBorder
import com.example.ui.theme.RedContainer
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

/**
 * شاشة الإعدادات المنظمة بتصميم الأقسام التفاعلية (Accordion / Expandable Sections)
 * - بدون ظهور بيانات العيادة
 * - أقسام منظمة تفتح وتغلق عند الضغط عليها
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DeviceSettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    val isPrinterConnected by viewModel.printerManager.isConnected.collectAsState()
    val printerName by viewModel.printerManager.connectedDeviceName.collectAsState()
    val isSpeakerConnected by viewModel.audioRouteManager.isSpeakerConnected.collectAsState()
    val speakerName by viewModel.audioRouteManager.connectedSpeakerName.collectAsState()
    val isTestingAudio by viewModel.isTestingAudio.collectAsState()

    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    // حالات فتح وإغلاق الأقسام (Expandable State)
    var isBluetoothSectionOpen by remember { mutableStateOf(false) }
    var isAudioSectionOpen by remember { mutableStateOf(true) } // افتراضياً مفتوح أو حسب الضغط
    var isPrintSectionOpen by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Top Bar
        AppTopBar(
            title = "لوحة الإعدادات",
            subtitle = "التحكم في الصوت، البلوتوث، والطباعة",
            showBackButton = true,
            showMenuButton = false,
            showSettingsButton = false,
            onBackClick = { viewModel.navigateBack() }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {

            // ==========================================
            // 1. قسم إعدادات التحكم في الصوت والنداء (Audio & Voice Call)
            // ==========================================
            SettingsAccordionCard(
                title = "إعدادات التحكم في الصوت والنداء",
                subtitle = "نبرة الصوت، السرعة، النغمة، وقالب النداء",
                icon = Icons.Default.Tune,
                isOpen = isAudioSectionOpen,
                onToggle = { isAudioSectionOpen = !isAudioSectionOpen },
                statusBadge = "${(settings.volume * 100).toInt()}% صوت"
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Header with title & reset button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "خصائص محرك النطق الآلي (TTS)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )

                        // زر استعادة الإعدادات الافتراضية
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF1F5F9))
                                .clickable { viewModel.onResetAudioDefaults() }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "استعادة الافتراضي",
                                tint = TextSecondary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "افتراضي",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 1.1 نغمة التنبيه قبل النداء (Chime)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF8FAFC))
                            .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(if (settings.enableChime) NavyDark.copy(alpha = 0.1f) else Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = if (settings.enableChime) NavyDark else TextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "نغمة التنبيه قبل النداء (Chime)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyDark
                                )
                                Text(
                                    text = "تشغيل جرس تنبيه قبل نطق رقم المراجع",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                        Switch(
                            checked = settings.enableChime,
                            onCheckedChange = { viewModel.onToggleChime(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = NavyDark,
                                uncheckedTrackColor = Color(0xFFE2E8F0)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 1.2 سرعة النطق (Speed)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "سرعة نطق الصوت",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                        Text(
                            text = "${String.format(java.util.Locale.US, "%.2f", settings.speechRate)}x",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                    Slider(
                        value = settings.speechRate,
                        onValueChange = { viewModel.onSpeechRateChanged(it) },
                        valueRange = 0.5f..1.5f,
                        steps = 9,
                        colors = SliderDefaults.colors(
                            thumbColor = NavyDark,
                            activeTrackColor = NavyDark,
                            inactiveTrackColor = Color(0xFFE2E8F0)
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // 1.3 طبقة الصوت (Pitch)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "طبقة الصوت (Pitch)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                        Text(
                            text = "${String.format(java.util.Locale.US, "%.2f", settings.pitch)}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                    Slider(
                        value = settings.pitch,
                        onValueChange = { viewModel.onPitchChanged(it) },
                        valueRange = 0.6f..1.4f,
                        steps = 8,
                        colors = SliderDefaults.colors(
                            thumbColor = NavyDark,
                            activeTrackColor = NavyDark,
                            inactiveTrackColor = Color(0xFFE2E8F0)
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // 1.4 شدة الصوت (Volume)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مستوى شدة الصوت",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                        Text(
                            text = "${(settings.volume * 100).toInt()}%",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                    Slider(
                        value = settings.volume,
                        onValueChange = { viewModel.onVolumeChanged(it) },
                        valueRange = 0.1f..1.0f,
                        steps = 9,
                        colors = SliderDefaults.colors(
                            thumbColor = NavyDark,
                            activeTrackColor = NavyDark,
                            inactiveTrackColor = Color(0xFFE2E8F0)
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 1.5 صيغة النداء الصوتي
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = NavyDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "صيغة النداء الصوتي",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "استخدم رمز %s ليتم استبداله برقم المراجع آلياً",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = settings.callPhrase,
                        onValueChange = { viewModel.onCallPhraseChanged(it) },
                        placeholder = { Text("المُراجِع رَقْم %s", fontSize = 13.sp, color = TextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFFF8FAFC),
                            unfocusedContainerColor = Color(0xFFF8FAFC),
                            focusedBorderColor = NavyDark,
                            unfocusedBorderColor = Color(0xFFE2E8F0)
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // صيغ مقترحة سريعة
                    Text(
                        text = "صيغ سريعة جاهزة:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val phrases = listOf(
                            "المُراجِع رَقْم %s",
                            "الرَقْم %s",
                            "تَذْكِرَة رَقْم %s",
                            "دَوْر رَقْم %s"
                        )
                        phrases.forEach { phrase ->
                            val isSelected = settings.callPhrase == phrase
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NavyDark else Color(0xFFF1F5F9))
                                    .clickable { viewModel.onCallPhraseChanged(phrase) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = phrase,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else NavyDark
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // زر تجربة الصوت
                    Button(
                        onClick = { viewModel.onTestAudio() },
                        enabled = !isTestingAudio,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("test_audio_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                    ) {
                        if (isTestingAudio) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "جاري تشغيل الصوت التجريبي...",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تجربة إعدادات الصوت والنداء الآن",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // ==========================================
            // 2. قسم أجهزة البلوتوث (Bluetooth Devices Hub)
            // ==========================================
            SettingsAccordionCard(
                title = "إعدادات أجهزة البلوتوث والاتصال",
                subtitle = "الطابعة الحرارية والسماعة الخارجية المقترنة",
                icon = Icons.Default.Bluetooth,
                isOpen = isBluetoothSectionOpen,
                onToggle = { isBluetoothSectionOpen = !isBluetoothSectionOpen },
                statusBadge = if (isPrinterConnected || isSpeakerConnected) "متصل" else "غير متصل"
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // بطاقة الطابعة الحرارية
                    DeviceSubCard(
                        icon = Icons.Default.Print,
                        categoryTag = "طابعة الإيصالات والوصولات",
                        title = "الطابعة الحرارية (Thermal Printer)",
                        deviceName = if (printerName.isNotBlank()) printerName else if (settings.selectedPrinterName.isNotBlank()) settings.selectedPrinterName else "لم يتم تعيين طابعة بعد",
                        deviceAddress = settings.selectedPrinterAddress,
                        isConnected = isPrinterConnected,
                        selectButtonText = "اختيار أو تغيير الطابعة",
                        onSelectClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) },
                        onDisconnectClick = { viewModel.onDisconnectPrinter() }
                    )

                    // بطاقة السماعة الخارجية
                    DeviceSubCard(
                        icon = Icons.Default.VolumeUp,
                        categoryTag = "مخرج النداء الصوتي للمراجعين",
                        title = "السماعة الخارجية (Bluetooth Speaker)",
                        deviceName = if (speakerName.isNotBlank()) speakerName else if (settings.selectedSpeakerName.isNotBlank()) settings.selectedSpeakerName else "سماعة الهاتف الداخلية الافتراضية",
                        deviceAddress = settings.selectedSpeakerAddress,
                        isConnected = isSpeakerConnected,
                        selectButtonText = "اختيار أو تغيير السماعة",
                        onSelectClick = { viewModel.navigateTo(AppScreen.CHOOSE_SPEAKER) },
                        onDisconnectClick = { viewModel.onDisconnectSpeaker() }
                    )
                }
            }

            // ==========================================
            // 3. قسم إعدادات ورق الطباعة الحرارية (Printing & Paper)
            // ==========================================
            SettingsAccordionCard(
                title = "إعدادات ورق الطباعة الحرارية",
                subtitle = "تحديد مقاس رول الورق المستخدم (58mm أو 80mm)",
                icon = Icons.Default.ReceiptLong,
                isOpen = isPrintSectionOpen,
                onToggle = { isPrintSectionOpen = !isPrintSectionOpen },
                statusBadge = settings.paperSize.label
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "اختر المقاس المطابق لطابعتك لضبط هوامش الوصل بدقة:",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PaperSizeOption(
                            size = PaperSize.WIDTH_58MM,
                            isSelected = settings.paperSize == PaperSize.WIDTH_58MM,
                            onSelect = { viewModel.onPaperSizeChanged(PaperSize.WIDTH_58MM) },
                            modifier = Modifier.weight(1f)
                        )

                        PaperSizeOption(
                            size = PaperSize.WIDTH_80MM,
                            isSelected = settings.paperSize == PaperSize.WIDTH_80MM,
                            onSelect = { viewModel.onPaperSizeChanged(PaperSize.WIDTH_80MM) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Bottom Navigation Bar
        BottomNavBar(
            activeScreen = AppScreen.DEVICE_SETTINGS,
            onHomeClick = { viewModel.navigateTo(AppScreen.HOME) },
            onQueueClick = { viewModel.navigateTo(AppScreen.QUEUE_LIST) },
            onSettingsClick = { /* Already here */ }
        )
    }
}

/**
 * بطاقة إعداد قابلة للطي والفتح (Accordion Section)
 */
@Composable
fun SettingsAccordionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    isOpen: Boolean,
    onToggle: () -> Unit,
    statusBadge: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .border(
                1.dp,
                if (isOpen) NavyDark.copy(alpha = 0.3f) else Color(0xFFF1F5F9),
                RoundedCornerShape(18.dp)
            )
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header (Clickable row to toggle open/close)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isOpen) NavyDark else NavyDark.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (isOpen) Color.White else NavyDark,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = subtitle,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (statusBadge != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF1F5F9))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = statusBadge,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Icon(
                        imageVector = if (isOpen) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = if (isOpen) "إغلاق" else "فتح",
                        tint = NavyDark,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Animated Collapsible Content
            AnimatedVisibility(
                visible = isOpen,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 18.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFFF1F5F9))
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    content()
                }
            }
        }
    }
}

/**
 * بطاقة إعداد جهاز البلوتوث (طابعة أو سماعة) داخل القسم
 */
@Composable
fun DeviceSubCard(
    icon: ImageVector,
    categoryTag: String,
    title: String,
    deviceName: String,
    deviceAddress: String,
    isConnected: Boolean,
    selectButtonText: String,
    onSelectClick: () -> Unit,
    onDisconnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFF8FAFC))
            .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row: Icon + Title + Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(NavyDark.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = NavyDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = categoryTag,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextMuted
                        )
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                }

                // Status Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (isConnected) GreenContainer else Color(0xFFF1F5F9))
                        .border(
                            1.dp,
                            if (isConnected) GreenBorder else Color(0xFFE2E8F0),
                            CircleShape
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isConnected) GreenSuccess else TextMuted)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isConnected) "متصل" else "غير متصل",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isConnected) GreenText else TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // الجهاز المحدد
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "الجهاز المختار:",
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                        Text(
                            text = deviceName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                    if (deviceAddress.isNotBlank()) {
                        Text(
                            text = deviceAddress,
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // أزرار الاختيار وقطع الاتصال
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // زر الاختيار
                Button(
                    onClick = onSelectClick,
                    modifier = Modifier
                        .weight(1.3f)
                        .height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = selectButtonText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // زر قطع الاتصال
                if (isConnected) {
                    Box(
                        modifier = Modifier
                            .weight(0.9f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(RedContainer)
                            .border(1.dp, RedBorder, RoundedCornerShape(10.dp))
                            .clickable { onDisconnectClick() },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                tint = RedDestructive,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "قطع الاتصال",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = RedDestructive
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PaperSizeOption(
    size: PaperSize,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) NavyDark else Color(0xFFE2E8F0),
                shape = RoundedCornerShape(12.dp)
            )
            .background(if (isSelected) NavyDark.copy(alpha = 0.05f) else Color.White)
            .clickable { onSelect() }
            .padding(vertical = 12.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (isSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isSelected) NavyDark else TextMuted,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = size.label,
                fontSize = 14.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) NavyDark else TextPrimary
            )
        }
    }
}
