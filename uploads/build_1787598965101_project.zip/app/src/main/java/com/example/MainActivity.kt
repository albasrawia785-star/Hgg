package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.POSRepository
import com.example.ui.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private var posViewModelRef: POSViewModel? = null

    override fun onResume() {
        super.onResume()
        posViewModelRef?.checkActiveUserStatusOnResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.utils.UserAli.ensureFirebaseInitialized(applicationContext)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize Room Database & Repository
                val context = LocalContext.current
                val database = remember { AppDatabase.getDatabase(context) }
                val repository = remember { POSRepository(database.posDao()) }
                
                // Instantiate ViewModel with Custom Factory
                val posViewModel: POSViewModel = viewModel(
                    factory = POSViewModelFactory(repository, context)
                )
                posViewModelRef = posViewModel

                LaunchedEffect(Unit) {
                    posViewModel.checkActiveUserStatusOnResume()
                }

                // Force layout direction to RTL for native Arabic presentation
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val isLoggedIn by posViewModel.isLoggedIn.collectAsState()
                    val hasSeenOnboarding by posViewModel.hasSeenOnboarding.collectAsState()
                    val isTrialExpired by posViewModel.isTrialExpired.collectAsState()
                    val printerAlertMessage by posViewModel.printerAlertMessage.collectAsState()
                    val showTrialLimitDialog by posViewModel.showTrialLimitDialog.collectAsState()
                    val demoRestrictedDialogMessage by posViewModel.demoRestrictedDialogMessage.collectAsState()

                    if (demoRestrictedDialogMessage != null) {
                        AlertDialog(
                            onDismissRequest = { posViewModel.dismissDemoRestrictedDialog() },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = POSAccent,
                                    modifier = Modifier.size(32.dp)
                                )
                            },
                            title = {
                                Text(
                                    text = "الوضع التجريبي - تنبيه",
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                                    fontSize = 18.sp,
                                    color = POSPrimary
                                )
                            },
                            text = {
                                Text(
                                    text = demoRestrictedDialogMessage ?: "",
                                    fontSize = 14.sp,
                                    color = Color.DarkGray,
                                    lineHeight = 22.sp
                                )
                            },
                            confirmButton = {
                                Button(
                                    onClick = { posViewModel.dismissDemoRestrictedDialog() },
                                    colors = ButtonDefaults.buttonColors(containerColor = POSPrimary),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = "حسناً، فهمت",
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                }
                            },
                            shape = RoundedCornerShape(20.dp),
                            containerColor = Color.White
                        )
                    }

                    if (showTrialLimitDialog) {
                        AlertDialog(
                            onDismissRequest = { posViewModel.dismissTrialLimitDialog() },
                            title = {
                                Text(
                                    text = "تنبيه الحساب التجريبي",
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                                    fontSize = 18.sp,
                                    color = POSPrimary
                                )
                            },
                            text = {
                                Text(
                                    text = "يجب عليك الاشتراك في النسخة الكاملة للأستمرار",
                                    fontSize = 14.sp,
                                    color = Color.Black
                                )
                            },
                            confirmButton = {
                                TextButton(
                                    onClick = { posViewModel.dismissTrialLimitDialog() }
                                ) {
                                    Text(
                                        text = "موافق",
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = POSPrimary
                                    )
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            containerColor = Color.White
                        )
                    }

                    if (printerAlertMessage != null) {
                        AlertDialog(
                            onDismissRequest = { posViewModel.clearPrinterAlert() },
                            title = {
                                Text(
                                    text = "تنبيه حالة الطابعة",
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
                                    fontSize = 18.sp,
                                    color = POSPrimary
                                )
                            },
                            text = {
                                Text(
                                    text = printerAlertMessage ?: "",
                                    fontSize = 14.sp,
                                    color = Color.Black
                                )
                            },
                            confirmButton = {},
                            dismissButton = {
                                TextButton(
                                    onClick = { posViewModel.clearPrinterAlert() }
                                ) {
                                    Text(
                                        text = "موافق",
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = POSPrimary
                                    )
                                }
                            },
                            shape = RoundedCornerShape(16.dp),
                            containerColor = Color.White
                        )
                    }

                    if (isTrialExpired) {
                        TrialExpiredScreen()
                    } else if (!hasSeenOnboarding) {
                        OnboardingWelcomeScreen(
                            onFinish = { posViewModel.completeOnboarding() }
                        )
                    } else if (!isLoggedIn) {
                        LoginScreen(viewModel = posViewModel)
                    } else {
                        androidx.activity.compose.BackHandler {
                            // Prevent back button from returning to login or exiting unexpectedly, minimize task instead
                            (context as? android.app.Activity)?.moveTaskToBack(true)
                        }
                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            containerColor = POSBackground,
                            bottomBar = {
                                POSBottomNavigation(viewModel = posViewModel)
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                POSMainContent(viewModel = posViewModel)
                                
                                // Bottom Sheet for Cart Detail
                                CartSheetOverlay(viewModel = posViewModel)

                                // Checkout Dialog
                                CheckoutDialogOverlay(viewModel = posViewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun POSMainContent(viewModel: POSViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()

    // Smooth transition animations between tabs (150ms-200ms)
    AnimatedContent(
        targetState = currentTab,
        transitionSpec = {
            fadeIn(animationSpec = androidx.compose.animation.core.tween(150)) togetherWith
            fadeOut(animationSpec = androidx.compose.animation.core.tween(150))
        },
        label = "POSScreenTransition"
    ) { tabIndex ->
        when (tabIndex) {
            0 -> HomeScreen(viewModel = viewModel)
            1 -> ExpensesScreen(viewModel = viewModel)
            2 -> OrdersScreen(viewModel = viewModel)
            3 -> SettingsScreen(viewModel = viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartSheetOverlay(viewModel: POSViewModel) {
    val showCartSheet by viewModel.showCartSheet.collectAsState()

    if (showCartSheet) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.setShowCartSheet(false) },
            containerColor = POSSurface,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            modifier = Modifier.testTag("cart_bottom_sheet")
        ) {
            CartSheetContent(
                viewModel = viewModel,
                onClose = { viewModel.setShowCartSheet(false) },
                onCheckoutClick = {
                    viewModel.setShowCartSheet(false)
                    viewModel.setShowPaymentDialog(true)
                }
            )
        }
    }
}

@Composable
fun CheckoutDialogOverlay(viewModel: POSViewModel) {
    val showPaymentDialog by viewModel.showPaymentDialog.collectAsState()

    if (showPaymentDialog) {
        PaymentDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.setShowPaymentDialog(false) },
            onPaymentSuccess = {
                // Success actions are handled inside the callback
            }
        )
    }
}
