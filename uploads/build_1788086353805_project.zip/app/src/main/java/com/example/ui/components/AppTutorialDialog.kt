package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class TutorialStep(
    val stepNumber: Int,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val iconBgColor: Color,
    val iconTint: Color,
    val mainDescription: String,
    val bulletPoints: List<String>,
    val tip: String
)

@Composable
fun AppTutorialDialog(
    onDismiss: () -> Unit
) {
    val steps = remember {
        listOf(
            TutorialStep(
                stepNumber = 1,
                title = "بدء الجلسة وتفعيل الدور",
                subtitle = "الخطوة الأولى في بداية يوم العمل",
                icon = Icons.Default.PlayArrow,
                iconBgColor = Color(0xFFEFF6FF),
                iconTint = Color(0xFF2563EB),
                mainDescription = "لتشغيل النظام وبدء استقبال المراجعين وعرض الأرقام على شاشات التلفزيون:",
                bulletPoints = listOf(
                    "اضغط على زر 'بدء' في البطاقة العلوية لتفعيل جلسة العيادة.",
                    "لن تظهر أرقام المراجعين على الشاشة إلا بعد أن تضغط على بطاقة المراجع لاستدعائه.",
                    "يمكنك إيقاف العيادة مؤقتاً بأي وقت عبر زر 'إيقاف'."
                ),
                tip = "نصيحة: تفعيل الدور يضمن مزامنة الشاشات وسماعات النداء تلقائياً."
            ),
            TutorialStep(
                stepNumber = 2,
                title = "إضافة المراجعين وطباعة التذاكر",
                subtitle = "تسجيل المرضى وإصدار أرقام الانتظار",
                icon = Icons.Default.PersonAdd,
                iconBgColor = Color(0xFFF0FDF4),
                iconTint = Color(0xFF0F766E),
                mainDescription = "لإضافة مراجع جديد إلى قائمة الانتظار ومنحه تذكرة ورقية:",
                bulletPoints = listOf(
                    "اضغط على زر '+' الأزرق أسفل الشاشة أو في القائمة العلوية.",
                    "أدخل اسم المراجع (اختياري) وأي ملاحظات خاصة بالحالة أو العيادة.",
                    "قم بتفعيل خيار 'طباعة التذكرة' لطباعة إيصال ورقي فوري يحمل رقم الدور ووقت الوصول.",
                    "يمكنك تفعيل خيار الطباعة التلقائية الدائمة من لوحة الإعدادات."
                ),
                tip = "نصيحة: يمكن معاينة شكل التذكرة بالنقر على أيقونة الطابعة الصغيرة بجانب المراجع."
            ),
            TutorialStep(
                stepNumber = 3,
                title = "استدعاء المراجع والنداء الصوتي",
                subtitle = "نطق صوتي فصيح وعرض فوري على الشاشة",
                icon = Icons.Default.RecordVoiceOver,
                iconBgColor = Color(0xFFFAF5FF),
                iconTint = Color(0xFF7C3AED),
                mainDescription = "لاستدعاء المراجع القادم إلى غرفة الكشف والمعاينة:",
                bulletPoints = listOf(
                    "انقر مباشرة على بطاقة المراجع المطلوب في القائمة.",
                    "سيقوم النظام فوراً بنطق رقم واسم المراجع بصوت واضح عبر سماعة الهاتف أو مكبر الصوت الخارجي.",
                    "سيتم إبراز رقم المراجع على شاشة التلفزيون بخط كبير مع نغمة جرس (Chime) مميزة.",
                    "يمكنك تخصيص صيغة النداء وسرعة الصوت وطبقة الصوت من قسم إعدادات الصوت."
                ),
                tip = "نصيحة: يمكنك استدعاء المراجعين حسب الدور أو اختيار أي مراجع محدد مباشرة."
            ),
            TutorialStep(
                stepNumber = 4,
                title = "شاشة التلفزيون الذكية (TV Display)",
                subtitle = "بث مباشر لاسلكي عبر Wi-Fi وشبكة العيادة",
                icon = Icons.Default.Tv,
                iconBgColor = Color(0xFFEFF6FF),
                iconTint = Color(0xFF0284C7),
                mainDescription = "لعرض أرقام الانتظار في صالة الاستقبال على شاشة التلفزيون الذكي:",
                bulletPoints = listOf(
                    "تأكد من اتصال الهاتف والتلفزيون بنفس شبكة الـ Wi-Fi.",
                    "اضغط على أيقونة التلفزيون العلوية لفتح رابط الشاشة أو رمز QR.",
                    "افتح متصفح شاشة التلفزيون واكتب الرابط المباشر (مثل: http://192.168.1.X:8080).",
                    "إذا لم يتوفر راوتر Wi-Fi، يمكنك تفعيل 'نقطة اتصال الهواتف المحمولة (Hotspot)' من إعدادات التطبيق وربط التلفزيون بها."
                ),
                tip = "نصيحة: شاشة الـ TV مصممة بألوان طبية مريحة وتحدث نفسها في أجزاء من الثانية تلقائياً."
            ),
            TutorialStep(
                stepNumber = 5,
                title = "ربط الطابعة الحرارية والسماعة",
                subtitle = "توصيل طابعات الإيصالات ومكبرات الصوت Bluetooth",
                icon = Icons.Default.Print,
                iconBgColor = Color(0xFFFFFBEB),
                iconTint = Color(0xFFD97706),
                mainDescription = "لربط الأجهزة الملحقة عبر تقنية البلوتوث اللاسلكية:",
                bulletPoints = listOf(
                    "من شاشة الإعدادات، افتح قسم 'طابعة البلوتوث الحرارية'.",
                    "اختر طابعة الفواتير المقترنة (مثل: POS-58 أو POS-80) واضغط اتصال.",
                    "اختر مقاس الورق (58 ملم أو 80 ملم) واضبط نص الترويقة وتذييل التذكرة.",
                    "من قسم 'سماعة البلوتوث ومكبر الصوت'، يمكنك تحويل بث النداء الصوتي إلى ساوند بار أو سماعة الصالة."
                ),
                tip = "نصيحة: تظهر شارات خضراء بالأعلى عند نجاح اتصال الطابعة أو شاشة التلفزيون."
            ),
            TutorialStep(
                stepNumber = 6,
                title = "إدارة المراجعين وتأجيل الدور",
                subtitle = "التعامل مع الغائبين والمراجعين المؤجلين",
                icon = Icons.Default.Schedule,
                iconBgColor = Color(0xFFFEF2F2),
                iconTint = Color(0xFFDC2626),
                mainDescription = "إذا لم يحضر المراجع فور استدعائه وتريد خدمة المراجع التالي:",
                bulletPoints = listOf(
                    "اضغط على زر 'تأجيل' في بطاقة المراجع لنقله لقائمة المؤجلين دون حذف رقمه.",
                    "عند عودة المراجع، اضغط على زر 'إرجاع للدور' لإعادته لقائمة الانتظار في مقدمة الدور.",
                    "يمكنك تصفية القائمة عبر التبويبات العلوية (الكل، بالانتظار، تم النداء، مؤجل)."
                ),
                tip = "نصيحة: شريط التصفح السفلي يتيح لك التنقل السلس بين صفحات المراجعين."
            ),
            TutorialStep(
                stepNumber = 7,
                title = "التقارير اليومية وتصفير الدور",
                subtitle = "إحصائيات دقيقة وأرشفة دورية",
                icon = Icons.Default.Assessment,
                iconBgColor = Color(0xFFF0FDF4),
                iconTint = Color(0xFF0F766E),
                mainDescription = "في نهاية يوم العمل أو عند الرغبة في مراجعة الإحصائيات:",
                bulletPoints = listOf(
                    "افتح قسم 'تقارير العيادة والإحصائيات' من القائمة.",
                    "استعرض إجمالي المراجعين، عدد من تم خدمتهم، والمراجعين في الانتظار والمؤجلين.",
                    "يمكنك طباعة تقرير إحصائي موجز على الطابعة الحرارية بضغطة واحدة.",
                    "لبدء يوم جديد، اضغط على 'تصفير الدور' مع خيار حفظ وأرشفة اليوم الحالي في السجلات."
                ),
                tip = "نصيحة: كافة بيانات المراجعين مخزنة بأمان على جهازك ولا تتطلب اتصالاً بالإنترنت."
            )
        )
    }

    var currentStepIndex by remember { mutableIntStateOf(0) }
    val currentStep = steps[currentStepIndex]
    val totalSteps = steps.size

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            modifier = Modifier.testTag("app_tutorial_dialog"),
            shape = RoundedCornerShape(24.dp),
            containerColor = Color.White,
            title = null,
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp)
                ) {
                    // Header with close button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0F766E).copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = Color(0xFF0F766E),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "البرنامج التعليمي ودليل الاستخدام",
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "الخطوة ${currentStep.stepNumber} من $totalSteps",
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Step Progress Indicator Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (i in 0 until totalSteps) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(
                                        if (i <= currentStepIndex) Color(0xFF0F766E)
                                        else Color(0xFFE2E8F0)
                                    )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Animated Step Content
                    AnimatedContent(
                        targetState = currentStep,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "TutorialStepAnimation"
                    ) { step ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(330.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            // Step Icon and Title Card
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = step.iconBgColor.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, step.iconTint.copy(alpha = 0.25f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(step.iconBgColor)
                                            .border(1.dp, step.iconTint.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = step.icon,
                                            contentDescription = null,
                                            tint = step.iconTint,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = step.title,
                                            fontSize = 14.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0F172A)
                                        )
                                        Text(
                                            text = step.subtitle,
                                            fontSize = 11.5.sp,
                                            color = Color(0xFF64748B)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = step.mainDescription,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF334155),
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Bullet Points
                            Column(
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                step.bulletPoints.forEach { point ->
                                    Row(
                                        verticalAlignment = Alignment.Top,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .padding(top = 5.dp)
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(step.iconTint)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = point,
                                            fontSize = 12.sp,
                                            color = Color(0xFF475569),
                                            lineHeight = 17.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Tip Box
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFFFFBEB),
                                border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "نصيحة",
                                        tint = Color(0xFFD97706),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = step.tip,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF92400E),
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentStepIndex > 0) {
                        OutlinedButton(
                            onClick = { currentStepIndex-- },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                            modifier = Modifier.height(42.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "السابق",
                                tint = Color(0xFF475569),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "السابق",
                                fontSize = 12.5.sp,
                                color = Color(0xFF475569)
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    if (currentStepIndex < totalSteps - 1) {
                        Button(
                            onClick = { currentStepIndex++ },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0F766E)
                            ),
                            modifier = Modifier.height(42.dp)
                        ) {
                            Text(
                                text = "التالي",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "التالي",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    } else {
                        Button(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0F766E)
                            ),
                            modifier = Modifier.height(42.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "إنهاء الدليل",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            },
            dismissButton = {}
        )
    }
}
