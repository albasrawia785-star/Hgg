package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.audio.CallingState
import com.example.data.model.Patient
import com.example.ui.theme.AmberBorder
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberText
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.GreenBorder
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedBorder
import com.example.ui.theme.RedContainer
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

@Composable
fun MainHomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentPatient by viewModel.currentPatient.collectAsState()
    val patients by viewModel.patients.collectAsState()
    val postponedPatients by viewModel.postponedPatients.collectAsState()
    val activeWaitingPatients by viewModel.activeWaitingPatients.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val isPrinterConnected by viewModel.printerManager.isConnected.collectAsState()
    val printerName by viewModel.printerManager.connectedDeviceName.collectAsState()
    val isSpeakerConnected by viewModel.audioRouteManager.isSpeakerConnected.collectAsState()
    val speakerName by viewModel.audioRouteManager.connectedSpeakerName.collectAsState()

    val callingState by viewModel.callingState.collectAsState()
    val activeCallingPatient by viewModel.activeCallingPatient.collectAsState()

    val showAddDialog by viewModel.showAddPatientDialog.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()
    val showPostponedSheet by viewModel.showPostponedSheet.collectAsState()
    val previewPatient by viewModel.previewTicketPatient.collectAsState()
    val isQueueStarted by viewModel.isQueueStarted.collectAsState()

    val totalCount = patients.size
    val waitingCount = activeWaitingPatients.size
    val postponedCount = postponedPatients.size
    val nextNumber = if (patients.isEmpty()) 1 else (patients.maxOf { it.queueNumber } + 1)

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // 1. Top Status Bar & Header
        HeaderSection(
            clinicName = settings.clinicName,
            doctorName = settings.doctorName,
            isPrinterConnected = isPrinterConnected,
            printerName = if (printerName.isNotBlank()) printerName else if (settings.selectedPrinterName.isNotBlank()) settings.selectedPrinterName else "طابعة",
            onPrinterClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) }
        )

        // 2. Active Calling Live Banner (Directly on Home Screen without switching screens)
        AnimatedVisibility(
            visible = callingState != CallingState.IDLE,
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyDark)
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "جاري النداء الصوتي للمراجع رقم ${activeCallingPatient?.formattedNumber ?: (currentPatient?.formattedNumber ?: "")}...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = GreenSuccess,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 3. Main Scrollable Content
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(2.dp))

            // 3. Hero Card: If empty -> show Add Patient Prompt; If not empty -> show current patient number
            if (patients.isEmpty() || currentPatient == null) {
                // Empty State Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(24.dp))
                        .shadow(
                            elevation = 2.dp,
                            shape = RoundedCornerShape(24.dp),
                            spotColor = Color(0x0A1B2B48)
                        )
                        .padding(vertical = 32.dp, horizontal = 20.dp)
                        .testTag("empty_queue_card"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(NavyDark.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = null,
                                tint = NavyDark,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "قائمة المراجعين فارغة",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "اضغط على الزر أدناه لإضافة أول مراجع وسيبدأ من الرقم 1",
                            fontSize = 13.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = { viewModel.onAddPatientClicked() },
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .height(50.dp)
                                .testTag("empty_state_add_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    tint = TextOnNavy,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "إضافة مراجع جديد",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextOnNavy
                                )
                            }
                        }
                    }
                }
            } else {
                // Active Patient Hero Card
                val active = currentPatient!!
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(24.dp))
                        .shadow(
                            elevation = 2.dp,
                            shape = RoundedCornerShape(24.dp),
                            spotColor = Color(0x0A1B2B48)
                        )
                        .clickable {
                            viewModel.onOpenTicketPreview(active)
                        }
                        .padding(vertical = 24.dp, horizontal = 20.dp)
                        .testTag("current_patient_card")
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "المراجع الحالي",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        // Prominent Huge Number
                        Text(
                            text = active.formattedNumber,
                            fontSize = 92.sp,
                            fontWeight = FontWeight.Black,
                            color = NavyDark,
                            lineHeight = 92.sp,
                            letterSpacing = (-2).sp,
                            textAlign = TextAlign.Center
                        )

                        if (active.name.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "المراجع: ${active.name}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }

                        if (active.note.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "ملاحظة: ${active.note}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = TextMuted
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Status Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (!isQueueStarted) Color(0xFFFEF3C7)
                                    else if (active.isCalled) GreenContainer
                                    else Color(0xFFF8FAFC)
                                )
                                .border(
                                    1.dp,
                                    if (!isQueueStarted) AmberBorder
                                    else if (active.isCalled) GreenBorder
                                    else Color(0xFFE2E8F0),
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(horizontal = 14.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = if (!isQueueStarted) "تشغيل عرض المراجعين على شاشة TV"
                                else if (active.isCalled) "تم الاستدعاء (نشط)"
                                else "بانتظار الاستدعاء...",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (!isQueueStarted) AmberText
                                else if (active.isCalled) GreenText
                                else TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Quick Stats Row (Total, Waiting, Postponed)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Total Today Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo(AppScreen.QUEUE_LIST) }
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Column {
                        Text(
                            text = "إجمالي اليوم",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$totalCount",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                }

                // In Waiting Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(16.dp))
                        .clickable { viewModel.navigateTo(AppScreen.QUEUE_LIST) }
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Column {
                        Text(
                            text = "في الانتظار",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$waitingCount",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                }

                // Postponed Card (المؤجلين)
                Box(
                    modifier = Modifier
                        .weight(1.1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (postponedCount > 0) AmberContainer else Color.White)
                        .border(
                            1.dp,
                            if (postponedCount > 0) AmberBorder else Color(0xFFF1F5F9),
                            RoundedCornerShape(16.dp)
                        )
                        .clickable { viewModel.onOpenPostponedSheet() }
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "المؤجلين",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (postponedCount > 0) AmberText else TextMuted
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.HourglassTop,
                                contentDescription = null,
                                tint = if (postponedCount > 0) AmberText else TextMuted,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "$postponedCount",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (postponedCount > 0) AmberText else NavyDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 5. Action Controls Section
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Primary Calling Action Button (Navy with clear label)
                val isCalled = currentPatient?.isCalled == true
                Button(
                    onClick = {
                        if (isCalled) {
                            viewModel.onCallNextPatientClicked()
                        } else {
                            viewModel.onCallCurrentPatientClicked()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .shadow(
                            elevation = 4.dp,
                            shape = RoundedCornerShape(16.dp),
                            spotColor = NavyDark.copy(alpha = 0.25f)
                        )
                        .testTag("call_patient_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (isCalled) Icons.Default.SkipNext else Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isCalled) "استدعاء المراجع التالي" else "استدعاء المراجع",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Secondary Row of Actions: "استدعاء مرة أخرى" + "تأجيل المراجع"
                if (currentPatient != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Re-call button ("استدعاء مرة أخرى")
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White)
                                .border(1.5.dp, NavyDark, RoundedCornerShape(14.dp))
                                .clickable { viewModel.onRecallCurrentPatient() }
                                .testTag("recall_home_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Replay,
                                    contentDescription = "استدعاء مرة أخرى",
                                    tint = NavyDark,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "استدعاء مرة أخرى",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyDark
                                )
                            }
                        }

                        // Postpone button ("تأجيل المراجع")
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(AmberContainer)
                                .border(1.5.dp, AmberBorder, RoundedCornerShape(14.dp))
                                .clickable { viewModel.onPostponeCurrentPatient() }
                                .testTag("postpone_patient_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.HourglassTop,
                                    contentDescription = "تأجيل المراجع",
                                    tint = AmberText,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تأجيل المراجع",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberText
                                )
                            }
                        }
                    }
                }

                // Row with "إضافة مراجع" and "تصفير"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Add Patient Button
                    Box(
                        modifier = Modifier
                            .weight(1.1f)
                            .height(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White)
                            .border(1.5.dp, NavyDark, RoundedCornerShape(14.dp))
                            .clickable { viewModel.onAddPatientClicked() }
                            .testTag("add_patient_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = "إضافة مراجع",
                                tint = NavyDark,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "إضافة مراجع",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                    }

                    // Reset Button
                    Box(
                        modifier = Modifier
                            .weight(0.9f)
                            .height(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(RedContainer)
                            .border(1.dp, RedBorder, RoundedCornerShape(14.dp))
                            .clickable { viewModel.onOpenResetDialog() }
                            .testTag("reset_queue_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تصفير",
                                tint = RedDestructive,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تصفير",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = RedDestructive
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // 6. Bottom Navigation Bar
        BottomNavBar(
            activeScreen = AppScreen.HOME,
            onHomeClick = { /* Already here */ },
            onQueueClick = { viewModel.navigateTo(AppScreen.QUEUE_LIST) },
            onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
        )
    }

    // Dialogs
    if (showAddDialog) {
        AddPatientDialog(
            nextQueueNumber = nextNumber,
            initialAutoPrint = settings.autoPrintOnAdd,
            onConfirm = { name, note, shouldPrint ->
                viewModel.onConfirmAddPatient(name, note, shouldPrint)
            },
            onDismiss = { viewModel.onDismissAddPatientDialog() }
        )
    }

    if (showResetDialog) {
        ResetConfirmDialog(
            onConfirmWithArchive = { viewModel.onConfirmResetQueue(archive = true) },
            onConfirmWithoutArchive = { viewModel.onConfirmResetQueue(archive = false) },
            onDismiss = { viewModel.onDismissResetDialog() }
        )
    }

    if (showPostponedSheet) {
        PostponedPatientsDialog(
            postponedPatients = postponedPatients,
            onRecallPatient = { patient ->
                viewModel.onRecallPostponedPatient(patient)
                viewModel.onDismissPostponedSheet()
            },
            onRestorePatient = { patient ->
                viewModel.onRestorePostponedToQueue(patient)
            },
            onDeletePatient = { patient ->
                viewModel.onDeletePatient(patient)
            },
            onDismiss = { viewModel.onDismissPostponedSheet() }
        )
    }

    if (previewPatient != null) {
        TicketPreviewDialog(
            patient = previewPatient!!,
            settings = settings,
            onPrintClick = { viewModel.onPrintPreviewTicket() },
            onDismiss = { viewModel.onDismissTicketPreview() }
        )
    }
}

/**
 * نافذة عرض قائمة المراجعين المؤجلين (Postponed Patients List Dialog)
 */
@Composable
fun PostponedPatientsDialog(
    postponedPatients: List<Patient>,
    onRecallPatient: (Patient) -> Unit,
    onRestorePatient: (Patient) -> Unit,
    onDeletePatient: (Patient) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .padding(20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Title Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(AmberContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.HourglassTop,
                                contentDescription = null,
                                tint = AmberText,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "قائمة المراجعين المؤجلين",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                            Text(
                                text = "المراجعون الذين حجزوا ولم يحضروا عند النداء",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (postponedPatients.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = GreenSuccess,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "لا يوجد مراجعين مؤجلين حالياً",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                            Text(
                                text = "جميع المراجعين إما في الانتظار أو تم إنهاؤهم",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height((postponedPatients.size * 90).coerceAtMost(320).dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(postponedPatients, key = { it.id }) { patient ->
                            PostponedPatientCardItem(
                                patient = patient,
                                onRecallClick = { onRecallPatient(patient) },
                                onRestoreClick = { onRestorePatient(patient) },
                                onDeleteClick = { onDeletePatient(patient) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Close Button
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9))
                ) {
                    Text(
                        text = "إغلاق",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                }
            }
        }
    }
}

@Composable
fun PostponedPatientCardItem(
    patient: Patient,
    onRecallClick: () -> Unit,
    onRestoreClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFF8FAFC))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(AmberContainer)
                            .border(1.dp, AmberBorder, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = patient.formattedNumber,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            color = AmberText
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (patient.name.isNotBlank()) "المراجع: ${patient.name}" else "المراجع رقم ${patient.formattedNumber}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        if (patient.note.isNotBlank()) {
                            Text(
                                text = patient.note,
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف",
                        tint = RedDestructive,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action buttons: استدعاء الآن + إعادة للدور
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onRecallClick,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(38.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "استدعاء الآن",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(0.9f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                        .clickable { onRestoreClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "إعادة للدور",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}

/**
 * Top Header Component
 */
@Composable
fun HeaderSection(
    clinicName: String,
    doctorName: String,
    isPrinterConnected: Boolean,
    printerName: String,
    onPrinterClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Clinic & Doctor Identity
            Column {
                Text(
                    text = clinicName,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = doctorName,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextSecondary
                )
            }

            // Connection Status Indicators
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Printer Status Chip
                DeviceStatusChip(
                    icon = Icons.Default.Print,
                    label = if (isPrinterConnected) printerName else "طابعة",
                    isConnected = isPrinterConnected,
                    onClick = onPrinterClick
                )
            }
        }
    }
}

@Composable
fun DeviceStatusChip(
    icon: ImageVector,
    label: String,
    isConnected: Boolean,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isConnected) GreenContainer else Color(0xFFF1F5F9))
            .border(
                1.dp,
                if (isConnected) GreenBorder else Color(0xFFE2E8F0),
                RoundedCornerShape(20.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(if (isConnected) GreenSuccess else TextMuted)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isConnected) GreenText else TextSecondary,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label.take(9),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = if (isConnected) GreenText else TextSecondary
        )
    }
}

/**
 * Bottom Navigation Bar - شريط التنقل السفلي لقائمة المراجعين والإعدادات
 */
@Composable
fun BottomNavBar(
    activeScreen: AppScreen,
    onHomeClick: () -> Unit = {},
    onQueueClick: () -> Unit,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White)
            .border(1.dp, Color(0xFFF1F5F9))
            .padding(vertical = 8.dp, horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavTabItem(
                label = "الرئيسية",
                icon = Icons.Default.Home,
                isActive = activeScreen == AppScreen.HOME,
                onClick = onHomeClick
            )
            NavTabItem(
                label = "قائمة المراجعين",
                icon = Icons.Default.FormatListNumbered,
                isActive = activeScreen == AppScreen.QUEUE_LIST,
                onClick = onQueueClick
            )
            NavTabItem(
                label = "الإعدادات",
                icon = Icons.Default.Settings,
                isActive = activeScreen == AppScreen.DEVICE_SETTINGS || activeScreen == AppScreen.CHOOSE_PRINTER,
                onClick = onSettingsClick
            )
        }
    }
}

@Composable
fun NavTabItem(
    label: String,
    icon: ImageVector,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isActive) NavyDark else TextMuted,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            color = if (isActive) NavyDark else TextMuted
        )
    }
}
