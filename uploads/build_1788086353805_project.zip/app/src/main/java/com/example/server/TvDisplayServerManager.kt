package com.example.server

import android.content.Context
import android.util.Log
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ActiveTvCall(
    val callId: Long = 0L,
    val queueNumber: Int = 0,
    val patientName: String = "",
    val timestamp: Long = 0L
)

class TvDisplayServerManager(private val context: Context) {

    private val TAG = "TvDisplayServer"
    private val scope = CoroutineScope(Dispatchers.IO)
    private var serverJob: Job? = null
    private var serverSocket: ServerSocket? = null

    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _serverPort = MutableStateFlow(8080)
    val serverPort: StateFlow<Int> = _serverPort.asStateFlow()

    private val _serverUrl = MutableStateFlow("")
    val serverUrl: StateFlow<String> = _serverUrl.asStateFlow()

    private val _connectedClientsCount = MutableStateFlow(0)
    val connectedClientsCount: StateFlow<Int> = _connectedClientsCount.asStateFlow()

    private val _isTvConnected = MutableStateFlow(false)
    val isTvConnected: StateFlow<Boolean> = _isTvConnected.asStateFlow()

    private var lastStatusPingTime: Long = 0L
    private var watchdogJob: Job? = null

    // State cached for TV queries
    private var currentSettings = SystemSettings()
    private var currentPatientsList = listOf<Patient>()
    private var currentActivePatient: Patient? = null
    private var isSessionStarted: Boolean = false
    private var latestCallEvent = ActiveTvCall()

    fun updateState(settings: SystemSettings, patients: List<Patient>, activePatient: Patient?, isSessionStarted: Boolean = this.isSessionStarted) {
        this.currentSettings = settings
        this.currentPatientsList = patients
        this.currentActivePatient = activePatient
        this.isSessionStarted = isSessionStarted
    }

    fun notifyPatientCalled(patient: Patient) {
        latestCallEvent = ActiveTvCall(
            callId = System.currentTimeMillis(),
            queueNumber = patient.queueNumber,
            patientName = patient.name,
            timestamp = System.currentTimeMillis()
        )
    }

    fun startServer(port: Int = 8080) {
        if (_isServerRunning.value) return

        serverJob?.cancel()
        watchdogJob?.cancel()

        watchdogJob = scope.launch {
            while (isActive) {
                kotlinx.coroutines.delay(2000)
                if (_isTvConnected.value && System.currentTimeMillis() - lastStatusPingTime > 4000L) {
                    _isTvConnected.value = false
                    _connectedClientsCount.value = 0
                }
            }
        }

        serverJob = scope.launch {
            try {
                _serverPort.value = port
                val ip = getLocalIpAddress()
                val url = "http://$ip:$port"
                _serverUrl.value = url

                serverSocket = ServerSocket(port).apply {
                    reuseAddress = true
                }
                _isServerRunning.value = true
                Log.d(TAG, "TV Display Server started at $url")

                while (isActive && serverSocket?.isClosed == false) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        scope.launch {
                            handleClient(clientSocket)
                        }
                    } catch (e: Exception) {
                        if (!isActive) break
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error starting TV server: ${e.message}", e)
            } finally {
                _isServerRunning.value = false
                _isTvConnected.value = false
                _connectedClientsCount.value = 0
            }
        }
    }

    fun stopServer() {
        try {
            serverJob?.cancel()
            watchdogJob?.cancel()
            watchdogJob = null
            serverSocket?.close()
            serverSocket = null
        } catch (_: Exception) {}
        _isServerRunning.value = false
        _isTvConnected.value = false
        _connectedClientsCount.value = 0
    }

    fun refreshUrl() {
        val ip = getLocalIpAddress()
        _serverUrl.value = "http://$ip:${_serverPort.value}"
    }

    fun getLocalIpAddress(): String {
        try {
            val candidateIps = mutableListOf<String>()
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val hostAddress = address.hostAddress ?: continue
                        candidateIps.add(hostAddress)
                    }
                }
            }

            // 1. Android Local-Only Hotspot interface (192.168.49.x)
            candidateIps.firstOrNull { it.startsWith("192.168.49.") }?.let { return it }

            // 2. Standard Android Hotspot Gateway (192.168.43.x)
            candidateIps.firstOrNull { it.startsWith("192.168.43.") }?.let { return it }

            // 3. Local Wi-Fi Network (192.168.x.x)
            candidateIps.firstOrNull { it.startsWith("192.168.") }?.let { return it }

            // 4. Other private IP ranges (10.x.x.x or 172.x.x.x)
            candidateIps.firstOrNull { it.startsWith("10.") || it.startsWith("172.") }?.let { return it }

            if (candidateIps.isNotEmpty()) {
                return candidateIps.first()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting IP: ${e.message}")
        }
        return "192.168.49.1"
    }

    private suspend fun handleClient(socket: Socket) = withContext(Dispatchers.IO) {
        try {
            socket.soTimeout = 10000
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val outputStream = socket.getOutputStream()

            val requestLine = reader.readLine() ?: return@withContext
            val parts = requestLine.split(" ")
            if (parts.size < 2) return@withContext

            val method = parts[0]
            val path = parts[1]

            when {
                path.startsWith("/api/status") -> {
                    serveStatusJson(outputStream)
                }
                path.startsWith("/api/audio") -> {
                    serveAudioWav(outputStream)
                }
                path == "/" || path.startsWith("/index.html") || path.startsWith("/tv") -> {
                    serveTvHtml(outputStream)
                }
                else -> {
                    serveNotFound(outputStream)
                }
            }
        } catch (_: Exception) {
        } finally {
            try {
                socket.close()
            } catch (_: Exception) {}
        }
    }

    private fun serveStatusJson(output: OutputStream) {
        lastStatusPingTime = System.currentTimeMillis()
        if (!_isTvConnected.value) {
            _isTvConnected.value = true
            _connectedClientsCount.value = 1
        }

        val json = JSONObject().apply {
            put("clinicName", currentSettings.clinicName.ifBlank { "عيادة الشفاء التخصصية" })
            put("clinicSubtitle", currentSettings.clinicSubtitle)
            put("doctorName", currentSettings.doctorName)
            put("doctorSpecialty", currentSettings.doctorSpecialty)
            put("clinicPhone", currentSettings.clinicPhone)
            put("clinicAddress", currentSettings.clinicAddress)
            put("customFooter", currentSettings.tvFooterSlogan.ifBlank { currentSettings.footerMessage })
            put("callTemplate", currentSettings.callPhrase)
            put("volume", currentSettings.volume)
            put("speechRate", currentSettings.speechRate)
            put("isSessionStarted", isSessionStarted)

            // Current Active (Only shown if actively called / clicked)
            if (isSessionStarted && currentActivePatient != null && currentActivePatient?.isCurrent == true) {
                put("currentPatient", JSONObject().apply {
                    put("id", currentActivePatient?.id)
                    put("number", currentActivePatient?.queueNumber)
                    put("formattedNumber", currentActivePatient?.formattedNumber)
                    put("name", currentActivePatient?.name)
                    put("isPostponed", currentActivePatient?.isPostponed)
                })
            } else {
                put("currentPatient", JSONObject.NULL)
            }

            // Latest call trigger for TV chime & speech (Only if a patient has been called)
            if (isSessionStarted && latestCallEvent.queueNumber > 0) {
                put("activeCall", JSONObject().apply {
                    put("callId", latestCallEvent.callId)
                    put("queueNumber", latestCallEvent.queueNumber)
                    put("patientName", latestCallEvent.patientName)
                    put("timestamp", latestCallEvent.timestamp)
                })
            } else {
                put("activeCall", JSONObject().apply {
                    put("callId", 0L)
                    put("queueNumber", 0)
                    put("patientName", "")
                    put("timestamp", 0L)
                })
            }

            // Waiting patients (Hidden until patient is clicked / called)
            val waitingArr = JSONArray()
            if (isSessionStarted && (currentActivePatient != null && currentActivePatient?.isCurrent == true || latestCallEvent.queueNumber > 0)) {
                currentPatientsList
                    .filter { !it.isPostponed && !it.isCalled }
                    .take(8)
                    .forEach { p ->
                        waitingArr.put(JSONObject().apply {
                            put("number", p.queueNumber)
                            put("formattedNumber", p.formattedNumber)
                            put("name", p.name)
                        })
                    }
            }
            put("waitingList", waitingArr)

            // Postponed patients (Hidden until session starts)
            val postponedArr = JSONArray()
            if (isSessionStarted) {
                currentPatientsList
                    .filter { it.isPostponed }
                    .take(6)
                    .forEach { p ->
                        postponedArr.put(JSONObject().apply {
                            put("number", p.queueNumber)
                            put("formattedNumber", p.formattedNumber)
                            put("name", p.name)
                        })
                    }
            }
            put("postponedList", postponedArr)

            put("totalPatients", currentPatientsList.size)
            put("waitingCount", currentPatientsList.count { !it.isPostponed && !it.isCalled })
            put("postponedCount", currentPatientsList.count { it.isPostponed })
            put("serverTime", SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
        }

        val bytes = json.toString().toByteArray(Charsets.UTF_8)
        val headers = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: application/json; charset=UTF-8\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"

        output.write(headers.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun serveAudioWav(output: OutputStream) {
        val audioFile = java.io.File(context.cacheDir, "call_latest.wav")
        if (audioFile.exists() && audioFile.length() > 0) {
            val bytes = audioFile.readBytes()
            val headers = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: audio/wav\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Accept-Ranges: bytes\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                    "Connection: close\r\n\r\n"
            output.write(headers.toByteArray(Charsets.UTF_8))
            output.write(bytes)
            output.flush()
        } else {
            serveNotFound(output)
        }
    }

    private fun serveTvHtml(output: OutputStream) {
        val html = generateTvHtmlPage()
        val bytes = html.toByteArray(Charsets.UTF_8)
        val headers = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"

        output.write(headers.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun serveNotFound(output: OutputStream) {
        val response = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun generateTvHtmlPage(): String {
        return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>شاشة الانتظار والمراجعين | TV Queue Display</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans Arabic", "Cairo", Arial, sans-serif;
            user-select: none;
            -webkit-user-select: none;
        }

        html, body {
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            background-color: #EDF2F7;
            background-image: radial-gradient(#CBD5E1 1px, transparent 1px);
            background-size: 24px 24px;
            color: #0F172A;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
        }

        /* Ambient background decorative shape on the left */
        .ambient-shape-left {
            position: absolute;
            top: 20px;
            left: 0;
            width: 140px;
            height: 420px;
            background: linear-gradient(135deg, #0D9488 0%, #0F766E 100%);
            border-top-right-radius: 90px;
            border-bottom-right-radius: 90px;
            z-index: 1;
            box-shadow: 4px 10px 30px rgba(13, 148, 136, 0.25);
        }

        /* Decorative Dot Matrices */
        .dot-matrix {
            position: absolute;
            display: grid;
            grid-template-columns: repeat(4, 5px);
            grid-gap: 8px;
            opacity: 0.35;
            z-index: 1;
        }
        .dot-matrix span {
            width: 5px;
            height: 5px;
            background-color: #0D9488;
            border-radius: 50%;
        }
        .dot-matrix.left-mid {
            bottom: 180px;
            right: 28px;
        }
        .dot-matrix.right-edge {
            top: 220px;
            left: 20px;
        }

        /* Top Audio Enable Bar / Discreet Floating Button */
        .audio-unmute-bar {
            position: absolute;
            top: 14px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 100;
            background: rgba(13, 148, 136, 0.95);
            backdrop-filter: blur(8px);
            color: #FFFFFF;
            padding: 8px 24px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 6px 20px rgba(13, 148, 136, 0.4);
            cursor: pointer;
            transition: all 0.3s ease;
            animation: pulse-audio 2s infinite alternate;
        }
        .audio-unmute-bar.muted-hidden {
            display: none;
        }
        @keyframes pulse-audio {
            0% { transform: translateX(-50%) scale(1); }
            100% { transform: translateX(-50%) scale(1.04); }
        }

        /* Main Container */
        .screen-container {
            width: 100%;
            height: 100%;
            padding: 24px 32px 18px 32px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            z-index: 10;
            position: relative;
        }

        /* Main Content 2-Column Grid */
        .content-body {
            display: grid;
            grid-template-columns: 370px 1fr;
            gap: 36px;
            align-items: stretch;
            flex: 1;
            margin-bottom: 20px;
            height: calc(100vh - 126px);
        }

        /* ================= LEFT COLUMN ================= */
        .left-column {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding-right: 8px;
        }

        /* Clinic Brand Section */
        .clinic-brand-box {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 12px;
        }

        .brand-logo-circle {
            width: 106px;
            height: 106px;
            background: #FFFFFF;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            border: 4px solid #E6FFFA;
            flex-shrink: 0;
            position: relative;
        }

        .brand-logo-inner {
            width: 82px;
            height: 82px;
            border-radius: 50%;
            background: linear-gradient(135deg, #0F766E 0%, #042F2E 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2DD4BF;
        }

        .brand-logo-inner svg {
            width: 48px;
            height: 48px;
            fill: #2DD4BF;
        }

        .clinic-titles {
            display: flex;
            flex-direction: column;
        }

        .clinic-titles h1 {
            font-size: 38px;
            font-weight: 900;
            color: #0A192F;
            line-height: 1.1;
            margin-bottom: 4px;
            letter-spacing: -0.5px;
        }

        .clinic-titles p {
            font-size: 15px;
            font-weight: 700;
            color: #0D9488;
        }

        .brand-divider {
            width: 140px;
            height: 2px;
            background: linear-gradient(to left, #0D9488, transparent);
            margin-top: 8px;
            position: relative;
        }
        .brand-divider::after {
            content: '';
            position: absolute;
            right: 0;
            top: -3px;
            width: 8px;
            height: 8px;
            background: #0D9488;
            transform: rotate(45deg);
        }

        /* Doctor Card */
        .doctor-card {
            background: #FFFFFF;
            border-radius: 20px;
            padding: 16px 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.05);
            border: 1px solid rgba(226, 232, 240, 0.9);
            margin-top: 10px;
            margin-bottom: 16px;
        }

        .doctor-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: #E6FFFA;
            border: 2px solid #0D9488;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #0D9488;
            flex-shrink: 0;
        }

        .doctor-avatar svg {
            width: 32px;
            height: 32px;
            fill: #0D9488;
        }

        .doctor-meta {
            display: flex;
            flex-direction: column;
        }

        .doctor-label {
            font-size: 13px;
            font-weight: 700;
            color: #0D9488;
            margin-bottom: 2px;
        }

        .doctor-name {
            font-size: 20px;
            font-weight: 900;
            color: #0F172A;
            line-height: 1.2;
            margin-bottom: 2px;
        }

        .doctor-spec {
            font-size: 13px;
            font-weight: 600;
            color: #64748B;
        }

        /* Clinic Details & Contact Card */
        .clinic-info-card {
            background: #071527;
            border-radius: 20px;
            padding: 18px 22px;
            color: #FFFFFF;
            box-shadow: 0 12px 30px rgba(7, 21, 39, 0.25);
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .info-row {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .info-row-icon {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            border: 2px solid #0D9488;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2DD4BF;
            flex-shrink: 0;
        }

        .info-row-icon svg {
            width: 22px;
            height: 22px;
            fill: #2DD4BF;
        }

        .info-row-details {
            display: flex;
            flex-direction: column;
        }

        .info-row-label {
            font-size: 11px;
            font-weight: 700;
            color: #2DD4BF;
            margin-bottom: 2px;
        }

        .info-row-value {
            font-size: 15px;
            font-weight: 800;
            color: #FFFFFF;
            direction: ltr;
            text-align: right;
        }

        .info-row-divider {
            height: 1px;
            background: rgba(255, 255, 255, 0.1);
        }

        /* ================= RIGHT COLUMN ================= */
        .right-column {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            gap: 20px;
            height: 100%;
        }

        .live-queue-wrapper {
            display: none;
            flex-direction: column;
            justify-content: space-between;
            gap: 20px;
            height: 100%;
        }

        /* Standby Card Styling (When session hasn't started) */
        .standby-card {
            flex: 1;
            background: #FFFFFF;
            border-radius: 28px;
            box-shadow: 0 14px 40px rgba(15, 23, 42, 0.07);
            border: 1px solid rgba(226, 232, 240, 0.9);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px 36px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .standby-icon-circle {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            background: rgba(13, 148, 136, 0.08);
            border: 2px dashed #0D9488;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            animation: pulse-ring 2.5s infinite ease-in-out;
        }

        .standby-icon-circle svg {
            width: 48px;
            height: 48px;
            fill: #0D9488;
        }

        @keyframes pulse-ring {
            0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(13, 148, 136, 0.25); }
            50% { transform: scale(1.06); box-shadow: 0 0 0 14px rgba(13, 148, 136, 0); }
            100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(13, 148, 136, 0); }
        }

        .standby-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #FEF3C7;
            color: #92400E;
            border: 1px solid #FCD34D;
            padding: 6px 18px;
            border-radius: 20px;
            font-size: 15px;
            font-weight: 800;
            margin-bottom: 14px;
        }

        .standby-dot {
            width: 8px;
            height: 8px;
            background: #D97706;
            border-radius: 50%;
            display: inline-block;
            animation: blink 1.5s infinite;
        }

        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.3; }
        }

        .standby-title {
            font-size: 30px;
            font-weight: 900;
            color: #071527;
            margin-bottom: 10px;
        }

        .standby-desc {
            font-size: 18px;
            font-weight: 600;
            color: #64748B;
            line-height: 1.5;
            max-width: 520px;
            margin-bottom: 22px;
        }

        .standby-tip {
            background: #F0FDF4;
            border: 1px solid #BBF7D0;
            color: #166534;
            padding: 12px 24px;
            border-radius: 16px;
            font-size: 15px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .standby-tip svg {
            width: 20px;
            height: 20px;
            fill: #16A34A;
            flex-shrink: 0;
        }

        /* Main Current Patient Card */
        .current-patient-card {
            flex: 1;
            background: #FFFFFF;
            border-radius: 28px;
            box-shadow: 0 14px 40px rgba(15, 23, 42, 0.07);
            border: 1px solid rgba(226, 232, 240, 0.9);
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px 24px 20px 24px;
            overflow: hidden;
            transition: all 0.4s ease;
        }

        .current-patient-card.calling-pulse {
            border-color: #0D9488;
            box-shadow: 0 0 50px rgba(13, 148, 136, 0.45);
            animation: pulse-border 1.2s infinite alternate;
        }

        @keyframes pulse-border {
            0% { transform: scale(1); }
            100% { transform: scale(1.015); }
        }

        /* Attached Top Right Pill Badge */
        .current-pill-tag {
            position: absolute;
            top: 0;
            right: 50px;
            background: linear-gradient(135deg, #0D9488 0%, #0F766E 100%);
            color: #FFFFFF;
            padding: 10px 28px;
            border-bottom-left-radius: 24px;
            border-bottom-right-radius: 24px;
            font-size: 18px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 6px 18px rgba(13, 148, 136, 0.35);
        }

        .pill-icon {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            border: 1.5px solid rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .pill-icon svg {
            width: 16px;
            height: 16px;
            fill: #FFFFFF;
        }

        /* Giant Bold Queue Number */
        .giant-queue-number {
            font-size: 190px;
            font-weight: 900;
            line-height: 0.95;
            color: #071527;
            font-variant-numeric: tabular-nums;
            letter-spacing: -2px;
            margin-top: 10px;
            text-align: center;
            z-index: 2;
        }

        .current-patient-name {
            font-size: 26px;
            font-weight: 800;
            color: #0D9488;
            margin-top: 4px;
            min-height: 32px;
            z-index: 2;
        }

        /* Subtle Wave Vector graphic at the bottom of the card */
        .card-wave-bg {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 70px;
            opacity: 0.25;
            pointer-events: none;
            z-index: 1;
        }

        /* Next Patients Section */
        .next-patients-section {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .next-section-header {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 16px;
        }

        .next-header-line {
            flex: 1;
            height: 1px;
            background: #0D9488;
            opacity: 0.4;
            position: relative;
        }

        .next-header-line.left-line::after {
            content: '';
            position: absolute;
            left: 0;
            top: -2px;
            width: 5px;
            height: 5px;
            background: #0D9488;
            border-radius: 50%;
        }

        .next-header-line.right-line::after {
            content: '';
            position: absolute;
            right: 0;
            top: -2px;
            width: 5px;
            height: 5px;
            background: #0D9488;
            border-radius: 50%;
        }

        .next-header-title {
            font-size: 17px;
            font-weight: 800;
            color: #0F766E;
        }

        /* 5 Next Patient Cards Row */
        .next-cards-row {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 14px;
        }

        .next-tile {
            background: #FFFFFF;
            border-radius: 18px;
            height: 96px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-shadow: 0 6px 16px rgba(15, 23, 42, 0.05);
            border: 1px solid rgba(226, 232, 240, 0.85);
            position: relative;
            transition: transform 0.2s;
        }

        .next-tile-number {
            font-size: 44px;
            font-weight: 900;
            color: #071527;
            line-height: 1;
            margin-bottom: 6px;
            font-variant-numeric: tabular-nums;
        }

        .next-tile-bar {
            width: 28px;
            height: 4px;
            background: #0D9488;
            border-radius: 2px;
        }

        /* ================= BOTTOM FOOTER BAR ================= */
        .bottom-footer-bar {
            height: 60px;
            background: #071527;
            border-radius: 20px;
            padding: 0 28px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: #FFFFFF;
            box-shadow: 0 10px 25px rgba(7, 21, 39, 0.3);
            flex-shrink: 0;
        }

        .footer-segment {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .footer-icon-circle {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            border: 1.5px solid #0D9488;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2DD4BF;
        }

        .footer-icon-circle svg {
            width: 20px;
            height: 20px;
            fill: #2DD4BF;
        }

        .footer-text-bold {
            font-size: 18px;
            font-weight: 800;
            color: #FFFFFF;
            letter-spacing: 0.5px;
        }

        .footer-text-subtle {
            font-size: 14px;
            font-weight: 600;
            color: #2DD4BF;
            margin-right: 4px;
        }

        .footer-center-slogan {
            font-size: 16px;
            font-weight: 800;
            color: #E2E8F0;
            letter-spacing: 0.5px;
        }

        .footer-divider-dot {
            width: 1px;
            height: 24px;
            background: rgba(255, 255, 255, 0.15);
            margin: 0 10px;
        }
    </style>
</head>
<body onclick="autoEnableAudio()" onkeydown="autoEnableAudio()">

    <!-- Decorative Elements from Reference Design -->
    <div class="ambient-shape-left"></div>
    <div class="dot-matrix left-mid">
        <span></span><span></span><span></span><span></span>
        <span></span><span></span><span></span><span></span>
        <span></span><span></span><span></span><span></span>
        <span></span><span></span><span></span><span></span>
    </div>
    <div class="dot-matrix right-edge">
        <span></span><span></span><span></span><span></span>
        <span></span><span></span><span></span><span></span>
        <span></span><span></span><span></span><span></span>
        <span></span><span></span><span></span><span></span>
    </div>

    <!-- Hidden HTML5 Audio Element for Phone TTS Stream -->
    <audio id="tvAudioPlayer" preload="auto"></audio>

    <!-- Top Discreet Audio Unlock Prompt for Smart TVs -->
    <div id="audioUnlockBar" class="audio-unmute-bar" onclick="enableAudioOnTv(event)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
        <span>انقر على الشاشة أو اضغط OK في جهاز التحكم لتفعيل الصوت</span>
    </div>

    <!-- Main Screen Container -->
    <div class="screen-container">

        <div class="content-body">

            <!-- ================= LEFT COLUMN ================= -->
            <div class="left-column">

                <!-- Clinic Identity -->
                <div class="clinic-brand-box">
                    <div class="brand-logo-circle">
                        <div class="brand-logo-inner">
                            <svg viewBox="0 0 24 24"><path d="M19 10.5h-4.5V6a1.5 1.5 0 0 0-3 0v4.5H7a1.5 1.5 0 0 0 0 3h4.5V18a1.5 1.5 0 0 0 3 0v-4.5H19a1.5 1.5 0 0 0 0-3z"/></svg>
                        </div>
                    </div>
                    <div class="clinic-titles">
                        <h1 id="clinicName">عيادة الشفاء التخصصية</h1>
                        <p id="clinicSubtitle">للطب و الاستشارات الطبية</p>
                        <div class="brand-divider"></div>
                    </div>
                </div>

                <!-- Doctor Info Card -->
                <div class="doctor-card">
                    <div class="doctor-avatar">
                        <svg viewBox="0 0 24 24"><path d="M12 2a4 4 0 0 1 4 4 4 4 0 0 1-4 4 4 4 0 0 1-4-4 4 4 0 0 1 4-4m0 10c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4z"/></svg>
                    </div>
                    <div class="doctor-meta">
                        <span class="doctor-label">الطبيب المعالج</span>
                        <span class="doctor-name" id="doctorName">د. أحمد عبدالله</span>
                        <span class="doctor-spec" id="doctorSpec" style="display: none;"></span>
                    </div>
                </div>

                <!-- Clinic Details & Contact Card -->
                <div class="clinic-info-card">
                    <div class="info-row">
                        <div class="info-row-icon">
                            <svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
                        </div>
                        <div class="info-row-details">
                            <span class="info-row-label">رقم الهاتف / الحجز</span>
                            <span class="info-row-value" id="clinicPhone">07701234567</span>
                        </div>
                    </div>
                    <div class="info-row-divider"></div>
                    <div class="info-row">
                        <div class="info-row-icon">
                            <svg viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
                        </div>
                        <div class="info-row-details">
                            <span class="info-row-label">موقع العيادة</span>
                            <span class="info-row-value" id="clinicAddress" style="direction: rtl; font-size: 14px;">بغداد - الحارثية</span>
                        </div>
                    </div>
                </div>

            </div>

            <!-- ================= RIGHT COLUMN ================= -->
            <div class="right-column">

                <!-- 1. Standby Screen (Shown before pressing Start) -->
                <div class="standby-card" id="standbyCard">
                    <div class="standby-icon-circle">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
                    </div>
                    <div class="standby-badge">
                        <span class="standby-dot"></span>
                        <span>مرحلة تسجيل المراجعين</span>
                    </div>
                    <div class="standby-title">أهلاً وسهلاً بكم في العيادة</div>
                    <div class="standby-desc">يتم حالياً تجهيز وإدخال المراجعين، وسيبدأ عرض الأدوار والنداء الصوتي فور بدء الجلسة</div>
                    <div class="standby-tip">
                        <svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/></svg>
                        <span>يرجى استلام وصل وتذكرة المراجعة والانتظار في الصالة</span>
                    </div>
                </div>

                <!-- 2. Live Active Queue Wrapper (Shown when session is Started) -->
                <div class="live-queue-wrapper" id="liveQueueWrapper">
                    <!-- Current Active Patient Box -->
                    <div class="current-patient-card" id="currentPatientCard">
                        <!-- Top Right Badge Pill -->
                        <div class="current-pill-tag">
                            <div class="pill-icon">
                                <svg viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                            </div>
                            <span>رقم المراجع الحالي</span>
                        </div>

                        <!-- Giant Number -->
                        <div class="giant-queue-number" id="currentNumber">--</div>
                        <div class="current-patient-name" id="currentPatientName"></div>

                        <!-- SVG Wave texture -->
                        <svg class="card-wave-bg" viewBox="0 0 500 150" preserveAspectRatio="none">
                            <path d="M0,80 C150,140 350,20 500,80 L500,150 L0,150 Z" fill="#0D9488" />
                        </svg>
                    </div>

                    <!-- Next Upcoming Queue Numbers -->
                    <div class="next-patients-section">
                        <div class="next-section-header">
                            <div class="next-header-line right-line"></div>
                            <div class="next-header-title">أرقام المراجعين التالية</div>
                            <div class="next-header-line left-line"></div>
                        </div>

                        <!-- 5 Next Tiles Row -->
                        <div class="next-cards-row" id="nextCardsRow">
                            <div class="next-tile"><div class="next-tile-number">--</div><div class="next-tile-bar"></div></div>
                            <div class="next-tile"><div class="next-tile-number">--</div><div class="next-tile-bar"></div></div>
                            <div class="next-tile"><div class="next-tile-number">--</div><div class="next-tile-bar"></div></div>
                            <div class="next-tile"><div class="next-tile-number">--</div><div class="next-tile-bar"></div></div>
                            <div class="next-tile"><div class="next-tile-number">--</div><div class="next-tile-bar"></div></div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

        <!-- ================= BOTTOM FOOTER BAR ================= -->
        <footer class="bottom-footer-bar">
            <!-- Left: Date -->
            <div class="footer-segment">
                <div class="footer-icon-circle">
                    <svg viewBox="0 0 24 24"><path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V10h14v10zm0-12H5V6h14v2z"/></svg>
                </div>
                <div class="footer-text-bold" id="liveDateText">الثلاثاء 26 أغسطس 2025</div>
            </div>

            <div class="footer-divider-dot"></div>

            <!-- Center: Slogan -->
            <div class="footer-segment">
                <div class="footer-icon-circle">
                    <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                </div>
                <div class="footer-center-slogan" id="footerSlogan">رعايتكم هي أولويتنا</div>
            </div>

            <div class="footer-divider-dot"></div>

            <!-- Right: Live Clock -->
            <div class="footer-segment">
                <div class="footer-icon-circle">
                    <svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                </div>
                <div class="footer-text-bold" id="liveTimeText">10:30</div>
                <span class="footer-text-subtle" id="liveAmPmText">صباحاً</span>
            </div>
        </footer>

    </div>

    <script>
        let audioContext = null;
        let isAudioAllowed = false;
        let lastPlayedCallId = 0;
        let arabicVoice = null;

        function loadArabicVoices() {
            if (!('speechSynthesis' in window)) return;
            const voices = window.speechSynthesis.getVoices();
            if (voices && voices.length > 0) {
                arabicVoice = voices.find(v => v.lang && (v.lang.startsWith('ar') || v.lang.includes('AR'))) || voices[0];
            }
        }

        if ('speechSynthesis' in window) {
            loadArabicVoices();
            window.speechSynthesis.onvoiceschanged = loadArabicVoices;
        }

        function enableAudioOnTv(e) {
            if (e) e.stopPropagation();
            try {
                if (!audioContext) {
                    audioContext = new (window.AudioContext || window.webkitAudioContext)();
                }
                if (audioContext.state === 'suspended') {
                    audioContext.resume();
                }

                const audioPlayer = document.getElementById('tvAudioPlayer');
                if (audioPlayer) {
                    audioPlayer.play().catch(() => {});
                }

                isAudioAllowed = true;
                const unlockBar = document.getElementById('audioUnlockBar');
                if (unlockBar) {
                    unlockBar.classList.add('muted-hidden');
                }

                loadArabicVoices();
                playHospitalChime();
            } catch (err) {
                console.error("Audio init error:", err);
            }
        }

        function autoEnableAudio() {
            if (!isAudioAllowed) {
                enableAudioOnTv();
            }
        }

        // 2-tone melodic chime (880Hz -> 659.25Hz)
        function playHospitalChime() {
            try {
                if (!audioContext) {
                    audioContext = new (window.AudioContext || window.webkitAudioContext)();
                }
                if (audioContext.state === 'suspended') {
                    audioContext.resume();
                }

                const now = audioContext.currentTime;

                const osc1 = audioContext.createOscillator();
                const gain1 = audioContext.createGain();
                osc1.type = 'sine';
                osc1.frequency.setValueAtTime(880, now);
                gain1.gain.setValueAtTime(0.7, now);
                gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
                osc1.connect(gain1);
                gain1.connect(audioContext.destination);
                osc1.start(now);
                osc1.stop(now + 0.5);

                const osc2 = audioContext.createOscillator();
                const gain2 = audioContext.createGain();
                osc2.type = 'sine';
                osc2.frequency.setValueAtTime(659.25, now + 0.35);
                gain2.gain.setValueAtTime(0.8, now + 0.35);
                gain2.gain.exponentialRampToValueAtTime(0.001, now + 1.1);
                osc2.connect(gain2);
                gain2.connect(audioContext.destination);
                osc2.start(now + 0.35);
                osc2.stop(now + 1.1);
            } catch (err) {
                console.error("Chime error:", err);
            }
        }

        let currentVolume = 1.0;
        let currentSpeechRate = 0.85;

        // Play call announcement with direct phone TTS stream audio
        function playPatientCallAnnouncement(queueNumber) {
            playHospitalChime();

            const audioPlayer = document.getElementById('tvAudioPlayer');
            if (audioPlayer) {
                audioPlayer.volume = Math.max(0.1, Math.min(1.0, currentVolume));
                setTimeout(() => {
                    audioPlayer.src = '/api/audio/latest.wav?t=' + Date.now();
                    audioPlayer.play().catch(err => {
                        console.log("Audio file play fallback to synthesis:", err);
                        speakPatientFallback(queueNumber);
                    });
                }, 550);
            } else {
                speakPatientFallback(queueNumber);
            }
        }

        function speakPatientFallback(queueNumber) {
            if (!('speechSynthesis' in window)) return;
            try {
                window.speechSynthesis.cancel();
                const phrase = "المراجع رقم " + (queueNumber || "1") + " ، يرجى التوجه إلى غرفة العيادة";
                const utterance = new SpeechSynthesisUtterance(phrase);
                utterance.lang = 'ar-SA';
                utterance.rate = Math.max(0.5, Math.min(1.5, currentSpeechRate));
                utterance.volume = Math.max(0.1, Math.min(1.0, currentVolume));
                loadArabicVoices();
                if (arabicVoice) utterance.voice = arabicVoice;
                window.speechSynthesis.speak(utterance);
            } catch (e) {}
        }

        // Real-time polling function
        async function fetchQueueStatus() {
            try {
                const response = await fetch('/api/status?t=' + Date.now());
                if (!response.ok) return;

                const data = await response.json();

                // 1. Clinic & Doctor Details
                if (data.clinicName && data.clinicName.trim() !== '') {
                    document.getElementById('clinicName').innerText = data.clinicName;
                }
                if (data.clinicSubtitle && data.clinicSubtitle.trim() !== '') {
                    document.getElementById('clinicSubtitle').innerText = data.clinicSubtitle;
                }
                if (data.doctorName && data.doctorName.trim() !== '') {
                    document.getElementById('doctorName').innerText = data.doctorName;
                }
                if (data.clinicPhone && data.clinicPhone.trim() !== '') {
                    document.getElementById('clinicPhone').innerText = data.clinicPhone;
                }
                if (data.clinicAddress && data.clinicAddress.trim() !== '') {
                    document.getElementById('clinicAddress').innerText = data.clinicAddress;
                }
                if (data.customFooter && data.customFooter.trim() !== '') {
                    document.getElementById('footerSlogan').innerText = data.customFooter;
                }
                if (typeof data.volume === 'number') {
                    currentVolume = data.volume;
                }
                if (typeof data.speechRate === 'number') {
                    currentSpeechRate = data.speechRate;
                }

                // 2. Session Started / Standby Switch
                const isStarted = !!data.isSessionStarted;
                const standbyCard = document.getElementById('standbyCard');
                const liveQueueWrapper = document.getElementById('liveQueueWrapper');
                if (isStarted) {
                    if (standbyCard) standbyCard.style.display = 'none';
                    if (liveQueueWrapper) liveQueueWrapper.style.display = 'flex';
                } else {
                    if (standbyCard) standbyCard.style.display = 'flex';
                    if (liveQueueWrapper) liveQueueWrapper.style.display = 'none';
                }

                // 3. Active Patient
                const heroCard = document.getElementById('currentPatientCard');
                const numEl = document.getElementById('currentNumber');
                const nameEl = document.getElementById('currentPatientName');

                if (isStarted && data.currentPatient && data.currentPatient.number) {
                    numEl.innerText = data.currentPatient.number;
                    nameEl.innerText = data.currentPatient.name ? data.currentPatient.name : '';
                } else {
                    numEl.innerText = '--';
                    nameEl.innerText = isStarted ? 'بانتظار استدعاء المراجع' : '';
                }

                // 4. Upcoming 5 Waiting Patients
                const nextRow = document.getElementById('nextCardsRow');
                if (nextRow && data.waitingList && Array.isArray(data.waitingList)) {
                    let tilesHtml = '';
                    const top5 = isStarted ? data.waitingList.slice(0, 5) : [];
                    for (let i = 0; i < 5; i++) {
                        const p = top5[i];
                        const val = p ? p.number : '--';
                        tilesHtml += '<div class="next-tile"><div class="next-tile-number">' + val + '</div><div class="next-tile-bar"></div></div>';
                    }
                    nextRow.innerHTML = tilesHtml;
                }

                // 5. Calling event trigger (Only when session is active)
                if (isStarted && data.activeCall && data.activeCall.callId && data.activeCall.callId > lastPlayedCallId) {
                    lastPlayedCallId = data.activeCall.callId;

                    if (heroCard) {
                        heroCard.classList.add('calling-pulse');
                        setTimeout(() => {
                            heroCard.classList.remove('calling-pulse');
                        }, 6000);
                    }

                    if (isAudioAllowed) {
                        playPatientCallAnnouncement(data.activeCall.queueNumber);
                    }
                }

            } catch (err) {
                console.error("Fetch error:", err);
            }
        }

        // Live Clock & Arabic Date Formatter
        function updateClock() {
            const now = new Date();

            // Time & AM/PM
            let hours = now.getHours();
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const isPm = hours >= 12;
            hours = hours % 12;
            hours = hours ? hours : 12; // 12-hour format

            document.getElementById('liveTimeText').innerText = hours + ':' + minutes;
            document.getElementById('liveAmPmText').innerText = isPm ? 'مساءً' : 'صباحاً';

            // Arabic Day & Date
            const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
            const months = [
                'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
            ];

            const dayName = days[now.getDay()];
            const dayNum = now.getDate();
            const monthName = months[now.getMonth()];
            const yearNum = now.getFullYear();

            document.getElementById('liveDateText').innerText = dayName + ' ' + dayNum + ' ' + monthName + ' ' + yearNum;
        }

        // Global listeners to automatically activate audio on any keypress (Remote Control OK/Enter/Arrows) or click
        window.addEventListener('click', enableAudioOnTv);
        window.addEventListener('keydown', enableAudioOnTv);
        window.addEventListener('touchstart', enableAudioOnTv);
        window.addEventListener('pointerdown', enableAudioOnTv);

        // Start loops
        setInterval(fetchQueueStatus, 700);
        setInterval(updateClock, 1000);
        fetchQueueStatus();
        updateClock();
    </script>
</body>
</html>
        """.trimIndent()
    }
}
