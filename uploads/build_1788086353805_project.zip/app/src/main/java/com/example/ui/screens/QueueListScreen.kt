package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.audio.CallingState
import com.example.data.model.Patient
import com.example.data.model.UserAccountType
import com.example.ui.components.ClinicBottomNavBar
import com.example.ui.components.TvDisplayDialog
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.QueueFilterType

@Composable
fun QueueListScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val pagedPatients by viewModel.pagedPatients.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val liveTotalCount by viewModel.liveTotalCount.collectAsState()
    val waitingCount by viewModel.waitingCount.collectAsState()
    val postponedCount by viewModel.postponedCount.collectAsState()
    val servedCount by viewModel.servedCount.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()
    val totalPages by viewModel.totalPages.collectAsState()
    val currentFilterCount by viewModel.currentFilterCount.collectAsState()
    val pageSize by viewModel.pageSize.collectAsState()
    val nextNumber by viewModel.nextQueueNumber.collectAsState()

    val currentPatient by viewModel.currentPatient.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val callingState by viewModel.callingState.collectAsState()
    val activeCallingPatient by viewModel.activeCallingPatient.collectAsState()

    val showAddDialog by viewModel.showAddPatientDialog.collectAsState()
    val previewPatient by viewModel.previewTicketPatient.collectAsState()
    val showTvDialog by viewModel.showTvDialog.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()

    val isTvServerRunning by viewModel.isTvServerRunning.collectAsState()
    val tvServerUrl by viewModel.tvServerUrl.collectAsState()
    val isTvConnected by viewModel.isTvConnected.collectAsState()
    val isPrinterConnected by viewModel.isPrinterConnected.collectAsState()
    val isHotspotActive by viewModel.isHotspotActive.collectAsState()
    val hotspotSsid by viewModel.hotspotSsid.collectAsState()
    val hotspotPassword by viewModel.hotspotPassword.collectAsState()
    val hotspotStatusMessage by viewModel.hotspotStatusMessage.collectAsState()
    val isHotspotLoading by viewModel.isHotspotLoading.collectAsState()
    val isTvAudioOnly by viewModel.isTvAudioOnly.collectAsState()
    val isQueueStarted by viewModel.isQueueStarted.collectAsState()
    val authState by viewModel.authState.collectAsState()
    val allPatientsList by viewModel.patients.collectAsState()

    var patientToDelete by remember { mutableStateOf<Patient?>(null) }
    var patientToPostpone by remember { mutableStateOf<Patient?>(null) }

    // ضبط اتجاه الواجهة من اليمين إلى اليسار (RTL) لمطابقة التصميم المرفق بالصورة بدقة 100%
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier.fillMaxSize()
        ) {
            // خلفية العيادة الواقعية مع تدرج وطبقة زجاجية ناعمة
            Image(
                painter = painterResource(id = R.drawable.bg_clinic),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // طبقة الشفافية واللون الطبي الهادئ (Frosted Glass Overlay)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF1F5F9).copy(alpha = 0.52f))
            )

            Column(modifier = Modifier.fillMaxSize()) {
                // =========================================================
                // 1. الهيدر العلوي: اسم العيادة والطبيب، زر الحذف، ومؤشرات الأجهزة
                // =========================================================
                TopClinicHeaderExact(
                    clinicName = settings.clinicName.ifBlank { "عيادة الشفاء التخصصية" },
                    doctorName = settings.doctorName.ifBlank { "د. أحمد عبدالله" },
                    isTvConnected = isTvConnected,
                    isPrinterConnected = isPrinterConnected,
                    onDeleteAllClick = { viewModel.onOpenResetDialog() },
                    onTvClick = { viewModel.onOpenTvDialog() },
                    onPrinterClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) }
                )

                // شريط النداء الصوتي الحي
                AnimatedVisibility(
                    visible = callingState != CallingState.IDLE,
                    enter = slideInVertically() + fadeIn(),
                    exit = slideOutVertically() + fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F172A).copy(alpha = 0.90f))
                            .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(15.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جاري النداء الصوتي للمراجع رقم ${activeCallingPatient?.formattedNumber ?: (currentPatient?.formattedNumber ?: "")}...",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = Color(0xFF22C55E),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // =========================================================
                // 2. بطاقة تشغيل عرض المراجعين على شاشة TV مع زر البدء الدائري المتناسق
                // =========================================================
                StandbyControlCard(
                    waitingCount = waitingCount,
                    isQueueStarted = isQueueStarted,
                    currentPatient = currentPatient,
                    onStartClick = { viewModel.onStartQueueClicked() },
                    onPauseClick = { viewModel.onPauseQueue() }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // =========================================================
                // 3. شريط أزرار الفلترة الأفقية المتصل المماثل للتصميم الزجاجي بالصورة
                // =========================================================
                FilterButtonBarExact(
                    selectedFilter = selectedFilter,
                    liveTotalCount = liveTotalCount,
                    waitingCount = waitingCount,
                    postponedCount = postponedCount,
                    servedCount = servedCount,
                    onSelectFilter = { viewModel.onSelectFilter(it) }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // =========================================================
                // 4. قائمة بطاقات المراجعين الزجاجية
                // =========================================================
                if (pagedPatients.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White.copy(alpha = 0.75f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.9f)),
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2563EB).copy(alpha = 0.10f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FormatListNumbered,
                                        contentDescription = null,
                                        tint = Color(0xFF2563EB),
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = when (selectedFilter) {
                                        QueueFilterType.ALL -> "قائمة المراجعين فارغة"
                                        QueueFilterType.WAITING -> "لا يوجد مراجعين في الانتظار"
                                        QueueFilterType.POSTPONED -> "لا يوجد مراجعين مؤجلين"
                                        QueueFilterType.SERVED -> "لم يتم استدعاء أي مراجع بعد"
                                    },
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "اضغط على زر (+) في الشريط السفلي لإضافة مراجع جديد",
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(pagedPatients, key = { it.id }) { patient ->
                            val isActive = (currentPatient?.id == patient.id) || (activeCallingPatient?.id == patient.id)
                            PatientCardExactMatch(
                                patient = patient,
                                isActive = isActive,
                                onCardClick = { viewModel.onCallSpecificPatient(patient) },
                                onCalendarClick = { viewModel.onOpenTicketPreview(patient) },
                                onDeleteClick = { patientToDelete = patient },
                                onPostponeClick = { patientToPostpone = patient },
                                onRestoreClick = { viewModel.onRestorePostponedToQueue(patient) }
                            )
                        }
                        item {
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }
                }

                // =========================================================
                // 5. شريط الترقيم المماثل للصورة (التالي | صفحة 1 من 5 | السابق)
                // =========================================================
                if (totalPages > 1 || currentFilterCount > 0) {
                    PaginationBarExactMatch(
                        currentPage = currentPage,
                        totalPages = if (totalPages < 1) 1 else totalPages,
                        totalCount = currentFilterCount,
                        onPrevClick = { viewModel.onPrevPage() },
                        onNextClick = { viewModel.onNextPage() }
                    )
                }

                // =========================================================
                // 6. شريط التنقل السفلي: قائمة المراجعين + زر الإضافة (+) + الإعدادات
                // =========================================================
                ClinicBottomNavBar(
                    activeScreen = AppScreen.QUEUE_LIST,
                    onQueueClick = { /* Already here */ },
                    onAddClick = { viewModel.onAddPatientClicked() },
                    onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
                )
            }
        }
    }

    // =========================================================
    // النوافذ المنبثقة
    // =========================================================
    if (showAddDialog) {
        AddPatientDialog(
            nextQueueNumber = nextNumber,
            initialAutoPrint = settings.autoPrintOnAdd,
            onConfirm = { name, note, shouldPrint ->
                viewModel.onConfirmAddPatient(name, note, shouldPrint)
            },
            onDismiss = { viewModel.onDismissAddPatientDialog() }
        )
    }

    if (previewPatient != null) {
        TicketPreviewDialog(
            patient = previewPatient!!,
            settings = settings,
            onPrintClick = { viewModel.onPrintPreviewTicket() },
            onDismiss = { viewModel.onDismissTicketPreview() }
        )
    }

    if (showTvDialog) {
        TvDisplayDialog(
            isRunning = isTvServerRunning,
            serverUrl = tvServerUrl,
            isHotspotActive = isHotspotActive,
            hotspotSsid = hotspotSsid,
            hotspotPassword = hotspotPassword,
            hotspotStatusMessage = hotspotStatusMessage,
            isHotspotLoading = isHotspotLoading,
            isTvAudioOnly = isTvAudioOnly,
            onToggleServer = { viewModel.onToggleTvServer(it) },
            onToggleHotspot = { viewModel.onToggleLocalHotspot(it) },
            onToggleTvAudioOnly = { viewModel.onToggleTvAudioOnly(it) },
            onRefreshIp = { viewModel.onRefreshTvIp() },
            onDismiss = { viewModel.onDismissTvDialog() }
        )
    }

    patientToDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientToDelete = null },
            title = {
                Text(
                    text = "حذف المراجع",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = NavyDark
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف المراجع رقم ${patient.formattedNumber}${if (patient.name.isNotBlank()) " (${patient.name})" else ""} من القائمة؟",
                    fontSize = 14.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeletePatient(patient)
                        patientToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "حذف", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { patientToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "إلغاء", color = NavyDark, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }

    patientToPostpone?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientToPostpone = null },
            title = {
                Text(
                    text = "تأجيل المراجع",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color(0xFF0F172A)
                )
            },
            text = {
                val namePart = if (patient.name.isNotBlank()) " (${patient.name})" else ""
                Text(
                    text = "هل أنت متأكد من رغبتك في تأجيل المراجع رقم #${patient.formattedNumber}$namePart ونقله إلى قائمة المؤجلين؟",
                    fontSize = 14.sp,
                    color = Color(0xFF334155),
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onPostponeSpecificPatient(patient)
                        patientToPostpone = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "تأكيد التأجيل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { patientToPostpone = null },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Text(text = "إلغاء", color = Color(0xFF475569), fontWeight = FontWeight.Medium, fontSize = 13.sp)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

/**
 * الشريط العلوي للعيادة بتصميم زجاجي احترافي:
 * - اليمين: اسم العيادة والطبيب مع أيقونة المركز الطبي
 * - اليسار: زر تصفير / حذف الدور
 * - السطر الثاني: كبسولتا حالة شاشة العرض TV والطابعة مع مؤشر الاتصال المضيء
 */
@Composable
private fun TopClinicHeaderExact(
    clinicName: String,
    doctorName: String,
    isTvConnected: Boolean,
    isPrinterConnected: Boolean,
    onDeleteAllClick: () -> Unit,
    onTvClick: () -> Unit,
    onPrinterClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        color = Color.White.copy(alpha = 0.82f),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.95f)),
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // الصف الأول: اسم العيادة والطبيب في اليمين بشكل مريح، وزر حذف الجميع في أقصى اليسار
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // أيقونة العيادة الطبية بتصميم تدرجي أنيق
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .shadow(2.dp, RoundedCornerShape(14.dp), spotColor = Color(0x332563EB))
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF3B82F6), Color(0xFF1D4ED8))
                                )
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalHospital,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = clinicName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = doctorName,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // زر إعادة ضبط / تصفير الدور في اليسار
                Surface(
                    onClick = onDeleteAllClick,
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFEF2F2).copy(alpha = 0.90f),
                    border = BorderStroke(1.dp, Color(0xFFFECACA)),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("delete_all_patients_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف الجميع",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "تصفير الدور",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // الصف الثاني: كبسولتا الأجهزة المتناسقة
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // كبسولة الشاشة
                DeviceChipExact(
                    label = if (isTvConnected) "شاشة متصلة" else "شاشة غير متصلة",
                    icon = Icons.Default.Tv,
                    isConnected = isTvConnected,
                    onClick = onTvClick,
                    modifier = Modifier.weight(1f)
                )

                // كبسولة الطابعة
                DeviceChipExact(
                    label = if (isPrinterConnected) "طابعة متصلة" else "طابعة غير متصلة",
                    icon = Icons.Default.Print,
                    isConnected = isPrinterConnected,
                    onClick = onPrinterClick,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * كبسولة الأجهزة كما في التطبيقات الطبية التجارية
 */
@Composable
private fun DeviceChipExact(
    label: String,
    icon: ImageVector,
    isConnected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isConnected) Color(0xFFF0FDF4).copy(alpha = 0.85f) else Color.White.copy(alpha = 0.70f),
        border = BorderStroke(1.dp, if (isConnected) Color(0xFF86EFAC) else Color(0xFFE2E8F0)),
        modifier = modifier.height(36.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // الأيقونة والنص على اليمين (RTL)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isConnected) Color(0xFF16A34A) else Color(0xFF64748B),
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = label,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isConnected) Color(0xFF15803D) else Color(0xFF475569)
                )
            }

            // مؤشر الاتصال المضيء في اليسار (LED Dot) مع هالة ناعمة
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (isConnected) Color(0xFF22C55E) else Color(0xFFCBD5E1))
                    .border(1.5.dp, Color.White, CircleShape)
            )
        }
    }
}

/**
 * بطاقة تشغيل عرض المراجعين على شاشة TV:
 * - النص والمعلومات على اليمين
 * - زر "بدء" (أو "إيقاف مؤقت") دائري متناسق وأنيق
 */
@Composable
private fun StandbyControlCard(
    waitingCount: Int,
    isQueueStarted: Boolean,
    currentPatient: Patient?,
    onStartClick: () -> Unit,
    onPauseClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.82f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.95f)),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // اليمين (RTL): العنوان وحالة العرض والعدد
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(if (isQueueStarted) Color(0xFF22C55E) else Color(0xFFF59E0B))
                            .border(1.dp, Color.White, CircleShape)
                    )
                    Text(
                        text = if (isQueueStarted && currentPatient != null) {
                            if (currentPatient.name.isNotBlank()) {
                                "المراجع الحالي: ${currentPatient.name} (#${currentPatient.formattedNumber})"
                            } else {
                                "المراجع الحالي: رقم #${currentPatient.formattedNumber}"
                            }
                        } else if (isQueueStarted) {
                            "الجلسة نشطة (انقر على مراجع لبدء النداء)"
                        } else {
                            "تشغيل عرض المراجعين على شاشة TV"
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isQueueStarted) Color(0xFF15803D) else Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = if (isQueueStarted) {
                        if (currentPatient != null) {
                            "$waitingCount مراجع في الانتظار"
                        } else {
                            "اضغط على أي مراجع في القائمة لعرض رقمه على شاشة TV"
                        }
                    } else {
                        "$waitingCount مراجع بانتظار البدء (اضغط بدء للتفعيل)"
                    },
                    fontSize = 11.5.sp,
                    color = Color(0xFF64748B)
                )
            }

            // اليسار: زر البدء الزجاجي الدائري المتناسق
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .shadow(elevation = 4.dp, shape = CircleShape, spotColor = Color(0x33000000))
                    .clip(CircleShape)
                    .background(
                        if (isQueueStarted) {
                            Brush.linearGradient(listOf(Color(0xFFD97706), Color(0xFFB45309)))
                        } else {
                            Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
                        }
                    )
                    .border(2.dp, Color.White.copy(alpha = 0.90f), CircleShape)
                    .clickable {
                        if (isQueueStarted) onPauseClick() else onStartClick()
                    }
                    .testTag("start_queue_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isQueueStarted) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isQueueStarted) "إيقاف مؤقت" else "بدء",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

/**
 * شريط أزرار الفلترة الزجاجي المتصل (الكل | في الانتظار | المؤجلين | تم استدعاء)
 */
@Composable
private fun FilterButtonBarExact(
    selectedFilter: QueueFilterType,
    liveTotalCount: Int,
    waitingCount: Int,
    postponedCount: Int,
    servedCount: Int,
    onSelectFilter: (QueueFilterType) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color.White.copy(alpha = 0.80f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.95f)),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            FilterTabPill(
                label = "الكل",
                count = liveTotalCount,
                isSelected = selectedFilter == QueueFilterType.ALL,
                onClick = { onSelectFilter(QueueFilterType.ALL) },
                modifier = Modifier.weight(1f)
            )

            Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0xFFE2E8F0)))

            FilterTabPill(
                label = "في الانتظار",
                count = waitingCount,
                isSelected = selectedFilter == QueueFilterType.WAITING,
                onClick = { onSelectFilter(QueueFilterType.WAITING) },
                modifier = Modifier.weight(1.25f)
            )

            Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0xFFE2E8F0)))

            FilterTabPill(
                label = "المؤجلين",
                count = postponedCount,
                isSelected = selectedFilter == QueueFilterType.POSTPONED,
                onClick = { onSelectFilter(QueueFilterType.POSTPONED) },
                modifier = Modifier.weight(1.1f)
            )

            Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0xFFE2E8F0)))

            FilterTabPill(
                label = "تم استدعاء",
                count = servedCount,
                isSelected = selectedFilter == QueueFilterType.SERVED,
                onClick = { onSelectFilter(QueueFilterType.SERVED) },
                modifier = Modifier.weight(1.25f)
            )
        }
    }
}

@Composable
private fun FilterTabPill(
    label: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isSelected) {
                    Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
                } else {
                    Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                }
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "$label $count",
            fontSize = 11.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else Color(0xFF334155),
            textAlign = TextAlign.Center
        )
    }
}

/**
 * بطاقة المراجع الزجاجية المتناسقة والمطابقة للتصميم بدقة عالية:
 * - اليمين: مربع الرقم المتناسق بتدرج لوني وحدود بلورية ناعمة
 * - الوسط: "المراجع [الاسم] #[الرقم]" وتحتها الملاحظة
 * - اليسار: شارة الحالة المتناسقة (مع نقطة مضيئة)، زر التأجيل/الإرجاع، وأزرار الحذف والتذكرة
 */
@Composable
private fun PatientCardExactMatch(
    patient: Patient,
    isActive: Boolean,
    onCardClick: () -> Unit,
    onCalendarClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onPostponeClick: () -> Unit,
    onRestoreClick: () -> Unit
) {
    val isPostponed = patient.isPostponed
    val isCalled = patient.isCalled && !isPostponed

    val borderColor = if (isActive) Color(0xFF3B82F6) else Color.White.copy(alpha = 0.90f)
    val borderWidth = if (isActive) 1.5.dp else 1.dp

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() },
        shape = RoundedCornerShape(18.dp),
        color = if (isActive) Color.White.copy(alpha = 0.88f) else Color.White.copy(alpha = 0.80f),
        border = BorderStroke(borderWidth, borderColor),
        shadowElevation = if (isActive) 3.dp else 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // القسم الأيمن: مربع الرقم ومعلومات المراجع
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // مربع الرقم المتناسق مع تدرج لوني مميز
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .shadow(
                            elevation = if (isActive) 3.dp else 1.dp,
                            shape = RoundedCornerShape(14.dp),
                            spotColor = if (isActive) Color(0x332563EB) else Color(0x1A000000)
                        )
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            when {
                                isActive -> Brush.linearGradient(
                                    listOf(Color(0xFF2563EB), Color(0xFF1D4ED8))
                                )
                                isPostponed -> Brush.linearGradient(
                                    listOf(Color(0xFFFFFBEB), Color(0xFFFEF3C7))
                                )
                                isCalled -> Brush.linearGradient(
                                    listOf(Color(0xFFF8FAFC), Color(0xFFF1F5F9))
                                )
                                else -> Brush.linearGradient(
                                    listOf(Color(0xFFF1F5F9), Color(0xFFE2E8F0))
                                )
                            }
                        )
                        .border(
                            1.dp,
                            when {
                                isActive -> Color.White.copy(alpha = 0.6f)
                                isPostponed -> Color(0xFFFDE68A)
                                isCalled -> Color(0xFFE2E8F0)
                                else -> Color(0xFFCBD5E1)
                            },
                            RoundedCornerShape(14.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = patient.formattedNumber,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            isActive -> Color.White
                            isPostponed -> Color(0xFFB45309)
                            isCalled -> Color(0xFF64748B)
                            else -> Color(0xFF0F172A)
                        }
                    )
                }

                // اسم المراجع والملاحظة
                Column {
                    val titleText = if (patient.name.isNotBlank()) {
                        patient.name
                    } else {
                        "المراجع رقم ${patient.formattedNumber}"
                    }
                    Text(
                        text = titleText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (patient.note.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = patient.note,
                            fontSize = 12.sp,
                            color = Color(0xFF64748B),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // القسم الأيسر: الشارة وأزرار التأجيل/الإرجاع وأيقونات الإجراءات
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // زر التأجيل أو إعادة الإرجاع للانتظار
                if (isPostponed) {
                    Surface(
                        onClick = onRestoreClick,
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFEFF6FF).copy(alpha = 0.90f),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "إرجاع للانتظار",
                                tint = Color(0xFF2563EB),
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "إرجاع",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2563EB)
                            )
                        }
                    }
                } else if (!isCalled || isActive) {
                    Surface(
                        onClick = onPostponeClick,
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFFFBEB).copy(alpha = 0.90f),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FastForward,
                                contentDescription = "تأجيل المراجع",
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "تأجيل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD97706)
                            )
                        }
                    }
                }

                // شارة الحالة المتناسقة
                when {
                    isActive -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFDCFCE7).copy(alpha = 0.92f))
                                .border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF16A34A))
                                )
                                Text(
                                    text = "نشط الآن",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D)
                                )
                            }
                        }
                    }
                    isPostponed -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFEF3C7).copy(alpha = 0.85f))
                                .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "مؤجل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB45309)
                            )
                        }
                    }
                    isCalled -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF1F5F9).copy(alpha = 0.85f))
                                .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "تم الاستدعاء",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    else -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFEFF6FF).copy(alpha = 0.85f))
                                .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "في الانتظار",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1D4ED8)
                            )
                        }
                    }
                }

                // زر أيقونة الحذف بتصميم كبسولي أنيق
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A).copy(alpha = 0.04f))
                        .border(1.dp, Color(0xFF0F172A).copy(alpha = 0.06f), RoundedCornerShape(8.dp))
                        .clickable { onDeleteClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(16.dp)
                    )
                }

                // زر أيقونة التقويم / التذكرة بتصميم كبسولي أنيق
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0F172A).copy(alpha = 0.04f))
                        .border(1.dp, Color(0xFF0F172A).copy(alpha = 0.06f), RoundedCornerShape(8.dp))
                        .clickable { onCalendarClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "تذكرة",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * شريط الترقيم الزجاجي المماثل للصورة:
 * - اليمين: زر "السابق →"
 * - الوسط: "صفحة 1 من 5" وتحتها "(100 مراجع)"
 * - اليسار: زر "← التالي"
 */
@Composable
private fun PaginationBarExactMatch(
    currentPage: Int,
    totalPages: Int,
    totalCount: Int,
    onPrevClick: () -> Unit,
    onNextClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color.White.copy(alpha = 0.82f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.95f)),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // اليمين: زر السابق
            Surface(
                onClick = onPrevClick,
                enabled = currentPage > 1,
                shape = RoundedCornerShape(10.dp),
                color = if (currentPage > 1) Color.White.copy(alpha = 0.90f) else Color(0xFFF1F5F9).copy(alpha = 0.60f),
                border = BorderStroke(1.dp, if (currentPage > 1) Color(0xFFE2E8F0) else Color(0xFFE2E8F0).copy(alpha = 0.5f)),
                modifier = Modifier.height(34.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "السابق",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (currentPage > 1) Color(0xFF334155) else Color(0xFF94A3B8)
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "السابق",
                        tint = if (currentPage > 1) Color(0xFF334155) else Color(0xFF94A3B8),
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            // الوسط: صفحة X من Y
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "صفحة $currentPage من $totalPages",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = "($totalCount مراجع)",
                    fontSize = 10.5.sp,
                    color = Color(0xFF64748B)
                )
            }

            // اليسار: زر التالي
            Surface(
                onClick = onNextClick,
                enabled = currentPage < totalPages,
                shape = RoundedCornerShape(10.dp),
                color = if (currentPage < totalPages) Color(0xFF0F172A) else Color(0xFF94A3B8).copy(alpha = 0.60f),
                modifier = Modifier.height(34.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "التالي",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "التالي",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
