package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AppScreen

/**
 * شريط التنقل السفلي الاحترافي المطابق للصورة:
 * - اليمين: قائمة المراجعين (أيقونة القائمة + النص باللون الأخضر عند التفعيل)
 * - الوسط: زر الإضافة الدائري الأخضر (+)
 * - اليسار: الإعدادات (أيقونة الترس + النص)
 */
@Composable
fun ClinicBottomNavBar(
    activeScreen: AppScreen,
    onQueueClick: () -> Unit,
    onAddClick: (() -> Unit)? = null,
    onReportsClick: () -> Unit = {},
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeColor = Color(0xFF0F172A)
    val inactiveSlate = Color(0xFF64748B)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(elevation = 12.dp, shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp), spotColor = Color(0x1A000000)),
        color = Color.White.copy(alpha = 0.88f),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.95f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(66.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // التبويب الأيمن: قائمة المراجعين
            NavTabItem(
                label = "قائمة المراجعين",
                icon = Icons.AutoMirrored.Filled.List,
                isActive = activeScreen == AppScreen.QUEUE_LIST || activeScreen == AppScreen.HOME,
                activeColor = activeColor,
                inactiveColor = inactiveSlate,
                onClick = onQueueClick,
                modifier = Modifier.weight(1f)
            )

            // الزر الأوسط: زر الإضافة الدائري الزجاجي (+) المتناسق تماماً
            Box(
                modifier = Modifier
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .shadow(elevation = 6.dp, shape = CircleShape, spotColor = Color(0x330F172A))
                        .clip(CircleShape)
                        .background(Color(0xFF0F172A))
                        .border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                        .clickable { onAddClick?.invoke() }
                        .testTag("nav_add_patient_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "إضافة مراجع",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // التبويب الأيسر: الإعدادات
            NavTabItem(
                label = "الإعدادات",
                icon = Icons.Default.Settings,
                isActive = activeScreen == AppScreen.DEVICE_SETTINGS || activeScreen == AppScreen.CHOOSE_PRINTER,
                activeColor = activeColor,
                inactiveColor = inactiveSlate,
                onClick = onSettingsClick,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun NavTabItem(
    label: String,
    icon: ImageVector,
    isActive: Boolean,
    activeColor: Color,
    inactiveColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentColor = if (isActive) activeColor else inactiveColor

    Box(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = currentColor,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                color = currentColor
            )
        }
    }
}

