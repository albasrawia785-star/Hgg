package com.example.data.export

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Patient
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Enterprise Report Export Manager
 * Handles local generation, PDF creation, and formatted text export of daily patient lists
 * and comprehensive multi-date clinic logs.
 */
object ReportExportManager {

    private val isoDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val arabicFullDateFormat = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar"))
    private val arabicShortDateFormat = SimpleDateFormat("yyyy/MM/dd", Locale.US)
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale("ar"))
    private val timestampFileFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    enum class ExportScope {
        TODAY,
        SELECTED_DATE,
        ALL_ARCHIVE
    }

    enum class ExportFormat {
        PDF,
        TEXT
    }

    data class ExportResult(
        val file: File,
        val uri: Uri,
        val format: ExportFormat,
        val title: String,
        val patientCount: Int,
        val textContent: String? = null
    )

    /**
     * Generate a structured Text Report (.txt)
     */
    fun generateTextReport(
        context: Context,
        patients: List<Patient>,
        scope: ExportScope,
        selectedDateDisplay: String = "",
        clinicName: String = "عيادة الطبيب"
    ): ExportResult {
        val now = Date()
        val generationTimeStr = "${arabicFullDateFormat.format(now)} - ${timeFormat.format(now)}"
        val totalCount = patients.size
        val servedCount = patients.count { !it.isPostponed && it.isCalled }
        val waitingCount = patients.count { !it.isPostponed && !it.isCalled }
        val postponedCount = patients.count { it.isPostponed }
        val servedPercent = if (totalCount > 0) (servedCount.toFloat() / totalCount * 100).toInt() else 0

        val sb = StringBuilder()
        val isComprehensive = (scope == ExportScope.ALL_ARCHIVE)
        val reportTitle = when (scope) {
            ExportScope.TODAY -> "كشف المراجعين اليومي"
            ExportScope.SELECTED_DATE -> "تقرير كشف المراجعين ($selectedDateDisplay)"
            ExportScope.ALL_ARCHIVE -> "التقرير العام الشامل لكافة المراجعين والتواريخ"
        }

        // Header Decoration
        sb.appendLine("================================================================================")
        sb.appendLine("                             $clinicName")
        sb.appendLine("                     نظام إدارة وتنسيق طابور المرضى")
        sb.appendLine("================================================================================")
        sb.appendLine("نوع التقرير: $reportTitle")
        sb.appendLine("تاريخ ووقت الاستخراج: $generationTimeStr")
        if (scope == ExportScope.SELECTED_DATE && selectedDateDisplay.isNotBlank()) {
            sb.appendLine("التاريخ المحدد: $selectedDateDisplay")
        }
        sb.appendLine("--------------------------------------------------------------------------------")
        sb.appendLine("[ ملخص الإحصائيات العامة ]")
        sb.appendLine("   • إجمالي عدد المراجعين: $totalCount مراجع")
        sb.appendLine("   • الحالات المكتملة (تم الكشف): $servedCount ($servedPercent%)")
        sb.appendLine("   • الحالات قيد الانتظار: $waitingCount")
        sb.appendLine("   • الحالات المؤجلة: $postponedCount")
        sb.appendLine("================================================================================")
        sb.appendLine()

        if (patients.isEmpty()) {
            sb.appendLine("  [ لا توجد سجلات مراجعين مسجلة في هذا النطاق ]")
        } else if (!isComprehensive) {
            // Single day or single view table
            sb.appendLine(String.format(Locale.US, "%-6s | %-24s | %-12s | %-12s | %s", "الرقم", "اسم المراجع", "الوقت", "الحالة", "ملاحظات"))
            sb.appendLine("--------------------------------------------------------------------------------")
            patients.sortedBy { it.queueNumber }.forEach { p ->
                val statusStr = when {
                    p.isPostponed -> "مؤجل"
                    p.isCalled -> "مكتمل"
                    else -> "انتظار"
                }
                val nameStr = if (p.name.isNotBlank()) p.name.take(24) else "المراجع #${p.queueNumber}"
                val timeStr = timeFormat.format(Date(p.timestamp))
                val noteStr = if (p.note.isNotBlank()) p.note else "-"
                val queueNumStr = "#${p.queueNumber}"
                sb.appendLine(String.format(Locale.US, "%-6s | %-24s | %-12s | %-12s | %s", queueNumStr, nameStr, timeStr, statusStr, noteStr))
            }
        } else {
            // Comprehensive archive grouped by Date & Sessions
            val groupedByDate = patients.groupBy { isoDateFormat.format(Date(it.timestamp)) }
                .entries.sortedByDescending { it.key }

            sb.appendLine("[ تفاصيل السجلات موزعة زمنياً حسب التواريخ ]")
            sb.appendLine()

            groupedByDate.forEachIndexed { dateIndex, entry ->
                val dateKey = entry.key
                val datePatients = entry.value.sortedBy { it.queueNumber }
                val sampleTimestamp = datePatients.firstOrNull()?.timestamp ?: System.currentTimeMillis()
                val dateDisplay = arabicFullDateFormat.format(Date(sampleTimestamp))
                val dTotal = datePatients.size
                val dServed = datePatients.count { !it.isPostponed && it.isCalled }
                val dWaiting = datePatients.count { !it.isPostponed && !it.isCalled }
                val dPostponed = datePatients.count { it.isPostponed }

                sb.appendLine("--------------------------------------------------------------------------------")
                sb.appendLine("تاريخ: $dateDisplay ($dateKey)")
                sb.appendLine("   [ إجمالي اليوم: $dTotal | مكتمل: $dServed | انتظار: $dWaiting | مؤجل: $dPostponed ]")
                sb.appendLine("--------------------------------------------------------------------------------")
                sb.appendLine(String.format(Locale.US, "  %-6s | %-22s | %-10s | %-10s | %-14s | %s", "الرقم", "اسم المراجع", "الوقت", "الحالة", "الجلسة", "الملاحظات"))
                sb.appendLine("  " + "-".repeat(76))

                datePatients.forEach { p ->
                    val statusStr = when {
                        p.isPostponed -> "مؤجل"
                        p.isCalled -> "مكتمل"
                        else -> "انتظار"
                    }
                    val nameStr = if (p.name.isNotBlank()) p.name.take(22) else "المراجع #${p.queueNumber}"
                    val timeStr = timeFormat.format(Date(p.timestamp))
                    val sessionStr = if (p.sessionTitle.isNotBlank()) p.sessionTitle.take(14) else "جلسة عادية"
                    val noteStr = if (p.note.isNotBlank()) p.note else "-"
                    val queueNumStr = "#${p.queueNumber}"
                    sb.appendLine(String.format(Locale.US, "  %-6s | %-22s | %-10s | %-10s | %-14s | %s", queueNumStr, nameStr, timeStr, statusStr, sessionStr, noteStr))
                }
                sb.appendLine()
            }
        }

        sb.appendLine()
        sb.appendLine("================================================================================")
        sb.appendLine("نهاية التقرير - تم الاستخراج آلياً بواسطة تطبيق إدارة العيادة.")
        sb.appendLine("================================================================================")

        val reportContent = sb.toString()

        // Write to local cache file
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val prefix = if (isComprehensive) "تقرير_عام_شامل" else "كشف_مراجعين"
        val fileName = "${prefix}_${timestampFileFormat.format(now)}.txt"
        val file = File(reportsDir, fileName)
        file.writeText(reportContent, Charsets.UTF_8)

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        return ExportResult(
            file = file,
            uri = uri,
            format = ExportFormat.TEXT,
            title = reportTitle,
            patientCount = totalCount,
            textContent = reportContent
        )
    }

    /**
     * Generate an Enterprise Multi-Page PDF Report (.pdf)
     */
    fun generatePdfReport(
        context: Context,
        patients: List<Patient>,
        scope: ExportScope,
        selectedDateDisplay: String = "",
        clinicName: String = "عيادة الطبيب"
    ): ExportResult {
        val now = Date()
        val generationTimeStr = "${arabicFullDateFormat.format(now)} - ${timeFormat.format(now)}"
        val totalCount = patients.size
        val servedCount = patients.count { !it.isPostponed && it.isCalled }
        val waitingCount = patients.count { !it.isPostponed && !it.isCalled }
        val postponedCount = patients.count { it.isPostponed }
        val servedPercent = if (totalCount > 0) (servedCount.toFloat() / totalCount * 100).toInt() else 0

        val isComprehensive = (scope == ExportScope.ALL_ARCHIVE)
        val reportTitle = when (scope) {
            ExportScope.TODAY -> "كشف المراجعين اليومي"
            ExportScope.SELECTED_DATE -> "تقرير كشف المراجعين ($selectedDateDisplay)"
            ExportScope.ALL_ARCHIVE -> "التقرير العام الشامل لكافة المراجعين والتواريخ"
        }

        val pdfDocument = PdfDocument()
        val pageWidth = 595 // Standard A4 width (points)
        val pageHeight = 842 // Standard A4 height (points)
        val margin = 32f

        // Paints
        val primaryPaint = Paint().apply {
            color = Color.rgb(15, 23, 42) // NavyDark #0F172A
            isAntiAlias = true
        }

        val headerBgPaint = Paint().apply {
            color = Color.rgb(15, 23, 42) // Slate 900
            isAntiAlias = true
        }

        val tealPaint = Paint().apply {
            color = Color.rgb(13, 148, 136) // Teal #0D9488
            isAntiAlias = true
        }

        val bluePaint = Paint().apply {
            color = Color.rgb(37, 99, 235) // Blue #2563EB
            isAntiAlias = true
        }

        val amberPaint = Paint().apply {
            color = Color.rgb(217, 119, 6) // Amber #D97706
            isAntiAlias = true
        }

        val textPrimaryPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 10f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val textTitlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 15f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val textSubtitlePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            textSize = 9.5f
            isAntiAlias = true
        }

        val rowBgEvenPaint = Paint().apply {
            color = Color.rgb(248, 250, 252) // #F8FAFC
            isAntiAlias = true
        }

        val rowBgOddPaint = Paint().apply {
            color = Color.WHITE
            isAntiAlias = true
        }

        val tableHeaderPaint = Paint().apply {
            color = Color.rgb(241, 245, 249) // #F1F5F9
            isAntiAlias = true
        }

        val borderPaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val greenBadgePaint = Paint().apply {
            color = Color.rgb(204, 251, 241) // Teal 100
            isAntiAlias = true
        }

        val blueBadgePaint = Paint().apply {
            color = Color.rgb(239, 246, 255) // Blue 100
            isAntiAlias = true
        }

        val amberBadgePaint = Paint().apply {
            color = Color.rgb(254, 243, 199) // Amber 100
            isAntiAlias = true
        }

        // Table Columns layout (X coordinates for RTL table across 531 pt printable width)
        // Left margin: 32, Right margin: 595 - 32 = 563
        // Columns from Right to Left:
        // Col 1: الرقم (Queue #) -> width 45
        // Col 2: اسم المراجع (Name) -> width 140
        // Col 3: وقت التسجيل (Time) -> width 75
        // Col 4: حالة الكشف (Status) -> width 65
        // Col 5: الجلسة / التاريخ (Session/Date) -> width 95
        // Col 6: ملاحظات (Notes) -> width 111

        var currentPageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, currentPageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas: Canvas = page.canvas
        var y = margin

        fun drawHeaderAndStats() {
            // Top Header Card Banner
            val headerRect = RectF(margin, y, pageWidth - margin, y + 68f)
            canvas.drawRoundRect(headerRect, 10f, 10f, headerBgPaint)

            // Clinic Name & Title (RTL alignment)
            canvas.drawText(clinicName, pageWidth - margin - 18f - primaryPaint.measureText(clinicName), y + 26f, textTitlePaint)
            val subHeader = "$reportTitle • $generationTimeStr"
            canvas.drawText(subHeader, pageWidth - margin - 18f - primaryPaint.measureText(subHeader), y + 46f, textSubtitlePaint)

            y += 78f

            // 4 Mini Summary Stats Cards
            val cardWidth = (pageWidth - margin * 2 - 24f) / 4f
            val cardHeight = 36f

            // Stat 1: Total
            val stat1Rect = RectF(margin, y, margin + cardWidth, y + cardHeight)
            canvas.drawRoundRect(stat1Rect, 6f, 6f, tableHeaderPaint)
            canvas.drawRoundRect(stat1Rect, 6f, 6f, borderPaint)
            val s1Title = "الإجمالي: $totalCount مراجع"
            canvas.drawText(s1Title, stat1Rect.centerX() - textPrimaryPaint.measureText(s1Title) / 2f, y + 22f, Paint(textPrimaryPaint).apply { isFakeBoldText = true })

            // Stat 2: Served
            val stat2Rect = RectF(margin + cardWidth + 8f, y, margin + cardWidth * 2 + 8f, y + cardHeight)
            canvas.drawRoundRect(stat2Rect, 6f, 6f, greenBadgePaint)
            val s2Title = "مكتمل: $servedCount ($servedPercent%)"
            canvas.drawText(s2Title, stat2Rect.centerX() - tealPaint.measureText(s2Title) / 2f, y + 22f, Paint(tealPaint).apply { isFakeBoldText = true; textSize = 9.5f })

            // Stat 3: Waiting
            val stat3Rect = RectF(margin + (cardWidth + 8f) * 2, y, margin + cardWidth * 3 + 16f, y + cardHeight)
            canvas.drawRoundRect(stat3Rect, 6f, 6f, blueBadgePaint)
            val s3Title = "قيد الانتظار: $waitingCount"
            canvas.drawText(s3Title, stat3Rect.centerX() - bluePaint.measureText(s3Title) / 2f, y + 22f, Paint(bluePaint).apply { isFakeBoldText = true; textSize = 9.5f })

            // Stat 4: Postponed
            val stat4Rect = RectF(margin + (cardWidth + 8f) * 3, y, pageWidth - margin, y + cardHeight)
            canvas.drawRoundRect(stat4Rect, 6f, 6f, amberBadgePaint)
            val s4Title = "المؤجلون: $postponedCount"
            canvas.drawText(s4Title, stat4Rect.centerX() - amberPaint.measureText(s4Title) / 2f, y + 22f, Paint(amberPaint).apply { isFakeBoldText = true; textSize = 9.5f })

            y += 46f
        }

        fun drawTableHeader() {
            val thRect = RectF(margin, y, pageWidth - margin, y + 22f)
            canvas.drawRoundRect(thRect, 4f, 4f, tableHeaderPaint)
            canvas.drawRoundRect(thRect, 4f, 4f, borderPaint)

            val thPaint = Paint(textPrimaryPaint).apply {
                isFakeBoldText = true
                textSize = 9f
                color = Color.rgb(51, 65, 85)
            }

            // Headers from Right to Left
            canvas.drawText("الرقم", pageWidth - margin - 36f, y + 14.5f, thPaint)
            canvas.drawText("اسم المراجع", pageWidth - margin - 150f, y + 14.5f, thPaint)
            canvas.drawText("وقت التسجيل", pageWidth - margin - 240f, y + 14.5f, thPaint)
            canvas.drawText("الحالة", pageWidth - margin - 310f, y + 14.5f, thPaint)
            canvas.drawText(if (isComprehensive) "التاريخ / الجلسة" else "الجلسة", pageWidth - margin - 400f, y + 14.5f, thPaint)
            canvas.drawText("ملاحظات", margin + 12f, y + 14.5f, thPaint)

            y += 24f
        }

        fun drawFooter() {
            val footerText = "نظام العيادة الذكي • صفحة $currentPageNumber • استخرج بتاريخ: $generationTimeStr"
            val footerPaint = Paint().apply {
                color = Color.rgb(148, 163, 184)
                textSize = 8f
                isAntiAlias = true
            }
            canvas.drawLine(margin, pageHeight - 24f, pageWidth - margin, pageHeight - 24f, borderPaint)
            canvas.drawText(footerText, pageWidth / 2f - footerPaint.measureText(footerText) / 2f, pageHeight - 12f, footerPaint)
        }

        // Draw First Page Header
        drawHeaderAndStats()
        drawTableHeader()

        if (patients.isEmpty()) {
            val emptyMsg = "لا توجد سجلات مراجعين متاحة في هذا التقرير."
            canvas.drawText(emptyMsg, pageWidth / 2f - textPrimaryPaint.measureText(emptyMsg) / 2f, y + 40f, textPrimaryPaint)
        } else {
            val sortedPatients = if (isComprehensive) {
                patients.sortedWith(compareByDescending<Patient> { it.timestamp }.thenBy { it.queueNumber })
            } else {
                patients.sortedBy { it.queueNumber }
            }

            val rowHeight = 22f
            var currentDateHeaderKey = ""

            sortedPatients.forEachIndexed { index, p ->
                // If comprehensive and date changed, draw date section separator
                if (isComprehensive) {
                    val pDateKey = isoDateFormat.format(Date(p.timestamp))
                    if (pDateKey != currentDateHeaderKey) {
                        currentDateHeaderKey = pDateKey
                        // Check if we need a new page for date section
                        if (y + 35f > pageHeight - 35f) {
                            drawFooter()
                            pdfDocument.finishPage(page)
                            currentPageNumber++
                            pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, currentPageNumber).create()
                            page = pdfDocument.startPage(pageInfo)
                            canvas = page.canvas
                            y = margin
                            drawTableHeader()
                        }

                        val dateSecRect = RectF(margin, y, pageWidth - margin, y + 18f)
                        val dateSecPaint = Paint().apply {
                            color = Color.rgb(238, 242, 255) // Indigo 50
                            isAntiAlias = true
                        }
                        canvas.drawRoundRect(dateSecRect, 3f, 3f, dateSecPaint)
                        val dateSecText = "تاريخ: ${arabicFullDateFormat.format(Date(p.timestamp))} ($pDateKey)"
                        val dateSecTextPaint = Paint().apply {
                            color = Color.rgb(67, 56, 202) // Indigo 700
                            textSize = 9f
                            isFakeBoldText = true
                            isAntiAlias = true
                        }
                        canvas.drawText(dateSecText, pageWidth - margin - 12f - dateSecTextPaint.measureText(dateSecText), y + 12.5f, dateSecTextPaint)
                        y += 20f
                    }
                }

                // Check pagination
                if (y + rowHeight > pageHeight - 35f) {
                    drawFooter()
                    pdfDocument.finishPage(page)
                    currentPageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, currentPageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    y = margin
                    drawTableHeader()
                }

                // Draw Row Background
                val rowRect = RectF(margin, y, pageWidth - margin, y + rowHeight)
                canvas.drawRect(rowRect, if (index % 2 == 0) rowBgEvenPaint else rowBgOddPaint)
                canvas.drawLine(margin, y + rowHeight, pageWidth - margin, y + rowHeight, borderPaint)

                // 1. Queue Number
                val qNumText = "#${p.queueNumber}"
                val numPaint = Paint(textPrimaryPaint).apply { isFakeBoldText = true }
                canvas.drawText(qNumText, pageWidth - margin - 32f, y + 14.5f, numPaint)

                // 2. Name
                val nameText = if (p.name.isNotBlank()) p.name.take(22) else "المراجع #${p.queueNumber}"
                canvas.drawText(nameText, pageWidth - margin - 165f, y + 14.5f, textPrimaryPaint)

                // 3. Time
                val timeStr = timeFormat.format(Date(p.timestamp))
                canvas.drawText(timeStr, pageWidth - margin - 245f, y + 14.5f, textPrimaryPaint)

                // 4. Status Badge
                val (statusLabel, statusBadgePaint, statusTextPaint) = when {
                    p.isPostponed -> Triple("مؤجل", amberBadgePaint, Paint().apply { color = Color.rgb(180, 83, 9); textSize = 8.5f; isFakeBoldText = true; isAntiAlias = true })
                    p.isCalled -> Triple("مكتمل", greenBadgePaint, Paint().apply { color = Color.rgb(15, 118, 110); textSize = 8.5f; isFakeBoldText = true; isAntiAlias = true })
                    else -> Triple("انتظار", blueBadgePaint, Paint().apply { color = Color.rgb(29, 78, 216); textSize = 8.5f; isFakeBoldText = true; isAntiAlias = true })
                }
                val badgeRect = RectF(pageWidth - margin - 318f, y + 3f, pageWidth - margin - 275f, y + rowHeight - 3f)
                canvas.drawRoundRect(badgeRect, 4f, 4f, statusBadgePaint)
                canvas.drawText(statusLabel, badgeRect.centerX() - statusTextPaint.measureText(statusLabel) / 2f, y + 13.5f, statusTextPaint)

                // 5. Session / Date
                val sessText = if (isComprehensive) {
                    arabicShortDateFormat.format(Date(p.timestamp))
                } else {
                    if (p.sessionTitle.isNotBlank()) p.sessionTitle.take(12) else "جلسة عادية"
                }
                canvas.drawText(sessText, pageWidth - margin - 395f, y + 14.5f, textPrimaryPaint)

                // 6. Notes
                val notesText = if (p.note.isNotBlank()) p.note.take(18) else "-"
                canvas.drawText(notesText, margin + 12f, y + 14.5f, textPrimaryPaint)

                y += rowHeight
            }
        }

        drawFooter()
        pdfDocument.finishPage(page)

        // Save PDF to cache files
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val prefix = if (isComprehensive) "تقرير_عام_شامل" else "كشف_مراجعين"
        val fileName = "${prefix}_${timestampFileFormat.format(now)}.pdf"
        val file = File(reportsDir, fileName)

        val outputStream = FileOutputStream(file)
        pdfDocument.writeTo(outputStream)
        outputStream.flush()
        outputStream.close()
        pdfDocument.close()

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        return ExportResult(
            file = file,
            uri = uri,
            format = ExportFormat.PDF,
            title = reportTitle,
            patientCount = totalCount
        )
    }

    /**
     * Share exported file via system chooser (WhatsApp, Email, Drive, etc.)
     */
    fun shareExportedFile(context: Context, exportResult: ExportResult) {
        val mimeType = if (exportResult.format == ExportFormat.PDF) "application/pdf" else "text/plain"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, exportResult.uri)
            putExtra(Intent.EXTRA_SUBJECT, exportResult.title)
            putExtra(Intent.EXTRA_TEXT, "مرفق ${exportResult.title} الصادر من نظام إدارة العيادة.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "مشاركة التقرير عبر...")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    /**
     * Open exported file in default viewer (PDF Viewer, Text Editor)
     */
    fun openExportedFile(context: Context, exportResult: ExportResult) {
        try {
            val mimeType = if (exportResult.format == ExportFormat.PDF) "application/pdf" else "text/plain"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(exportResult.uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "لم يتم العثور على تطبيق لفتح الملف، يمكنك مشاركته بدلاً من ذلك", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Helper to export and directly share PDF
     */
    fun exportAndSharePdf(
        context: Context,
        patients: List<Patient>,
        scope: ExportScope,
        selectedDateDisplay: String = "",
        clinicName: String = "عيادة الطبيب"
    ) {
        val result = generatePdfReport(context, patients, scope, selectedDateDisplay, clinicName)
        shareExportedFile(context, result)
    }

    /**
     * Helper to export and directly share TXT
     */
    fun exportAndShareText(
        context: Context,
        patients: List<Patient>,
        scope: ExportScope,
        selectedDateDisplay: String = "",
        clinicName: String = "عيادة الطبيب"
    ) {
        val result = generateTextReport(context, patients, scope, selectedDateDisplay, clinicName)
        shareExportedFile(context, result)
    }

    /**
     * Copy formatted report text to clipboard
     */
    fun copyTextToClipboard(context: Context, text: String, label: String = "تقرير العيادة") {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "تم نسخ التقرير إلى الحافظة بنجاح", Toast.LENGTH_SHORT).show()
    }
}
