package com.example.audio

import android.content.Context
import com.example.bluetooth.AudioRouteManager
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.Locale

enum class CallingState {
    IDLE,
    CHIME_PLAYING,
    TTS_SPEAKING,
    COMPLETED,
    ERROR
}

class AnnouncementManager(
    private val context: Context,
    private val audioRouteManager: AudioRouteManager
) {
    private val chimePlayer = ChimePlayer(context)
    private val ttsManager = TtsManager(context)

    private val _callingState = MutableStateFlow(CallingState.IDLE)
    val callingState: StateFlow<CallingState> = _callingState.asStateFlow()

    private val _activeCallingPatient = MutableStateFlow<Patient?>(null)
    val activeCallingPatient: StateFlow<Patient?> = _activeCallingPatient.asStateFlow()

    fun applyVolume(volume: Float) {
        ttsManager.applyStreamVolume(volume)
    }

    /**
     * Announces a patient number cleanly using:
     * 1. Crisp hospital acoustic alert chime (if enabled)
     * 2. Clear native Arabic TextToSpeech utterance with user-configured rate, pitch, volume, and phrase
     * @param mutePhone if true, skips local phone audio (used when audio plays exclusively from TV)
     */
    suspend fun announcePatient(
        patient: Patient,
        settings: SystemSettings = SystemSettings(),
        mutePhone: Boolean = false
    ): Boolean = withContext(Dispatchers.Main) {
        try {
            _activeCallingPatient.value = patient
            _callingState.value = CallingState.CHIME_PLAYING

            // 2. Format phrase cleanly using custom template and natural Arabic number words
            val numInt = patient.queueNumber
            val arabicNumberWord = numberToArabicWords(numInt)
            val template = if (settings.callPhrase.isNotBlank()) {
                settings.callPhrase
            } else {
                "المراجع رقم {number} ، يرجى التوجه إلى غرفة العيادة"
            }
            val textToSpeak = formatCallPhrase(template, arabicNumberWord)

            // Synthesize audio to file asynchronously for TV web display stream
            try {
                val tvAudioFile = java.io.File(context.cacheDir, "call_latest.wav")
                ttsManager.synthesizeToFile(textToSpeak, tvAudioFile)
            } catch (_: Exception) {}

            if (mutePhone) {
                // TV is handling the audio broadcast; keep phone silent
                _callingState.value = CallingState.TTS_SPEAKING
                kotlinx.coroutines.delay(1200L)
                _callingState.value = CallingState.COMPLETED
                kotlinx.coroutines.delay(200L)
                return@withContext true
            }

            // 1. Play crisp hospital acoustic alert chime (400ms) if enabled
            if (settings.enableChime) {
                chimePlayer.playChime()
            }

            _callingState.value = CallingState.TTS_SPEAKING
            ttsManager.setSpeechRate(settings.speechRate)

            // Direct instant playback on device speaker / bluetooth A2DP
            val ttsSuccess = ttsManager.speak(textToSpeak, volume = 1.0f)

            // 3. Mark completed briefly then return to IDLE
            _callingState.value = CallingState.COMPLETED
            kotlinx.coroutines.delay(250L)
            ttsSuccess
        } catch (_: Exception) {
            false
        } finally {
            _callingState.value = CallingState.IDLE
            _activeCallingPatient.value = null
        }
    }

    /**
     * Plays a test announcement using current audio settings
     */
    suspend fun testAnnouncement(settings: SystemSettings): Boolean = withContext(Dispatchers.Main) {
        try {
            _callingState.value = CallingState.CHIME_PLAYING

            if (settings.enableChime) {
                chimePlayer.playChime()
            }

            _callingState.value = CallingState.TTS_SPEAKING
            ttsManager.setSpeechRate(settings.speechRate)

            val template = if (settings.callPhrase.isNotBlank()) {
                settings.callPhrase
            } else {
                "المراجع رقم {number} ، يرجى التوجه إلى غرفة العيادة"
            }
            val textToSpeak = formatCallPhrase(template, "25")

            val ttsSuccess = ttsManager.speak(textToSpeak, volume = 1.0f)
            _callingState.value = CallingState.COMPLETED
            kotlinx.coroutines.delay(250L)
            ttsSuccess
        } catch (_: Exception) {
            false
        } finally {
            _callingState.value = CallingState.IDLE
            _activeCallingPatient.value = null
        }
    }

    private fun formatCallPhrase(template: String, numberStr: String): String {
        val cleanNumberStr = numberStr.trim()
        return when {
            template.contains("%s") -> {
                try {
                    template.format(cleanNumberStr)
                } catch (_: Exception) {
                    "المراجع رقم $cleanNumberStr ، يرجى التوجه إلى غرفة العيادة"
                }
            }
            template.contains("%d") -> {
                val numInt = cleanNumberStr.toIntOrNull() ?: 1
                try {
                    String.format(Locale.US, template, numInt)
                } catch (_: Exception) {
                    "المراجع رقم $cleanNumberStr ، يرجى التوجه إلى غرفة العيادة"
                }
            }
            template.contains("{number}") -> {
                template.replace("{number}", cleanNumberStr)
            }
            else -> {
                "$template $cleanNumberStr"
            }
        }
    }

    fun numberToArabicWords(num: Int): String {
        // Passing the digit directly after "رقم" causes Google TTS to pronounce the exact natural Arabic ordinal/cardinal form smoothly without tanween
        return num.toString()
    }

    fun stop() {
        ttsManager.stop()
        resetState()
    }

    fun resetState() {
        _callingState.value = CallingState.IDLE
        _activeCallingPatient.value = null
    }

    fun shutdown() {
        ttsManager.shutdown()
    }
}
