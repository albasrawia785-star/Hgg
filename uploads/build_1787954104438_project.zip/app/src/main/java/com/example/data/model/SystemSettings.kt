package com.example.data.model

import com.example.ClinicInfo

data class SystemSettings(
    val clinicName: String = ClinicInfo.clinicName,
    val clinicSubtitle: String = ClinicInfo.clinicSubtitle,
    val doctorName: String = ClinicInfo.doctorName,
    val doctorSpecialty: String = ClinicInfo.doctorSpecialty,
    val clinicPhone: String = ClinicInfo.clinicPhone,
    val clinicAddress: String = ClinicInfo.clinicAddress,
    val footerMessage: String = ClinicInfo.footerMessage,
    val ticketGreeting: String = ClinicInfo.ticketGreeting,
    val tvFooterSlogan: String = ClinicInfo.tvFooterSlogan,
    val paperSize: PaperSize = PaperSize.WIDTH_80MM,
    val autoPrintOnAdd: Boolean = true,
    val callPhrase: String = ClinicInfo.callPhrase,
    val speechRate: Float = 0.85f,
    val pitch: Float = 1.0f,
    val volume: Float = 1.0f,
    val enableChime: Boolean = true,
    val selectedPrinterName: String = "",
    val selectedPrinterAddress: String = "",
    val selectedSpeakerName: String = "",
    val selectedSpeakerAddress: String = "",
    val isRtlLayout: Boolean = false
)
