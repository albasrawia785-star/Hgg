package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.ClinicInfo
import com.example.data.local.AppDatabase
import com.example.data.local.QueueDao
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class QueueRepository(
    private val context: Context,
    private val database: AppDatabase = AppDatabase.getInstance(context)
) {

    private val queueDao: QueueDao = database.queueDao()
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val prefs: SharedPreferences =
        context.getSharedPreferences("clinic_queue_prefs", Context.MODE_PRIVATE)

    private val _patients = MutableStateFlow<List<Patient>>(emptyList())
    val patients: StateFlow<List<Patient>> = _patients.asStateFlow()

    private val _archivedPatients = MutableStateFlow<List<Patient>>(emptyList())
    val archivedPatients: StateFlow<List<Patient>> = _archivedPatients.asStateFlow()

    private val _currentPatient = MutableStateFlow<Patient?>(null)
    val currentPatient: StateFlow<Patient?> = _currentPatient.asStateFlow()

    private val _settings = MutableStateFlow(SystemSettings())
    val settings: StateFlow<SystemSettings> = _settings.asStateFlow()

    // High-performance reactive stream of all patients directly from SQLite
    val allPatients: Flow<List<Patient>> = queueDao.getAllPatients()

    val liveQueueCountFlow: Flow<Int> = queueDao.getLiveQueueCountFlow()
    val waitingCountFlow: Flow<Int> = queueDao.getWaitingCountFlow()
    val postponedCountFlow: Flow<Int> = queueDao.getPostponedCountFlow()
    val servedCountFlow: Flow<Int> = queueDao.getServedCountFlow()
    val topWaitingPatients: Flow<List<Patient>> = queueDao.getTopWaitingPatientsFlow(8)
    val topPostponedPatients: Flow<List<Patient>> = queueDao.getTopPostponedPatientsFlow(6)

    val queueDaoInstance: QueueDao get() = queueDao
    val nextQueueNumberFlow: Flow<Int> = queueDao.getNextQueueNumberFlow()

    fun getPagedLiveQueue(filter: String, limit: Int, offset: Int): Flow<List<Patient>> {
        return queueDao.getPagedLiveQueue(filter, limit, offset)
    }

    fun getFilterCountFlow(filter: String): Flow<Int> {
        return queueDao.getFilterCountFlow(filter)
    }

    fun getPagedReportPatients(sessionId: String?, searchQuery: String, filter: String, limit: Int, offset: Int): Flow<List<Patient>> {
        return queueDao.getPagedReportPatients(sessionId, searchQuery, filter, limit, offset)
    }

    fun getReportCountFlow(sessionId: String?, searchQuery: String, filter: String): Flow<Int> {
        return queueDao.getReportCountFlow(sessionId, searchQuery, filter)
    }

    init {
        loadSettings()
        repositoryScope.launch {
            migrateFromPreferencesIfNeeded()

            // Observe live queue reactively (limited to avoid UI freeze on large sets)
            launch {
                queueDao.getLiveQueue().collect { list ->
                    _patients.value = list
                    val current = list.firstOrNull { it.isCurrent && !it.isPostponed }
                        ?: list.firstOrNull { !it.isCalled && !it.isPostponed }
                        ?: list.firstOrNull { !it.isPostponed }
                    _currentPatient.value = current
                }
            }

            // Observe archive reactively
            launch {
                queueDao.getArchivedPatients().collect { list ->
                    _archivedPatients.value = list
                }
            }
        }
    }

    private fun loadSettings() {
        val paperSizeName = prefs.getString("paper_size", PaperSize.WIDTH_80MM.name) ?: PaperSize.WIDTH_80MM.name
        val paperSize = try {
            PaperSize.valueOf(paperSizeName)
        } catch (_: Exception) {
            PaperSize.WIDTH_80MM
        }
        val autoPrint = prefs.getBoolean("auto_print", true)
        val callPhrase = prefs.getString("call_phrase", "المُراجِع رَقْم %s") ?: "المُراجِع رَقْم %s"
        val speechRate = prefs.getFloat("speech_rate", 0.85f)
        val pitch = prefs.getFloat("pitch", 1.0f)
        val volume = prefs.getFloat("volume", 1.0f)
        val enableChime = prefs.getBoolean("enable_chime", true)

        val selectedPrinter = prefs.getString("printer_name", "") ?: ""
        val selectedPrinterAddr = prefs.getString("printer_addr", "") ?: ""
        val selectedSpeaker = prefs.getString("speaker_name", "") ?: ""
        val selectedSpeakerAddr = prefs.getString("speaker_addr", "") ?: ""
        val isRtlLayout = prefs.getBoolean("is_rtl_layout", false)

        _settings.value = SystemSettings(
            clinicName = ClinicInfo.clinicName,
            doctorName = ClinicInfo.doctorName,
            clinicPhone = ClinicInfo.clinicPhone,
            footerMessage = ClinicInfo.footerMessage,
            paperSize = paperSize,
            autoPrintOnAdd = autoPrint,
            callPhrase = callPhrase,
            speechRate = speechRate,
            pitch = pitch,
            volume = volume,
            enableChime = enableChime,
            selectedPrinterName = selectedPrinter,
            selectedPrinterAddress = selectedPrinterAddr,
            selectedSpeakerName = selectedSpeaker,
            selectedSpeakerAddress = selectedSpeakerAddr,
            isRtlLayout = isRtlLayout
        )
    }

    fun updateSettings(newSettings: SystemSettings) {
        _settings.value = newSettings.copy(
            clinicName = ClinicInfo.clinicName,
            doctorName = ClinicInfo.doctorName,
            clinicPhone = ClinicInfo.clinicPhone,
            footerMessage = ClinicInfo.footerMessage
        )
        prefs.edit()
            .putString("paper_size", newSettings.paperSize.name)
            .putBoolean("auto_print", newSettings.autoPrintOnAdd)
            .putString("call_phrase", newSettings.callPhrase)
            .putFloat("speech_rate", newSettings.speechRate)
            .putFloat("pitch", newSettings.pitch)
            .putFloat("volume", newSettings.volume)
            .putBoolean("enable_chime", newSettings.enableChime)
            .putString("printer_name", newSettings.selectedPrinterName)
            .putString("printer_addr", newSettings.selectedPrinterAddress)
            .putString("speaker_name", newSettings.selectedSpeakerName)
            .putString("speaker_addr", newSettings.selectedSpeakerAddress)
            .putBoolean("is_rtl_layout", newSettings.isRtlLayout)
            .apply()
    }

    private suspend fun migrateFromPreferencesIfNeeded() = withContext(Dispatchers.IO) {
        val alreadyMigrated = prefs.getBoolean("room_migrated_v1", false)
        if (alreadyMigrated) return@withContext

        val listToInsert = mutableListOf<Patient>()
        val queueJson = prefs.getString("queue_data", null)
        if (!queueJson.isNullOrBlank() && queueJson != "[]") {
            try {
                val array = JSONArray(queueJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    listToInsert.add(
                        Patient(
                            id = 0,
                            queueNumber = obj.getInt("queueNumber"),
                            name = obj.optString("name", ""),
                            note = obj.optString("note", ""),
                            timestamp = obj.getLong("timestamp"),
                            isCalled = obj.optBoolean("isCalled", false),
                            isCurrent = obj.optBoolean("isCurrent", false),
                            isPostponed = obj.optBoolean("isPostponed", false),
                            sessionId = obj.optString("sessionId", "live_session"),
                            sessionTitle = obj.optString("sessionTitle", "الجلسة الحالية النشطة")
                        )
                    )
                }
            } catch (_: Exception) {}
        }

        val archiveJson = prefs.getString("reports_archive_data", null)
        if (!archiveJson.isNullOrBlank() && archiveJson != "[]") {
            try {
                val array = JSONArray(archiveJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    listToInsert.add(
                        Patient(
                            id = 0,
                            queueNumber = obj.getInt("queueNumber"),
                            name = obj.optString("name", ""),
                            note = obj.optString("note", ""),
                            timestamp = obj.getLong("timestamp"),
                            isCalled = obj.optBoolean("isCalled", false),
                            isCurrent = obj.optBoolean("isCurrent", false),
                            isPostponed = obj.optBoolean("isPostponed", false),
                            sessionId = obj.optString("sessionId", "session_${obj.optLong("timestamp", 0)}"),
                            sessionTitle = obj.optString("sessionTitle", "جلسة سابقة")
                        )
                    )
                }
            } catch (_: Exception) {}
        }

        if (listToInsert.isNotEmpty()) {
            queueDao.insertPatients(listToInsert)
        }

        prefs.edit()
            .putBoolean("room_migrated_v1", true)
            .remove("queue_data")
            .remove("reports_archive_data")
            .apply()
    }

    suspend fun addPatient(name: String = "", note: String = ""): Patient = withContext(Dispatchers.IO) {
        val maxQueueNum = queueDao.getMaxLiveQueueNumber() ?: 0
        val nextNumber = maxQueueNum + 1
        val waitingCount = queueDao.getLiveQueueCount()
        val isFirstActive = (waitingCount == 0)
        val newPatient = Patient(
            id = 0,
            queueNumber = nextNumber,
            name = name.trim(),
            note = note.trim(),
            timestamp = System.currentTimeMillis(),
            isCalled = false,
            isCurrent = isFirstActive,
            isPostponed = false,
            sessionId = "live_session",
            sessionTitle = "الجلسة الحالية النشطة"
        )
        val insertedId = queueDao.insertPatient(newPatient)
        newPatient.copy(id = insertedId.toInt())
    }

    suspend fun insertBatchPatients(patients: List<Patient>): List<Long> = withContext(Dispatchers.IO) {
        queueDao.insertPatients(patients)
    }

    suspend fun callCurrentPatient(): Patient? = withContext(Dispatchers.IO) {
        val current = queueDao.getCurrentPatientDirect()
            ?: queueDao.getNextWaitingPatient()
            ?: return@withContext null

        queueDao.clearCurrentFlags()
        queueDao.markAsCalled(current.id)
        current.copy(isCalled = true, isCurrent = true, isPostponed = false)
    }

    suspend fun callNextPatient(): Patient? = withContext(Dispatchers.IO) {
        val current = queueDao.getCurrentPatientDirect()
        val target = if (current != null) {
            queueDao.getNextWaitingPatientAfter(current.queueNumber) ?: queueDao.getNextWaitingPatient()
        } else {
            queueDao.getNextWaitingPatient()
        } ?: return@withContext null

        queueDao.clearCurrentFlags()
        queueDao.markAsCalled(target.id)
        target.copy(isCalled = true, isCurrent = true, isPostponed = false)
    }

    suspend fun postponePatient(patient: Patient): Patient = withContext(Dispatchers.IO) {
        val isTargetCurrent = queueDao.getCurrentPatientDirect()?.id == patient.id
        queueDao.markAsPostponed(patient.id)

        if (isTargetCurrent) {
            val nextCurrent = queueDao.getNextWaitingPatientAfter(patient.queueNumber)
                ?: queueDao.getNextWaitingPatient()
            if (nextCurrent != null) {
                queueDao.markAsCurrent(nextCurrent.id)
            }
        }
        patient.copy(isPostponed = true, isCurrent = false)
    }

    suspend fun postponeCurrentPatient(): Pair<Patient?, Patient?> = withContext(Dispatchers.IO) {
        val current = queueDao.getCurrentPatientDirect() ?: return@withContext Pair(null, null)
        queueDao.markAsPostponed(current.id)

        val nextCurrent = queueDao.getNextWaitingPatientAfter(current.queueNumber)
            ?: queueDao.getNextWaitingPatient()

        if (nextCurrent != null) {
            queueDao.markAsCurrent(nextCurrent.id)
        }

        Pair(
            current.copy(isPostponed = true, isCurrent = false),
            nextCurrent?.copy(isCurrent = true)
        )
    }

    suspend fun recallPostponedPatient(patient: Patient): Patient = withContext(Dispatchers.IO) {
        queueDao.clearCurrentFlags()
        queueDao.markAsReactivated(patient.id)
        patient.copy(isPostponed = false, isCalled = true, isCurrent = true)
    }

    suspend fun restorePostponedToQueue(patient: Patient) = withContext(Dispatchers.IO) {
        queueDao.restorePostponed(patient.id)
    }

    suspend fun archiveAndResetQueue(): Int = withContext(Dispatchers.IO) {
        val currentList = _patients.value
        val count = currentList.size
        if (count > 0) {
            val sessionCounter = prefs.getInt("session_counter", 1)
            val timeFormat = SimpleDateFormat("hh:mm:ss a", Locale("ar"))
            val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale("ar"))
            val now = System.currentTimeMillis()
            val formattedTime = timeFormat.format(Date(now))
            val formattedDate = dateFormat.format(Date(now))
            val sessionTitle = "جلسة #$sessionCounter ($formattedDate • $formattedTime)"
            val sessionId = "session_${now}_$sessionCounter"

            queueDao.archiveLiveQueue(sessionId, sessionTitle)
            prefs.edit().putInt("session_counter", sessionCounter + 1).apply()
        }
        count
    }

    suspend fun deletePatient(patient: Patient) = withContext(Dispatchers.IO) {
        queueDao.deletePatientById(patient.id)
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        if (sessionId == "live_session") {
            queueDao.clearLiveQueue()
        } else {
            queueDao.deleteSession(sessionId)
        }
    }

    suspend fun deleteByDate(dateKey: String) = withContext(Dispatchers.IO) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayKey = dateFormat.format(Date())
        if (dateKey == todayKey) {
            queueDao.clearLiveQueue()
        }
        val (startTime, endTime) = getDayStartAndEnd(dateKey)
        if (startTime != null && endTime != null) {
            queueDao.deleteByDateRange(startTime, endTime)
        }
    }

    suspend fun deleteServedPatients(targetDateKey: String? = null, targetSessionId: String? = null) = withContext(Dispatchers.IO) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayKey = dateFormat.format(Date())

        val shouldFilterLive = (targetDateKey == null || targetDateKey == "ALL" || targetDateKey == todayKey) &&
                (targetSessionId == null || targetSessionId == "ALL" || targetSessionId == "live_session")

        if (shouldFilterLive) {
            queueDao.deleteServedBySession("live_session")
        }

        if (!targetSessionId.isNullOrBlank() && targetSessionId != "ALL" && targetSessionId != "live_session") {
            queueDao.deleteServedBySession(targetSessionId)
        } else if (!targetDateKey.isNullOrBlank() && targetDateKey != "ALL") {
            val (startTime, endTime) = getDayStartAndEnd(targetDateKey)
            if (startTime != null && endTime != null) {
                queueDao.deleteServedByDateRange(startTime, endTime)
            }
        } else if (targetSessionId == null || targetSessionId == "ALL") {
            queueDao.deleteServedBySession(null)
        }
    }

    suspend fun deletePostponedPatients(targetDateKey: String? = null, targetSessionId: String? = null) = withContext(Dispatchers.IO) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val todayKey = dateFormat.format(Date())

        val shouldFilterLive = (targetDateKey == null || targetDateKey == "ALL" || targetDateKey == todayKey) &&
                (targetSessionId == null || targetSessionId == "ALL" || targetSessionId == "live_session")

        if (shouldFilterLive) {
            queueDao.deletePostponedBySession("live_session")
        }

        if (!targetSessionId.isNullOrBlank() && targetSessionId != "ALL" && targetSessionId != "live_session") {
            queueDao.deletePostponedBySession(targetSessionId)
        } else if (!targetDateKey.isNullOrBlank() && targetDateKey != "ALL") {
            val (startTime, endTime) = getDayStartAndEnd(targetDateKey)
            if (startTime != null && endTime != null) {
                queueDao.deletePostponedByDateRange(startTime, endTime)
            }
        } else if (targetSessionId == null || targetSessionId == "ALL") {
            queueDao.deletePostponedBySession(null)
        }
    }

    suspend fun clearAllReportsAndQueue() = withContext(Dispatchers.IO) {
        queueDao.clearAll()
    }

    suspend fun selectPatient(patient: Patient) = withContext(Dispatchers.IO) {
        queueDao.clearCurrentFlags()
        queueDao.markAsCurrent(patient.id)
    }

    suspend fun callSpecificPatient(patientId: Int): Patient? = withContext(Dispatchers.IO) {
        val patient = queueDao.getPatientById(patientId)
            ?: _patients.value.firstOrNull { it.id == patientId }
            ?: return@withContext null
        queueDao.clearCurrentFlags()
        queueDao.markAsCalled(patient.id)
        patient.copy(isCalled = true, isCurrent = true, isPostponed = false)
    }

    suspend fun resetQueue() = archiveAndResetQueue()

    private fun getDayStartAndEnd(dateKey: String): Pair<Long?, Long?> {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(dateKey) ?: return Pair(null, null)
            val cal = Calendar.getInstance().apply {
                time = date
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val start = cal.timeInMillis
            cal.set(Calendar.HOUR_OF_DAY, 23)
            cal.set(Calendar.MINUTE, 59)
            cal.set(Calendar.SECOND, 59)
            cal.set(Calendar.MILLISECOND, 999)
            val end = cal.timeInMillis
            Pair(start, end)
        } catch (_: Exception) {
            Pair(null, null)
        }
    }
}
