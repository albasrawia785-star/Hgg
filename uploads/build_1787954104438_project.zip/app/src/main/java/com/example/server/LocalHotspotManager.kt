package com.example.server

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LocalHotspotManager(private val context: Context) {
    private val TAG = "LocalHotspotManager"
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private var hotspotReservation: WifiManager.LocalOnlyHotspotReservation? = null

    private val _isHotspotActive = MutableStateFlow(false)
    val isHotspotActive: StateFlow<Boolean> = _isHotspotActive.asStateFlow()

    private val _ssid = MutableStateFlow("")
    val ssid: StateFlow<String> = _ssid.asStateFlow()

    private val _password = MutableStateFlow("")
    val password: StateFlow<String> = _password.asStateFlow()

    private val _statusMessage = MutableStateFlow("شبكة الواي فاي متوقفة")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    @SuppressLint("MissingPermission")
    fun startLocalHotspot(onSuccess: (() -> Unit)? = null, onFailure: ((String) -> Unit)? = null) {
        if (_isHotspotActive.value) {
            onSuccess?.invoke()
            return
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            _statusMessage.value = "إنشاء شبكة الواي فاي التلقائية يتطلب أندرويد 8 أو أحدث"
            onFailure?.invoke(_statusMessage.value)
            return
        }

        _isLoading.value = true
        _statusMessage.value = "جاري إنشاء شبكة الواي فاي للعيادة..."

        try {
            wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                    super.onStarted(reservation)
                    hotspotReservation = reservation
                    _isHotspotActive.value = true
                    _isLoading.value = false

                    var foundSsid = ""
                    var foundPassword = ""

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        try {
                            reservation?.softApConfiguration?.let { config ->
                                foundSsid = config.ssid ?: ""
                                foundPassword = config.passphrase ?: ""
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error reading softApConfiguration: ${e.message}")
                        }
                    }

                    if (foundSsid.isBlank()) {
                        try {
                            @Suppress("DEPRECATION")
                            reservation?.wifiConfiguration?.let { config ->
                                foundSsid = config.SSID ?: ""
                                foundPassword = config.preSharedKey ?: ""
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error reading wifiConfiguration: ${e.message}")
                        }
                    }

                    if (foundSsid.isBlank()) {
                        foundSsid = "عيادة_الطبيب_TV"
                    }

                    // Remove quotes if present
                    _ssid.value = foundSsid.removeSurrounding("\"")
                    _password.value = foundPassword.removeSurrounding("\"")
                    _statusMessage.value = "تم إنشاء شبكة الواي فاي بنجاح"

                    Log.d(TAG, "Hotspot started successfully! SSID: ${_ssid.value}, Pass: ${_password.value}")
                    onSuccess?.invoke()
                }

                override fun onStopped() {
                    super.onStopped()
                    hotspotReservation = null
                    _isHotspotActive.value = false
                    _isLoading.value = false
                    _ssid.value = ""
                    _password.value = ""
                    _statusMessage.value = "تم إيقاف شبكة الواي فاي"
                }

                override fun onFailed(reason: Int) {
                    super.onFailed(reason)
                    hotspotReservation = null
                    _isHotspotActive.value = false
                    _isLoading.value = false
                    val errorDesc = when (reason) {
                        ERROR_NO_CHANNEL -> "لا توجد قنوات لاسلكية متاحة حالياً"
                        ERROR_GENERIC -> "يرجى التأكد من تشغيل الواي فاي ومنح إذن الموقع"
                        ERROR_INCOMPATIBLE_MODE -> "الوضع غير متوافق"
                        ERROR_TETHERING_DISALLOWED -> "المشاركة غير مسموحة من النظام"
                        else -> "فشل التشغيل (رمز $reason)"
                    }
                    _statusMessage.value = errorDesc
                    Log.e(TAG, "Hotspot failed: $errorDesc ($reason)")
                    onFailure?.invoke(errorDesc)
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            _isLoading.value = false
            _isHotspotActive.value = false
            val msg = "يرجى منح إذن الموقع أو إذن الأجهزة المجاورة لتشغيل الواي فاي"
            _statusMessage.value = msg
            Log.e(TAG, "SecurityException: ${e.message}", e)
            onFailure?.invoke(msg)
        } catch (e: Exception) {
            _isLoading.value = false
            _isHotspotActive.value = false
            val msg = "حدث خطأ أثناء إنشاء الشبكة: ${e.message}"
            _statusMessage.value = msg
            Log.e(TAG, "Exception: ${e.message}", e)
            onFailure?.invoke(msg)
        }
    }

    fun stopLocalHotspot() {
        try {
            hotspotReservation?.close()
            hotspotReservation = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing hotspot: ${e.message}", e)
        }
        _isHotspotActive.value = false
        _isLoading.value = false
        _ssid.value = ""
        _password.value = ""
        _statusMessage.value = "تم إيقاف شبكة الواي فاي"
    }
}
