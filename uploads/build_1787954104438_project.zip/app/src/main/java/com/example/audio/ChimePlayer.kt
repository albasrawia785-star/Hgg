package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.ToneGenerator
import android.media.AudioManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.exp
import kotlin.math.sin

/**
 * Pure AudioTrack Hospital Chime Synthesizer.
 * Generates an authentic two-tone clinic chime (G5 784Hz -> D5 587Hz with harmonic overtones and smooth decay).
 * Eliminates all MediaPlayer codec errors and native dependencies.
 */
class ChimePlayer(private val context: Context) {

    suspend fun playChime(): Boolean = withContext(Dispatchers.IO) {
        try {
            playSynthesizedChime()
        } catch (_: Exception) {
            playToneFallback()
        }
    }

    /**
     * Dual-tone hospital alert chime with natural acoustic resonance
     */
    private suspend fun playSynthesizedChime(): Boolean = withContext(Dispatchers.IO) {
        var audioTrack: AudioTrack? = null
        try {
            val sampleRate = 44100
            val durationSec = 0.40
            val numSamples = (sampleRate * durationSec).toInt()
            val buffer = ShortArray(numSamples)

            val freq1 = 880.0 // A5
            val freq2 = 659.25 // E5
            val transitionSample = (sampleRate * 0.18).toInt()

            for (i in 0 until numSamples) {
                val time = i.toDouble() / sampleRate
                val isTone1 = i < transitionSample
                val baseFreq = if (isTone1) freq1 else freq2
                val toneTime = if (isTone1) time else (time - 0.18)

                // Exponential decay envelope
                val decay = exp(-7.5 * toneTime)

                // Fundamental frequency + soft second harmonic for natural chime resonance
                val fundamental = sin(2.0 * Math.PI * baseFreq * time)
                val overtone = 0.25 * sin(2.0 * Math.PI * (baseFreq * 2.0) * time)
                val sample = (fundamental + overtone) * decay * 0.85

                buffer[i] = (sample * Short.MAX_VALUE)
                    .toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                    .toShort()
            }

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()

            delay((durationSec * 1000).toLong())
            true
        } catch (e: Exception) {
            playToneFallback()
        } finally {
            try {
                audioTrack?.stop()
                audioTrack?.release()
            } catch (_: Exception) {}
        }
    }

    private fun playToneFallback(): Boolean {
        return try {
            val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
            toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400)
            true
        } catch (_: Exception) {
            false
        }
    }
}



