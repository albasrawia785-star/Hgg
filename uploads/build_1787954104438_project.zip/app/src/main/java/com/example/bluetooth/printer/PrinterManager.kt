package com.example.bluetooth.printer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

class PrinterManager(private val context: Context) {

    // Standard SPP UUID for Bluetooth Classic Serial Printers
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var socket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _connectedDeviceName = MutableStateFlow("")
    val connectedDeviceName: StateFlow<String> = _connectedDeviceName.asStateFlow()

    private val _connectedDeviceAddress = MutableStateFlow("")
    val connectedDeviceAddress: StateFlow<String> = _connectedDeviceAddress.asStateFlow()

    private val _isConnecting = MutableStateFlow(false)
    val isConnecting: StateFlow<Boolean> = _isConnecting.asStateFlow()

    private val _lastPrintStatus = MutableStateFlow<String?>(null)
    val lastPrintStatus: StateFlow<String?> = _lastPrintStatus.asStateFlow()

    @SuppressLint("MissingPermission")
    suspend fun connectPrinter(device: BluetoothDevice): Boolean = withContext(Dispatchers.IO) {
        _isConnecting.value = true
        disconnectPrinter()

        var connected = false
        var lastException: Exception? = null

        try {
            val btAdapter = BluetoothAdapter.getDefaultAdapter()
            btAdapter?.cancelDiscovery()

            // 1. Try standard RFCOMM secure socket
            try {
                val newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                newSocket.connect()
                socket = newSocket
                outputStream = newSocket.outputStream
                connected = true
            } catch (e1: Exception) {
                lastException = e1
                // 2. Fallback to insecure RFCOMM socket
                try {
                    val insecureSocket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID)
                    insecureSocket.connect()
                    socket = insecureSocket
                    outputStream = insecureSocket.outputStream
                    connected = true
                } catch (e2: Exception) {
                    lastException = e2
                    // 3. Fallback via reflection to channel 1 if needed
                    try {
                        val method = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                        val reflexSocket = method.invoke(device, 1) as? BluetoothSocket
                        reflexSocket?.connect()
                        if (reflexSocket?.isConnected == true) {
                            socket = reflexSocket
                            outputStream = reflexSocket.outputStream
                            connected = true
                        }
                    } catch (e3: Exception) {
                        lastException = e3
                    }
                }
            }

            if (connected && socket?.isConnected == true && outputStream != null) {
                _isConnected.value = true
                _connectedDeviceName.value = device.name ?: device.address ?: "طابعة حرارية"
                _connectedDeviceAddress.value = device.address ?: ""
                _lastPrintStatus.value = "تم الاتصال بالطابعة بنجاح: ${_connectedDeviceName.value}"
            } else {
                _isConnected.value = false
                _connectedDeviceName.value = ""
                _connectedDeviceAddress.value = ""
                _lastPrintStatus.value = "فشل الاتصال بالطابعة: ${lastException?.localizedMessage ?: "تعذر فتح المنفذ"}"
                disconnectPrinter()
            }
        } catch (e: Exception) {
            _isConnected.value = false
            _connectedDeviceName.value = ""
            _connectedDeviceAddress.value = ""
            _lastPrintStatus.value = "فشل الاتصال: ${e.localizedMessage}"
            disconnectPrinter()
        } finally {
            _isConnecting.value = false
        }

        connected
    }

    suspend fun disconnectPrinter() = withContext(Dispatchers.IO) {
        try {
            outputStream?.flush()
            outputStream?.close()
        } catch (_: IOException) {}
        try {
            socket?.close()
        } catch (_: IOException) {}
        outputStream = null
        socket = null
        _isConnected.value = false
        _connectedDeviceName.value = ""
        _connectedDeviceAddress.value = ""
        _lastPrintStatus.value = "تم قطع الاتصال بالطابعة"
    }

    suspend fun printTicket(
        patient: Patient,
        settings: com.example.data.model.SystemSettings,
        paperSize: PaperSize = settings.paperSize
    ): Boolean = withContext(Dispatchers.IO) {
        val currentSocket = socket
        val currentStream = outputStream

        if (currentSocket != null && currentSocket.isConnected && currentStream != null) {
            try {
                val printBytes = BitmapEscPosHelper.buildTicketPrintBytes(patient, settings, paperSize)
                currentStream.write(printBytes)
                currentStream.flush()
                _lastPrintStatus.value = "تمت طباعة التذكرة للمراجع رقم ${patient.formattedNumber} بنجاح"
                return@withContext true
            } catch (e: Exception) {
                _lastPrintStatus.value = "خطأ أثناء إرسال أمر الطباعة: ${e.localizedMessage}"
                _isConnected.value = false
                return@withContext false
            }
        } else {
            _lastPrintStatus.value = "الطابعة غير متصلة. يرجى توصيل طابعة البلوتوث من الإعدادات أولاً."
            return@withContext false
        }
    }

    suspend fun printReportSummary(
        title: String,
        dateText: String,
        totalCount: Int,
        servedCount: Int,
        waitingCount: Int,
        postponedCount: Int,
        settings: com.example.data.model.SystemSettings,
        paperSize: PaperSize = settings.paperSize
    ): Boolean = withContext(Dispatchers.IO) {
        val currentSocket = socket
        val currentStream = outputStream

        if (currentSocket != null && currentSocket.isConnected && currentStream != null) {
            try {
                val printBytes = BitmapEscPosHelper.buildReportPrintBytes(
                    title = title,
                    dateText = dateText,
                    totalCount = totalCount,
                    servedCount = servedCount,
                    waitingCount = waitingCount,
                    postponedCount = postponedCount,
                    settings = settings,
                    paperSize = paperSize
                )
                currentStream.write(printBytes)
                currentStream.flush()
                _lastPrintStatus.value = "تمت طباعة التقرير بنجاح"
                return@withContext true
            } catch (e: Exception) {
                _lastPrintStatus.value = "خطأ أثناء طباعة التقرير: ${e.localizedMessage}"
                _isConnected.value = false
                return@withContext false
            }
        } else {
            _lastPrintStatus.value = "الطابعة غير متصلة. يرجى توصيل طابعة البلوتوث أولاً."
            return@withContext false
        }
    }
}
