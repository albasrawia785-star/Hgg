package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Patient
import kotlinx.coroutines.flow.Flow

@Dao
interface QueueDao {

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' ORDER BY queueNumber ASC")
    fun getLiveQueue(): Flow<List<Patient>>

    @Query("""
        SELECT * FROM patients 
        WHERE sessionId = 'live_session'
          AND (
              (:filter = 'ALL')
              OR (:filter = 'WAITING' AND isCalled = 0 AND isPostponed = 0)
              OR (:filter = 'POSTPONED' AND isPostponed = 1)
              OR (:filter = 'SERVED' AND isCalled = 1 AND isPostponed = 0)
          )
        ORDER BY queueNumber ASC
        LIMIT :limit OFFSET :offset
    """)
    fun getPagedLiveQueue(filter: String, limit: Int, offset: Int): Flow<List<Patient>>

    @Query("""
        SELECT COUNT(*) FROM patients 
        WHERE sessionId = 'live_session'
          AND (
              (:filter = 'ALL')
              OR (:filter = 'WAITING' AND isCalled = 0 AND isPostponed = 0)
              OR (:filter = 'POSTPONED' AND isPostponed = 1)
              OR (:filter = 'SERVED' AND isCalled = 1 AND isPostponed = 0)
          )
    """)
    fun getFilterCountFlow(filter: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM patients WHERE sessionId = 'live_session'")
    fun getLiveQueueCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM patients WHERE sessionId = 'live_session' AND isCalled = 0 AND isPostponed = 0")
    fun getWaitingCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM patients WHERE sessionId = 'live_session' AND isPostponed = 1")
    fun getPostponedCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM patients WHERE sessionId = 'live_session' AND isCalled = 1 AND isPostponed = 0")
    fun getServedCountFlow(): Flow<Int>

    @Query("SELECT COALESCE(MAX(queueNumber), 0) + 1 FROM patients WHERE sessionId = 'live_session'")
    fun getNextQueueNumberFlow(): Flow<Int>

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' AND isCurrent = 1 AND isPostponed = 0 LIMIT 1")
    fun getCurrentPatientFlow(): Flow<Patient?>

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' AND isCurrent = 1 AND isPostponed = 0 LIMIT 1")
    suspend fun getCurrentPatientDirect(): Patient?

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' AND isCalled = 0 AND isPostponed = 0 ORDER BY queueNumber ASC LIMIT 1")
    suspend fun getNextWaitingPatient(): Patient?

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' AND queueNumber > :currentQueueNumber AND isCalled = 0 AND isPostponed = 0 ORDER BY queueNumber ASC LIMIT 1")
    suspend fun getNextWaitingPatientAfter(currentQueueNumber: Int): Patient?

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' AND queueNumber < :currentQueueNumber AND isPostponed = 0 ORDER BY queueNumber DESC LIMIT 1")
    suspend fun getPreviousPatientBefore(currentQueueNumber: Int): Patient?

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' AND isCalled = 0 AND isPostponed = 0 ORDER BY queueNumber ASC LIMIT :limit")
    fun getTopWaitingPatientsFlow(limit: Int = 8): Flow<List<Patient>>

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' AND isPostponed = 1 ORDER BY queueNumber ASC LIMIT :limit")
    fun getTopPostponedPatientsFlow(limit: Int = 6): Flow<List<Patient>>

    @Query("""
        SELECT * FROM patients 
        WHERE (:sessionId IS NULL OR sessionId = :sessionId)
          AND (:searchQuery = '' OR name LIKE '%' || :searchQuery || '%' OR CAST(queueNumber AS TEXT) LIKE '%' || :searchQuery || '%')
          AND (
              (:filter = 'ALL')
              OR (:filter = 'WAITING' AND isCalled = 0 AND isPostponed = 0)
              OR (:filter = 'POSTPONED' AND isPostponed = 1)
              OR (:filter = 'SERVED' AND isCalled = 1 AND isPostponed = 0)
          )
        ORDER BY timestamp DESC
        LIMIT :limit OFFSET :offset
    """)
    fun getPagedReportPatients(sessionId: String?, searchQuery: String, filter: String, limit: Int, offset: Int): Flow<List<Patient>>

    @Query("""
        SELECT COUNT(*) FROM patients 
        WHERE (:sessionId IS NULL OR sessionId = :sessionId)
          AND (:searchQuery = '' OR name LIKE '%' || :searchQuery || '%' OR CAST(queueNumber AS TEXT) LIKE '%' || :searchQuery || '%')
          AND (
              (:filter = 'ALL')
              OR (:filter = 'WAITING' AND isCalled = 0 AND isPostponed = 0)
              OR (:filter = 'POSTPONED' AND isPostponed = 1)
              OR (:filter = 'SERVED' AND isCalled = 1 AND isPostponed = 0)
          )
    """)
    fun getReportCountFlow(sessionId: String?, searchQuery: String, filter: String): Flow<Int>

    @Query("SELECT * FROM patients WHERE sessionId != 'live_session' ORDER BY timestamp DESC")
    fun getArchivedPatients(): Flow<List<Patient>>

    @Query("SELECT * FROM patients ORDER BY timestamp DESC")
    fun getAllPatients(): Flow<List<Patient>>

    @Query("SELECT * FROM patients WHERE sessionId = 'live_session' ORDER BY queueNumber ASC")
    suspend fun getLiveQueueList(): List<Patient>

    @Query("SELECT * FROM patients WHERE sessionId = :sessionId ORDER BY queueNumber ASC")
    suspend fun getPatientsBySession(sessionId: String): List<Patient>

    @Query("SELECT * FROM patients WHERE id = :id LIMIT 1")
    suspend fun getPatientById(id: Int): Patient?

    @Query("SELECT MAX(queueNumber) FROM patients WHERE sessionId = 'live_session'")
    suspend fun getMaxLiveQueueNumber(): Int?

    @Query("SELECT COUNT(*) FROM patients WHERE sessionId = 'live_session'")
    suspend fun getLiveQueueCount(): Int

    @Query("SELECT COUNT(*) FROM patients")
    suspend fun getTotalPatientCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatient(patient: Patient): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPatients(patients: List<Patient>): List<Long>

    @Update
    suspend fun updatePatient(patient: Patient)

    @Update
    suspend fun updatePatients(patients: List<Patient>)

    @Query("UPDATE patients SET isCurrent = 0 WHERE sessionId = 'live_session'")
    suspend fun clearCurrentFlags()

    @Query("UPDATE patients SET isCalled = 1, isCurrent = 1, isPostponed = 0 WHERE id = :patientId")
    suspend fun markAsCalled(patientId: Int)

    @Query("UPDATE patients SET isCurrent = 1 WHERE id = :patientId")
    suspend fun markAsCurrent(patientId: Int)

    @Query("UPDATE patients SET isPostponed = 1, isCurrent = 0 WHERE id = :patientId")
    suspend fun markAsPostponed(patientId: Int)

    @Query("UPDATE patients SET isPostponed = 0, isCalled = 1, isCurrent = 1 WHERE id = :patientId")
    suspend fun markAsReactivated(patientId: Int)

    @Query("UPDATE patients SET isPostponed = 0, isCalled = 0 WHERE id = :patientId")
    suspend fun restorePostponed(patientId: Int)

    @Query("UPDATE patients SET sessionId = :newSessionId, sessionTitle = :newSessionTitle, isCurrent = 0 WHERE sessionId = 'live_session'")
    suspend fun archiveLiveQueue(newSessionId: String, newSessionTitle: String): Int

    @Delete
    suspend fun deletePatient(patient: Patient)

    @Query("DELETE FROM patients WHERE id = :id")
    suspend fun deletePatientById(id: Int)

    @Query("DELETE FROM patients WHERE sessionId = :sessionId")
    suspend fun deleteSession(sessionId: String): Int

    @Query("DELETE FROM patients WHERE sessionId = 'live_session'")
    suspend fun clearLiveQueue(): Int

    @Query("DELETE FROM patients")
    suspend fun clearAll(): Int

    @Query("DELETE FROM patients WHERE isCalled = 1 AND isPostponed = 0 AND (:sessionId IS NULL OR sessionId = :sessionId)")
    suspend fun deleteServedBySession(sessionId: String?): Int

    @Query("DELETE FROM patients WHERE isPostponed = 1 AND (:sessionId IS NULL OR sessionId = :sessionId)")
    suspend fun deletePostponedBySession(sessionId: String?): Int

    @Query("DELETE FROM patients WHERE isCalled = 1 AND isPostponed = 0 AND timestamp >= :startTime AND timestamp <= :endTime")
    suspend fun deleteServedByDateRange(startTime: Long, endTime: Long): Int

    @Query("DELETE FROM patients WHERE isPostponed = 1 AND timestamp >= :startTime AND timestamp <= :endTime")
    suspend fun deletePostponedByDateRange(startTime: Long, endTime: Long): Int

    @Query("DELETE FROM patients WHERE timestamp >= :startTime AND timestamp <= :endTime")
    suspend fun deleteByDateRange(startTime: Long, endTime: Long): Int
}
