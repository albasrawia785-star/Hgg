package com.example.bluetooth.printer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Typeface
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BitmapEscPosHelper {

    /**
     * Renders a crisp Arabic ticket matching the required layout to a Bitmap
     */
    fun renderTicketBitmap(
        patient: Patient,
        settings: SystemSettings,
        paperSize: PaperSize
    ): Bitmap {
        val width = paperSize.widthDots
        val scale = if (paperSize == PaperSize.WIDTH_80MM) 1.0f else 0.75f

        // Calculate dynamic height based on optional fields
        var estimatedHeight = 520f * scale
        if (patient.name.isNotBlank()) estimatedHeight += 40f * scale
        if (patient.note.isNotBlank()) estimatedHeight += 40f * scale
        if (settings.doctorName.isNotBlank()) estimatedHeight += 32f * scale
        if (settings.clinicPhone.isNotBlank()) estimatedHeight += 32f * scale

        val height = estimatedHeight.toInt()

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
        }

        val linePaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 2f * scale
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(8f * scale, 6f * scale), 0f)
        }
        val margin = 20f * scale

        var y = 46f * scale

        // 1. Clinic Name
        paint.textSize = 34f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(settings.clinicName, width / 2f, y, paint)
        y += 34f * scale

        // 2. Doctor Name (if set)
        if (settings.doctorName.isNotBlank()) {
            paint.textSize = 24f * scale
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText(settings.doctorName, width / 2f, y, paint)
            y += 30f * scale
        }

        // 3. Clinic Phone (if set)
        if (settings.clinicPhone.isNotBlank()) {
            paint.textSize = 20f * scale
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText("هاتف: ${settings.clinicPhone}", width / 2f, y, paint)
            y += 30f * scale
        }

        // 4. Dashed separator
        canvas.drawLine(margin, y, width - margin, y, linePaint)
        y += 38f * scale

        // 5. "المراجع رقم"
        paint.textSize = 26f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("المراجع رقم", width / 2f, y, paint)
        y += 74f * scale

        // 6. Huge Bold Patient Number e.g. "25"
        paint.textSize = 80f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(patient.formattedNumber, width / 2f, y, paint)
        y += 36f * scale

        // 7. Patient Name (if provided)
        if (patient.name.isNotBlank()) {
            paint.textSize = 24f * scale
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("اسم المراجع: ${patient.name}", width / 2f, y, paint)
            y += 34f * scale
        }

        // 8. Notes / Service type (ONLY if not blank)
        if (patient.note.isNotBlank()) {
            paint.textSize = 22f * scale
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText("ملاحظات: ${patient.note}", width / 2f, y, paint)
            y += 34f * scale
        }

        // 9. Dashed separator
        canvas.drawLine(margin, y, width - margin, y, linePaint)
        y += 34f * scale

        // 10. Date and Time
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.US)
        val dateObj = Date(patient.timestamp)
        val dateText = dateFormat.format(dateObj)
        val timeText = timeFormat.format(dateObj)

        paint.textSize = 21f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(dateText, width / 2f, y, paint)
        y += 28f * scale
        canvas.drawText(timeText, width / 2f, y, paint)
        y += 36f * scale

        // 11. Footer Notice & Greeting
        paint.textSize = 22f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(settings.footerMessage.ifBlank { "يرجى الاحتفاظ بالوصل" }, width / 2f, y, paint)
        y += 28f * scale

        paint.textSize = 19f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("شكراً لزيارتكم • نتمنى لكم الصحة والعافية", width / 2f, y, paint)

        return bitmap
    }

    /**
     * Converts a Bitmap into 1-bit monochrome thresholded bytes for ESC/POS raster command
     */
    fun convertBitmapToMonochromeRaster(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val widthBytes = (width + 7) / 8
        val rasterBytes = ByteArray(widthBytes * height)

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        for (y in 0 until height) {
            for (x in 0 until width) {
                val pixel = pixels[y * width + x]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luminance = (r * 0.299 + g * 0.587 + b * 0.114).toInt()

                // Thresholding: dark pixels become 1 (print black dot)
                if (luminance < 160) {
                    val byteIndex = y * widthBytes + (x / 8)
                    val bitIndex = 7 - (x % 8)
                    rasterBytes[byteIndex] = (rasterBytes[byteIndex].toInt() or (1 shl bitIndex)).toByte()
                }
            }
        }
        return rasterBytes
    }

    /**
     * Generates complete ESC/POS raw byte packet for printing ticket
     */
    fun buildTicketPrintBytes(
        patient: Patient,
        settings: SystemSettings,
        paperSize: PaperSize
    ): ByteArray {
        val bitmap = renderTicketBitmap(patient, settings, paperSize)
        val raster = convertBitmapToMonochromeRaster(bitmap)
        val imageCommand = EscPosPrinter.createRasterImageCommand(raster, bitmap.width, bitmap.height)

        val out = ByteArrayOutputStream()
        out.write(EscPosPrinter.CMD_INIT)
        out.write(EscPosPrinter.CMD_ALIGN_CENTER)
        out.write(imageCommand)
        out.write(EscPosPrinter.CMD_FEED_5_LINES)
        out.write(EscPosPrinter.CMD_CUT_PAPER_PARTIAL)

        return out.toByteArray()
    }

    /**
     * Renders an analytical summary report to Bitmap for thermal printer
     */
    fun renderReportSummaryBitmap(
        title: String,
        dateText: String,
        totalCount: Int,
        servedCount: Int,
        waitingCount: Int,
        postponedCount: Int,
        settings: SystemSettings,
        paperSize: PaperSize
    ): Bitmap {
        val width = paperSize.widthDots
        val scale = if (paperSize == PaperSize.WIDTH_80MM) 1.0f else 0.75f
        val height = (580f * scale).toInt()

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
        }

        val linePaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 2f * scale
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(8f * scale, 6f * scale), 0f)
        }
        val margin = 20f * scale
        var y = 44f * scale

        // 1. Clinic Name
        paint.textSize = 32f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(settings.clinicName, width / 2f, y, paint)
        y += 32f * scale

        // 2. Doctor Name
        if (settings.doctorName.isNotBlank()) {
            paint.textSize = 22f * scale
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText(settings.doctorName, width / 2f, y, paint)
            y += 28f * scale
        }

        // 3. Title
        paint.textSize = 24f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(title, width / 2f, y, paint)
        y += 28f * scale

        // 4. Date text
        paint.textSize = 20f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(dateText, width / 2f, y, paint)
        y += 26f * scale

        // 5. Line
        canvas.drawLine(margin, y, width - margin, y, linePaint)
        y += 36f * scale

        // 6. Metrics
        paint.textSize = 22f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("إجمالي المسجلين: $totalCount مراجع", width / 2f, y, paint)
        y += 32f * scale

        canvas.drawText("تمت خدمتهم: $servedCount", width / 2f, y, paint)
        y += 30f * scale

        canvas.drawText("قيد الانتظار: $waitingCount", width / 2f, y, paint)
        y += 30f * scale

        canvas.drawText("المؤجلون: $postponedCount", width / 2f, y, paint)
        y += 32f * scale

        // 7. Line
        canvas.drawLine(margin, y, width - margin, y, linePaint)
        y += 34f * scale

        // 8. Printed at
        val timeFormat = SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale.US)
        paint.textSize = 18f * scale
        paint.color = Color.DKGRAY
        canvas.drawText("وقت الطباعة: ${timeFormat.format(Date())}", width / 2f, y, paint)

        return bitmap
    }

    /**
     * Generates ESC/POS print bytes for report summary
     */
    fun buildReportPrintBytes(
        title: String,
        dateText: String,
        totalCount: Int,
        servedCount: Int,
        waitingCount: Int,
        postponedCount: Int,
        settings: SystemSettings,
        paperSize: PaperSize
    ): ByteArray {
        val bitmap = renderReportSummaryBitmap(
            title = title,
            dateText = dateText,
            totalCount = totalCount,
            servedCount = servedCount,
            waitingCount = waitingCount,
            postponedCount = postponedCount,
            settings = settings,
            paperSize = paperSize
        )
        val raster = convertBitmapToMonochromeRaster(bitmap)
        val imageCommand = EscPosPrinter.createRasterImageCommand(raster, bitmap.width, bitmap.height)

        val out = ByteArrayOutputStream()
        out.write(EscPosPrinter.CMD_INIT)
        out.write(EscPosPrinter.CMD_ALIGN_CENTER)
        out.write(imageCommand)
        out.write(EscPosPrinter.CMD_FEED_5_LINES)
        out.write(EscPosPrinter.CMD_CUT_PAPER_PARTIAL)

        return out.toByteArray()
    }
}
