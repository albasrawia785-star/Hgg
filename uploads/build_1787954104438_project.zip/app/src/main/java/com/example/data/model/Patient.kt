package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "patients",
    indices = [
        Index(value = ["sessionId", "queueNumber"]),
        Index(value = ["sessionId", "isCalled", "isPostponed", "queueNumber"]),
        Index(value = ["sessionId", "isCurrent"]),
        Index(value = ["sessionId", "isPostponed", "queueNumber"]),
        Index(value = ["timestamp"]),
        Index(value = ["queueNumber"])
    ]
)
data class Patient(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val queueNumber: Int,
    val name: String = "",
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isCalled: Boolean = false,
    val isCurrent: Boolean = false,
    val isPostponed: Boolean = false,
    val sessionId: String = "live_session",
    val sessionTitle: String = "الجلسة الحالية النشطة"
) {
    val formattedNumber: String
        get() = queueNumber.toString()

    val formattedTime: String
        get() {
            val sdf = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault())
            return sdf.format(java.util.Date(timestamp))
        }
}
