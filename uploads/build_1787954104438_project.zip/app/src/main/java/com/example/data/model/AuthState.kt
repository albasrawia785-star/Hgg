package com.example.data.model

enum class UserAccountType(val titleAr: String, val badgeText: String) {
    TRIAL("حساب تجريبي", "نسخة تجريبية"),
    FULL("النسخة الكاملة", "النسخة الكاملة (غير محدود)")
}

data class AuthState(
    val isLoggedIn: Boolean = false,
    val username: String = "",
    val accountType: UserAccountType = UserAccountType.TRIAL,
    val maxTrialPatients: Int = 3
)
