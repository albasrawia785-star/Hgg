package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.ui.components.SubscriptionRequiredDialog
import com.example.ui.screens.CallingStateScreen
import com.example.ui.screens.ChoosePrinterScreen
import com.example.ui.screens.DeviceSettingsScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MainHomeScreen
import com.example.ui.screens.QueueListScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.ResetConfirmDialog
import com.example.ui.screens.TicketPreviewDialog
import com.example.ui.theme.ClinicQueueTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ClinicQueueTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()
    val showSubscriptionDialog by viewModel.showSubscriptionDialog.collectAsState()
    val previewTicketPatient by viewModel.previewTicketPatient.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Request Bluetooth permissions dynamically on Android 12+
    val permissionsToRequest = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            viewModel.bluetoothDeviceManager.refreshPairedDevices()
        }
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(permissionsToRequest)
    }

    // Display snackbars for user feedback
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            scope.launch {
                snackbarHostState.showSnackbar(msg)
            }
            viewModel.clearToastMessage()
        }
    }

    // Android Hardware / Gesture Back Navigation Handler
    BackHandler(enabled = currentScreen != AppScreen.QUEUE_LIST && currentScreen != AppScreen.HOME && currentScreen != AppScreen.LOGIN) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Screen Routing
            when (currentScreen) {
                AppScreen.LOGIN -> {
                    LoginScreen(viewModel = viewModel)
                }
                AppScreen.HOME, AppScreen.QUEUE_LIST -> {
                    QueueListScreen(viewModel = viewModel)
                }
                AppScreen.DEVICE_SETTINGS -> {
                    DeviceSettingsScreen(viewModel = viewModel)
                }
                AppScreen.CHOOSE_PRINTER -> {
                    ChoosePrinterScreen(viewModel = viewModel)
                }
                AppScreen.CALLING_ACTIVE -> {
                    CallingStateScreen(viewModel = viewModel)
                }
                AppScreen.REPORTS -> {
                    ReportsScreen(viewModel = viewModel)
                }
            }

            // Subscription Limit Alert Dialog
            if (showSubscriptionDialog) {
                SubscriptionRequiredDialog(
                    onUpgradeClick = { viewModel.onUpgradeToFullVersion() },
                    onDismiss = { viewModel.onDismissSubscriptionDialog() }
                )
            }

            // Reset Queue Confirmation Dialog
            if (showResetDialog) {
                ResetConfirmDialog(
                    onConfirm = { viewModel.onConfirmResetQueue() },
                    onDismiss = { viewModel.onDismissResetDialog() }
                )
            }

            // Ticket Preview Modal Dialog
            previewTicketPatient?.let { patient ->
                TicketPreviewDialog(
                    patient = patient,
                    settings = settings,
                    onPrintClick = { viewModel.onPrintPreviewTicket() },
                    onDismiss = { viewModel.onDismissTicketPreview() }
                )
            }
        }
    }
}
