package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AppScreen

/**
 * شريط التنقل السفلي المنظم والمتناسق (Bottom Navigation Bar):
 * - توزيع متوازن ومتماثل بين التبويبات
 * - مؤشر علوي أزرق أفقي دقيق على التبويب النشط بمحاذاة الحافة العلوية
 * - خلفية بيضاء مع إطار علوي وظل ناعم يعكس جودة وتناسق التصميم
 */
@Composable
fun ClinicBottomNavBar(
    activeScreen: AppScreen,
    onQueueClick: () -> Unit,
    onReportsClick: () -> Unit = {},
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(elevation = 6.dp, spotColor = Color(0x14000000)),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .height(62.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // التبويب الأول: قائمة المراجعين
            NavTabItem(
                label = "قائمة المراجعين",
                icon = Icons.Default.FormatListNumbered,
                isActive = activeScreen == AppScreen.QUEUE_LIST || activeScreen == AppScreen.HOME,
                onClick = onQueueClick,
                modifier = Modifier.weight(1f)
            )

            // التبويب الثاني: الإعدادات
            NavTabItem(
                label = "الإعدادات",
                icon = Icons.Default.Settings,
                isActive = activeScreen == AppScreen.DEVICE_SETTINGS || activeScreen == AppScreen.CHOOSE_PRINTER,
                onClick = onSettingsClick,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun NavTabItem(
    label: String,
    icon: ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeNavy = Color(0xFF0F172A)
    val inactiveSlate = Color(0xFF64748B)

    Box(
        modifier = modifier
            .fillMaxHeight()
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // شريط المؤشر العلوي الأزرق تماماً في أعلى الحافة العلوية
        if (isActive) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .width(48.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp))
                    .background(Color(0xFF2563EB))
            )
        }

        // محتوى التبويب المتناسق
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isActive) Color(0xFFDBEAFE) else Color.Transparent)
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isActive) activeNavy else inactiveSlate,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                color = if (isActive) activeNavy else inactiveSlate
            )
        }
    }
}
