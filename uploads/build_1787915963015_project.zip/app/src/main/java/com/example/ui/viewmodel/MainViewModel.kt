package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AnnouncementManager
import com.example.audio.CallingState
import com.example.bluetooth.AudioRouteManager
import com.example.bluetooth.BluetoothDeviceManager
import com.example.bluetooth.printer.PrinterManager
import com.example.data.model.BluetoothDeviceInfo
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import com.example.data.repository.QueueRepository
import com.example.server.LocalHotspotManager
import com.example.server.TvDisplayServerManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppScreen {
    HOME,
    QUEUE_LIST,
    DEVICE_SETTINGS,
    CHOOSE_PRINTER,
    CALLING_ACTIVE,
    REPORTS
}

data class SessionReportGroup(
    val sessionId: String,
    val sessionTitle: String,
    val isLive: Boolean,
    val timestamp: Long,
    val patients: List<Patient>
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = QueueRepository(application)
    val bluetoothDeviceManager = BluetoothDeviceManager(application)
    val printerManager = PrinterManager(application)
    val audioRouteManager = AudioRouteManager(application)
    val announcementManager = AnnouncementManager(application, audioRouteManager)
    val tvDisplayServerManager = TvDisplayServerManager(application)
    val localHotspotManager = LocalHotspotManager(application)

    private val _currentScreen = MutableStateFlow(AppScreen.QUEUE_LIST)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val backStack = mutableListOf(AppScreen.QUEUE_LIST)

    val patients: StateFlow<List<Patient>> = repository.patients
    val archivedPatients: StateFlow<List<Patient>> = repository.archivedPatients

    // قائمة كافة المراجعين الموجهة لشاشة التقارير مستخرجة مباشرة وبسرعة فائقة من قاعدة بيانات SQLite
    val allReportsPatients: StateFlow<List<Patient>> = repository.allPatients
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val sessionGroups: StateFlow<List<SessionReportGroup>> = kotlinx.coroutines.flow.combine(
        repository.patients,
        repository.archivedPatients
    ) { currentList, archivedList ->
        val result = mutableListOf<SessionReportGroup>()
        if (currentList.isNotEmpty()) {
            val liveTime = currentList.maxOfOrNull { it.timestamp } ?: System.currentTimeMillis()
            result.add(
                SessionReportGroup(
                    sessionId = "live_session",
                    sessionTitle = "الجلسة الحالية النشطة (مباشر)",
                    isLive = true,
                    timestamp = liveTime,
                    patients = currentList
                )
            )
        }
        val grouped = archivedList.groupBy { it.sessionId }
        grouped.forEach { (sId, sPatients) ->
            val title = sPatients.firstOrNull()?.sessionTitle?.takeIf { it.isNotBlank() } ?: "جلسة سابقة"
            val maxTime = sPatients.maxOfOrNull { it.timestamp } ?: 0L
            result.add(
                SessionReportGroup(
                    sessionId = sId,
                    sessionTitle = title,
                    isLive = false,
                    timestamp = maxTime,
                    patients = sPatients
                )
            )
        }
        result.sortedByDescending { it.timestamp }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val currentPatient: StateFlow<Patient?> = repository.currentPatient
    val settings: StateFlow<SystemSettings> = repository.settings

    val isTvServerRunning: StateFlow<Boolean> = tvDisplayServerManager.isServerRunning
    val tvServerUrl: StateFlow<String> = tvDisplayServerManager.serverUrl
    val isTvConnected: StateFlow<Boolean> = tvDisplayServerManager.isTvConnected
    val isPrinterConnected: StateFlow<Boolean> = printerManager.isConnected

    val isHotspotActive: StateFlow<Boolean> = localHotspotManager.isHotspotActive
    val hotspotSsid: StateFlow<String> = localHotspotManager.ssid
    val hotspotPassword: StateFlow<String> = localHotspotManager.password
    val hotspotStatusMessage: StateFlow<String> = localHotspotManager.statusMessage
    val isHotspotLoading: StateFlow<Boolean> = localHotspotManager.isLoading

    private val _isTvAudioOnly = MutableStateFlow(true)
    val isTvAudioOnly: StateFlow<Boolean> = _isTvAudioOnly.asStateFlow()

    private val _showTvDialog = MutableStateFlow(false)
    val showTvDialog: StateFlow<Boolean> = _showTvDialog.asStateFlow()

    val postponedPatients: StateFlow<List<Patient>> = patients
        .map { list -> list.filter { it.isPostponed } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val activeWaitingPatients: StateFlow<List<Patient>> = patients
        .map { list -> list.filter { !it.isPostponed && !it.isCalled } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val callingState: StateFlow<CallingState> = announcementManager.callingState
    val activeCallingPatient: StateFlow<Patient?> = announcementManager.activeCallingPatient

    private val _showResetDialog = MutableStateFlow(false)
    val showResetDialog: StateFlow<Boolean> = _showResetDialog.asStateFlow()

    private val _showAddPatientDialog = MutableStateFlow(false)
    val showAddPatientDialog: StateFlow<Boolean> = _showAddPatientDialog.asStateFlow()

    private val _showPostponedSheet = MutableStateFlow(false)
    val showPostponedSheet: StateFlow<Boolean> = _showPostponedSheet.asStateFlow()

    private val _previewTicketPatient = MutableStateFlow<Patient?>(null)
    val previewTicketPatient: StateFlow<Patient?> = _previewTicketPatient.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _currentTimeFormatted = MutableStateFlow("")
    val currentTimeFormatted: StateFlow<String> = _currentTimeFormatted.asStateFlow()

    private val _currentDateFormatted = MutableStateFlow("")
    val currentDateFormatted: StateFlow<String> = _currentDateFormatted.asStateFlow()

    private val _isTestingAudio = MutableStateFlow(false)
    val isTestingAudio: StateFlow<Boolean> = _isTestingAudio.asStateFlow()

    private val _isQueueStarted = MutableStateFlow(false)
    val isQueueStarted: StateFlow<Boolean> = _isQueueStarted.asStateFlow()

    private var callingJob: Job? = null
    private var testAudioJob: Job? = null

    init {
        updateTimeAndDate()
        // Automatically start the TV display server so it's always ready for Smart TV / Hotspot
        tvDisplayServerManager.startServer()

        // Synchronize state with TV server
        viewModelScope.launch {
            patients.collect { list ->
                tvDisplayServerManager.updateState(settings.value, list, currentPatient.value, _isQueueStarted.value)
            }
        }
        viewModelScope.launch {
            settings.collect { currentSettings ->
                tvDisplayServerManager.updateState(currentSettings, patients.value, currentPatient.value, _isQueueStarted.value)
            }
        }
        viewModelScope.launch {
            currentPatient.collect { current ->
                tvDisplayServerManager.updateState(settings.value, patients.value, current, _isQueueStarted.value)
            }
        }
        viewModelScope.launch {
            _isQueueStarted.collect { started ->
                tvDisplayServerManager.updateState(settings.value, patients.value, currentPatient.value, started)
            }
        }
    }

    fun onToggleTvAudioOnly(enable: Boolean) {
        _isTvAudioOnly.value = enable
        _toastMessage.value = if (enable) "تم تفعيل خروج الصوت من شاشة التلفزيون فقط" else "تم تفعيل خروج الصوت من الهاتف أيضاً"
    }

    fun onToggleLocalHotspot(enable: Boolean) {
        if (enable) {
            localHotspotManager.startLocalHotspot(
                onSuccess = {
                    tvDisplayServerManager.refreshUrl()
                    _toastMessage.value = "تم إنشاء شبكة الواي فاي للعيادة بنجاح"
                },
                onFailure = { error: String ->
                    _toastMessage.value = error
                }
            )
        } else {
            localHotspotManager.stopLocalHotspot()
            tvDisplayServerManager.refreshUrl()
            _toastMessage.value = "تم إيقاف شبكة الواي فاي"
        }
    }

    fun onOpenTvDialog() {
        tvDisplayServerManager.startServer()
        _showTvDialog.value = true
    }

    fun onDismissTvDialog() {
        _showTvDialog.value = false
    }

    fun onToggleTvServer(enable: Boolean) {
        if (enable) {
            tvDisplayServerManager.startServer()
            _toastMessage.value = "تم تشغيل خادم شاشة التلفزيون"
        } else {
            tvDisplayServerManager.stopServer()
            _toastMessage.value = "تم إيقاف خادم شاشة التلفزيون"
        }
    }

    fun onRefreshTvIp() {
        tvDisplayServerManager.refreshUrl()
        _toastMessage.value = "تم تحديث عنوان الشبكة: ${tvDisplayServerManager.serverUrl.value}"
    }

    fun updateTimeAndDate() {
        val now = Date()
        val timeFmt = SimpleDateFormat("hh:mm a", Locale.US)
        val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        _currentTimeFormatted.value = timeFmt.format(now)
        _currentDateFormatted.value = dateFmt.format(now)
    }

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            backStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (backStack.size > 1) {
            backStack.removeAt(backStack.size - 1)
            _currentScreen.value = backStack.last()
            return true
        }
        return false
    }

    fun onAddPatientClicked() {
        _showAddPatientDialog.value = true
    }

    fun onDismissAddPatientDialog() {
        _showAddPatientDialog.value = false
    }

    fun onOpenPostponedSheet() {
        _showPostponedSheet.value = true
    }

    fun onDismissPostponedSheet() {
        _showPostponedSheet.value = false
    }

    fun onConfirmAddPatient(name: String, note: String, shouldPrint: Boolean) {
        viewModelScope.launch {
            updateTimeAndDate()
            val newPatient = repository.addPatient(name = name, note = note)

            if (shouldPrint) {
                val currentSettings = settings.value
                val success = printerManager.printTicket(
                    patient = newPatient,
                    settings = currentSettings,
                    paperSize = currentSettings.paperSize
                )
                if (success) {
                    _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber} وطباعة الوصل"
                } else {
                    _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber} (لم تتم الطباعة - تأكد من اتصال الطابعة)"
                }
            } else {
                _toastMessage.value = "تمت إضافة المراجع رقم ${newPatient.formattedNumber}"
            }
        }
    }

    private fun shouldMutePhone(): Boolean {
        return _isTvAudioOnly.value && (isTvServerRunning.value || isHotspotActive.value)
    }

    /**
     * استدعاء المراجع الحالي في نفس الشاشة دون الانتقال لشاشة منفصلة
     */
    fun onCallCurrentPatientClicked() {
        _isQueueStarted.value = true
        viewModelScope.launch {
            val patientToCall = repository.callCurrentPatient()
            if (patientToCall == null) {
                _toastMessage.value = "القائمة فارغة. يرجى إضافة مراجع أولاً."
                return@launch
            }

            tvDisplayServerManager.notifyPatientCalled(patientToCall)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = patientToCall,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
        }
    }

    /**
     * استدعاء المراجع التالي والانتقال إليه مباشرة
     */
    fun onCallNextPatientClicked() {
        _isQueueStarted.value = true
        viewModelScope.launch {
            val nextPatient = repository.callNextPatient()
            if (nextPatient == null) {
                _toastMessage.value = "لا يوجد مراجعين حالياً"
                return@launch
            }

            tvDisplayServerManager.notifyPatientCalled(nextPatient)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = nextPatient,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
            _toastMessage.value = "تم استدعاء المراجع التالي رقم ${nextPatient.formattedNumber}"
        }
    }

    /**
     * إعادة استدعاء المراجع الحالي
     */
    fun onRecallCurrentPatient() {
        val current = currentPatient.value ?: return
        tvDisplayServerManager.notifyPatientCalled(current)
        callingJob?.cancel()
        callingJob = viewModelScope.launch {
            announcementManager.announcePatient(
                patient = current,
                settings = settings.value,
                mutePhone = shouldMutePhone()
            )
        }
    }

    /**
     * تأجيل المراجع الحالي وإضافته لقائمة المؤجلين ثم الانتقال للتالي تلقائياً
     */
    fun onPostponeCurrentPatient() {
        viewModelScope.launch {
            val (postponed, next) = repository.postponeCurrentPatient()
            if (postponed != null) {
                callingJob?.cancel()
                announcementManager.resetState()
                if (next != null) {
                    _toastMessage.value = "تم تأجيل المراجع ${postponed.formattedNumber} وتعيين المراجع ${next.formattedNumber}"
                } else {
                    _toastMessage.value = "تم نقل المراجع رقم ${postponed.formattedNumber} إلى قائمة المؤجلين"
                }
            } else {
                _toastMessage.value = "لا يوجد مراجع حالي لتأجيله"
            }
        }
    }

    /**
     * تأجيل مراجع محدد من القائمة
     */
    fun onPostponeSpecificPatient(patient: Patient) {
        viewModelScope.launch {
            val postponed = repository.postponePatient(patient)
            callingJob?.cancel()
            announcementManager.resetState()
            _toastMessage.value = "تم تأجيل المراجع رقم ${postponed.formattedNumber}"
        }
    }

    /**
     * استدعاء مراجع مؤجل مباشرة
     */
    fun onRecallPostponedPatient(patient: Patient) {
        _isQueueStarted.value = true
        viewModelScope.launch {
            val reactivated = repository.recallPostponedPatient(patient)
            tvDisplayServerManager.notifyPatientCalled(reactivated)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = reactivated,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
            _toastMessage.value = "تم استدعاء المراجع المؤجل رقم ${reactivated.formattedNumber}"
        }
    }

    /**
     * إعادة المراجع المؤجل إلى قائمة الانتظار
     */
    fun onRestorePostponedToQueue(patient: Patient) {
        viewModelScope.launch {
            repository.restorePostponedToQueue(patient)
            _toastMessage.value = "تمت إعادة المراجع رقم ${patient.formattedNumber} إلى قائمة الانتظار"
        }
    }

    /**
     * حذف مراجع
     */
    fun onDeletePatient(patient: Patient) {
        viewModelScope.launch {
            repository.deletePatient(patient)
            _toastMessage.value = "تم حذف المراجع رقم ${patient.formattedNumber}"
        }
    }

    /**
     * حذف جميع المراجعين الذين تمت خدمتهم من التقارير
     */
    fun onDeleteServedPatients(dateKey: String? = null, sessionId: String? = null) {
        viewModelScope.launch {
            repository.deleteServedPatients(dateKey, sessionId)
            _toastMessage.value = "تم حذف المراجعين الذين تمت خدمتهم من التقرير المحدد"
        }
    }

    /**
     * حذف جميع المراجعين المؤجلين من التقارير
     */
    fun onDeletePostponedPatients(dateKey: String? = null, sessionId: String? = null) {
        viewModelScope.launch {
            repository.deletePostponedPatients(dateKey, sessionId)
            _toastMessage.value = "تم حذف المراجعين المؤجلين"
        }
    }

    /**
     * حذف جلسة كاملة
     */
    fun onDeleteSession(sessionId: String, sessionTitle: String = "") {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            val titleText = if (sessionTitle.isNotBlank()) " ($sessionTitle)" else ""
            _toastMessage.value = "تم حذف بيانات الجلسة$titleText بالكامل من التقارير"
        }
    }

    /**
     * حذف تاريخ محدد بالكامل من الأرشيف
     */
    fun onDeleteByDate(dateKey: String, displayDate: String) {
        viewModelScope.launch {
            repository.deleteByDate(dateKey)
            _toastMessage.value = "تم حذف أرشيف يوم $displayDate بالكامل"
        }
    }

    /**
     * طباعة ملخص التقرير والإحصائيات عبر طابعة البلوتوث
     */
    fun onPrintReportSummary(
        title: String = "تقرير العيادة",
        dateText: String,
        totalCount: Int,
        servedCount: Int,
        waitingCount: Int,
        postponedCount: Int
    ) {
        viewModelScope.launch {
            if (!printerManager.isConnected.value) {
                _toastMessage.value = "الطابعة غير متصلة، يرجى توصيلها من الإعدادات"
                return@launch
            }
            val success = printerManager.printReportSummary(
                title = title,
                dateText = dateText,
                totalCount = totalCount,
                servedCount = servedCount,
                waitingCount = waitingCount,
                postponedCount = postponedCount,
                settings = settings.value
            )
            if (success) {
                _toastMessage.value = "تم إرسال التقرير للطابعة بنجاح"
            } else {
                _toastMessage.value = printerManager.lastPrintStatus.value
            }
        }
    }

    /**
     * مسح وحذف كافة السجلات في التقرير وقائمة الانتظار نهائياً
     */
    fun onClearAllReports() {
        viewModelScope.launch {
            repository.clearAllReportsAndQueue()
            _isQueueStarted.value = false
            _toastMessage.value = "تم مسح كافة سجلات التقارير بنجاح"
        }
    }

    fun onCallSpecificPatient(patient: Patient) {
        _isQueueStarted.value = true
        viewModelScope.launch {
            val patientToCall = repository.callSpecificPatient(patient.id)
                ?: patient.copy(isCalled = true, isCurrent = true, isPostponed = false)
            tvDisplayServerManager.notifyPatientCalled(patientToCall)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = patientToCall,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
        }
    }

    fun onCallNextPatientFromCallingScreen() {
        viewModelScope.launch {
            val nextPatient = repository.callNextPatient() ?: return@launch
            tvDisplayServerManager.notifyPatientCalled(nextPatient)
            callingJob?.cancel()
            callingJob = viewModelScope.launch {
                announcementManager.announcePatient(
                    patient = nextPatient,
                    settings = settings.value,
                    mutePhone = shouldMutePhone()
                )
            }
        }
    }

    fun onDismissCallingScreen() {
        callingJob?.cancel()
        announcementManager.resetState()
        navigateBack()
    }

    fun onStartQueue() {
        _isQueueStarted.value = true
        _toastMessage.value = "تم بدء العيادة وعرض أرقام المراجعين على الشاشة"
    }

    fun onPauseQueue() {
        _isQueueStarted.value = false
        _toastMessage.value = "تم إيقاف عرض الأرقام مؤقتاً (الشاشة في وضع الاستعداد)"
    }

    fun onStartQueueClicked() {
        _isQueueStarted.value = true
        val current = currentPatient.value
        if (current == null) {
            onCallNextPatientClicked()
        } else {
            onCallCurrentPatientClicked()
        }
        _toastMessage.value = "تم بدء الدور وعرض الأرقام"
    }

    fun onOpenResetDialog() {
        _showResetDialog.value = true
    }

    fun onDismissResetDialog() {
        _showResetDialog.value = false
    }

    /**
     * تصفير الدور مع ترحيل الأسماء مباشرة إلى صفحة التقارير
     */
    fun onConfirmResetQueue() {
        _isQueueStarted.value = false
        _showResetDialog.value = false
        viewModelScope.launch {
            val count = repository.archiveAndResetQueue()
            if (count > 0) {
                _toastMessage.value = "تم تصفير الدور وتحويل $count مراجع إلى صفحة التقارير"
            } else {
                _toastMessage.value = "تم تصفير قائمة الدور بنجاح"
            }
        }
    }

    fun onOpenTicketPreview(patient: Patient) {
        _previewTicketPatient.value = patient
    }

    fun onDismissTicketPreview() {
        _previewTicketPatient.value = null
    }

    fun onPrintPreviewTicket() {
        val patient = _previewTicketPatient.value ?: return
        viewModelScope.launch {
            val success = printerManager.printTicket(
                patient = patient,
                settings = settings.value,
                paperSize = settings.value.paperSize
            )
            if (success) {
                _toastMessage.value = "تمت طباعة التذكرة بنجاح"
            }
        }
    }

    // Clinic and Doctor Settings
    fun onClinicNameChanged(name: String) {
        repository.updateSettings(settings.value.copy(clinicName = name))
    }

    fun onDoctorNameChanged(name: String) {
        repository.updateSettings(settings.value.copy(doctorName = name))
    }

    fun onClinicPhoneChanged(phone: String) {
        repository.updateSettings(settings.value.copy(clinicPhone = phone))
    }

    fun onFooterMessageChanged(msg: String) {
        repository.updateSettings(settings.value.copy(footerMessage = msg))
    }

    fun onPaperSizeChanged(size: PaperSize) {
        repository.updateSettings(settings.value.copy(paperSize = size))
    }

    fun onToggleAutoPrint(enabled: Boolean) {
        repository.updateSettings(settings.value.copy(autoPrintOnAdd = enabled))
    }

    fun onLayoutDirectionChanged(isRtl: Boolean) {
        repository.updateSettings(settings.value.copy(isRtlLayout = isRtl))
    }

    // Audio Control Methods
    fun onSpeechRateChanged(rate: Float) {
        repository.updateSettings(settings.value.copy(speechRate = rate))
    }

    fun onPitchChanged(pitch: Float) {
        repository.updateSettings(settings.value.copy(pitch = pitch))
    }

    fun onVolumeChanged(volume: Float) {
        repository.updateSettings(settings.value.copy(volume = volume))
    }

    fun onToggleChime(enabled: Boolean) {
        repository.updateSettings(settings.value.copy(enableChime = enabled))
    }

    fun onCallPhraseChanged(phrase: String) {
        repository.updateSettings(settings.value.copy(callPhrase = phrase))
    }

    fun onTestAudio() {
        testAudioJob?.cancel()
        testAudioJob = viewModelScope.launch {
            _isTestingAudio.value = true
            announcementManager.testAnnouncement(settings.value)
            _isTestingAudio.value = false
        }
    }

    fun onResetAudioDefaults() {
        repository.updateSettings(
            settings.value.copy(
                speechRate = 0.85f,
                pitch = 1.0f,
                volume = 1.0f,
                enableChime = true,
                callPhrase = "المُراجِع رَقْم %s"
            )
        )
        _toastMessage.value = "تمت استعادة إعدادات الصوت الافتراضية"
    }

    fun onSelectPrinter(device: BluetoothDeviceInfo) {
        viewModelScope.launch {
            val btDevice = bluetoothDeviceManager.getDevice(device.address)
            if (btDevice != null) {
                _toastMessage.value = "جاري الاتصال بالطابعة ${device.name}..."
                val success = printerManager.connectPrinter(btDevice)
                if (success) {
                    repository.updateSettings(
                        settings.value.copy(
                            selectedPrinterName = device.name,
                            selectedPrinterAddress = device.address
                        )
                    )
                    _toastMessage.value = "تم الاتصال بالطابعة ${device.name} بنجاح"
                    navigateBack()
                } else {
                    _toastMessage.value = "فشل الاتصال بالطابعة ${device.name}. تأكد من تشغيلها واقترانها."
                }
            } else {
                _toastMessage.value = "تعذر العثور على عنوان جهاز الطابعة"
            }
        }
    }

    fun onDisconnectPrinter() {
        viewModelScope.launch {
            printerManager.disconnectPrinter()
            repository.updateSettings(
                settings.value.copy(
                    selectedPrinterName = "",
                    selectedPrinterAddress = ""
                )
            )
            _toastMessage.value = "تم قطع الاتصال بالطابعة"
        }
    }

    fun onSelectSpeaker(device: BluetoothDeviceInfo) {
        audioRouteManager.connectSpeaker(device.name, device.address)
        repository.updateSettings(
            settings.value.copy(
                selectedSpeakerName = device.name,
                selectedSpeakerAddress = device.address
            )
        )
        _toastMessage.value = "تم تحديد وتحويل الصوت إلى السماعة ${device.name}"
        navigateBack()
    }

    fun onDisconnectSpeaker() {
        audioRouteManager.disconnectSpeaker()
        repository.updateSettings(
            settings.value.copy(
                selectedSpeakerName = "",
                selectedSpeakerAddress = ""
            )
        )
        _toastMessage.value = "تم قطع الاتصال بالسماعة والتحويل إلى سماعة الهاتف"
    }

    fun clearToastMessage() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        announcementManager.shutdown()
    }
}
