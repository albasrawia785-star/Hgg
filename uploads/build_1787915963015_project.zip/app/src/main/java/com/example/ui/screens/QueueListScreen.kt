package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.CallingState
import com.example.data.model.Patient
import com.example.ui.components.ClinicBottomNavBar
import com.example.ui.components.TvDisplayDialog
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

enum class QueueFilterType(val label: String) {
    ALL("الكل"),
    WAITING("في الانتظار"),
    POSTPONED("المؤجلين"),
    SERVED("تم الاستدعاء")
}

@Composable
fun QueueListScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val patients by viewModel.patients.collectAsState()
    val postponedPatients by viewModel.postponedPatients.collectAsState()
    val activeWaitingPatients by viewModel.activeWaitingPatients.collectAsState()
    val currentPatient by viewModel.currentPatient.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val callingState by viewModel.callingState.collectAsState()
    val activeCallingPatient by viewModel.activeCallingPatient.collectAsState()
    val isQueueStarted by viewModel.isQueueStarted.collectAsState()

    val showAddDialog by viewModel.showAddPatientDialog.collectAsState()
    val previewPatient by viewModel.previewTicketPatient.collectAsState()
    val showTvDialog by viewModel.showTvDialog.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()

    val isTvServerRunning by viewModel.isTvServerRunning.collectAsState()
    val tvServerUrl by viewModel.tvServerUrl.collectAsState()
    val isTvConnected by viewModel.isTvConnected.collectAsState()
    val isPrinterConnected by viewModel.isPrinterConnected.collectAsState()
    val isHotspotActive by viewModel.isHotspotActive.collectAsState()
    val hotspotSsid by viewModel.hotspotSsid.collectAsState()
    val hotspotPassword by viewModel.hotspotPassword.collectAsState()
    val hotspotStatusMessage by viewModel.hotspotStatusMessage.collectAsState()
    val isHotspotLoading by viewModel.isHotspotLoading.collectAsState()
    val isTvAudioOnly by viewModel.isTvAudioOnly.collectAsState()

    var selectedFilter by remember { mutableStateOf(QueueFilterType.ALL) }
    var patientToDelete by remember { mutableStateOf<Patient?>(null) }

    val waitingList = activeWaitingPatients
    val postponedList = postponedPatients
    val servedList = patients.filter { it.isCalled && !it.isPostponed }

    val filteredList = when (selectedFilter) {
        QueueFilterType.ALL -> patients
        QueueFilterType.WAITING -> waitingList
        QueueFilterType.POSTPONED -> postponedList
        QueueFilterType.SERVED -> servedList
    }

    val nextNumber = if (patients.isEmpty()) 1 else (patients.maxOf { it.queueNumber } + 1)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // =========================================================
            // 1. أعلى الصفحة: اسم العيادة، حالة الشاشة والطابعة، وحذف جميع المراجعين
            // =========================================================
            TopClinicHeader(
                clinicName = settings.clinicName.ifBlank { "عيادة الشفاء التخصصية" },
                doctorName = settings.doctorName.ifBlank { "د. أحمد عبدالله" },
                isTvConnected = isTvConnected,
                isPrinterConnected = isPrinterConnected,
                onDeleteAllClick = { viewModel.onOpenResetDialog() },
                onTvClick = { viewModel.onOpenTvDialog() },
                onPrinterClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) }
            )

            // =========================================================
            // 2. زر "ابدأ" / بطاقة حالة الجلسة الذكية التي تم طلبها
            // =========================================================
            QueueSessionControlCard(
                isQueueStarted = isQueueStarted,
                onStartClick = { viewModel.onStartQueueClicked() },
                onPauseClick = { viewModel.onPauseQueue() }
            )

            // =========================================================
            // 3. شريط التنبيه الصوتي الحي (عند الاستدعاء)
            // =========================================================
            AnimatedVisibility(
                visible = callingState != CallingState.IDLE,
                enter = slideInVertically() + fadeIn(),
                exit = slideOutVertically() + fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A))
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "جاري النداء الصوتي للمراجع رقم ${activeCallingPatient?.formattedNumber ?: (currentPatient?.formattedNumber ?: "")}...",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = Color(0xFF22C55E),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // =========================================================
            // 4. سطر التوجيه والإجمالي
            // =========================================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "اضغط على أي مراجع للاستدعاء الصوتي مباشرة",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "الإجمالي: ${patients.size}",
                    fontSize = 13.sp,
                    color = Color(0xFF0F172A),
                    fontWeight = FontWeight.Bold
                )
            }

            // =========================================================
            // 5. تبويبات التصفية الأفقية (الكل، في الانتظار، المؤجلين، تم الاستدعاء)
            // =========================================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QueueFilterPill(
                    label = "الكل",
                    count = patients.size,
                    isSelected = selectedFilter == QueueFilterType.ALL,
                    onClick = { selectedFilter = QueueFilterType.ALL },
                    modifier = Modifier.weight(1f)
                )
                QueueFilterPill(
                    label = "في الانتظار",
                    count = waitingList.size,
                    isSelected = selectedFilter == QueueFilterType.WAITING,
                    onClick = { selectedFilter = QueueFilterType.WAITING },
                    modifier = Modifier.weight(1.3f)
                )
                QueueFilterPill(
                    label = "المؤجلين",
                    count = postponedList.size,
                    isSelected = selectedFilter == QueueFilterType.POSTPONED,
                    onClick = { selectedFilter = QueueFilterType.POSTPONED },
                    modifier = Modifier.weight(1.1f)
                )
                QueueFilterPill(
                    label = "تم استدعاء",
                    count = servedList.size,
                    isSelected = selectedFilter == QueueFilterType.SERVED,
                    onClick = { selectedFilter = QueueFilterType.SERVED },
                    modifier = Modifier.weight(1.3f)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // =========================================================
            // 6. قائمة بطاقات المراجعين المطابقة تماماً للصورة
            // =========================================================
            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0F172A).copy(alpha = 0.05f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FormatListNumbered,
                                contentDescription = null,
                                tint = Color(0xFF0F172A).copy(alpha = 0.5f),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = when (selectedFilter) {
                                QueueFilterType.ALL -> "قائمة المراجعين فارغة"
                                QueueFilterType.WAITING -> "لا يوجد مراجعين في الانتظار"
                                QueueFilterType.POSTPONED -> "لا يوجد مراجعين مؤجلين"
                                QueueFilterType.SERVED -> "لم يتم استدعاء أي مراجع بعد"
                            },
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "اضغط على زر (+) في الأسفل لإضافة مراجع جديد",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredList, key = { it.id }) { patient ->
                        val isActive = (currentPatient?.id == patient.id) || (activeCallingPatient?.id == patient.id)
                        PatientCardExact(
                            patient = patient,
                            isActive = isActive,
                            onCardClick = { viewModel.onCallSpecificPatient(patient) },
                            onHourglassClick = {
                                if (patient.isPostponed) {
                                    viewModel.onRestorePostponedToQueue(patient)
                                } else {
                                    viewModel.onPostponeSpecificPatient(patient)
                                }
                            },
                            onReceiptClick = { viewModel.onOpenTicketPreview(patient) },
                            onDeleteClick = { patientToDelete = patient }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(84.dp))
                    }
                }
            }

            // =========================================================
            // 7. شريط التنقل السفلي: قائمة المراجعين + الإعدادات
            // =========================================================
            ClinicBottomNavBar(
                activeScreen = AppScreen.QUEUE_LIST,
                onQueueClick = { /* Already here */ },
                onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
            )
        }

        // =========================================================
        // زر الإضافة العائم (+) في الأسفل إلى اليسار
        // =========================================================
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 20.dp, bottom = 78.dp)
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF1E293B))
                .clickable { viewModel.onAddPatientClicked() }
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(16.dp), spotColor = Color(0x55000000))
                .testTag("fab_add_patient"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة مراجع",
                tint = Color.White,
                modifier = Modifier.size(28.dp)
            )
        }
    }

    // =========================================================
    // النوافذ المنبثقة (إضافة، طباعة، TV، وتصفير)
    // =========================================================
    if (showAddDialog) {
        AddPatientDialog(
            nextQueueNumber = nextNumber,
            initialAutoPrint = settings.autoPrintOnAdd,
            onConfirm = { name, note, shouldPrint ->
                viewModel.onConfirmAddPatient(name, note, shouldPrint)
            },
            onDismiss = { viewModel.onDismissAddPatientDialog() }
        )
    }

    if (previewPatient != null) {
        TicketPreviewDialog(
            patient = previewPatient!!,
            settings = settings,
            onPrintClick = { viewModel.onPrintPreviewTicket() },
            onDismiss = { viewModel.onDismissTicketPreview() }
        )
    }

    if (showTvDialog) {
        TvDisplayDialog(
            isRunning = isTvServerRunning,
            serverUrl = tvServerUrl,
            isHotspotActive = isHotspotActive,
            hotspotSsid = hotspotSsid,
            hotspotPassword = hotspotPassword,
            hotspotStatusMessage = hotspotStatusMessage,
            isHotspotLoading = isHotspotLoading,
            isTvAudioOnly = isTvAudioOnly,
            onToggleServer = { viewModel.onToggleTvServer(it) },
            onToggleHotspot = { viewModel.onToggleLocalHotspot(it) },
            onToggleTvAudioOnly = { viewModel.onToggleTvAudioOnly(it) },
            onRefreshIp = { viewModel.onRefreshTvIp() },
            onDismiss = { viewModel.onDismissTvDialog() }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.onDismissResetDialog() },
            modifier = Modifier.testTag("delete_all_confirm_dialog"),
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFFEF2F2)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = "حذف جميع المراجعين",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف جميع المراجعين من قائمة الدور؟ سيتم ترحيل بيانات الجلسة الحالية تلقائياً إلى صفحة التقارير، وتفريغ القائمة للبدء من جديد.",
                    fontSize = 14.sp,
                    color = Color(0xFF475569),
                    lineHeight = 22.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.onConfirmResetQueue() },
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("confirm_delete_all_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(
                        text = "تأكيد حذف الجميع",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.onDismissResetDialog() },
                    modifier = Modifier.height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Text(
                        text = "إلغاء",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF475569)
                    )
                }
            }
        )
    }

    patientToDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientToDelete = null },
            title = {
                Text(
                    text = "حذف المراجع",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = NavyDark
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف المراجع رقم ${patient.formattedNumber}${if (patient.name.isNotBlank()) " (${patient.name})" else ""} من القائمة؟",
                    fontSize = 14.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeletePatient(patient)
                        patientToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "حذف", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { patientToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "إلغاء", color = NavyDark, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

/**
 * الشريط العلوي المنظم وفق أعلى معايير التصميم المؤسسي:
 * - اليمين: اسم العيادة واسم الطبيب
 * - اليسار: زر "حذف جميع المراجعين" الأنيق والواضح بتدرج ناعم يحمي من الأخطاء
 * - الصف السفلي: مؤشرات الأجهزة المتصلة (شاشة متصلة / غير متصلة، وطابعة متصلة / غير متصلة)
 */
@Composable
private fun TopClinicHeader(
    clinicName: String,
    doctorName: String,
    isTvConnected: Boolean,
    isPrinterConnected: Boolean,
    onDeleteAllClick: () -> Unit,
    onTvClick: () -> Unit,
    onPrinterClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // الصف الأول: اسم العيادة والطبيب باليمين، وزر حذف جميع المراجعين باليسار
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f, fill = false),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = clinicName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = doctorName,
                        fontSize = 12.5.sp,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // زر حذف جميع المراجعين المرتب والأنيق
                Surface(
                    onClick = onDeleteAllClick,
                    shape = RoundedCornerShape(9.dp),
                    color = Color(0xFFFEF2F2),
                    border = BorderStroke(1.dp, Color(0xFFFECACA)),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("delete_all_patients_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف جميع المراجعين",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "حذف جميع المراجعين",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // الصف الثاني: شريط حالة الأجهزة المتصلة (شاشة TV، والطابعة الحرارية)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // مؤشر شاشة متصلة أو غير متصلة
                DeviceStatusChip(
                    label = if (isTvConnected) "شاشة متصلة" else "شاشة غير متصلة",
                    icon = Icons.Default.Tv,
                    isConnected = isTvConnected,
                    onClick = onTvClick,
                    modifier = Modifier.weight(1f),
                    testTag = "tv_status_chip"
                )

                // مؤشر طابعة متصلة أو غير متصلة
                DeviceStatusChip(
                    label = if (isPrinterConnected) "طابعة متصلة" else "طابعة غير متصلة",
                    icon = Icons.Default.Print,
                    isConnected = isPrinterConnected,
                    onClick = onPrinterClick,
                    modifier = Modifier.weight(1f),
                    testTag = "printer_status_chip"
                )
            }
        }
    }
}

/**
 * كبسولة عرض حالة الأجهزة (شاشة / طابعة) بتصميم راقٍ متناسق وعالي الدقة
 */
@Composable
private fun DeviceStatusChip(
    label: String,
    icon: ImageVector,
    isConnected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val activeBg = Color(0xFFF0FDF4)
    val activeBorder = Color(0xFFBBF7D0)
    val activeText = Color(0xFF166534)
    val activeDot = Color(0xFF22C55E)
    val activeIcon = Color(0xFF16A34A)

    val inactiveBg = Color(0xFFF8FAFC)
    val inactiveBorder = Color(0xFFE2E8F0)
    val inactiveText = Color(0xFF64748B)
    val inactiveDot = Color(0xFF94A3B8)
    val inactiveIcon = Color(0xFF64748B)

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(9.dp),
        color = if (isConnected) activeBg else inactiveBg,
        border = BorderStroke(1.dp, if (isConnected) activeBorder else inactiveBorder),
        modifier = modifier
            .height(36.dp)
            .then(if (testTag.isNotBlank()) Modifier.testTag(testTag) else Modifier)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // أيقونة الجهاز والنص
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isConnected) activeIcon else inactiveIcon,
                    modifier = Modifier.size(17.dp)
                )
                Text(
                    text = label,
                    fontSize = 12.sp,
                    fontWeight = if (isConnected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isConnected) activeText else inactiveText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // مؤشر نقطة الحالة الحية (أخضر حي عند الاتصال / رمادي عند عدم الاتصال)
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (isConnected) activeDot else inactiveDot)
            )
        }
    }
}

/**
 * بطاقة جلسة العيادة وحالة الاستعداد مع زر "إبدأ" / "إيقاف مؤقت"
 */
@Composable
private fun QueueSessionControlCard(
    isQueueStarted: Boolean,
    onStartClick: () -> Unit,
    onPauseClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(18.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // بيانات الحالة على اليمين (Start في RTL)
            Column(
                horizontalAlignment = Alignment.Start,
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isQueueStarted) "الجلسة نشطة • بث الشاشة قيد العمل" else "العيادة في وضع الاستعداد",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(if (isQueueStarted) Color(0xFF22C55E) else Color(0xFF94A3B8))
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isQueueStarted) "شاشة TV تبث الأرقام والنداء الصوتي مباشرة" else "اضغط ابدأ لبث عرض الأرقام واستدعاء المراجعين",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // زر ابدأ / إيقاف مؤقت على اليسار (End في RTL)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isQueueStarted) Color(0xFFFEF2F2) else Color(0xFF22C55E))
                    .border(
                        if (isQueueStarted) 1.dp else 0.dp,
                        if (isQueueStarted) Color(0xFFFECACA) else Color.Transparent,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable {
                        if (isQueueStarted) onPauseClick() else onStartClick()
                    }
                    .shadow(
                        elevation = if (isQueueStarted) 0.dp else 4.dp,
                        shape = RoundedCornerShape(12.dp),
                        spotColor = Color(0x4022C55E)
                    )
                    .padding(horizontal = 22.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isQueueStarted) "إيقاف مؤقت" else "إبدأ",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isQueueStarted) Color(0xFFDC2626) else Color.White
                )
            }
        }
    }
}

/**
 * كبسولة الفلترة الأفقية المطابقة للصورة:
 * - عند التحديد: خلفية كحلية داكنة مع نص أبيض
 * - بدون تحديد: خلفية بيضاء مع إطار رمادي أنيق #CBD5E1
 */
@Composable
private fun QueueFilterPill(
    label: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) Color(0xFF0F172A) else Color.White)
            .border(
                1.dp,
                if (isSelected) Color(0xFF0F172A) else Color(0xFFCBD5E1),
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = label,
                fontSize = 12.5.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFF0F172A)
            )
            Text(
                text = "$count",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color(0xFF0F172A)
            )
        }
    }
}

/**
 * بطاقة المراجع المطابقة للصورة 100%:
 * - بطاقة المراجع النشط (الأولى بالصورة): إطار أزرق سماوي #93C5FD، مربع رقم أزرق صلب، شارة "نشط الآن"
 * - بطاقة المراجع غير النشط (الثانية بالصورة): إطار رمادي خفيف، رقم عادي أسود، نص "تم الاستدعاء"
 * - أزرار العمليات باليسار:
 *    1. ساعة رملية في دائرة ذهبية دافئة (في أقصى اليسار)
 *    2. أيقونة التقويم والتذكرة
 *    3. أيقونة الحذف
 */
@Composable
private fun PatientCardExact(
    patient: Patient,
    isActive: Boolean,
    onCardClick: () -> Unit,
    onHourglassClick: () -> Unit,
    onReceiptClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val isPostponed = patient.isPostponed
    val isCalled = patient.isCalled && !isPostponed

    val cardBorderColor = if (isActive) Color(0xFF93C5FD) else Color(0xFFE2E8F0)
    val cardBorderWidth = if (isActive) 1.5.dp else 1.dp

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(cardBorderWidth, cardBorderColor, RoundedCornerShape(16.dp))
            .clickable { onCardClick() }
            .shadow(
                elevation = if (isActive) 2.dp else 0.dp,
                shape = RoundedCornerShape(16.dp),
                spotColor = Color(0x202563EB)
            )
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // بيانات المراجع ورقم الدور إلى اليمين (Start في RTL)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // صندوق رقم الدور (أزرق صلب للنشط، ورقم أسود عادي لغير النشط كما بالصورة)
                if (isActive) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF2563EB)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = patient.formattedNumber,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .width(46.dp)
                            .height(46.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = patient.formattedNumber,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF0F172A)
                        )
                    }
                }

                // عنوان واسم المراجع وملاحظاته
                Column {
                    Text(
                        text = if (patient.name.isNotBlank()) {
                            "المراجع ${patient.name} (${patient.formattedNumber})"
                        } else {
                            "المراجع رقم ${patient.formattedNumber}"
                        },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    if (patient.note.isNotBlank()) {
                        Text(
                            text = patient.note,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                // شارة الحالة ("نشط الآن" بالأخضر الفاتح، أو نص "تم الاستدعاء" بالرمادي)
                if (isActive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFDCFCE7))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "نشط الآن",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF16A34A)
                        )
                    }
                } else {
                    Text(
                        text = when {
                            isPostponed -> "مؤجل"
                            isCalled -> "تم الاستدعاء"
                            else -> "في الانتظار"
                        },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = when {
                            isPostponed -> Color(0xFFD97706)
                            isCalled -> Color(0xFF64748B)
                            else -> Color(0xFF2563EB)
                        }
                    )
                }
            }

            // أزرار العمليات إلى اليسار (End في RTL)
            // في RTL: الحذف يظهر يمين التقويم، والتقويم يمين الساعة الرملية،
            // وبالتالي تظهر الساعة الرملية في أقصى اليسار تماماً كما في الصورة!
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // 1. أيقونة الحذف
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // 2. أيقونة التذكرة والتقويم
                IconButton(
                    onClick = onReceiptClick,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DateRange,
                        contentDescription = "تذكرة المراجع",
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // 3. زر الساعة الرملية الدائري الذهبي المطابق للصورة تماماً
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFFFDE68A),
                                    Color(0xFFF59E0B),
                                    Color(0xFFD97706)
                                )
                            )
                        )
                        .clickable { onHourglassClick() }
                        .shadow(
                            elevation = 4.dp,
                            shape = CircleShape,
                            spotColor = Color(0x66D97706)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.HourglassTop,
                        contentDescription = "تأجيل أو استعادة المراجع",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
