package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserFirebaseConfig
import com.example.ui.theme.DarkChipBg
import com.example.ui.theme.ElegantGlowGreen
import com.example.ui.theme.ElegantLilacPrimary

@Composable
fun FirebaseConfigCard(
    serverIp: String,
    serverPort: Int,
    isServerActive: Boolean,
    currentConfig: UserFirebaseConfig,
    onSaveConfig: (UserFirebaseConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var isEditMode by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val effectiveIp = if (serverIp.isNotBlank()) serverIp else "192.168.49.1"
    val fullBaseUrl = "http://$effectiveIp:$serverPort"

    // Form states
    var apiKeyInput by remember(currentConfig) { mutableStateOf(currentConfig.apiKey) }
    var authDomainInput by remember(currentConfig) { mutableStateOf(currentConfig.authDomain) }
    var projectIdInput by remember(currentConfig) { mutableStateOf(currentConfig.projectId) }
    var storageBucketInput by remember(currentConfig) { mutableStateOf(currentConfig.storageBucket) }
    var messagingSenderIdInput by remember(currentConfig) { mutableStateOf(currentConfig.messagingSenderId) }
    var appIdInput by remember(currentConfig) { mutableStateOf(currentConfig.appId) }
    var databaseUrlInput by remember(currentConfig) { mutableStateOf(currentConfig.databaseURL) }

    val resolvedApiKey = apiKeyInput.ifBlank { "local-app-api-key-${effectiveIp.replace(".", "")}" }
    val resolvedAuthDomain = authDomainInput.ifBlank { "$effectiveIp:$serverPort" }
    val resolvedProjectId = projectIdInput.ifBlank { "universal-offline-app" }
    val resolvedStorageBucket = storageBucketInput.ifBlank { "$effectiveIp.appspot.local" }
    val resolvedMessagingSenderId = messagingSenderIdInput.ifBlank { "1092837465" }
    val resolvedAppId = appIdInput.ifBlank { "1:1092837465:web:app_${serverPort}" }
    val resolvedDatabaseUrl = databaseUrlInput.ifBlank { fullBaseUrl }

    val firebaseConfigCode = """
const firebaseConfig = {
  apiKey: "$resolvedApiKey",
  authDomain: "$resolvedAuthDomain",
  databaseURL: "$resolvedDatabaseUrl",
  projectId: "$resolvedProjectId",
  storageBucket: "$resolvedStorageBucket",
  messagingSenderId: "$resolvedMessagingSenderId",
  appId: "$resolvedAppId"
};

// تهيئة محرك فايربيس وقواعد البيانات في موقعك
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const rtdb = firebase.database();
    """.trimIndent()

    val scriptIncludeCode = """
<!-- أضف هذا السطر في موقعك لتحميل محرك فايربيس وقاعدة البيانات الشاملة -->
<script src="$fullBaseUrl/firebase.js"></script>

<script>
  $firebaseConfigCode
</script>
    """.trimIndent()

    val reactUsageCode = """
// استخدام شامل لأي موقع (دردشة، متجر، ألعاب، استبيانات، إدارة، طلاب، تفاعل)
import { useEffect, useState } from 'react';

// 1. إضافة أو إرسال أي بيان لأي مستخدم (Realtime Multi-User)
async function sendItem(collectionName, data) {
  return await db.collection(collectionName).add({
    ...data,
    createdAt: Date.now()
  });
}

// 2. مزامنة فورية حية متعددة المستخدمين (Realtime Multi-User onSnapshot)
// تظهر أي إضافة أو تعديل من أي جهاز فوراً لكل المستخدمين المتصلين!
function useLiveCollection(collectionName) {
  const [items, setItems] = useState([]);
  useEffect(() => {
    return db.collection(collectionName).onSnapshot(snapshot => {
      const list = [];
      snapshot.forEach(doc => list.push({ id: doc.id, ...doc.data() }));
      setItems(list);
    });
  }, [collectionName]);
  return items;
}
    """.trimIndent()

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .testTag("firebase_config_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = null,
                        tint = ElegantLilacPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "محرك Firebase ومزامنة المستخدمين الحية",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (currentConfig.projectId.isNotBlank()) "مشروع مخصص: ${currentConfig.projectId} • مزامنة فورية متعددة" else "دعم شامل لجميع المواقع • مزامنة فورية بين الأجهزة",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = { expanded = !expanded },
                    modifier = Modifier.testTag("toggle_firebase_config_button")
                ) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "عرض بيانات الربط",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 14.dp)) {

                    // Mode Switch: View Code vs Edit Custom Config
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TabRow(
                            selectedTabIndex = selectedTab,
                            containerColor = DarkChipBg,
                            contentColor = ElegantLilacPrimary,
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Tab(
                                selected = selectedTab == 0 && !isEditMode,
                                onClick = { selectedTab = 0; isEditMode = false },
                                text = { Text("الكود المولد", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) }
                            )
                            Tab(
                                selected = selectedTab == 1 && !isEditMode,
                                onClick = { selectedTab = 1; isEditMode = false },
                                text = { Text("HTML Script", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) }
                            )
                            Tab(
                                selected = selectedTab == 2 && !isEditMode,
                                onClick = { selectedTab = 2; isEditMode = false },
                                text = { Text("React / JS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)) }
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        FilledTonalIconButton(
                            onClick = { isEditMode = !isEditMode },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = if (isEditMode) ElegantLilacPrimary else DarkChipBg
                            ),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = if (isEditMode) Icons.Default.Check else Icons.Default.Edit,
                                contentDescription = "تعديل بيانات Firebase",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isEditMode) {
                        // Edit Custom Firebase Configuration Form
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkChipBg, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "📝 تخصيص بيانات Firebase لأي موقع:",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "سيتم حفظ هذه الإعدادات وحقنها تلقائياً لجميع الأجهزة والمستخدمين المتصلين.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = apiKeyInput,
                                onValueChange = { apiKeyInput = it },
                                label = { Text("apiKey") },
                                placeholder = { Text("مثال: AIzaSyBJaO_j_Q...") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            OutlinedTextField(
                                value = projectIdInput,
                                onValueChange = { projectIdInput = it },
                                label = { Text("projectId") },
                                placeholder = { Text("مثال: my-universal-app") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            OutlinedTextField(
                                value = authDomainInput,
                                onValueChange = { authDomainInput = it },
                                label = { Text("authDomain") },
                                placeholder = { Text("مثال: my-app.firebaseapp.com") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            OutlinedTextField(
                                value = storageBucketInput,
                                onValueChange = { storageBucketInput = it },
                                label = { Text("storageBucket") },
                                placeholder = { Text("مثال: my-app.firebasestorage.app") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            OutlinedTextField(
                                value = messagingSenderIdInput,
                                onValueChange = { messagingSenderIdInput = it },
                                label = { Text("messagingSenderId") },
                                placeholder = { Text("مثال: 894664321700") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            OutlinedTextField(
                                value = appIdInput,
                                onValueChange = { appIdInput = it },
                                label = { Text("appId") },
                                placeholder = { Text("مثال: 1:894664321700:web:f4d1b59a...") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = {
                                        apiKeyInput = ""
                                        authDomainInput = ""
                                        projectIdInput = ""
                                        storageBucketInput = ""
                                        messagingSenderIdInput = ""
                                        appIdInput = ""
                                        databaseUrlInput = ""
                                        onSaveConfig(UserFirebaseConfig())
                                        Toast.makeText(context, "تمت استعادة الإعدادات الافتراضية", Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Text("استعادة الافتراضي")
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Button(
                                    onClick = {
                                        val newConfig = UserFirebaseConfig(
                                            apiKey = apiKeyInput.trim(),
                                            authDomain = authDomainInput.trim(),
                                            projectId = projectIdInput.trim(),
                                            storageBucket = storageBucketInput.trim(),
                                            messagingSenderId = messagingSenderIdInput.trim(),
                                            appId = appIdInput.trim(),
                                            databaseURL = databaseUrlInput.trim()
                                        )
                                        onSaveConfig(newConfig)
                                        isEditMode = false
                                        Toast.makeText(context, "تم حفظ بيانات Firebase بنجاح!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ElegantLilacPrimary)
                                ) {
                                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("حفظ وتطبيق")
                                }
                            }
                        }
                    } else {
                        // Code Display Box
                        val codeToDisplay = when (selectedTab) {
                            0 -> firebaseConfigCode
                            1 -> scriptIncludeCode
                            else -> reactUsageCode
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkChipBg,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (selectedTab == 0) "إعدادات الربط المحقونة:" else if (selectedTab == 1) "تضمين المكتبة والإعداد:" else "أمثلة الاستدعاء في React لأي موقع:",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Button(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Firebase Config", codeToDisplay)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "تم نسخ الكود للحافظة بنجاح!", Toast.LENGTH_SHORT).show()
                                        },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = ElegantLilacPrimary),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "نسخ الكود",
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                ) {
                                    Text(
                                        text = codeToDisplay,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            lineHeight = 16.sp
                                        ),
                                        color = ElegantGlowGreen
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "💡 يدعم أي موقع ويب (دردشة، متجر، استبيان، منصة تعليمية، إلخ). أي تعديل يقوم به أي مستخدم ينعكس لحظياً على شاشات باقي المستخدمين المتصلين بنقطة الاتصال عبر تقنية SSE المباشرة.",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
