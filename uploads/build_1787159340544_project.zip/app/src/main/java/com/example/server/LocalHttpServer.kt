package com.example.server

import com.example.data.local.AppDatabase
import com.example.data.local.SharedRecordEntity
import com.example.model.HostedSite
import com.example.model.ServerLog
import com.example.model.UserFirebaseConfig
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.URLDecoder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Enterprise-grade Local Web & Database Server.
 * Solves ERR_EMPTY_RESPONSE by implementing full HTTP/1.1 response streaming,
 * proper socket shutdown flushing, and fallback routes.
 */
class LocalHttpServer(
    private val port: Int = 8080,
    private val ipProvider: () -> String = { "192.168.49.1" },
    private val webRootDirProvider: () -> File,
    private val siteMetaProvider: () -> HostedSite,
    private val firebaseConfigProvider: () -> UserFirebaseConfig = { UserFirebaseConfig() },
    private val database: AppDatabase,
    private val onLog: (ServerLog) -> Unit
) {
    private var primaryServerSocket: ServerSocket? = null
    private var port80ServerSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val threadPool = Executors.newCachedThreadPool()

    // Real-Time SSE Active Client Subscribers
    private val sseClients = CopyOnWriteArrayList<OutputStream>()

    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)

        // 1. Start Configured Primary Port (e.g. 8080)
        try {
            primaryServerSocket = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(port))
            }
            threadPool.execute {
                listenOnSocket(primaryServerSocket, port)
            }
            onLog(
                ServerLog(
                    clientIp = ipProvider(),
                    requestPath = "خادم الويب الشامل يعمل وجاهز لاستقبال الطلبات على المنفذ [$port]",
                    statusCode = 200,
                    isVideoChunk = false
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            onLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "خطأ في تشغيل المنفذ $port: ${e.message}",
                    statusCode = 500,
                    isVideoChunk = false
                )
            )
        }

        // 2. Start Standard HTTP Port 80 if allowed
        if (port != 80) {
            try {
                port80ServerSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(80))
                }
                threadPool.execute {
                    listenOnSocket(port80ServerSocket, 80)
                }
            } catch (e: Exception) {}
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            primaryServerSocket?.close()
        } catch (e: Exception) {}
        try {
            port80ServerSocket?.close()
        } catch (e: Exception) {}
        primaryServerSocket = null
        port80ServerSocket = null
        sseClients.clear()
    }

    fun isServerRunning(): Boolean = isRunning.get()

    private fun listenOnSocket(socketServer: ServerSocket?, currentPort: Int) {
        while (isRunning.get()) {
            try {
                val socket = socketServer?.accept() ?: break
                threadPool.execute {
                    handleClient(socket, currentPort)
                }
            } catch (e: SocketException) {
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun handleClient(socket: Socket, currentPort: Int) {
        val clientIp = socket.inetAddress?.hostAddress ?: "unknown"
        var isSseStream = false
        try {
            socket.soTimeout = 10000
            socket.tcpNoDelay = true

            val rawInput = socket.getInputStream()
            val rawOutput = socket.getOutputStream()

            // Read the full HTTP header block safely using byte parsing
            val (headerText, bodyStream) = readHttpHeaderBlock(rawInput)
            if (headerText.isBlank()) {
                // If Chrome connected without sending data yet, write default response and flush
                serveDynamicWelcomePortal(rawOutput, clientIp, "/")
                rawOutput.flush()
                return
            }

            val lines = headerText.lines().filter { it.isNotBlank() }
            val requestLine = lines.firstOrNull() ?: ""
            val parts = requestLine.trim().split("\\s+".toRegex())
            val method = if (parts.isNotEmpty()) parts[0].uppercase() else "GET"
            val rawPath = if (parts.size >= 2) parts[1] else "/"
            val path = try {
                URLDecoder.decode(rawPath.substringBefore("?"), "UTF-8")
            } catch (e: Exception) {
                rawPath.substringBefore("?")
            }
            val queryString = rawPath.substringAfter("?", "")

            val headers = mutableMapOf<String, String>()
            var contentLength = 0
            for (i in 1 until lines.size) {
                val line = lines[i]
                val colon = line.indexOf(':')
                if (colon != -1) {
                    val k = line.substring(0, colon).trim().lowercase()
                    val v = line.substring(colon + 1).trim()
                    headers[k] = v
                    if (k == "content-length") {
                        contentLength = v.toIntOrNull() ?: 0
                    }
                }
            }

            // Read body if present
            var body = ""
            if (contentLength in 1..10485760 && bodyStream != null) {
                val bodyBytes = ByteArray(contentLength)
                var totalRead = 0
                while (totalRead < contentLength) {
                    val read = bodyStream.read(bodyBytes, totalRead, contentLength - totalRead)
                    if (read == -1) break
                    totalRead += read
                }
                body = String(bodyBytes, 0, totalRead, Charsets.UTF_8)
            }

            val host = headers["host"] ?: ipProvider()
            val userAgent = headers["user-agent"] ?: ""

            // Handle CORS Pre-flight Options for 100% of requests
            if (method == "OPTIONS") {
                sendCorsOk(rawOutput)
                rawOutput.flush()
                return
            }

            when {
                // 1. Firebase JS SDK / Firestore SDK Files
                isFirebaseScriptPath(path) -> {
                    serveFirebaseSdkScript(rawOutput)
                }

                // 2. Realtime SSE Stream (Firestore onSnapshot & Realtime DB on('value'))
                path == "/api/live" || path == "/api/events" || path == "/api/stream" || path == "/api/subscribe" || path.endsWith(".sse") -> {
                    isSseStream = true
                    socket.soTimeout = 0
                    handleRealtimeSseConnection(rawOutput, clientIp)
                }

                // 3. Captive Network Probes (Apple, Android, Windows)
                isAppleProbe(path, host, userAgent) -> {
                    serveApplePortal(rawOutput, clientIp, path)
                }
                isAndroidProbe(path, host) -> {
                    serveAndroidPortalProbe(rawOutput, clientIp, path, currentPort)
                }
                isWindowsOrFirefoxProbe(path, host) -> {
                    serveGenericCaptiveProbe(rawOutput, clientIp, path, currentPort)
                }

                // 4. Favicon
                path == "/favicon.ico" -> {
                    val favFile = File(webRootDirProvider(), "favicon.ico")
                    if (favFile.exists() && favFile.isFile) {
                        serveStaticFile(rawOutput, favFile, clientIp, path)
                    } else {
                        serveFaviconFallback(rawOutput)
                    }
                }

                // 5. Explicit API / CRUD / JSON Endpoints (Must start with /api/, /db/, /data/, or be a non-GET method)
                isExplicitApiRequest(method, path, queryString) -> {
                    handleUniversalDatabaseApi(rawOutput, method, path, queryString, body, clientIp)
                }

                // 6. All Other Requests -> Serve Static Website & SPA Fallback Route
                else -> {
                    serveWebRoute(rawOutput, clientIp, path)
                }
            }

            rawOutput.flush()
        } catch (e: Exception) {
            // Handled
        } finally {
            if (!isSseStream) {
                try {
                    socket.shutdownOutput()
                } catch (e: Exception) {}
                try {
                    socket.close()
                } catch (e: Exception) {}
            }
        }
    }

    /**
     * Safely reads the HTTP header block up to \r\n\r\n without premature stream truncation.
     */
    private fun readHttpHeaderBlock(inputStream: InputStream): Pair<String, InputStream?> {
        val buffer = ByteArrayOutputStream()
        val window = ByteArray(4)
        var windowPos = 0
        var totalRead = 0

        while (totalRead < 65536) { // Max 64KB for HTTP headers
            val b = inputStream.read()
            if (b == -1) break
            totalRead++
            buffer.write(b)

            window[windowPos % 4] = b.toByte()
            windowPos++

            if (windowPos >= 4) {
                val p0 = window[(windowPos - 4) % 4]
                val p1 = window[(windowPos - 3) % 4]
                val p2 = window[(windowPos - 2) % 4]
                val p3 = window[(windowPos - 1) % 4]
                if (p0 == '\r'.code.toByte() && p1 == '\n'.code.toByte() &&
                    p2 == '\r'.code.toByte() && p3 == '\n'.code.toByte()) {
                    // Reached end of HTTP headers
                    return Pair(buffer.toString("UTF-8"), inputStream)
                }
            }
        }
        return Pair(buffer.toString("UTF-8"), inputStream)
    }

    private fun isExplicitApiRequest(method: String, path: String, queryString: String): Boolean {
        if (method != "GET") return true
        val p = path.lowercase().removePrefix("/")
        return p.startsWith("api/") ||
                p.startsWith("api") ||
                p.startsWith("data/") ||
                p.startsWith("db/") ||
                queryString.contains("collection=")
    }

    private fun isFirebaseScriptPath(path: String): Boolean {
        val p = path.lowercase()
        return p == "/firebase.js" ||
                p == "/firebase-app.js" ||
                p == "/firebase-firestore.js" ||
                p == "/firebase-database.js" ||
                p == "/firebase-auth.js" ||
                p == "/local-db.js" ||
                p == "/firestore.js" ||
                p == "/realtime.js" ||
                p.contains("firebase") && p.endsWith(".js")
    }

    /**
     * Resolves currently active Firebase variables (from User Config or local defaults).
     */
    private fun getResolvedFirebaseConfig(): Map<String, String> {
        val userConfig = firebaseConfigProvider()
        val effectiveIp = ipProvider()

        val resolvedApiKey = userConfig.apiKey.ifBlank { "local-app-api-key-${effectiveIp.replace(".", "")}" }
        val resolvedAuthDomain = userConfig.authDomain.ifBlank { "$effectiveIp:$port" }
        val resolvedProjectId = userConfig.projectId.ifBlank { "universal-offline-app" }
        val resolvedStorageBucket = userConfig.storageBucket.ifBlank { "$effectiveIp.appspot.local" }
        val resolvedMessagingSenderId = userConfig.messagingSenderId.ifBlank { "1092837465" }
        val resolvedAppId = userConfig.appId.ifBlank { "1:1092837465:web:app_$port" }
        val resolvedDatabaseUrl = userConfig.databaseURL.ifBlank { "http://$effectiveIp:$port" }

        return mapOf(
            "apiKey" to resolvedApiKey,
            "authDomain" to resolvedAuthDomain,
            "projectId" to resolvedProjectId,
            "storageBucket" to resolvedStorageBucket,
            "messagingSenderId" to resolvedMessagingSenderId,
            "appId" to resolvedAppId,
            "databaseURL" to resolvedDatabaseUrl
        )
    }

    private fun getFirebaseFullSdkJs(): String {
        val cfg = getResolvedFirebaseConfig()
        val resolvedApiKey = cfg["apiKey"] ?: ""
        val resolvedAuthDomain = cfg["authDomain"] ?: ""
        val resolvedProjectId = cfg["projectId"] ?: ""
        val resolvedStorageBucket = cfg["storageBucket"] ?: ""
        val resolvedMessagingSenderId = cfg["messagingSenderId"] ?: ""
        val resolvedAppId = cfg["appId"] ?: ""
        val resolvedDatabaseUrl = cfg["databaseURL"] ?: ""

        return """
/**
 * Local Firebase & Firestore Full SDK Engine
 * 100% Offline Compatible with Realtime Updates & Local SQLite Persistence
 */
(function(window) {
    if (window.__FIREBASE_OFFLINE_SDK_READY__) return;
    window.__FIREBASE_OFFLINE_SDK_READY__ = true;

    // Injected Dynamic User Firebase Configuration
    window.firebaseConfig = {
      apiKey: "$resolvedApiKey",
      authDomain: "$resolvedAuthDomain",
      projectId: "$resolvedProjectId",
      storageBucket: "$resolvedStorageBucket",
      messagingSenderId: "$resolvedMessagingSenderId",
      appId: "$resolvedAppId",
      databaseURL: "$resolvedDatabaseUrl"
    };

    function generateId() {
        return 'doc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // --- FIRESTORE IMPLEMENTATION ---
    class DocumentSnapshot {
        constructor(id, data, exists = true) {
            this.id = id;
            this._data = data || {};
            this.exists = exists;
        }
        data() {
            return this._data;
        }
        get(field) {
            return this._data[field];
        }
    }

    class QuerySnapshot {
        constructor(docs) {
            this.docs = docs;
            this.size = docs.length;
            this.empty = docs.length === 0;
        }
        forEach(callback) {
            this.docs.forEach(callback);
        }
    }

    class DocumentReference {
        constructor(collectionPath, docId) {
            this.collectionPath = collectionPath;
            this.id = docId || generateId();
            this.path = collectionPath + '/' + this.id;
        }

        async get() {
            try {
                const res = await fetch('/api/' + this.collectionPath + '/' + this.id);
                if (!res.ok) return new DocumentSnapshot(this.id, null, false);
                const json = await res.json();
                const recordData = json.jsonData || json.record?.jsonData || json;
                return new DocumentSnapshot(this.id, recordData, true);
            } catch(e) {
                return new DocumentSnapshot(this.id, null, false);
            }
        }

        async set(data, options = {}) {
            const payload = {
                id: this.id,
                ...data
            };
            const res = await fetch('/api/' + this.collectionPath + '/' + this.id, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            return res.json();
        }

        async update(data) {
            const res = await fetch('/api/' + this.collectionPath + '/' + this.id, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        }

        async delete() {
            const res = await fetch('/api/' + this.collectionPath + '/' + this.id, {
                method: 'DELETE'
            });
            return res.json();
        }

        onSnapshot(callback) {
            this.get().then(callback);
            const evtSource = new EventSource('/api/live');
            evtSource.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    if (!data.collection || data.collection === this.collectionPath) {
                        this.get().then(callback);
                    }
                } catch(e) {}
            };
            return () => evtSource.close();
        }
    }

    class CollectionReference {
        constructor(path) {
            this.path = path;
        }

        doc(id) {
            return new DocumentReference(this.path, id);
        }

        async add(data) {
            const docId = data.id || generateId();
            const docRef = new DocumentReference(this.path, docId);
            await docRef.set(data);
            return docRef;
        }

        async get() {
            try {
                const res = await fetch('/api/' + this.path);
                const json = await res.json();
                const records = json.records || json.data || json.results || [];
                const docs = records.map(r => {
                    let docData = r.jsonData || r;
                    if (typeof docData === 'string') {
                        try { docData = JSON.parse(docData); } catch(e) {}
                    }
                    return new DocumentSnapshot(r.id, docData, true);
                });
                return new QuerySnapshot(docs);
            } catch(e) {
                return new QuerySnapshot([]);
            }
        }

        where(field, op, value) {
            return this;
        }

        orderBy(field, direction = 'asc') {
            return this;
        }

        limit(num) {
            return this;
        }

        onSnapshot(callback) {
            this.get().then(callback);
            const evtSource = new EventSource('/api/live');
            evtSource.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    if (!data.collection || data.collection === this.path || data.collection === 'all') {
                        this.get().then(callback);
                    }
                } catch(e) {}
            };
            return () => evtSource.close();
        }
    }

    class FirestoreInstance {
        collection(path) {
            return new CollectionReference(path);
        }
        doc(path) {
            const parts = path.split('/');
            return new DocumentReference(parts[0], parts[1]);
        }
    }

    // --- REALTIME DATABASE IMPLEMENTATION ---
    class DataSnapshot {
        constructor(key, val) {
            this.key = key;
            this._val = val;
        }
        val() {
            return this._val;
        }
        exists() {
            return this._val !== null && this._val !== undefined;
        }
        forEach(cb) {
            if (Array.isArray(this._val)) {
                this._val.forEach((item, idx) => cb(new DataSnapshot(idx, item)));
            } else if (typeof this._val === 'object' && this._val !== null) {
                Object.keys(this._val).forEach(k => cb(new DataSnapshot(k, this._val[k])));
            }
        }
    }

    class DatabaseReference {
        constructor(path) {
            this.path = (path || '').replace(/^\/|\/$/g, '');
        }

        child(subPath) {
            const newPath = this.path ? this.path + '/' + subPath : subPath;
            return new DatabaseReference(newPath);
        }

        push(data) {
            const newKey = generateId();
            const childRef = this.child(newKey);
            if (data !== undefined) {
                childRef.set(data);
            }
            return childRef;
        }

        async set(data) {
            const res = await fetch('/api/' + (this.path || 'root'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        }

        async update(data) {
            const res = await fetch('/api/' + (this.path || 'root'), {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        }

        async remove() {
            const res = await fetch('/api/' + (this.path || 'root'), {
                method: 'DELETE'
            });
            return res.json();
        }

        async once(eventType = 'value') {
            const res = await fetch('/api/' + (this.path || 'root'));
            const json = await res.json();
            return new DataSnapshot(this.path, json.records || json.data || json);
        }

        on(eventType, callback) {
            this.once(eventType).then(callback);
            const evtSource = new EventSource('/api/live');
            evtSource.onmessage = () => {
                this.once(eventType).then(callback);
            };
            return callback;
        }

        off(eventType, callback) {}
    }

    class DatabaseInstance {
        ref(path) {
            return new DatabaseReference(path);
        }
    }

    // --- AUTHENTICATION ---
    class AuthInstance {
        constructor() {
            this.currentUser = {
                uid: 'user_offline_admin_1',
                email: 'admin@school.local',
                displayName: 'مدير النظام',
                emailVerified: true
            };
        }
        onAuthStateChanged(cb) {
            setTimeout(() => cb(this.currentUser), 0);
            return () => {};
        }
        async signInWithEmailAndPassword(email, password) {
            return { user: this.currentUser };
        }
        async createUserWithEmailAndPassword(email, password) {
            return { user: this.currentUser };
        }
        async signOut() {
            return true;
        }
    }

    // --- FIREBASE ROOT OBJECT ---
    const firebase = {
        apps: [],
        initializeApp: function(config) {
            const app = {
                firestore: () => new FirestoreInstance(),
                database: () => new DatabaseInstance(),
                auth: () => new AuthInstance()
            };
            firebase.apps.push(app);
            return app;
        },
        firestore: function() {
            return new FirestoreInstance();
        },
        database: function() {
            return new DatabaseInstance();
        },
        auth: function() {
            return new AuthInstance();
        }
    };

    // Global Bindings
    window.firebase = firebase;
    window.firestore = firebase.firestore();
    window.db = firebase.firestore();
    window.localDB = firebase.firestore();
    window.realtimeDB = firebase.database();

    console.log("🔥 Universal Firebase & Firestore Engine is Fully Loaded & Ready!");
})(window);
        """.trimIndent()
    }

    private fun serveFirebaseSdkScript(output: OutputStream) {
        val jsCode = getFirebaseFullSdkJs()
        val bytes = jsCode.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: application/javascript; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun handleRealtimeSseConnection(output: OutputStream, clientIp: String) {
        val sseHeader = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/event-stream\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: keep-alive\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Headers: Content-Type\r\n\r\n"
        output.write(sseHeader.toByteArray(Charsets.UTF_8))
        output.flush()

        val welcomeEvent = "data: {\"type\": \"connected\", \"status\": \"online\", \"ip\": \"$clientIp\"}\n\n"
        output.write(welcomeEvent.toByteArray(Charsets.UTF_8))
        output.flush()

        sseClients.add(output)

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "⚡ اتصال Firestore / Realtime Live Stream نشط",
                statusCode = 200
            )
        )

        try {
            while (isRunning.get()) {
                Thread.sleep(15000)
                output.write(": ping\n\n".toByteArray(Charsets.UTF_8))
                output.flush()
            }
        } catch (e: Exception) {
            // Client closed stream
        } finally {
            sseClients.remove(output)
        }
    }

    private fun broadcastRealtimeChange(action: String, collection: String, recordId: Long) {
        val payload = JSONObject().apply {
            put("type", "change")
            put("action", action)
            put("collection", collection)
            put("recordId", recordId)
            put("timestamp", System.currentTimeMillis())
        }.toString()

        val eventMessage = "data: $payload\n\n"
        val bytes = eventMessage.toByteArray(Charsets.UTF_8)

        val deadClients = mutableListOf<OutputStream>()
        for (client in sseClients) {
            try {
                client.write(bytes)
                client.flush()
            } catch (e: Exception) {
                deadClients.add(client)
            }
        }
        sseClients.removeAll(deadClients.toSet())
    }

    private fun handleUniversalDatabaseApi(
        output: OutputStream,
        method: String,
        path: String,
        queryString: String,
        body: String,
        clientIp: String
    ) {
        val dao = database.sharedRecordDao()

        val cleanPath = path.removePrefix("/").removeSuffix("/")
        val segments = cleanPath.split("/").filter { it.isNotBlank() }

        val collection = when {
            getQueryParam(queryString, "collection") != null -> getQueryParam(queryString, "collection")!!
            segments.size >= 2 && segments[0] == "api" -> segments[1]
            segments.size >= 2 && segments[0] == "data" -> segments[1]
            segments.size >= 2 && segments[0] == "db" -> segments[1]
            segments.isNotEmpty() -> segments[0]
            else -> "records"
        }

        val pathId = segments.lastOrNull()?.toLongOrNull()

        when (method) {
            "GET" -> {
                runBlocking {
                    if (pathId != null) {
                        val record = dao.getRecordById(pathId)
                        if (record != null) {
                            val json = recordToJsonObject(record).toString(2)
                            sendJsonResponse(output, json, 200)
                        } else {
                            sendJsonResponse(output, "{\"error\": \"Record not found\", \"id\": $pathId}", 404)
                        }
                    } else {
                        val records = if (collection != "general" && collection != "api" && collection != "records") {
                            dao.getRecordsByCollection(collection)
                        } else {
                            dao.getAllRecords()
                        }

                        val jsonArray = JSONArray()
                        records.forEach { record ->
                            jsonArray.put(recordToJsonObject(record))
                        }

                        val responseJson = JSONObject().apply {
                            put("status", "success")
                            put("collection", collection)
                            put("count", records.size)
                            put("records", jsonArray)
                            put("data", jsonArray)
                            put("results", jsonArray)
                            put("items", jsonArray)
                        }.toString(2)

                        sendJsonResponse(output, responseJson, 200)
                    }
                }
            }

            "POST" -> {
                runBlocking {
                    try {
                        var author = "مستخدم ($clientIp)"
                        var content = ""
                        var title: String? = null
                        var targetCollection = collection
                        val rawJson = body.trim()

                        if (rawJson.startsWith("{")) {
                            val obj = JSONObject(rawJson)
                            if (obj.has("author")) author = obj.optString("author", author)
                            if (obj.has("studentName")) author = obj.optString("studentName", author)
                            if (obj.has("teacherName")) author = obj.optString("teacherName", author)
                            if (obj.has("name")) author = obj.optString("name", author)
                            if (obj.has("username")) author = obj.optString("username", author)
                            if (obj.has("title")) title = obj.optString("title")
                            if (obj.has("grade")) title = "درجة: " + obj.optString("grade")
                            if (obj.has("subject")) title = "مادة: " + obj.optString("subject")
                            if (obj.has("content")) content = obj.optString("content")
                            if (obj.has("text")) content = obj.optString("text")
                            if (obj.has("score")) content = "الدرجة: " + obj.optString("score")
                            if (obj.has("status")) content = "الحالة: " + obj.optString("status")
                            if (obj.has("message")) content = obj.optString("message")
                            if (obj.has("collection")) targetCollection = obj.optString("collection", collection)
                            if (content.isBlank() && obj.has("data")) content = obj.get("data").toString()
                            if (content.isBlank()) content = rawJson
                        } else if (rawJson.startsWith("[")) {
                            content = "مجموعة بيانات (${rawJson.length} حرف)"
                        } else {
                            content = rawJson
                        }

                        val record = SharedRecordEntity(
                            collection = targetCollection,
                            author = author,
                            title = title,
                            content = content,
                            jsonData = if (rawJson.isNotBlank()) rawJson else "{}",
                            clientIp = clientIp
                        )

                        val newId = dao.insertRecord(record)
                        val responseJson = JSONObject().apply {
                            put("status", "success")
                            put("id", newId)
                            put("message", "تم حفظ السجل بنجاح")
                            put("record", recordToJsonObject(record.copy(id = newId)))
                            put("data", recordToJsonObject(record.copy(id = newId)))
                        }.toString(2)

                        sendJsonResponse(output, responseJson, 201)
                        broadcastRealtimeChange("insert", targetCollection, newId)
                        onLog(
                            ServerLog(
                                clientIp = clientIp,
                                requestPath = "💾 POST $path (حفظ سجل جديد #$newId في [$targetCollection])",
                                statusCode = 201
                            )
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        val errJson = JSONObject().apply {
                            put("status", "error")
                            put("message", "خطأ في معالجة البيانات: ${e.message}")
                        }.toString()
                        sendJsonResponse(output, errJson, 400)
                    }
                }
            }

            "PUT", "PATCH" -> {
                runBlocking {
                    try {
                        val recordId = pathId
                        if (recordId != null) {
                            val existing = dao.getRecordById(recordId)
                            if (existing != null) {
                                val updated = existing.copy(
                                    content = if (body.isNotBlank()) body else existing.content,
                                    jsonData = if (body.isNotBlank()) body else existing.jsonData
                                )
                                dao.insertRecord(updated)
                                broadcastRealtimeChange("update", existing.collection, recordId)
                                sendJsonResponse(output, "{\"status\": \"updated\", \"id\": $recordId, \"message\": \"تم تحديث البيانات بنجاح\"}", 200)
                                onLog(
                                    ServerLog(
                                        clientIp = clientIp,
                                        requestPath = "✏️ PUT $path (تعديل السجل #$recordId في [${existing.collection}])",
                                        statusCode = 200
                                    )
                                )
                            } else {
                                sendJsonResponse(output, "{\"error\": \"Record not found\"}", 404)
                            }
                        } else {
                            sendJsonResponse(output, "{\"error\": \"Missing record ID\"}", 400)
                        }
                    } catch (e: Exception) {
                        sendJsonResponse(output, "{\"error\": \"${e.message}\"}", 500)
                    }
                }
            }

            "DELETE" -> {
                runBlocking {
                    if (pathId != null) {
                        dao.deleteRecordById(pathId)
                        broadcastRealtimeChange("delete", collection, pathId)
                        val res = JSONObject().apply {
                            put("status", "success")
                            put("message", "تم حذف السجل رقم $pathId بنجاح")
                        }.toString()
                        sendJsonResponse(output, res, 200)
                        onLog(
                            ServerLog(
                                clientIp = clientIp,
                                requestPath = "🗑️ DELETE $path (حذف السجل #$pathId من [$collection])",
                                statusCode = 200
                            )
                        )
                    } else if (collection != "general" && collection != "api" && collection != "records") {
                        dao.deleteRecordsByCollection(collection)
                        broadcastRealtimeChange("clear", collection, 0)
                        sendJsonResponse(output, "{\"status\": \"success\", \"message\": \"تم تفريغ سجلات $collection بالكامل\"}", 200)
                    } else {
                        val res = JSONObject().apply {
                            put("status", "error")
                            put("message", "يرجى تحديد معرف السجل المراد حذفه")
                        }.toString()
                        sendJsonResponse(output, res, 400)
                    }
                }
            }

            else -> {
                sendJsonResponse(output, "{\"error\": \"Method not allowed\"}", 405)
            }
        }
    }

    private fun recordToJsonObject(record: SharedRecordEntity): JSONObject {
        return JSONObject().apply {
            put("id", record.id)
            put("collection", record.collection)
            put("author", record.author)
            put("title", record.title ?: "")
            put("content", record.content)
            put("timestamp", record.timestamp)
            put("clientIp", record.clientIp)
            put("jsonData", try {
                if (record.jsonData.startsWith("{")) JSONObject(record.jsonData)
                else if (record.jsonData.startsWith("[")) JSONArray(record.jsonData)
                else record.jsonData
            } catch (e: Exception) {
                record.jsonData
            })
        }
    }

    private fun getQueryParam(queryString: String, paramName: String): String? {
        if (queryString.isBlank()) return null
        return queryString.split("&").firstOrNull { it.startsWith("$paramName=") }?.substringAfter("=")
    }

    private fun sendJsonResponse(output: OutputStream, json: String, statusCode: Int) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        val statusMsg = when (statusCode) {
            200 -> "200 OK"
            201 -> "201 Created"
            400 -> "400 Bad Request"
            404 -> "404 Not Found"
            405 -> "405 Method Not Allowed"
            else -> "500 Internal Server Error"
        }
        val header = "HTTP/1.1 $statusMsg\r\n" +
                "Content-Type: application/json; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept, Origin\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun sendCorsOk(output: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept, Cache-Control, Origin\r\n" +
                "Access-Control-Max-Age: 86400\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun isAppleProbe(path: String, host: String, userAgent: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        val ua = userAgent.lowercase()
        return h.contains("apple.com") ||
                h.contains("captive.apple.com") ||
                h.contains("airport.us") ||
                h.contains("ibook.info") ||
                h.contains("itools.info") ||
                h.contains("thinkdifferent.us") ||
                h.contains("appleiphonecell.com") ||
                h.contains("icloud.com") ||
                p.contains("hotspot-detect.html") ||
                p.contains("library/test/success.html") ||
                p.contains("canonical.html") ||
                p.contains("bag.xml") ||
                ua.contains("captivenetworksupport") ||
                ua.contains("wispr")
    }

    private fun isAndroidProbe(path: String, host: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        return p.contains("generate_204") ||
                p.contains("gen_204") ||
                p.contains("connectivitycheck") ||
                p.contains("check_network_status") ||
                h.contains("gstatic.com") ||
                h.contains("connectivitycheck.android.com")
    }

    private fun isWindowsOrFirefoxProbe(path: String, host: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        return h.contains("msftconnecttest.com") ||
                h.contains("msftncsi.com") ||
                h.contains("detectportal.firefox.com") ||
                p.contains("ncsi.txt") ||
                p.contains("connecttest.txt") ||
                p.contains("success.txt")
    }

    /**
     * Resolves and serves web routes with robust recursive search & SPA fallback.
     * Ensures any uploaded React, Vite, Next.js, or HTML portal opens reliably.
     */
    private fun serveWebRoute(outputStream: OutputStream, clientIp: String, requestPath: String) {
        val rootDir = webRootDirProvider()
        val cleanPath = requestPath.removePrefix("/").ifEmpty { "index.html" }
        var targetFile = File(rootDir, cleanPath)

        // 1. Direct Directory -> check nested index.html
        if (targetFile.isDirectory) {
            val nestedIndex = File(targetFile, "index.html")
            if (nestedIndex.exists() && nestedIndex.isFile && nestedIndex.length() > 0L) {
                serveStaticFile(outputStream, nestedIndex, clientIp, requestPath)
                return
            }
        }

        // 2. Direct File exists
        if (targetFile.exists() && targetFile.isFile && targetFile.length() > 0L) {
            serveStaticFile(outputStream, targetFile, clientIp, requestPath)
            return
        }

        // 3. Recursive Asset Search (for assets in subfolders e.g. /assets/index-xxx.js or /css/app.css)
        val lastSegment = cleanPath.substringAfterLast("/")
        val hasExtension = lastSegment.contains(".") && !lastSegment.startsWith(".")
        if (hasExtension) {
            val foundAsset = findFileRecursively(rootDir, lastSegment)
            if (foundAsset != null && foundAsset.isFile && foundAsset.length() > 0L) {
                serveStaticFile(outputStream, foundAsset, clientIp, requestPath)
                return
            }
        }

        // 4. Primary index.html at root
        val rootIndex = File(rootDir, "index.html")
        if (rootIndex.exists() && rootIndex.isFile && rootIndex.length() > 0L) {
            serveStaticFile(outputStream, rootIndex, clientIp, requestPath)
            return
        }

        // 5. Deep search for any HTML file if index.html is located in a nested folder (e.g. dist/index.html)
        val anyHtmlFile = findAnyHtmlFile(rootDir)
        if (anyHtmlFile != null && anyHtmlFile.isFile && anyHtmlFile.length() > 0L) {
            serveStaticFile(outputStream, anyHtmlFile, clientIp, requestPath)
            return
        }

        // 6. Dynamic Guaranteed Fallback: Render Welcome Page on-the-fly if files were cleared or empty
        serveDynamicWelcomePortal(outputStream, clientIp, requestPath)
    }

    private fun findFileRecursively(dir: File, targetName: String): File? {
        val files = dir.listFiles() ?: return null
        for (f in files) {
            if (f.isFile && f.name.equals(targetName, ignoreCase = true)) {
                return f
            }
            if (f.isDirectory) {
                val sub = findFileRecursively(f, targetName)
                if (sub != null) return sub
            }
        }
        return null
    }

    private fun findAnyHtmlFile(dir: File): File? {
        val files = dir.listFiles() ?: return null
        for (f in files) {
            if (f.isFile && (f.name.equals("index.html", ignoreCase = true) || f.name.endsWith(".html", ignoreCase = true))) {
                return f
            }
            if (f.isDirectory) {
                val sub = findAnyHtmlFile(f)
                if (sub != null) return sub
            }
        }
        return null
    }

    /**
     * Intercepts and serves static assets (HTML, JS, CSS, Media) with dynamic Firebase Variable Injection.
     */
    private fun serveStaticFile(outputStream: OutputStream, file: File, clientIp: String, requestedPath: String) {
        val mimeType = getMimeType(file.name)
        val isHtml = file.name.endsWith(".html", ignoreCase = true) || file.name.endsWith(".htm", ignoreCase = true)
        val isJs = file.name.endsWith(".js", ignoreCase = true) || file.name.endsWith(".mjs", ignoreCase = true)

        if (isHtml) {
            // 1. In HTML Files: Inject Full Firebase SDK + App Variables in head/body
            val originalHtml = file.readText(Charsets.UTF_8)
            val injectionScript = "<script>\n${getFirebaseFullSdkJs()}\n</script>"
            val finalHtml = when {
                originalHtml.contains("<head>", ignoreCase = true) -> {
                    originalHtml.replaceFirst("(?i)<head>".toRegex(), "<head>\n$injectionScript")
                }
                originalHtml.contains("<body>", ignoreCase = true) -> {
                    originalHtml.replaceFirst("(?i)<body>".toRegex(), "<body>\n$injectionScript")
                }
                else -> {
                    "$injectionScript\n$originalHtml"
                }
            }

            val bytes = finalHtml.toByteArray(Charsets.UTF_8)
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/html; charset=UTF-8\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                    "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                    "Cache-Control: no-cache\r\n" +
                    "Connection: close\r\n\r\n"

            outputStream.write(header.toByteArray(Charsets.UTF_8))
            outputStream.write(bytes)
            outputStream.flush()
        } else if (isJs) {
            // 2. In JavaScript Files: Intercept and Inject Header Variables & Firebase Config Replacements
            val originalJs = file.readText(Charsets.UTF_8)
            val cfg = getResolvedFirebaseConfig()
            val apiKey = cfg["apiKey"] ?: ""
            val authDomain = cfg["authDomain"] ?: ""
            val projectId = cfg["projectId"] ?: ""
            val storageBucket = cfg["storageBucket"] ?: ""
            val messagingSenderId = cfg["messagingSenderId"] ?: ""
            val appId = cfg["appId"] ?: ""
            val databaseURL = cfg["databaseURL"] ?: ""

            val jsPrefix = """
/* Injected Firebase Config Variables by Hotspot Web Server */
if (typeof window !== 'undefined') {
  window.firebaseConfig = window.firebaseConfig || {
    apiKey: "$apiKey",
    authDomain: "$authDomain",
    projectId: "$projectId",
    storageBucket: "$storageBucket",
    messagingSenderId: "$messagingSenderId",
    appId: "$appId",
    databaseURL: "$databaseURL"
  };
}
"""
            var modifiedJs = jsPrefix + "\n" + originalJs

            if (apiKey.isNotBlank() && !apiKey.startsWith("local-")) {
                modifiedJs = modifiedJs.replace(Regex("""apiKey\s*:\s*["'][^"']+["']"""), """apiKey: "$apiKey"""")
            }
            if (projectId.isNotBlank() && projectId != "universal-offline-app") {
                modifiedJs = modifiedJs.replace(Regex("""projectId\s*:\s*["'][^"']+["']"""), """projectId: "$projectId"""")
            }
            if (authDomain.isNotBlank()) {
                modifiedJs = modifiedJs.replace(Regex("""authDomain\s*:\s*["'][^"']+["']"""), """authDomain: "$authDomain"""")
            }
            if (storageBucket.isNotBlank()) {
                modifiedJs = modifiedJs.replace(Regex("""storageBucket\s*:\s*["'][^"']+["']"""), """storageBucket: "$storageBucket"""")
            }
            if (messagingSenderId.isNotBlank()) {
                modifiedJs = modifiedJs.replace(Regex("""messagingSenderId\s*:\s*["'][^"']+["']"""), """messagingSenderId: "$messagingSenderId"""")
            }
            if (appId.isNotBlank()) {
                modifiedJs = modifiedJs.replace(Regex("""appId\s*:\s*["'][^"']+["']"""), """appId: "$appId"""")
            }

            val bytes = modifiedJs.toByteArray(Charsets.UTF_8)
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/javascript; charset=UTF-8\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                    "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                    "Cache-Control: no-cache\r\n" +
                    "Connection: close\r\n\r\n"

            outputStream.write(header.toByteArray(Charsets.UTF_8))
            outputStream.write(bytes)
            outputStream.flush()
        } else {
            // 3. Media & Other Static Files
            val length = file.length()
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: $mimeType\r\n" +
                    "Content-Length: $length\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                    "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                    "Cache-Control: public, max-age=3600\r\n" +
                    "Connection: close\r\n\r\n"

            outputStream.write(header.toByteArray(Charsets.UTF_8))
            FileInputStream(file).use { fis ->
                fis.copyTo(outputStream, bufferSize = 16384)
            }
            outputStream.flush()
        }

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = if (isJs) "⚡ [JS Injected] $requestedPath" else "📄 $requestedPath (${file.name} - ${file.length() / 1024} KB)",
                statusCode = 200,
                isVideoChunk = false
            )
        )
    }

    private fun serveApplePortal(output: OutputStream, clientIp: String, path: String) {
        val rootDir = webRootDirProvider()
        val indexFile = File(rootDir, "index.html")
        if (indexFile.exists() && indexFile.isFile && indexFile.length() > 0L) {
            serveStaticFile(output, indexFile, clientIp, path)
        } else {
            serveDynamicWelcomePortal(output, clientIp, path)
        }
    }

    private fun serveAndroidPortalProbe(output: OutputStream, clientIp: String, path: String, currentPort: Int) {
        val targetUrl = "http://${ipProvider()}:$currentPort"
        val response = "HTTP/1.1 302 Found\r\n" +
                "Location: $targetUrl\r\n" +
                "Content-Type: text/html\r\n" +
                "Content-Length: 0\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun serveGenericCaptiveProbe(output: OutputStream, clientIp: String, path: String, currentPort: Int) {
        val targetUrl = "http://${ipProvider()}:$currentPort"
        val response = "HTTP/1.1 302 Found\r\n" +
                "Location: $targetUrl\r\n" +
                "Content-Type: text/html\r\n" +
                "Content-Length: 0\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun serveFaviconFallback(output: OutputStream) {
        val header = "HTTP/1.1 204 No Content\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    /**
     * Guaranteed Dynamic Welcome Portal fallback so the user NEVER sees ERR_EMPTY_RESPONSE or 404.
     */
    private fun serveDynamicWelcomePortal(outputStream: OutputStream, clientIp: String, requestedPath: String) {
        val ip = ipProvider()
        val html = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>بوابة نقطة الاتصال وقاعدة البيانات الحية</title>
    <script>
      ${getFirebaseFullSdkJs()}
    </script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #0f172a;
            color: #f8fafc;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 24px 16px;
        }
        .card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 20px;
            padding: 28px 20px;
            max-width: 540px;
            width: 100%;
            text-align: center;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            margin-bottom: 20px;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(52, 211, 153, 0.15);
            color: #34d399;
            padding: 6px 14px;
            border-radius: 99px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 16px;
        }
        .badge-dot {
            width: 8px;
            height: 8px;
            background: #34d399;
            border-radius: 50%;
        }
        h1 { font-size: 22px; font-weight: 800; margin-bottom: 8px; color: #ffffff; }
        p { font-size: 14px; color: #94a3b8; line-height: 1.6; margin-bottom: 20px; }
        .db-box {
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 20px;
            text-align: right;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 14px;
        }
        input, textarea {
            background: #1e293b;
            border: 1px solid #475569;
            border-radius: 10px;
            padding: 12px 14px;
            color: #ffffff;
            font-size: 14px;
            outline: none;
            width: 100%;
            font-family: inherit;
        }
        .btn {
            background: #8b5cf6;
            color: #ffffff;
            border: none;
            padding: 12px 20px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 700;
            width: 100%;
            cursor: pointer;
        }
        .records-list {
            margin-top: 14px;
            max-height: 200px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .record-item {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 10px 12px;
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">
            <span class="badge-dot"></span>
            <span>نقطة الاتصال متصلة وقاعدة البيانات نشطة</span>
        </div>
        <h1>🔥 خادم الويب ومحرك Firebase المحلي</h1>
        <p>عنوان الخادم: <strong>http://$ip:$port</strong></p>

        <div class="db-box">
            <h3 style="color:#a78bfa; margin-bottom:10px;">💾 حفظ وإرسال بيانات فورية (Firestore Realtime)</h3>
            <div class="form-group">
                <input type="text" id="itemName" placeholder="أدخل اسماً أو عنواناً...">
                <input type="text" id="itemDetails" placeholder="أدخل تفاصيل أو درجات أو رسالة...">
                <button class="btn" onclick="saveItem()">حفظ ومزامنة لحظية</button>
            </div>
            <div class="records-list" id="recordsList">
                <div style="color:#94a3b8;font-size:12px;text-align:center;">جاري تحميل البيانات الحية...</div>
            </div>
        </div>
    </div>

    <script>
        const db = window.firebase ? window.firebase.firestore() : null;

        async function saveItem() {
            const name = document.getElementById('itemName').value.trim();
            const details = document.getElementById('itemDetails').value.trim();
            if (!name) return alert('يرجى كتابة الاسم أو العنوان');

            if (db) {
                await db.collection('general').add({
                    name: name,
                    details: details,
                    timestamp: Date.now()
                });
                document.getElementById('itemName').value = '';
                document.getElementById('itemDetails').value = '';
            }
        }

        if (db) {
            db.collection('general').onSnapshot(snapshot => {
                const list = document.getElementById('recordsList');
                list.innerHTML = '';
                if (snapshot.empty) {
                    list.innerHTML = '<div style="color:#94a3b8;font-size:12px;text-align:center;">لا توجد سجلات بعد. أضف أول سجل بالأعلى!</div>';
                    return;
                }
                snapshot.forEach(doc => {
                    const data = doc.data();
                    const div = document.createElement('div');
                    div.className = 'record-item';
                    div.innerHTML = '<strong>' + (data.name || data.author || 'سجل') + '</strong>: ' + (data.details || data.content || JSON.stringify(data));
                    list.appendChild(div);
                });
            });
        }
    </script>
</body>
</html>
        """.trimIndent()

        val bytes = html.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"

        outputStream.write(header.toByteArray(Charsets.UTF_8))
        outputStream.write(bytes)
        outputStream.flush()

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "🌐 تقديم الصفحة الترحيبية التفاعلية وقاعدة البيانات ($requestedPath)",
                statusCode = 200,
                isVideoChunk = false
            )
        )
    }

    private fun getMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "html", "htm" -> "text/html; charset=UTF-8"
            "css" -> "text/css; charset=UTF-8"
            "js", "mjs", "jsx", "ts", "tsx" -> "application/javascript; charset=UTF-8"
            "json" -> "application/json; charset=UTF-8"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "svg" -> "image/svg+xml"
            "ico" -> "image/x-icon"
            "webp" -> "image/webp"
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain; charset=UTF-8"
            "xml" -> "application/xml"
            "map" -> "application/json"
            else -> "application/octet-stream"
        }
    }
}
