package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.HostedContentType
import com.example.model.HostedSite
import java.io.*
import java.text.DecimalFormat
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

object WebSiteAssetHelper {

    private const val WEB_ROOT_DIR = "hosted_web_root"

    fun getWebRootDir(context: Context): File {
        val dir = File(context.filesDir, WEB_ROOT_DIR)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun saveWebsiteFromUri(context: Context, uri: Uri): HostedSite {
        var originalFileName = "website.zip"
        var fileSize: Long = 0

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex != -1) originalFileName = cursor.getString(nameIndex) ?: "website.zip"
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: Exception) {
            // Fallback
        }

        val rootDir = getWebRootDir(context)
        // Clean out previous files completely
        rootDir.deleteRecursively()
        rootDir.mkdirs()

        val isZip = originalFileName.endsWith(".zip", ignoreCase = true) ||
                originalFileName.endsWith(".tar", ignoreCase = true) ||
                originalFileName.endsWith(".gz", ignoreCase = true)
        val isHtml = originalFileName.endsWith(".html", ignoreCase = true) ||
                originalFileName.endsWith(".htm", ignoreCase = true)

        var totalFiles = 0
        var totalBytes = 0L

        if (isZip) {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val (count, bytes) = unzipToDirectory(inputStream, rootDir)
                totalFiles = count
                totalBytes = bytes
            }
        } else {
            // Single HTML or standalone file -> save both as original name AND index.html if it's HTML
            val targetFile = File(rootDir, if (isHtml) "index.html" else originalFileName)
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(targetFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            totalFiles = 1
            totalBytes = targetFile.length()
        }

        // Post-processing: Normalize React / Vite / Next export builds
        normalizeWebRoot(rootDir)

        // Safety fallback: If somehow no index.html exists, create default portal
        val rootIndex = File(rootDir, "index.html")
        if (!rootIndex.exists() || rootIndex.length() == 0L) {
            // Check if any other html file exists and copy it as index.html
            val anyHtml = rootDir.walkTopDown().firstOrNull { it.isFile && it.name.endsWith(".html", ignoreCase = true) }
            if (anyHtml != null) {
                anyHtml.copyTo(rootIndex, overwrite = true)
            } else {
                createDefaultWebPortal(rootDir)
            }
        }

        // Recount files
        var verifiedCount = 0
        var verifiedBytes = 0L
        rootDir.walkTopDown().forEach { file ->
            if (file.isFile) {
                verifiedCount++
                verifiedBytes += file.length()
            }
        }

        val detectedType = if (isZip) HostedContentType.STATIC_SITE else HostedContentType.SINGLE_HTML

        return HostedSite(
            uri = uri,
            name = originalFileName,
            contentType = detectedType,
            sizeFormatted = formatFileSize(if (verifiedBytes > 0) verifiedBytes else totalBytes),
            fileCount = if (verifiedCount > 0) verifiedCount else totalFiles,
            isDefaultSample = false
        )
    }

    fun ensureDefaultWebsite(context: Context): HostedSite {
        val rootDir = getWebRootDir(context)
        val indexFile = File(rootDir, "index.html")
        if (!indexFile.exists() || indexFile.length() == 0L) {
            createDefaultWebPortal(rootDir)
        }

        var count = 0
        var totalBytes = 0L
        rootDir.walkTopDown().forEach { file ->
            if (file.isFile) {
                count++
                totalBytes += file.length()
            }
        }

        return HostedSite(
            uri = null,
            name = "بوابة تفاعلية مع قاعدة بيانات حية (Realtime DB)",
            contentType = HostedContentType.STATIC_SITE,
            sizeFormatted = formatFileSize(totalBytes),
            fileCount = count,
            isDefaultSample = true
        )
    }

    private fun createDefaultWebPortal(rootDir: File) {
        rootDir.mkdirs()
        val indexHtml = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>قاعدة بيانات محلية حية (Realtime DB)</title>
    <!-- مكتبة الربط المباشرة مثل Firestore -->
    <script src="/local-db.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #0f172a;
            color: #f8fafc;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 24px 16px;
        }
        .card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 20px;
            padding: 28px 20px;
            max-width: 540px;
            width: 100%;
            text-align: center;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            margin-bottom: 20px;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(52, 211, 153, 0.15);
            color: #34d399;
            padding: 6px 14px;
            border-radius: 99px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 16px;
        }
        .badge-dot {
            width: 8px;
            height: 8px;
            background: #34d399;
            border-radius: 50%;
        }
        h1 {
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 8px;
            color: #ffffff;
        }
        p {
            font-size: 14px;
            color: #94a3b8;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .db-box {
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 20px;
            text-align: right;
        }
        .db-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .db-title {
            font-size: 14px;
            font-weight: 700;
            color: #a78bfa;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 14px;
        }
        input, textarea {
            background: #1e293b;
            border: 1px solid #475569;
            border-radius: 10px;
            padding: 12px 14px;
            color: #ffffff;
            font-size: 14px;
            outline: none;
            width: 100%;
            font-family: inherit;
        }
        input:focus, textarea:focus {
            border-color: #8b5cf6;
        }
        .btn {
            background: #8b5cf6;
            color: #ffffff;
            border: none;
            padding: 12px 20px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 700;
            width: 100%;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn:hover { background: #7c3aed; }
        .records-list {
            margin-top: 14px;
            max-height: 220px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .record-item {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 10px 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .record-info {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .record-author {
            font-size: 13px;
            font-weight: 700;
            color: #e2e8f0;
        }
        .record-content {
            font-size: 12px;
            color: #94a3b8;
        }
        .record-time {
            font-size: 11px;
            color: #64748b;
        }
        .live-dot {
            display: inline-block;
            width: 6px;
            height: 6px;
            background: #10b981;
            border-radius: 50%;
            margin-left: 6px;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { opacity: 0.4; }
            50% { opacity: 1; }
            100% { opacity: 0.4; }
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">
            <span class="badge-dot"></span>
            <span>متصل بالشبكة المحلية السريعة</span>
        </div>
        
        <h1>🔥 خادم الويب الشامل و Firebase المحلي</h1>
        <p>مرحباً بك! هذه البوابة مستضافة محلياً على الهاتف وتعمل بدون إنترنت مع مزامنة لحظية بين جميع الأجهزة المتصلة بنفس شبكة Wi-Fi.</p>

        <!-- صندوق قاعدة البيانات المشتركة -->
        <div class="db-box">
            <div class="db-header">
                <span class="db-title">📊 مزامنة البيانات اللحظية (Real-Time Sync)</span>
                <span style="font-size: 11px; color: #10b981;"><span class="live-dot"></span>مباشر</span>
            </div>

            <div class="form-group">
                <input type="text" id="inputAuthor" placeholder="اسمك أو صفتك (مثال: المعلم أحمد، الطالب علي...)">
                <input type="text" id="inputTitle" placeholder="العنوان أو المادة (اختياري)">
                <textarea id="inputContent" rows="2" placeholder="اكتب ملاحظة، أو درجة، أو بيانات لمزامنتها مع الجميع..."></textarea>
                <button class="btn" onclick="saveRecord()">إرسال ومزامنة للجميع فوراً</button>
            </div>

            <div class="records-list" id="recordsList">
                <div style="color: #64748b; font-size: 12px; text-align: center; padding: 12px;">
                    جاري تحميل البيانات الحية...
                </div>
            </div>
        </div>
    </div>

    <script>
        // Use Global Firestore Instance directly injected by server
        const db = window.firestore || (window.firebase ? window.firebase.firestore() : null);

        async function saveRecord() {
            const author = document.getElementById('inputAuthor').value.trim() || 'مستخدم متصل';
            const title = document.getElementById('inputTitle').value.trim();
            const content = document.getElementById('inputContent').value.trim();

            if (!content) {
                alert('يرجى كتابة نص الملاحظة أو البيانات أولاً.');
                return;
            }

            try {
                if (db) {
                    await db.collection('general').add({
                        author: author,
                        title: title,
                        content: content,
                        timestamp: Date.now()
                    });
                } else {
                    await fetch('/api/records', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ author, title, content })
                    });
                }
                document.getElementById('inputContent').value = '';
            } catch(e) {
                alert('حدث خطأ أثناء الحفظ: ' + e.message);
            }
        }

        // Live Real-Time Data Listener
        if (db) {
            db.collection('general').onSnapshot((snapshot) => {
                const list = document.getElementById('recordsList');
                list.innerHTML = '';

                if (snapshot.empty) {
                    list.innerHTML = '<div style="color: #64748b; font-size: 12px; text-align: center; padding: 12px;">لا توجد سجلات محفوظة بعد. أضف أول سجل بالأعلى!</div>';
                    return;
                }

                snapshot.forEach(doc => {
                    const r = doc.data();
                    const item = document.createElement('div');
                    item.className = 'record-item';
                    
                    const timeStr = r.timestamp ? new Date(r.timestamp).toLocaleTimeString('ar-SA') : '';
                    
                    const authorName = escapeHtml(r.author || 'مستخدم');
                    const titleText = r.title ? (' • ' + escapeHtml(r.title)) : '';
                    const contentText = escapeHtml(r.content || '');

                    item.innerHTML = '<div class="record-info">' +
                        '<span class="record-author">' + authorName + titleText + '</span>' +
                        '<span class="record-content">' + contentText + '</span>' +
                        '</div>' +
                        '<span class="record-time">' + timeStr + '</span>';
                    list.appendChild(item);
                });
            });
        }

        function escapeHtml(text) {
            return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }
    </script>
</body>
</html>
        """.trimIndent()

        File(rootDir, "index.html").writeText(indexHtml, Charsets.UTF_8)
    }

    private fun unzipToDirectory(zipStream: InputStream, targetDir: File): Pair<Int, Long> {
        var fileCount = 0
        var totalBytes = 0L
        val zis = ZipInputStream(BufferedInputStream(zipStream))
        var entry: ZipEntry? = zis.nextEntry

        while (entry != null) {
            val entryName = entry.name
            val cleanName = entryName.replace('\\', '/')
            val file = File(targetDir, cleanName)
            val canonicalDestinationPath = targetDir.canonicalPath
            val canonicalTargetFile = file.canonicalPath

            if (!canonicalTargetFile.startsWith(canonicalDestinationPath + File.separator) && canonicalTargetFile != canonicalDestinationPath) {
                entry = zis.nextEntry
                continue
            }

            if (entry.isDirectory || cleanName.endsWith("/")) {
                file.mkdirs()
            } else {
                file.parentFile?.mkdirs()
                FileOutputStream(file).use { fos ->
                    val buffer = ByteArray(8192)
                    var len: Int
                    while (zis.read(buffer).also { len = it } > 0) {
                        fos.write(buffer, 0, len)
                        totalBytes += len
                    }
                }
                fileCount++
            }
            zis.closeEntry()
            entry = zis.nextEntry
        }
        zis.close()

        return Pair(fileCount, totalBytes)
    }

    private fun normalizeWebRoot(rootDir: File) {
        val directIndex = File(rootDir, "index.html")
        if (directIndex.exists() && directIndex.length() > 0L) return

        val standardBuildFolders = listOf("dist", "build", "out", "public", "web", "www")
        for (folderName in standardBuildFolders) {
            val buildDir = File(rootDir, folderName)
            if (buildDir.exists() && buildDir.isDirectory) {
                val candidate = File(buildDir, "index.html")
                if (candidate.exists() && candidate.length() > 0L) {
                    moveContentsToRoot(buildDir, rootDir)
                    return
                }
            }
        }

        var foundIndexDir: File? = null
        rootDir.walkTopDown().forEach { file ->
            if (foundIndexDir == null && file.isFile && (file.name.equals("index.html", ignoreCase = true) || file.name.endsWith(".html", ignoreCase = true))) {
                foundIndexDir = file.parentFile
            }
        }

        foundIndexDir?.let { subDir ->
            if (subDir.canonicalPath != rootDir.canonicalPath) {
                moveContentsToRoot(subDir, rootDir)
            }
        }
    }

    private fun moveContentsToRoot(sourceDir: File, rootDir: File) {
        val files = sourceDir.listFiles() ?: return
        for (file in files) {
            val dest = File(rootDir, file.name)
            if (file.isDirectory) {
                copyDirectory(file, dest)
            } else {
                file.copyTo(dest, overwrite = true)
            }
        }
    }

    private fun copyDirectory(source: File, target: File) {
        if (!target.exists()) target.mkdirs()
        source.listFiles()?.forEach { file ->
            val dest = File(target, file.name)
            if (file.isDirectory) {
                copyDirectory(file, dest)
            } else {
                file.copyTo(dest, overwrite = true)
            }
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val formatted = DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble()))
        return "$formatted ${units[digitGroups.coerceIn(0, units.size - 1)]}"
    }
}
