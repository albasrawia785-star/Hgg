package com.example.model

data class UserFirebaseConfig(
    val apiKey: String = "",
    val authDomain: String = "",
    val projectId: String = "",
    val storageBucket: String = "",
    val messagingSenderId: String = "",
    val appId: String = "",
    val databaseURL: String = ""
)
