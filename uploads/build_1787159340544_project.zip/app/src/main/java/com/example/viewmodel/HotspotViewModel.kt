package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.SharedRecordEntity
import com.example.hotspot.HotspotManager
import com.example.model.*
import com.example.server.DnsServer
import com.example.server.LocalHttpServer
import com.example.service.HotspotPortalService
import com.example.util.WebSiteAssetHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class HotspotViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context
        get() = getApplication<Application>().applicationContext

    val database = AppDatabase.getDatabase(context)

    private val _hotspotStatus = MutableStateFlow(HotspotStatus.STOPPED)
    val hotspotStatus: StateFlow<HotspotStatus> = _hotspotStatus.asStateFlow()

    private val _hotspotInfo = MutableStateFlow(HotspotInfo())
    val hotspotInfo: StateFlow<HotspotInfo> = _hotspotInfo.asStateFlow()

    private val _hostedSite = MutableStateFlow(HostedSite())
    val hostedSite: StateFlow<HostedSite> = _hostedSite.asStateFlow()

    private val _connectedDevices = MutableStateFlow<List<ConnectedDevice>>(emptyList())
    val connectedDevices: StateFlow<List<ConnectedDevice>> = _connectedDevices.asStateFlow()

    private val _serverLogs = MutableStateFlow<List<ServerLog>>(emptyList())
    val serverLogs: StateFlow<List<ServerLog>> = _serverLogs.asStateFlow()

    val databaseRecords: StateFlow<List<SharedRecordEntity>> = database.sharedRecordDao()
        .getAllRecordsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _customSsid = MutableStateFlow("WebPortal_Wifi")
    val customSsid: StateFlow<String> = _customSsid.asStateFlow()

    private val _customPassword = MutableStateFlow("00000000")
    val customPassword: StateFlow<String> = _customPassword.asStateFlow()

    private val _userFirebaseConfig = MutableStateFlow(loadSavedFirebaseConfig())
    val userFirebaseConfig: StateFlow<UserFirebaseConfig> = _userFirebaseConfig.asStateFlow()

    private val hotspotManager: HotspotManager
    private var httpServer: LocalHttpServer? = null
    private var dnsServer: DnsServer? = null
    private var devicePollingJob: Job? = null

    init {
        // Initialize default interactive website template
        val defaultSite = WebSiteAssetHelper.ensureDefaultWebsite(context)
        _hostedSite.value = defaultSite

        hotspotManager = HotspotManager(context) { status, info ->
            _hotspotStatus.value = status
            _hotspotInfo.value = info
            if (status == HotspotStatus.ACTIVE) {
                startHttpServer(info.port)
                startDevicePolling()
                HotspotPortalService.startService(context, info.ssid, info.serverUrl)
            } else if (status == HotspotStatus.STOPPED || status == HotspotStatus.ERROR) {
                stopHttpServer()
                stopDevicePolling()
                HotspotPortalService.stopService(context)
            }
        }
    }

    fun setCustomSsid(ssid: String) {
        _customSsid.value = ssid
        _hotspotInfo.update { it.copy(ssid = ssid) }
    }

    fun setCustomPassword(password: String) {
        _customPassword.value = password
        val isSecOpen = password.isBlank()
        _hotspotInfo.update {
            it.copy(
                password = if (isSecOpen) null else password,
                isSecurityOpen = isSecOpen
            )
        }
    }

    fun saveAndApplyWifiCredentials(newSsid: String, newPassword: String) {
        _customSsid.value = newSsid.ifBlank { "WebPortal_Wifi" }
        _customPassword.value = newPassword
        val isSecOpen = newPassword.isBlank()
        _hotspotInfo.update {
            it.copy(
                ssid = _customSsid.value,
                password = if (isSecOpen) null else newPassword,
                isSecurityOpen = isSecOpen
            )
        }
        addLog(
            ServerLog(
                clientIp = "127.0.0.1",
                requestPath = "تم حفظ الإعدادات: SSID = ${_customSsid.value} | " +
                        if (isSecOpen) "الأمان: بدون كلمة سر" else "كلمة المرور: $newPassword",
                statusCode = 200
            )
        )
    }

    fun onWebsiteSelected(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val savedSite = WebSiteAssetHelper.saveWebsiteFromUri(context, uri)
                _hostedSite.value = savedSite
                addLog(
                    ServerLog(
                        clientIp = "127.0.0.1",
                        requestPath = "📦 تم تثبيت ونشر الموقع: ${savedSite.name} (${savedSite.sizeFormatted} • ${savedSite.fileCount} ملفات)",
                        statusCode = 200
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
                addLog(
                    ServerLog(
                        clientIp = "127.0.0.1",
                        requestPath = "خطأ في معالجة ملف الموقع: ${e.message}",
                        statusCode = 500
                    )
                )
            }
        }
    }

    fun startHotspotAndServer() {
        val ssid = _customSsid.value.ifBlank { "WebPortal_Wifi" }
        val password = _customPassword.value.ifBlank { "00000000" }
        hotspotManager.startHotspot(ssid, password)
    }

    fun startServerWithSystemHotspot() {
        val ssid = _customSsid.value.ifBlank { "نقطة اتصال الهاتف" }
        val password = _customPassword.value.ifBlank { null }
        val isSecOpen = password.isNullOrEmpty()
        val localIp = hotspotManager.getLocalIpAddress()
        val info = HotspotInfo(
            ssid = ssid,
            password = password,
            isSecurityOpen = isSecOpen,
            ipAddress = localIp,
            port = 8080,
            isTetheringMode = true,
            errorMessage = null
        )
        _hotspotInfo.value = info
        _hotspotStatus.value = HotspotStatus.ACTIVE
        startHttpServer(8080)
        startDevicePolling()
        HotspotPortalService.startService(context, ssid, info.serverUrl)
        addLog(
            ServerLog(
                clientIp = localIp,
                requestPath = "⚡ تم تفعيل خادم الويب على نقطة اتصال الهاتف ($localIp:8080)",
                statusCode = 200
            )
        )
    }

    fun stopHotspotAndServer() {
        hotspotManager.stopHotspot()
        stopHttpServer()
        stopDevicePolling()
    }

    fun openTetheringSettings(activityContext: Context) {
        hotspotManager.openSystemTetheringSettings(activityContext)
    }

    private fun startHttpServer(port: Int) {
        stopHttpServer()
        try {
            httpServer = LocalHttpServer(
                port = port,
                ipProvider = { _hotspotInfo.value.ipAddress },
                webRootDirProvider = { WebSiteAssetHelper.getWebRootDir(context) },
                siteMetaProvider = { _hostedSite.value },
                firebaseConfigProvider = { _userFirebaseConfig.value },
                database = database,
                onLog = { log -> addLog(log) }
            ).apply {
                start()
            }

            // Start DNS Interceptor
            dnsServer = DnsServer(
                ipProvider = { _hotspotInfo.value.ipAddress },
                port = 53,
                onLog = { log -> addLog(log) }
            ).apply {
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopHttpServer() {
        httpServer?.stop()
        httpServer = null
        dnsServer?.stop()
        dnsServer = null
    }

    private fun startDevicePolling() {
        devicePollingJob?.cancel()
        devicePollingJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                val devices = hotspotManager.scanConnectedDevices()
                _connectedDevices.value = devices
                delay(4000)
            }
        }
    }

    private fun stopDevicePolling() {
        devicePollingJob?.cancel()
        devicePollingJob = null
        _connectedDevices.value = emptyList()
    }

    fun refreshDevices() {
        viewModelScope.launch(Dispatchers.IO) {
            val devices = hotspotManager.scanConnectedDevices()
            _connectedDevices.value = devices
        }
    }

    fun deleteDatabaseRecord(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            database.sharedRecordDao().deleteRecordById(id)
            addLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "🗑️ تم حذف السجل رقم #$id من قاعدة البيانات",
                    statusCode = 200
                )
            )
        }
    }

    fun clearAllDatabaseRecords() {
        viewModelScope.launch(Dispatchers.IO) {
            database.sharedRecordDao().clearAllRecords()
            addLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "🧹 تم مسح كافة سجلات قاعدة البيانات المشتركة",
                    statusCode = 200
                )
            )
        }
    }

    private fun addLog(log: ServerLog) {
        _serverLogs.update { current ->
            (listOf(log) + current).take(30)
        }
    }

    fun clearLogs() {
        _serverLogs.value = emptyList()
    }

    fun saveFirebaseConfig(config: UserFirebaseConfig) {
        _userFirebaseConfig.value = config
        val prefs = context.getSharedPreferences("firebase_prefs", Context.MODE_PRIVATE)
        prefs.edit().apply {
            putString("apiKey", config.apiKey)
            putString("authDomain", config.authDomain)
            putString("projectId", config.projectId)
            putString("storageBucket", config.storageBucket)
            putString("messagingSenderId", config.messagingSenderId)
            putString("appId", config.appId)
            putString("databaseURL", config.databaseURL)
            apply()
        }
        addLog(
            ServerLog(
                clientIp = "127.0.0.1",
                requestPath = "🔥 تم حفظ إعدادات Firebase المخصصة بنجاح وتطبيقها على الخادم",
                statusCode = 200
            )
        )
    }

    private fun loadSavedFirebaseConfig(): UserFirebaseConfig {
        val prefs = context.getSharedPreferences("firebase_prefs", Context.MODE_PRIVATE)
        return UserFirebaseConfig(
            apiKey = prefs.getString("apiKey", "") ?: "",
            authDomain = prefs.getString("authDomain", "") ?: "",
            projectId = prefs.getString("projectId", "") ?: "",
            storageBucket = prefs.getString("storageBucket", "") ?: "",
            messagingSenderId = prefs.getString("messagingSenderId", "") ?: "",
            appId = prefs.getString("appId", "") ?: "",
            databaseURL = prefs.getString("databaseURL", "") ?: ""
        )
    }

    override fun onCleared() {
        super.onCleared()
        stopHotspotAndServer()
    }
}
