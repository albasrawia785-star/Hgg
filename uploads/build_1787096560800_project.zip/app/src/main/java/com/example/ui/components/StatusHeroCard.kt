package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HotspotInfo
import com.example.model.HotspotStatus
import com.example.ui.theme.DarkChipBg
import com.example.ui.theme.ElegantGlowGreen
import com.example.ui.theme.ElegantLilacDark
import com.example.ui.theme.ElegantLilacPrimary
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.ErrorRoseDark

@Composable
fun StatusHeroCard(
    status: HotspotStatus,
    info: HotspotInfo,
    connectedDevicesCount: Int = 0,
    onToggleHotspot: () -> Unit,
    onStartSystemTethering: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isActive = status == HotspotStatus.ACTIVE
    val isStarting = status == HotspotStatus.STARTING

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isActive) 1.15f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isActive) ElegantLilacPrimary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline,
                RoundedCornerShape(28.dp)
            )
            .testTag("status_hero_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Live Status Header Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Status Indicator Pill
                Surface(
                    shape = RoundedCornerShape(99.dp),
                    color = when (status) {
                        HotspotStatus.ACTIVE -> ElegantGlowGreen.copy(alpha = 0.15f)
                        HotspotStatus.STARTING -> ElegantLilacPrimary.copy(alpha = 0.15f)
                        HotspotStatus.ERROR -> ErrorRose.copy(alpha = 0.15f)
                        HotspotStatus.STOPPED -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    modifier = Modifier.padding(2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .scale(if (isActive) pulseScale else 1f)
                                .clip(CircleShape)
                                .background(
                                    when (status) {
                                        HotspotStatus.ACTIVE -> ElegantGlowGreen
                                        HotspotStatus.STARTING -> ElegantLilacPrimary
                                        HotspotStatus.ERROR -> ErrorRose
                                        HotspotStatus.STOPPED -> MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (status) {
                                HotspotStatus.ACTIVE -> "حالة البث: نشط"
                                HotspotStatus.STARTING -> "جارٍ تشغيل النقطة..."
                                HotspotStatus.ERROR -> "تعذر التشغيل"
                                HotspotStatus.STOPPED -> "حالة البث: متوقف"
                            },
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = when (status) {
                                    HotspotStatus.ACTIVE -> ElegantGlowGreen
                                    HotspotStatus.STARTING -> ElegantLilacPrimary
                                    HotspotStatus.ERROR -> ErrorRose
                                    HotspotStatus.STOPPED -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        )
                    }
                }

                // Live Connected Devices Badge
                if (isActive) {
                    Surface(
                        shape = RoundedCornerShape(99.dp),
                        color = DarkChipBg,
                        modifier = Modifier.testTag("hero_connected_devices_badge")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Devices,
                                contentDescription = null,
                                tint = if (connectedDevicesCount > 0) ElegantGlowGreen else ElegantLilacPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$connectedDevicesCount أجهزة متصلة",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (connectedDevicesCount > 0) ElegantGlowGreen else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Info Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                // SSID Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = if (isActive) Icons.Default.Wifi else Icons.Default.WifiOff,
                        contentDescription = null,
                        tint = if (isActive) ElegantLilacPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "اسم شبكة Wi-Fi (SSID)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = info.ssid,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = {
                            copyToClipboard(context, "اسم الشبكة", info.ssid)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ اسم الشبكة",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                )

                // Server URL Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "رابط صفحة الفيديو المباشرة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = info.serverUrl,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = ElegantLilacPrimary
                            )
                        )
                    }
                    IconButton(
                        onClick = {
                            copyToClipboard(context, "رابط الفيديو", info.serverUrl)
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ رابط الفيديو",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Security Tag
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (info.isSecurityOpen || info.password.isNullOrEmpty()) {
                            "🔓 الأمان: شبكة مفتوحة بدون كلمة مرور (Open)"
                        } else {
                            "🔒 كلمة مرور Wi-Fi: ${info.password}"
                        },
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                        color = if (info.isSecurityOpen || info.password.isNullOrEmpty()) ElegantLilacPrimary else ElegantGlowGreen
                    )
                }
            }

            // Error message if any
            AnimatedVisibility(visible = !info.errorMessage.isNullOrEmpty()) {
                info.errorMessage?.let { error ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ErrorRose.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    ) {
                        Text(
                            text = error,
                            style = MaterialTheme.typography.bodySmall.copy(color = ErrorRose),
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Large Start/Stop Button
            Button(
                onClick = onToggleHotspot,
                enabled = !isStarting,
                shape = RoundedCornerShape(99.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isActive) ErrorRose else ElegantLilacPrimary,
                    contentColor = if (isActive) ErrorRoseDark else ElegantLilacDark
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("toggle_hotspot_button")
            ) {
                if (isStarting) {
                    CircularProgressIndicator(
                        color = ElegantLilacDark,
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("جارٍ بدء التشغيل...")
                } else {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isActive) "إيقاف تشغيل الخادم والبث" else "تشغيل البث المباشر (خادم + شبكة)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            // Dedicated System Hotspot Broadcast button (Option 2 - works 100% on all Android hardware)
            if (!isActive) {
                Spacer(modifier = Modifier.height(10.dp))
                FilledTonalButton(
                    onClick = onStartSystemTethering,
                    shape = RoundedCornerShape(99.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = DarkChipBg,
                        contentColor = ElegantLilacPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("start_tethering_server_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تشغيل البث مع نقطة اتصال الهاتف (الخيار الثاني)",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "تم نسخ $label إلى الحافظة", Toast.LENGTH_SHORT).show()
}
