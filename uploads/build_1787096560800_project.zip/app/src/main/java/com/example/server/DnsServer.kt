package com.example.server

import com.example.model.ServerLog
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Embedded DNS Interceptor (DNS Server).
 * Intercepts all incoming standard DNS queries (Port 53 UDP)
 * and resolves any requested domain name directly to the local hotspot server IP.
 * This guarantees the Captive Portal dialog triggers instantly across Android, iOS, Windows, Mac, and IoT devices.
 */
class DnsServer(
    private val ipProvider: () -> String = { "192.168.49.1" },
    private val port: Int = 53,
    private val onLog: (ServerLog) -> Unit = {}
) {
    private var datagramSocket: DatagramSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val executor = Executors.newSingleThreadExecutor()

    fun start() {
        if (isRunning.get()) return
        try {
            datagramSocket = DatagramSocket(port)
            isRunning.set(true)
            executor.execute {
                listen()
            }
            onLog(
                ServerLog(
                    clientIp = ipProvider(),
                    requestPath = "⚡ DNS INTERCEPTOR STARTED [Port $port - Catch-All Active]",
                    statusCode = 200,
                    isVideoChunk = false
                )
            )
        } catch (e: Exception) {
            // Port 53 might require root on standard sockets or fallback gracefully without crash
            isRunning.set(false)
            onLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "DNS Server (Port $port): ${e.message ?: "fallback to HTTP Captive interception"}",
                    statusCode = 500,
                    isVideoChunk = false
                )
            )
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            datagramSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        datagramSocket = null
    }

    fun isServerRunning(): Boolean = isRunning.get()

    private fun listen() {
        val buffer = ByteArray(512)
        while (isRunning.get()) {
            try {
                val packet = DatagramPacket(buffer, buffer.size)
                datagramSocket?.receive(packet) ?: break

                val targetIp = ipProvider()
                val responseData = buildDnsResponse(packet.data, packet.length, targetIp)

                if (responseData != null) {
                    val replyPacket = DatagramPacket(
                        responseData,
                        responseData.size,
                        packet.address,
                        packet.port
                    )
                    datagramSocket?.send(replyPacket)
                }
            } catch (e: Exception) {
                if (!isRunning.get()) break
            }
        }
    }

    /**
     * Constructs a valid standard DNS (RFC 1035) response packet resolving the requested query to targetIp.
     */
    private fun buildDnsResponse(request: ByteArray, length: Int, targetIp: String): ByteArray? {
        if (length < 12) return null

        val response = ByteArray(length + 16)
        // Copy Header & Question section
        System.arraycopy(request, 0, response, 0, length)

        // Set Flags: Standard query response, No error, Authoritative
        response[2] = 0x81.toByte()
        response[3] = 0x80.toByte()

        // Set Answer Count (ANCOUNT) = 1
        response[6] = 0x00.toByte()
        response[7] = 0x01.toByte()

        // Answer Section:
        // Name pointer pointing to the query name (0xC00C)
        var offset = length
        response[offset++] = 0xC0.toByte()
        response[offset++] = 0x0C.toByte()

        // Type A (0x0001)
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x01.toByte()

        // Class IN (0x0001)
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x01.toByte()

        // TTL = 60 seconds (0x0000003C)
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x3C.toByte()

        // Data Length (RDLENGTH) = 4 bytes for IPv4
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x04.toByte()

        // IPv4 Address bytes
        val ipParts = targetIp.split(".")
        if (ipParts.size == 4) {
            for (part in ipParts) {
                response[offset++] = (part.toIntOrNull() ?: 0).toByte()
            }
        } else {
            response[offset++] = 192.toByte()
            response[offset++] = 168.toByte()
            response[offset++] = 49.toByte()
            response[offset++] = 1.toByte()
        }

        val result = ByteArray(offset)
        System.arraycopy(response, 0, result, 0, offset)
        return result
    }
}
