package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.HostedContentType
import com.example.model.HostedSite
import java.io.*
import java.text.DecimalFormat
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

object WebSiteAssetHelper {

    private const val WEB_ROOT_DIR = "hosted_web_root"

    fun getWebRootDir(context: Context): File {
        val dir = File(context.filesDir, WEB_ROOT_DIR)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun saveWebsiteFromUri(context: Context, uri: Uri): HostedSite {
        var originalFileName = "website.zip"
        var fileSize: Long = 0

        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex != -1) originalFileName = cursor.getString(nameIndex) ?: "website.zip"
                if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
            }
        }

        val rootDir = getWebRootDir(context)
        // Clear previous files
        rootDir.deleteRecursively()
        rootDir.mkdirs()

        val isZip = originalFileName.endsWith(".zip", ignoreCase = true)
        val isHtml = originalFileName.endsWith(".html", ignoreCase = true) || originalFileName.endsWith(".htm", ignoreCase = true)

        var totalFiles = 0
        var totalBytes = 0L

        if (isZip) {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val (count, bytes) = unzipToDirectory(inputStream, rootDir)
                totalFiles = count
                totalBytes = bytes
            }
        } else {
            // Single HTML or file
            val targetFile = File(rootDir, if (isHtml) "index.html" else originalFileName)
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(targetFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            totalFiles = 1
            totalBytes = targetFile.length()
        }

        val detectedType = if (isZip) HostedContentType.STATIC_SITE else HostedContentType.SINGLE_HTML

        return HostedSite(
            uri = uri,
            name = originalFileName,
            contentType = detectedType,
            sizeFormatted = formatFileSize(totalBytes),
            fileCount = totalFiles,
            isDefaultSample = false
        )
    }

    fun ensureDefaultWebsite(context: Context): HostedSite {
        val rootDir = getWebRootDir(context)
        val indexFile = File(rootDir, "index.html")
        if (!indexFile.exists() || indexFile.length() == 0L) {
            createDefaultWebPortal(rootDir)
        }

        var count = 0
        var totalBytes = 0L
        rootDir.walkTopDown().forEach { file ->
            if (file.isFile) {
                count++
                totalBytes += file.length()
            }
        }

        return HostedSite(
            uri = null,
            name = "موقع ويب تفاعلي مع قاعدة بيانات مشتركة (Live DB Ready)",
            contentType = HostedContentType.STATIC_SITE,
            sizeFormatted = formatFileSize(totalBytes),
            fileCount = count,
            isDefaultSample = true
        )
    }

    private fun createDefaultWebPortal(rootDir: File) {
        rootDir.mkdirs()
        val indexHtml = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>بوابة الويب وقاعدة البيانات المشتركة</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #0b0f19 0%, #171e2e 100%);
            color: #f3f4f6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 24px 16px;
        }
        .card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(16px);
            border-radius: 24px;
            padding: 28px 20px;
            max-width: 540px;
            width: 100%;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            margin-bottom: 20px;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(52, 211, 153, 0.15);
            color: #34d399;
            padding: 6px 14px;
            border-radius: 99px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 16px;
        }
        .badge-dot {
            width: 8px;
            height: 8px;
            background: #34d399;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.95); opacity: 0.8; }
            50% { transform: scale(1.3); opacity: 1; }
            100% { transform: scale(0.95); opacity: 0.8; }
        }
        h1 {
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 10px;
            color: #ffffff;
        }
        p {
            font-size: 14px;
            color: #9ca3af;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .db-box {
            background: rgba(0, 0, 0, 0.35);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 20px;
            text-align: right;
        }
        .db-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .db-title {
            font-size: 15px;
            font-weight: 700;
            color: #c4b5fd;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 14px;
        }
        input, textarea {
            background: rgba(255, 255, 255, 0.07);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            padding: 12px 14px;
            color: #ffffff;
            font-size: 14px;
            outline: none;
            width: 100%;
            font-family: inherit;
        }
        input:focus, textarea:focus {
            border-color: #a78bfa;
            background: rgba(255, 255, 255, 0.1);
        }
        .btn {
            background: #8b5cf6;
            color: #ffffff;
            border: none;
            padding: 12px 20px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 700;
            width: 100%;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn:hover { background: #7c3aed; }
        .btn:active { transform: scale(0.98); }
        .records-list {
            margin-top: 14px;
            max-height: 220px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .record-item {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 10px;
            padding: 10px 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .record-info {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .record-author {
            font-size: 13px;
            font-weight: 700;
            color: #e5e7eb;
        }
        .record-text {
            font-size: 12px;
            color: #9ca3af;
        }
        .record-time {
            font-size: 10px;
            color: #6b7280;
        }
        .footer {
            margin-top: 16px;
            font-size: 12px;
            color: #6b7280;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">
            <span class="badge-dot"></span>
            قاعدة البيانات المشتركة نشطة
        </div>
        <h1>شبكة الويب والمشاركة المحلية 🌐</h1>
        <p>البيانات التي تكتبها هنا تُحفظ مباشرة في قاعدة بيانات الهاتف الأساسي ويراها جميع المتصلين بالشبكة فوراً.</p>
        
        <div class="db-box">
            <div class="db-header">
                <span class="db-title">إرسال منشور أو رسالة مشتركة:</span>
                <span id="recordsCount" style="font-size: 12px; color: #a78bfa;">0 سجلات</span>
            </div>
            <div class="form-group">
                <input type="text" id="authorInput" placeholder="اسمك أو اسم جهازك (مثال: أحمد)" />
                <textarea id="contentInput" rows="2" placeholder="اكتب نصاً، طلباً، أو رسالة ليراها الجميع..."></textarea>
                <button class="btn" onclick="saveRecord()">حفظ في قاعدة بيانات الهاتف 💾</button>
            </div>

            <div class="db-title" style="margin-top: 16px;">السجلات المشتركة في الهاتف:</div>
            <div class="records-list" id="recordsList">
                <div style="text-align: center; color: #6b7280; font-size: 12px; padding: 12px;">جاري تحميل البيانات المشتركة...</div>
            </div>
        </div>

        <div class="footer">Local SQLite & REST API Server • يعمل 100% بدون إنترنت</div>
    </div>

    <script>
        async function fetchRecords() {
            try {
                const res = await fetch('/api/records');
                const data = await res.json();
                if (data.records) {
                    renderRecords(data.records);
                }
            } catch (e) {
                console.error("Fetch records failed:", e);
            }
        }

        function renderRecords(records) {
            const list = document.getElementById('recordsList');
            const countEl = document.getElementById('recordsCount');
            countEl.innerText = records.length + ' سجل';

            if (records.length === 0) {
                list.innerHTML = '<div style="text-align: center; color: #6b7280; font-size: 12px; padding: 12px;">لا توجد سجلات بعد. كن أول من يضيف!</div>';
                return;
            }

            list.innerHTML = records.map(function(r) {
                var timeStr = new Date(r.timestamp).toLocaleTimeString('ar-EG', {hour:'2-digit', minute:'2-digit'});
                return '<div class="record-item">' +
                    '<div class="record-info">' +
                        '<div class="record-author">👤 ' + escapeHtml(r.author) + '</div>' +
                        '<div class="record-text">' + escapeHtml(r.content) + '</div>' +
                    '</div>' +
                    '<div class="record-time">' + timeStr + '</div>' +
                '</div>';
            }).join('');
        }

        async function saveRecord() {
            const author = document.getElementById('authorInput').value.trim() || 'مستخدم متصل';
            const content = document.getElementById('contentInput').value.trim();
            if (!content) {
                alert('يرجى كتابة نص الرسالة');
                return;
            }

            try {
                const res = await fetch('/api/records', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        author: author,
                        content: content,
                        collection: 'messages'
                    })
                });

                if (res.ok) {
                    document.getElementById('contentInput').value = '';
                    fetchRecords();
                } else {
                    alert('حدث خطأ أثناء الحفظ');
                }
            } catch (e) {
                alert('تعذر الاتصال بالخادم: ' + e.message);
            }
        }

        function escapeHtml(text) {
            if (!text) return '';
            return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }

        // Auto load and poll every 3 seconds for realtime live updates
        fetchRecords();
        setInterval(fetchRecords, 3000);
    </script>
</body>
</html>
        """.trimIndent()

        File(rootDir, "index.html").writeText(indexHtml, Charsets.UTF_8)
    }

    private fun unzipToDirectory(zipStream: InputStream, targetDir: File): Pair<Int, Long> {
        var fileCount = 0
        var totalBytes = 0L
        val zis = ZipInputStream(BufferedInputStream(zipStream))
        var entry: ZipEntry? = zis.nextEntry

        while (entry != null) {
            val fileName = entry.name
            val file = File(targetDir, fileName)
            val canonicalDestinationPath = targetDir.canonicalPath
            val canonicalTargetFile = file.canonicalPath
            if (!canonicalTargetFile.startsWith(canonicalDestinationPath + File.separator) && canonicalTargetFile != canonicalDestinationPath) {
                entry = zis.nextEntry
                continue
            }

            if (entry.isDirectory) {
                file.mkdirs()
            } else {
                file.parentFile?.mkdirs()
                FileOutputStream(file).use { fos ->
                    val buffer = ByteArray(8192)
                    var len: Int
                    while (zis.read(buffer).also { len = it } > 0) {
                        fos.write(buffer, 0, len)
                        totalBytes += len
                    }
                }
                fileCount++
            }
            zis.closeEntry()
            entry = zis.nextEntry
        }
        zis.close()

        hoistSingleRootDirectoryIfNeeded(targetDir)
        return Pair(fileCount, totalBytes)
    }

    private fun hoistSingleRootDirectoryIfNeeded(rootDir: File) {
        val indexDirect = File(rootDir, "index.html")
        if (indexDirect.exists()) return

        val children = rootDir.listFiles() ?: return
        if (children.size == 1 && children[0].isDirectory) {
            val subFolder = children[0]
            val subFiles = subFolder.listFiles() ?: return
            for (f in subFiles) {
                f.renameTo(File(rootDir, f.name))
            }
            subFolder.delete()
        } else {
            for (sub in children) {
                if (sub.isDirectory) {
                    val candidate = File(sub, "index.html")
                    if (candidate.exists()) {
                        sub.listFiles()?.forEach { f ->
                            f.renameTo(File(rootDir, f.name))
                        }
                        sub.delete()
                        break
                    }
                }
            }
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val formatted = DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble()))
        return "$formatted ${units[digitGroups.coerceIn(0, units.size - 1)]}"
    }
}
