package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.HotspotStatus
import com.example.ui.components.*
import com.example.ui.theme.DarkChipBg
import com.example.ui.theme.ElegantLilacPrimary
import com.example.viewmodel.HotspotViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HotspotMainScreen(
    viewModel: HotspotViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hotspotStatus by viewModel.hotspotStatus.collectAsStateWithLifecycle()
    val hotspotInfo by viewModel.hotspotInfo.collectAsStateWithLifecycle()
    val hostedSite by viewModel.hostedSite.collectAsStateWithLifecycle()
    val connectedDevices by viewModel.connectedDevices.collectAsStateWithLifecycle()
    val serverLogs by viewModel.serverLogs.collectAsStateWithLifecycle()
    val databaseRecords by viewModel.databaseRecords.collectAsStateWithLifecycle()
    val customSsid by viewModel.customSsid.collectAsStateWithLifecycle()
    val customPassword by viewModel.customPassword.collectAsStateWithLifecycle()

    var showCaptiveGuide by remember { mutableStateOf(false) }

    // Multi-permission launcher
    val permissionsToRequest = remember {
        mutableListOf<String>().apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.NEARBY_WIFI_DEVICES)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
                add(Manifest.permission.ACCESS_COARSE_LOCATION)
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }.toTypedArray()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted || results.isNotEmpty()) {
            if (hotspotStatus != HotspotStatus.ACTIVE) {
                viewModel.startHotspotAndServer()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkChipBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Wifi,
                                contentDescription = null,
                                tint = ElegantLilacPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "خادم استضافة محلي وقاعدة بيانات",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showCaptiveGuide = true },
                        modifier = Modifier.testTag("top_bar_info_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "دليل الاستخدام والتوجيه",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
            .fillMaxSize()
            .testTag("hotspot_main_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Status & Start/Stop Primary Hero Card
            StatusHeroCard(
                status = hotspotStatus,
                info = hotspotInfo,
                connectedDevicesCount = connectedDevices.size,
                onToggleHotspot = {
                    if (hotspotStatus == HotspotStatus.ACTIVE) {
                        viewModel.stopHotspotAndServer()
                    } else {
                        val hasPermissions = permissionsToRequest.all { perm ->
                            ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
                        }
                        if (hasPermissions) {
                            viewModel.startHotspotAndServer()
                        } else {
                            permissionLauncher.launch(permissionsToRequest)
                        }
                    }
                },
                onStartSystemHotspot = {
                    viewModel.startServerWithSystemHotspot()
                }
            )

            // 2. Barcode & QR Code Card (Scan to Open Website or Connect Wi-Fi)
            QrConnectCard(
                info = hotspotInfo,
                isHotspotActive = hotspotStatus == HotspotStatus.ACTIVE
            )

            // 3. Hosted Website File Picker Card
            WebsitePickerCard(
                site = hostedSite,
                isServerActive = hotspotStatus == HotspotStatus.ACTIVE,
                serverUrl = hotspotInfo.serverUrl,
                onWebsiteSelected = { uri -> viewModel.onWebsiteSelected(uri) }
            )

            // 4. Shared Database (REST API / Room) Inspector
            DatabaseInspectorCard(
                records = databaseRecords,
                onClearAll = { viewModel.clearAllDatabaseRecords() },
                onDeleteRecord = { id -> viewModel.deleteDatabaseRecord(id) }
            )

            // 5. Wi-Fi Configuration
            NetworkConfigCard(
                currentSsid = customSsid,
                currentPassword = customPassword,
                isHotspotActive = hotspotStatus == HotspotStatus.ACTIVE,
                onSaveCredentials = { newSsid, newPassword ->
                    viewModel.saveAndApplyWifiCredentials(newSsid, newPassword)
                },
                onOpenSystemSettings = { viewModel.openTetheringSettings(context) }
            )

            // 6. Connected Devices (Collapsible)
            ConnectedDevicesCard(
                devices = connectedDevices,
                isHotspotActive = hotspotStatus == HotspotStatus.ACTIVE,
                onRefresh = { viewModel.refreshDevices() }
            )

            // 7. Server Logs (Collapsible)
            LiveLogsCard(
                logs = serverLogs,
                onClearLogs = { viewModel.clearLogs() }
            )

            Spacer(modifier = Modifier.height(12.dp))
        }
    }

    // Dialogs
    if (showCaptiveGuide) {
        CaptiveGuideDialog(
            onDismiss = { showCaptiveGuide = false }
        )
    }
}
