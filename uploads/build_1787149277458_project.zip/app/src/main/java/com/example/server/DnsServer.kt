package com.example.server

import com.example.model.ServerLog
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Embedded High-Performance RFC 1035 Compliant DNS Server / Interceptor.
 *
 * Runs on Port 53 (UDP) and dynamically extracts the queried domain name from any device (iOS, Android, Windows, macOS).
 * It crafts and returns an Authoritative DNS Response (A record) pointing directly to the hotspot gateway IP.
 * This guarantees 100% reliable Captive Portal detection for Apple CNA (captive.apple.com, etc.), Android and browsers.
 */
class DnsServer(
    private val ipProvider: () -> String = { "192.168.49.1" },
    private val port: Int = 53,
    private val onLog: (ServerLog) -> Unit = {}
) {
    private var datagramSocket: DatagramSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val executor = Executors.newCachedThreadPool()

    fun start() {
        if (isRunning.get()) return
        try {
            datagramSocket = DatagramSocket(null).apply {
                reuseAddress = true
                bind(InetSocketAddress(port))
            }
            isRunning.set(true)
            executor.execute {
                listen()
            }
            onLog(
                ServerLog(
                    clientIp = ipProvider(),
                    requestPath = "⚡ DNS Interceptor Server Active on Port $port (Catch-All RFC 1035)",
                    statusCode = 200,
                    isVideoChunk = false
                )
            )
        } catch (e: Exception) {
            // Port 53 might require root on standard sockets or fallback gracefully without crash
            isRunning.set(false)
            onLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "DNS Interceptor Note (Port $port): ${e.message ?: "fallback to Multi-Port HTTP Captive Interceptor"}",
                    statusCode = 500,
                    isVideoChunk = false
                )
            )
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            datagramSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        datagramSocket = null
    }

    fun isServerRunning(): Boolean = isRunning.get()

    private fun listen() {
        val buffer = ByteArray(512)
        while (isRunning.get()) {
            try {
                val packet = DatagramPacket(buffer, buffer.size)
                datagramSocket?.receive(packet) ?: break

                val targetIp = ipProvider()
                val packetLength = packet.length
                val requestData = packet.data.copyOf(packetLength)
                val clientAddress = packet.address
                val clientPort = packet.port

                executor.execute {
                    try {
                        val responseData = buildDnsResponse(requestData, packetLength, targetIp)
                        if (responseData != null) {
                            val replyPacket = DatagramPacket(
                                responseData,
                                responseData.size,
                                clientAddress,
                                clientPort
                            )
                            datagramSocket?.send(replyPacket)
                        }
                    } catch (e: Exception) {
                        // ignore packet transmission errors
                    }
                }
            } catch (e: Exception) {
                if (!isRunning.get()) break
            }
        }
    }

    /**
     * Constructs a valid standard DNS (RFC 1035) response packet resolving the requested query to targetIp.
     */
    private fun buildDnsResponse(request: ByteArray, length: Int, targetIp: String): ByteArray? {
        if (length < 12) return null

        val response = ByteArray(length + 16)
        // 1. Copy Header & Question section directly from query
        System.arraycopy(request, 0, response, 0, length)

        // 2. Set Flags:
        // Byte 2: QR=1 (Response), Opcode=0 (Standard Query), AA=1 (Authoritative), TC=0, RD (copied from query)
        val rd = (request[2].toInt() and 0x01)
        response[2] = (0x84 or rd).toByte()
        // Byte 3: RA=1 (Recursion Available), RCODE=0 (No Error)
        response[3] = 0x80.toByte()

        // 3. Set Question Count QDCOUNT = 1, Answer Count ANCOUNT = 1, NSCOUNT = 0, ARCOUNT = 0
        response[4] = 0x00.toByte()
        response[5] = 0x01.toByte()
        response[6] = 0x00.toByte()
        response[7] = 0x01.toByte()
        response[8] = 0x00.toByte()
        response[9] = 0x00.toByte()
        response[10] = 0x00.toByte()
        response[11] = 0x00.toByte()

        // 4. Answer Section:
        var offset = length
        // Name pointer pointing to the query name in question section (offset 12 = 0x000C)
        response[offset++] = 0xC0.toByte()
        response[offset++] = 0x0C.toByte()

        // Type A (0x0001 = Host Address)
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x01.toByte()

        // Class IN (0x0001 = Internet)
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x01.toByte()

        // TTL = 60 seconds (0x0000003C)
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x3C.toByte()

        // Data Length (RDLENGTH) = 4 bytes for IPv4
        response[offset++] = 0x00.toByte()
        response[offset++] = 0x04.toByte()

        // IPv4 Address bytes (4 bytes)
        val ipParts = targetIp.split(".")
        if (ipParts.size == 4) {
            for (part in ipParts) {
                response[offset++] = (part.toIntOrNull() ?: 0).toByte()
            }
        } else {
            response[offset++] = 192.toByte()
            response[offset++] = 168.toByte()
            response[offset++] = 49.toByte()
            response[offset++] = 1.toByte()
        }

        val result = ByteArray(offset)
        System.arraycopy(response, 0, result, 0, offset)
        return result
    }
}
