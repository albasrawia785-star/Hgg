package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.ElegantGlowGreen
import com.example.ui.theme.ElegantLilacDark
import com.example.ui.theme.ElegantLilacPrimary

@Composable
fun CaptiveGuideDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(28.dp))
                .padding(8.dp)
                .testTag("captive_guide_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "كيف يعمل خادم الويب المحلي؟",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                GuideItem(
                    title = "1. دعم مواقع الويب وتطبيقات React",
                    description = "يمكنك رفع ملف HTML مباشر، أو ملف ZIP يحتوي على بناء مشروع ويب كامل (React build / Vue / Vite / HTML+CSS+JS). سيقوم الخادم بفك الضغط واستضافة الموقع تلقائياً."
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideItem(
                    title = "2. فتح الموقع من الأجهزة المتصلة",
                    description = "بمجرد اتصال أي جهاز بالشبكة، يكفي فتح المتصفح والدخول إلى الرابط المعروض (مثلاً: http://192.168.49.1:8080) وسيفتح الموقع بكامل مميزاته التفاعلية بدون إنترنت."
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideItem(
                    title = "3. التوجيه التلقائي (Captive Portal)",
                    description = "يقوم خادم DNS و HTTP باعتراض طلبات الشبكة في أجهزة iOS و Android لتسهيل فتح بوابة الموقع فور الاتصال بنقطة الـ Wi-Fi."
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideItem(
                    title = "4. سرعة وأمان محلي 100%",
                    description = "يتم نقل الملفات عبر الشبكة اللاسلكية المحلية مباشرة بين الهواتف بسرعات فائقة، مع الحفاظ التام على خصوصية البيانات دون أي اتصال خارجي."
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(99.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElegantLilacPrimary,
                        contentColor = ElegantLilacDark
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Text("فهمت ذلك", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

@Composable
private fun GuideItem(
    title: String,
    description: String
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = ElegantGlowGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
