package com.example.server

import com.example.data.local.AppDatabase
import com.example.data.local.SharedRecordEntity
import com.example.model.HostedSite
import com.example.model.ServerLog
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.URLDecoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * High-Performance Static Web & Single Page App (React/HTML/JS/CSS) Local Server with REST API Database.
 * Serves static sites and provides a built-in shared database endpoint (/api/records) accessible to all connected devices.
 */
class LocalHttpServer(
    private val port: Int = 8080,
    private val ipProvider: () -> String = { "192.168.49.1" },
    private val webRootDirProvider: () -> File,
    private val siteMetaProvider: () -> HostedSite,
    private val database: AppDatabase,
    private val onLog: (ServerLog) -> Unit
) {
    private var primaryServerSocket: ServerSocket? = null
    private var port80ServerSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val threadPool = Executors.newCachedThreadPool()

    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)

        // 1. Start Configured Primary Port (e.g. 8080)
        try {
            primaryServerSocket = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(port))
            }
            threadPool.execute {
                listenOnSocket(primaryServerSocket, port)
            }
            onLog(
                ServerLog(
                    clientIp = ipProvider(),
                    requestPath = "خادم الويب وقاعدة البيانات المشتركة يعملان على المنفذ [$port]",
                    statusCode = 200,
                    isVideoChunk = false
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            onLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "خطأ في تشغيل المنفذ $port: ${e.message}",
                    statusCode = 500,
                    isVideoChunk = false
                )
            )
        }

        // 2. Try starting Standard HTTP Port 80 (Captive Portal Standard Port)
        if (port != 80) {
            try {
                port80ServerSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(80))
                }
                threadPool.execute {
                    listenOnSocket(port80ServerSocket, 80)
                }
                onLog(
                    ServerLog(
                        clientIp = ipProvider(),
                        requestPath = "⚡ تم تفعيل المنفذ القياسي [80] لاعتراض الهوت سبوت الفوري",
                        statusCode = 200,
                        isVideoChunk = false
                    )
                )
            } catch (e: Exception) {
                // Port 80 fallback gracefully
            }
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            primaryServerSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            port80ServerSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        primaryServerSocket = null
        port80ServerSocket = null
    }

    fun isServerRunning(): Boolean = isRunning.get()

    private fun listenOnSocket(socketServer: ServerSocket?, currentPort: Int) {
        while (isRunning.get()) {
            try {
                val socket = socketServer?.accept() ?: break
                threadPool.execute {
                    handleClient(socket, currentPort)
                }
            } catch (e: SocketException) {
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun handleClient(socket: Socket, currentPort: Int) {
        val clientIp = socket.inetAddress?.hostAddress ?: "unknown"
        try {
            socket.soTimeout = 15000
            val inputStream = socket.getInputStream()
            val outputStream = socket.getOutputStream()
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))

            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return

            val method = parts[0].uppercase()
            val rawPath = parts[1]
            val path = URLDecoder.decode(rawPath.substringBefore("?"), "UTF-8")
            val queryString = rawPath.substringAfter("?", "")

            // Parse Headers
            val headers = mutableMapOf<String, String>()
            var line: String? = reader.readLine()
            var contentLength = 0
            while (!line.isNullOrEmpty()) {
                val colonIdx = line.indexOf(':')
                if (colonIdx != -1) {
                    val key = line.substring(0, colonIdx).trim().lowercase()
                    val value = line.substring(colonIdx + 1).trim()
                    headers[key] = value
                    if (key == "content-length") {
                        contentLength = value.toIntOrNull() ?: 0
                    }
                }
                line = reader.readLine()
            }

            // Read Body if POST/PUT
            var body = ""
            if (contentLength > 0 && (method == "POST" || method == "PUT" || method == "PATCH")) {
                val charBuffer = CharArray(contentLength)
                var readTotal = 0
                while (readTotal < contentLength) {
                    val read = reader.read(charBuffer, readTotal, contentLength - readTotal)
                    if (read == -1) break
                    readTotal += read
                }
                body = String(charBuffer, 0, readTotal)
            }

            val host = headers["host"] ?: ipProvider()
            val userAgent = headers["user-agent"] ?: ""

            // Handle CORS Pre-flight Options
            if (method == "OPTIONS") {
                sendCorsOk(outputStream)
                return
            }

            when {
                // 1. Shared Database REST API Endpoints (/api/records or /api/data)
                path.startsWith("/api/records") || path.startsWith("/api/data") -> {
                    handleDatabaseApi(outputStream, method, path, queryString, body, clientIp)
                }

                // 2. Favicon
                path == "/favicon.ico" -> {
                    val favFile = File(webRootDirProvider(), "favicon.ico")
                    if (favFile.exists()) {
                        serveStaticFile(outputStream, favFile, clientIp, path)
                    } else {
                        send404(outputStream, clientIp, path)
                    }
                }

                // 3. Apple Captive Probe
                isAppleProbe(path, host, userAgent) -> {
                    serveApplePortal(outputStream, clientIp, path)
                }

                // 4. Android Captive Probe
                isAndroidProbe(path, host) -> {
                    serveAndroidPortalRedirect(outputStream, clientIp, path, currentPort)
                }

                // 5. Windows / Firefox Probe
                isWindowsOrFirefoxProbe(path, host) -> {
                    serveGenericCaptiveRedirect(outputStream, clientIp, path, currentPort)
                }

                // 6. Normal Static File or SPA Route Request
                else -> {
                    serveWebRoute(outputStream, clientIp, path)
                }
            }
        } catch (e: Exception) {
            // Client socket disconnect
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {}
        }
    }

    private fun handleDatabaseApi(
        output: OutputStream,
        method: String,
        path: String,
        queryString: String,
        body: String,
        clientIp: String
    ) {
        val dao = database.sharedRecordDao()

        when (method) {
            "GET" -> {
                runBlocking {
                    val collection = getQueryParam(queryString, "collection")
                    val records = if (!collection.isNullOrEmpty()) {
                        dao.getRecordsByCollection(collection)
                    } else {
                        dao.getAllRecords()
                    }

                    val jsonArray = JSONArray()
                    records.forEach { record ->
                        val obj = JSONObject().apply {
                            put("id", record.id)
                            put("collection", record.collection)
                            put("author", record.author)
                            put("title", record.title ?: "")
                            put("content", record.content)
                            put("jsonData", try { JSONObject(record.jsonData) } catch (e: Exception) { record.jsonData })
                            put("timestamp", record.timestamp)
                            put("clientIp", record.clientIp)
                        }
                        jsonArray.put(obj)
                    }

                    val responseJson = JSONObject().apply {
                        put("status", "success")
                        put("count", records.size)
                        put("records", jsonArray)
                    }.toString(2)

                    sendJsonResponse(output, responseJson, 200)
                    onLog(
                        ServerLog(
                            clientIp = clientIp,
                            requestPath = "📥 GET $path (قراءة ${records.size} سجل من قاعدة البيانات المشتركة)",
                            statusCode = 200
                        )
                    )
                }
            }

            "POST" -> {
                runBlocking {
                    try {
                        val jsonObj = if (body.isNotBlank()) JSONObject(body) else JSONObject()
                        val collection = jsonObj.optString("collection", "general")
                        val author = jsonObj.optString("author", "مستخدم $clientIp")
                        val title = jsonObj.optString("title", "")
                        val content = jsonObj.optString("content", "")
                        val rawJsonData = if (jsonObj.has("jsonData")) jsonObj.get("jsonData").toString() else body

                        val record = SharedRecordEntity(
                            collection = collection,
                            author = author,
                            title = if (title.isBlank()) null else title,
                            content = content,
                            jsonData = rawJsonData,
                            clientIp = clientIp
                        )

                        val newId = dao.insertRecord(record)
                        val responseJson = JSONObject().apply {
                            put("status", "success")
                            put("message", "تم حفظ السجل في قاعدة بيانات الهاتف بنجاح")
                            put("id", newId)
                        }.toString(2)

                        sendJsonResponse(output, responseJson, 201)
                        onLog(
                            ServerLog(
                                clientIp = clientIp,
                                requestPath = "💾 POST $path (تمت إضافة سجل جديد #$newId من $author)",
                                statusCode = 201
                            )
                        )
                    } catch (e: Exception) {
                        val errJson = JSONObject().apply {
                            put("status", "error")
                            put("message", "خطأ في معالجة JSON: ${e.message}")
                        }.toString()
                        sendJsonResponse(output, errJson, 400)
                    }
                }
            }

            "DELETE" -> {
                runBlocking {
                    val idStr = path.substringAfterLast("/").toLongOrNull()
                    if (idStr != null) {
                        dao.deleteRecordById(idStr)
                        val res = JSONObject().apply {
                            put("status", "success")
                            put("message", "تم حذف السجل رقم $idStr")
                        }.toString()
                        sendJsonResponse(output, res, 200)
                    } else {
                        val res = JSONObject().apply {
                            put("status", "error")
                            put("message", "يرجى تحديد معرف السجل المراد حذفه")
                        }.toString()
                        sendJsonResponse(output, res, 400)
                    }
                }
            }

            else -> {
                sendJsonResponse(output, "{\"error\": \"Method not allowed\"}", 405)
            }
        }
    }

    private fun getQueryParam(queryString: String, paramName: String): String? {
        if (queryString.isBlank()) return null
        return queryString.split("&").firstOrNull { it.startsWith("$paramName=") }?.substringAfter("=")
    }

    private fun sendJsonResponse(output: OutputStream, json: String, statusCode: Int) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        val statusMsg = when (statusCode) {
            200 -> "200 OK"
            201 -> "201 Created"
            400 -> "400 Bad Request"
            404 -> "404 Not Found"
            405 -> "405 Method Not Allowed"
            else -> "500 Internal Server Error"
        }
        val header = "HTTP/1.1 $statusMsg\r\n" +
                "Content-Type: application/json; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun sendCorsOk(output: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun isAppleProbe(path: String, host: String, userAgent: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        val ua = userAgent.lowercase()
        return h.contains("apple.com") ||
                h.contains("captive.apple.com") ||
                h.contains("airport.us") ||
                h.contains("ibook.info") ||
                h.contains("itools.info") ||
                h.contains("thinkdifferent.us") ||
                h.contains("appleiphonecell.com") ||
                h.contains("icloud.com") ||
                p.contains("hotspot-detect.html") ||
                p.contains("library/test/success.html") ||
                p.contains("canonical.html") ||
                p.contains("bag.xml") ||
                ua.contains("captivenetworksupport") ||
                ua.contains("wispr")
    }

    private fun isAndroidProbe(path: String, host: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        return p.contains("generate_204") ||
                p.contains("gen_204") ||
                p.contains("connectivitycheck") ||
                p.contains("check_network_status") ||
                h.contains("gstatic.com") ||
                h.contains("google.com") ||
                h.contains("android.com") ||
                h.contains("googleapis.com")
    }

    private fun isWindowsOrFirefoxProbe(path: String, host: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        return h.contains("msftconnecttest.com") ||
                h.contains("msftncsi.com") ||
                h.contains("detectportal.firefox.com") ||
                p.contains("ncsi.txt") ||
                p.contains("connecttest.txt") ||
                p.contains("success.txt")
    }

    private fun serveWebRoute(outputStream: OutputStream, clientIp: String, requestPath: String) {
        val rootDir = webRootDirProvider()
        val cleanPath = requestPath.removePrefix("/").ifEmpty { "index.html" }
        var targetFile = File(rootDir, cleanPath)

        if (targetFile.isDirectory) {
            targetFile = File(targetFile, "index.html")
        }

        if (!targetFile.exists()) {
            val isAsset = cleanPath.contains(".")
            if (!isAsset) {
                targetFile = File(rootDir, "index.html")
            }
        }

        if (targetFile.exists() && targetFile.isFile) {
            serveStaticFile(outputStream, targetFile, clientIp, requestPath)
        } else {
            send404(outputStream, clientIp, requestPath)
        }
    }

    private fun serveStaticFile(outputStream: OutputStream, file: File, clientIp: String, requestedPath: String) {
        val mimeType = getMimeType(file.name)
        val length = file.length()

        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: $mimeType\r\n" +
                "Content-Length: $length\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: public, max-age=3600\r\n" +
                "Connection: close\r\n\r\n"

        outputStream.write(header.toByteArray(Charsets.UTF_8))
        FileInputStream(file).use { fis ->
            fis.copyTo(outputStream, bufferSize = 16384)
        }
        outputStream.flush()

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "📄 $requestedPath (${file.name} - ${length / 1024} KB)",
                statusCode = 200,
                isVideoChunk = false
            )
        )
    }

    private fun serveApplePortal(output: OutputStream, clientIp: String, path: String) {
        val rootDir = webRootDirProvider()
        val indexFile = File(rootDir, "index.html")
        if (indexFile.exists()) {
            serveStaticFile(output, indexFile, clientIp, path)
        } else {
            send404(output, clientIp, path)
        }
        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "⚡ تم فتح بوابة الموقع على جهاز Apple (iOS CNA)",
                statusCode = 200
            )
        )
    }

    private fun serveAndroidPortalRedirect(output: OutputStream, clientIp: String, path: String, currentPort: Int) {
        val targetUrl = "http://${ipProvider()}:$currentPort"
        val response = "HTTP/1.1 302 Found\r\n" +
                "Location: $targetUrl\r\n" +
                "Content-Length: 0\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "⚡ توجيه تلقائي لجهاز Android إلى $targetUrl",
                statusCode = 302
            )
        )
    }

    private fun serveGenericCaptiveRedirect(output: OutputStream, clientIp: String, path: String, currentPort: Int) {
        val targetUrl = "http://${ipProvider()}:$currentPort"
        val response = "HTTP/1.1 302 Found\r\n" +
                "Location: $targetUrl\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun send404(output: OutputStream, clientIp: String, path: String) {
        val notFoundHtml = "<html><body style='font-family:sans-serif;text-align:center;padding:40px;'>" +
                "<h2>404 - لم يتم العثور على الملف</h2>" +
                "<p>المسار المطلوب: <code>$path</code></p>" +
                "<a href='/'>العودة للصفحة الرئيسية للموقع</a>" +
                "</body></html>"
        val bytes = notFoundHtml.toByteArray(Charsets.UTF_8)
        val response = "HTTP/1.1 404 Not Found\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun getMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "html", "htm" -> "text/html; charset=UTF-8"
            "css" -> "text/css; charset=UTF-8"
            "js", "mjs" -> "application/javascript; charset=UTF-8"
            "json" -> "application/json; charset=UTF-8"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "svg" -> "image/svg+xml"
            "ico" -> "image/x-icon"
            "webp" -> "image/webp"
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain; charset=UTF-8"
            "xml" -> "application/xml"
            else -> "application/octet-stream"
        }
    }
}
