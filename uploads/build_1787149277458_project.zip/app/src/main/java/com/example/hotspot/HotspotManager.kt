package com.example.hotspot

import android.content.Context
import android.content.Intent
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import com.example.model.ConnectedDevice
import com.example.model.HotspotInfo
import com.example.model.HotspotStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.FileReader
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

class HotspotManager(
    private val context: Context,
    private val onStatusChange: (HotspotStatus, HotspotInfo) -> Unit
) {

    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var currentInfo = HotspotInfo()

    fun isHotspotRunning(): Boolean = reservation != null

    fun startHotspot(customSsid: String = "VideoPortal_Wifi", customPassword: String? = null) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            onStatusChange(
                HotspotStatus.ERROR,
                currentInfo.copy(errorMessage = "يتطلب تشغيل نقطة الاتصال نظام Android 8.0 (API 26) أو أحدث.")
            )
            return
        }

        onStatusChange(HotspotStatus.STARTING, currentInfo)

        try {
            // Android 8.0+ official startLocalOnlyHotspot API
            wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation?) {
                    super.onStarted(res)
                    reservation = res
                    if (res != null) {
                        var actualSsid = customSsid.ifBlank { "VideoPortal_Wifi" }
                        var actualPassword: String? = null

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            val config = res.softApConfiguration
                            if (config != null) {
                                actualSsid = config.ssid ?: actualSsid
                                actualPassword = config.passphrase
                            }
                        } else {
                            @Suppress("DEPRECATION")
                            val config: WifiConfiguration? = res.wifiConfiguration
                            if (config != null) {
                                actualSsid = config.SSID ?: actualSsid
                                actualPassword = config.preSharedKey
                            }
                        }

                        // Use the real, hardware-generated and verified system password so connection NEVER fails
                        val isSecOpen = actualPassword.isNullOrEmpty()
                        val localIp = getLocalIpAddress()
                        currentInfo = HotspotInfo(
                            ssid = actualSsid,
                            password = actualPassword,
                            isSecurityOpen = isSecOpen,
                            ipAddress = localIp,
                            port = 8080,
                            isTetheringMode = false,
                            errorMessage = null
                        )
                        onStatusChange(HotspotStatus.ACTIVE, currentInfo)
                    }
                }

                override fun onStopped() {
                    super.onStopped()
                    reservation = null
                    onStatusChange(HotspotStatus.STOPPED, currentInfo)
                }

                override fun onFailed(reason: Int) {
                    super.onFailed(reason)
                    reservation = null
                    val errorMsg = when (reason) {
                        ERROR_NO_CHANNEL -> "لا توجد قنوات Wi-Fi متاحة حالياً. يرجى إيقاف Wi-Fi وتشغيله مجدداً."
                        ERROR_GENERIC -> "تعذر بدء نقطة الاتصال تلقائياً. تأكد من تفعيل Wi-Fi في هاتفك."
                        ERROR_INCOMPATIBLE_MODE -> "نظام الهاتف يتطلب ضبط نقطة الاتصال عبر إعدادات النظام."
                        ERROR_TETHERING_DISALLOWED -> "مشاركة الشبكة مقيدة في إعدادات النظام."
                        else -> "فشل بدء نقطة الاتصال (كود: $reason)."
                    }
                    onStatusChange(
                        HotspotStatus.ERROR,
                        currentInfo.copy(errorMessage = errorMsg)
                    )
                }
            }, null)
        } catch (e: SecurityException) {
            e.printStackTrace()
            onStatusChange(
                HotspotStatus.ERROR,
                currentInfo.copy(errorMessage = "يرجى منح أذونات Wi-Fi والموقع لتشغيل نقطة الاتصال: ${e.message}")
            )
        } catch (e: Exception) {
            e.printStackTrace()
            onStatusChange(
                HotspotStatus.ERROR,
                currentInfo.copy(errorMessage = "حدث خطأ أثناء تشغيل نقطة الاتصال: ${e.message}")
            )
        }
    }

    fun stopHotspot() {
        try {
            reservation?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        reservation = null
        onStatusChange(HotspotStatus.STOPPED, currentInfo)
    }

    fun openSystemTetheringSettings(context: Context) {
        val intents = arrayOf(
            Intent().setComponent(
                android.content.ComponentName(
                    "com.android.settings",
                    "com.android.settings.TetherSettings"
                )
            ),
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return
            } catch (e: Exception) {
                // Try next
            }
        }
    }

    fun getLocalIpAddress(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val name = intf.name.lowercase()
                if (name.contains("wlan") || name.contains("ap") || name.contains("swlan") || name.contains("softap")) {
                    val addrs = Collections.list(intf.inetAddresses)
                    for (addr in addrs) {
                        if (!addr.isLoopbackAddress && addr is Inet4Address) {
                            val ip = addr.hostAddress
                            if (!ip.isNullOrEmpty()) {
                                return ip
                            }
                        }
                    }
                }
            }
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val ip = addr.hostAddress
                        if (!ip.isNullOrEmpty() && ip != "127.0.0.1") {
                            return ip
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "192.168.49.1"
    }

    suspend fun scanConnectedDevices(): List<ConnectedDevice> = withContext(Dispatchers.IO) {
        val devices = mutableListOf<ConnectedDevice>()
        try {
            val br = BufferedReader(FileReader("/proc/net/arp"))
            var line: String?
            var index = 0
            while (br.readLine().also { line = it } != null) {
                index++
                if (index == 1) continue
                val splitted = line?.split("\\s+".toRegex())?.filter { it.isNotBlank() } ?: continue
                if (splitted.size >= 4) {
                    val ip = splitted[0]
                    val mac = splitted[3]
                    val flags = splitted[2]
                    if (mac != "00:00:00:00:00:00" && flags != "0x0") {
                        val hostname = try {
                            val addr = InetAddress.getByName(ip)
                            addr.canonicalHostName.takeIf { it != ip } ?: "جهاز متصل (${mac.takeLast(5)})"
                        } catch (e: Exception) {
                            "جهاز متصل (${mac.takeLast(5)})"
                        }
                        devices.add(
                            ConnectedDevice(
                                ipAddress = ip,
                                macAddress = mac,
                                deviceName = hostname
                            )
                        )
                    }
                }
            }
            br.close()
        } catch (e: Exception) {
            // /proc/net/arp might be restricted on Android 10+ without root
        }
        devices
    }
}
