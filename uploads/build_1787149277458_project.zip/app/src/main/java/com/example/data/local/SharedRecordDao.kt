package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SharedRecordDao {

    @Query("SELECT * FROM shared_records ORDER BY timestamp DESC")
    fun getAllRecordsFlow(): Flow<List<SharedRecordEntity>>

    @Query("SELECT * FROM shared_records ORDER BY timestamp DESC")
    suspend fun getAllRecords(): List<SharedRecordEntity>

    @Query("SELECT * FROM shared_records WHERE collection = :collection ORDER BY timestamp DESC")
    suspend fun getRecordsByCollection(collection: String): List<SharedRecordEntity>

    @Query("SELECT * FROM shared_records WHERE id = :id LIMIT 1")
    suspend fun getRecordById(id: Long): SharedRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: SharedRecordEntity): Long

    @Query("DELETE FROM shared_records WHERE id = :id")
    suspend fun deleteRecordById(id: Long): Int

    @Query("DELETE FROM shared_records")
    suspend fun clearAllRecords()

    @Query("SELECT COUNT(*) FROM shared_records")
    fun getRecordCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM shared_records")
    suspend fun getRecordCount(): Int
}
