package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Common shared data record entity.
 * Supports flexible key-value documents / collections so any React or HTML project
 * can store users, messages, orders, form submissions, or products seamlessly.
 */
@Entity(tableName = "shared_records")
data class SharedRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val collection: String = "general", // e.g. "messages", "posts", "orders", "notes"
    val author: String = "مستخدم",
    val title: String? = null,
    val content: String = "",
    val jsonData: String = "{}",        // Full JSON payload for rich React objects
    val timestamp: Long = System.currentTimeMillis(),
    val clientIp: String = "127.0.0.1"
)
