package com.example.model

import android.net.Uri

enum class HotspotStatus {
    STOPPED,
    STARTING,
    ACTIVE,
    ERROR
}

data class HotspotInfo(
    val ssid: String = "WebPortal_Wifi",
    val password: String? = null,
    val isSecurityOpen: Boolean = true,
    val ipAddress: String = "192.168.49.1",
    val port: Int = 8080,
    val isTetheringMode: Boolean = false,
    val errorMessage: String? = null
) {
    val serverUrl: String
        get() = "http://$ipAddress:$port"
}

data class ConnectedDevice(
    val ipAddress: String,
    val macAddress: String,
    val deviceName: String = "جهاز متصل",
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

enum class HostedContentType {
    STATIC_SITE,   // ZIP bundle (React/Vue/HTML/CSS/JS export)
    SINGLE_HTML,   // Single HTML file
    VIDEO          // Direct MP4 video stream
}

data class HostedSite(
    val uri: Uri? = null,
    val name: String = "موقع ويب ترحيبي افتراضي (Web Portal)",
    val contentType: HostedContentType = HostedContentType.STATIC_SITE,
    val sizeFormatted: String = "120 KB",
    val fileCount: Int = 3,
    val isDefaultSample: Boolean = true
)

data class ServerLog(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val clientIp: String,
    val requestPath: String,
    val statusCode: Int,
    val isVideoChunk: Boolean = false
)
