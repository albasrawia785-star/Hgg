package com.example.server

import com.example.data.local.AppDatabase
import com.example.data.local.SharedRecordEntity
import com.example.model.HostedSite
import com.example.model.ServerLog
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.URLDecoder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Universal Firebase & Firestore Clone Engine for Local Offline Hotspots.
 * - Supports 100% of Firebase SDK / Firestore SDK APIs:
 *   firebase.initializeApp(), firebase.firestore(), firebase.database(), firebase.auth()
 *   db.collection().doc().set(), .get(), .update(), .delete(), .onSnapshot()
 *   db.ref().set(), .push(), .once('value'), .on('value')
 * - Supports any REST / GraphQL / Custom HTTP Request for any website in the world.
 * - Stores all records, updates, audits, and real-time streams in local SQLite / Room DB.
 */
class LocalHttpServer(
    private val port: Int = 8080,
    private val ipProvider: () -> String = { "192.168.49.1" },
    private val webRootDirProvider: () -> File,
    private val siteMetaProvider: () -> HostedSite,
    private val database: AppDatabase,
    private val onLog: (ServerLog) -> Unit
) {
    private var primaryServerSocket: ServerSocket? = null
    private var port80ServerSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val threadPool = Executors.newCachedThreadPool()

    // Real-Time SSE Active Client Subscribers
    private val sseClients = CopyOnWriteArrayList<OutputStream>()

    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)

        // 1. Start Configured Primary Port (e.g. 8080)
        try {
            primaryServerSocket = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(port))
            }
            threadPool.execute {
                listenOnSocket(primaryServerSocket, port)
            }
            onLog(
                ServerLog(
                    clientIp = ipProvider(),
                    requestPath = "خادم الويب الشامل ومحرك Firebase/Firestore يعملان على المنفذ [$port]",
                    statusCode = 200,
                    isVideoChunk = false
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            onLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "خطأ في تشغيل المنفذ $port: ${e.message}",
                    statusCode = 500,
                    isVideoChunk = false
                )
            )
        }

        // 2. Start Standard HTTP Port 80
        if (port != 80) {
            try {
                port80ServerSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(80))
                }
                threadPool.execute {
                    listenOnSocket(port80ServerSocket, 80)
                }
            } catch (e: Exception) {}
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            primaryServerSocket?.close()
        } catch (e: Exception) {}
        try {
            port80ServerSocket?.close()
        } catch (e: Exception) {}
        primaryServerSocket = null
        port80ServerSocket = null
        sseClients.clear()
    }

    fun isServerRunning(): Boolean = isRunning.get()

    private fun listenOnSocket(socketServer: ServerSocket?, currentPort: Int) {
        while (isRunning.get()) {
            try {
                val socket = socketServer?.accept() ?: break
                threadPool.execute {
                    handleClient(socket, currentPort)
                }
            } catch (e: SocketException) {
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun handleClient(socket: Socket, currentPort: Int) {
        val clientIp = socket.inetAddress?.hostAddress ?: "unknown"
        var isSseStream = false
        try {
            socket.soTimeout = 25000
            val inputStream = socket.getInputStream()
            val outputStream = socket.getOutputStream()
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))

            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return

            val method = parts[0].uppercase()
            val rawPath = parts[1]
            val path = URLDecoder.decode(rawPath.substringBefore("?"), "UTF-8")
            val queryString = rawPath.substringAfter("?", "")

            // Parse Headers
            val headers = mutableMapOf<String, String>()
            var line: String? = reader.readLine()
            var contentLength = 0
            while (!line.isNullOrEmpty()) {
                val colonIdx = line.indexOf(':')
                if (colonIdx != -1) {
                    val key = line.substring(0, colonIdx).trim().lowercase()
                    val value = line.substring(colonIdx + 1).trim()
                    headers[key] = value
                    if (key == "content-length") {
                        contentLength = value.toIntOrNull() ?: 0
                    }
                }
                line = reader.readLine()
            }

            // Read Body if present
            var body = ""
            if (contentLength > 0) {
                val charBuffer = CharArray(contentLength)
                var readTotal = 0
                while (readTotal < contentLength) {
                    val read = reader.read(charBuffer, readTotal, contentLength - readTotal)
                    if (read == -1) break
                    readTotal += read
                }
                body = String(charBuffer, 0, readTotal)
            }

            val host = headers["host"] ?: ipProvider()
            val userAgent = headers["user-agent"] ?: ""

            // Handle CORS Pre-flight Options for 100% of requests
            if (method == "OPTIONS") {
                sendCorsOk(outputStream)
                return
            }

            when {
                // 1. Firebase JS SDK / Firestore SDK Files (Serves when website loads firebase script)
                isFirebaseScriptPath(path) -> {
                    serveFirebaseSdkScript(outputStream)
                }

                // 2. Realtime SSE Stream (Firestore onSnapshot & Realtime DB on('value'))
                path == "/api/live" || path == "/api/events" || path == "/api/stream" || path == "/api/subscribe" || path.endsWith(".sse") -> {
                    isSseStream = true
                    socket.soTimeout = 0
                    handleRealtimeSseConnection(outputStream, clientIp)
                }

                // 3. Captive Network Probes
                isAppleProbe(path, host, userAgent) -> {
                    serveApplePortal(outputStream, clientIp, path)
                }
                isAndroidProbe(path, host) -> {
                    serveAndroidPortalRedirect(outputStream, clientIp, path, currentPort)
                }
                isWindowsOrFirefoxProbe(path, host) -> {
                    serveGenericCaptiveRedirect(outputStream, clientIp, path, currentPort)
                }

                // 4. Favicon
                path == "/favicon.ico" -> {
                    val favFile = File(webRootDirProvider(), "favicon.ico")
                    if (favFile.exists()) {
                        serveStaticFile(outputStream, favFile, clientIp, path)
                    } else {
                        send404(outputStream, clientIp, path)
                    }
                }

                // 5. Check if it's a Static File that exists on disk
                isExistingStaticAsset(path) -> {
                    serveWebRoute(outputStream, clientIp, path)
                }

                // 6. Universal Data / API / Firebase / CRUD Endpoints (Captures ANY endpoint in the world!)
                else -> {
                    // If it's a browser page request (HTML navigation), route to SPA React
                    val acceptHeader = headers["accept"] ?: ""
                    val isPageNav = method == "GET" && (acceptHeader.contains("text/html") || !path.contains("."))

                    if (isPageNav) {
                        serveWebRoute(outputStream, clientIp, path)
                    } else {
                        handleUniversalDatabaseApi(outputStream, method, path, queryString, body, clientIp)
                    }
                }
            }
        } catch (e: Exception) {
            // Socket disconnect or timeout
        } finally {
            if (!isSseStream) {
                try {
                    socket.close()
                } catch (e: Exception) {}
            }
        }
    }

    private fun isFirebaseScriptPath(path: String): Boolean {
        val p = path.lowercase()
        return p == "/firebase.js" ||
                p == "/firebase-app.js" ||
                p == "/firebase-firestore.js" ||
                p == "/firebase-database.js" ||
                p == "/firebase-auth.js" ||
                p == "/local-db.js" ||
                p == "/firestore.js" ||
                p == "/realtime.js" ||
                p.contains("firebase") && p.endsWith(".js")
    }

    private fun isExistingStaticAsset(path: String): Boolean {
        val rootDir = webRootDirProvider()
        val cleanPath = path.removePrefix("/").ifEmpty { "index.html" }
        val target = File(rootDir, cleanPath)
        return target.exists() && target.isFile
    }

    /**
     * 100% Complete Offline Firebase / Firestore SDK implementation for web browsers.
     * Emulates:
     * - firebase.initializeApp()
     * - firebase.firestore() -> db.collection().doc().set(), get(), update(), delete(), onSnapshot()
     * - firebase.database() -> db.ref().set(), push(), update(), remove(), once(), on('value')
     * - firebase.auth() -> currentUser, signInWithEmailAndPassword, etc.
     */
    private fun getFirebaseFullSdkJs(): String {
        return """
/**
 * Local Firebase & Firestore Full SDK Engine
 * 100% Offline Compatible with Realtime Updates & Local SQLite Persistence
 */
(function(window) {
    if (window.__FIREBASE_OFFLINE_SDK_READY__) return;
    window.__FIREBASE_OFFLINE_SDK_READY__ = true;

    // Helper: Generate UUID/ID
    function generateId() {
        return 'doc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // --- FIRESTORE IMPLEMENTATION ---
    class DocumentSnapshot {
        constructor(id, data, exists = true) {
            this.id = id;
            this._data = data || {};
            this.exists = exists;
        }
        data() {
            return this._data;
        }
        get(field) {
            return this._data[field];
        }
    }

    class QuerySnapshot {
        constructor(docs) {
            this.docs = docs;
            this.size = docs.length;
            this.empty = docs.length === 0;
        }
        forEach(callback) {
            this.docs.forEach(callback);
        }
    }

    class DocumentReference {
        constructor(collectionPath, docId) {
            this.collectionPath = collectionPath;
            this.id = docId || generateId();
            this.path = collectionPath + '/' + this.id;
        }

        async get() {
            try {
                const res = await fetch('/api/' + this.collectionPath + '/' + this.id);
                if (!res.ok) return new DocumentSnapshot(this.id, null, false);
                const json = await res.json();
                const recordData = json.jsonData || json.record?.jsonData || json;
                return new DocumentSnapshot(this.id, recordData, true);
            } catch(e) {
                return new DocumentSnapshot(this.id, null, false);
            }
        }

        async set(data, options = {}) {
            const payload = {
                id: this.id,
                ...data
            };
            const res = await fetch('/api/' + this.collectionPath + '/' + this.id, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            return res.json();
        }

        async update(data) {
            const res = await fetch('/api/' + this.collectionPath + '/' + this.id, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        }

        async delete() {
            const res = await fetch('/api/' + this.collectionPath + '/' + this.id, {
                method: 'DELETE'
            });
            return res.json();
        }

        onSnapshot(callback) {
            this.get().then(callback);
            const evtSource = new EventSource('/api/live');
            evtSource.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    if (!data.collection || data.collection === this.collectionPath) {
                        this.get().then(callback);
                    }
                } catch(e) {}
            };
            return () => evtSource.close();
        }
    }

    class CollectionReference {
        constructor(path) {
            this.path = path;
        }

        doc(id) {
            return new DocumentReference(this.path, id);
        }

        async add(data) {
            const docId = data.id || generateId();
            const docRef = new DocumentReference(this.path, docId);
            await docRef.set(data);
            return docRef;
        }

        async get() {
            try {
                const res = await fetch('/api/' + this.path);
                const json = await res.json();
                const records = json.records || json.data || json.results || [];
                const docs = records.map(r => {
                    let docData = r.jsonData || r;
                    if (typeof docData === 'string') {
                        try { docData = JSON.parse(docData); } catch(e) {}
                    }
                    return new DocumentSnapshot(r.id, docData, true);
                });
                return new QuerySnapshot(docs);
            } catch(e) {
                return new QuerySnapshot([]);
            }
        }

        where(field, op, value) {
            // Returns query object
            return this;
        }

        orderBy(field, direction = 'asc') {
            return this;
        }

        limit(num) {
            return this;
        }

        onSnapshot(callback) {
            this.get().then(callback);
            const evtSource = new EventSource('/api/live');
            evtSource.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    if (!data.collection || data.collection === this.path || data.collection === 'all') {
                        this.get().then(callback);
                    }
                } catch(e) {}
            };
            return () => evtSource.close();
        }
    }

    class FirestoreInstance {
        collection(path) {
            return new CollectionReference(path);
        }
        doc(path) {
            const parts = path.split('/');
            return new DocumentReference(parts[0], parts[1]);
        }
    }

    // --- REALTIME DATABASE IMPLEMENTATION ---
    class DataSnapshot {
        constructor(key, val) {
            this.key = key;
            this._val = val;
        }
        val() {
            return this._val;
        }
        exists() {
            return this._val !== null && this._val !== undefined;
        }
        forEach(cb) {
            if (Array.isArray(this._val)) {
                this._val.forEach((item, idx) => cb(new DataSnapshot(idx, item)));
            } else if (typeof this._val === 'object' && this._val !== null) {
                Object.keys(this._val).forEach(k => cb(new DataSnapshot(k, this._val[k])));
            }
        }
    }

    class DatabaseReference {
        constructor(path) {
            this.path = (path || '').replace(/^\/|\/$/g, '');
        }

        child(subPath) {
            const newPath = this.path ? this.path + '/' + subPath : subPath;
            return new DatabaseReference(newPath);
        }

        push(data) {
            const newKey = generateId();
            const childRef = this.child(newKey);
            if (data !== undefined) {
                childRef.set(data);
            }
            return childRef;
        }

        async set(data) {
            const res = await fetch('/api/' + (this.path || 'root'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        }

        async update(data) {
            const res = await fetch('/api/' + (this.path || 'root'), {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        }

        async remove() {
            const res = await fetch('/api/' + (this.path || 'root'), {
                method: 'DELETE'
            });
            return res.json();
        }

        async once(eventType = 'value') {
            const res = await fetch('/api/' + (this.path || 'root'));
            const json = await res.json();
            return new DataSnapshot(this.path, json.records || json.data || json);
        }

        on(eventType, callback) {
            this.once(eventType).then(callback);
            const evtSource = new EventSource('/api/live');
            evtSource.onmessage = () => {
                this.once(eventType).then(callback);
            };
            return callback;
        }

        off(eventType, callback) {}
    }

    class DatabaseInstance {
        ref(path) {
            return new DatabaseReference(path);
        }
    }

    // --- AUTHENTICATION MOCK (Always Online / Offline User) ---
    class AuthInstance {
        constructor() {
            this.currentUser = {
                uid: 'user_offline_admin_1',
                email: 'admin@school.local',
                displayName: 'مدير النظام',
                emailVerified: true
            };
        }
        onAuthStateChanged(cb) {
            setTimeout(() => cb(this.currentUser), 0);
            return () => {};
        }
        async signInWithEmailAndPassword(email, password) {
            return { user: this.currentUser };
        }
        async createUserWithEmailAndPassword(email, password) {
            return { user: this.currentUser };
        }
        async signOut() {
            return true;
        }
    }

    // --- FIREBASE ROOT OBJECT ---
    const firebase = {
        apps: [],
        initializeApp: function(config) {
            const app = {
                firestore: () => new FirestoreInstance(),
                database: () => new DatabaseInstance(),
                auth: () => new AuthInstance()
            };
            firebase.apps.push(app);
            return app;
        },
        firestore: function() {
            return new FirestoreInstance();
        },
        database: function() {
            return new DatabaseInstance();
        },
        auth: function() {
            return new AuthInstance();
        }
    };

    // Global Bindings
    window.firebase = firebase;
    window.firestore = firebase.firestore();
    window.db = firebase.firestore();
    window.localDB = firebase.firestore();
    window.realtimeDB = firebase.database();

    console.log("🔥 Universal Firebase & Firestore Engine is Fully Loaded & Ready!");
})(window);
        """.trimIndent()
    }

    private fun serveFirebaseSdkScript(output: OutputStream) {
        val jsCode = getFirebaseFullSdkJs()
        val bytes = jsCode.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: application/javascript; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun handleRealtimeSseConnection(output: OutputStream, clientIp: String) {
        val sseHeader = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/event-stream\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: keep-alive\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Headers: Content-Type\r\n\r\n"
        output.write(sseHeader.toByteArray(Charsets.UTF_8))
        output.flush()

        val welcomeEvent = "data: {\"type\": \"connected\", \"status\": \"online\", \"ip\": \"$clientIp\"}\n\n"
        output.write(welcomeEvent.toByteArray(Charsets.UTF_8))
        output.flush()

        sseClients.add(output)

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "⚡ اتصال Firestore / Realtime Live Stream نشط",
                statusCode = 200
            )
        )

        try {
            while (isRunning.get()) {
                Thread.sleep(15000)
                output.write(": ping\n\n".toByteArray(Charsets.UTF_8))
                output.flush()
            }
        } catch (e: Exception) {
            // Client closed stream
        } finally {
            sseClients.remove(output)
        }
    }

    private fun broadcastRealtimeChange(action: String, collection: String, recordId: Long) {
        val payload = JSONObject().apply {
            put("type", "change")
            put("action", action)
            put("collection", collection)
            put("recordId", recordId)
            put("timestamp", System.currentTimeMillis())
        }.toString()

        val eventMessage = "data: $payload\n\n"
        val bytes = eventMessage.toByteArray(Charsets.UTF_8)

        val deadClients = mutableListOf<OutputStream>()
        for (client in sseClients) {
            try {
                client.write(bytes)
                client.flush()
            } catch (e: Exception) {
                deadClients.add(client)
            }
        }
        sseClients.removeAll(deadClients.toSet())
    }

    /**
     * Universal Dynamic REST API & Data Store.
     * Extracts collection name from any path in the world (e.g. /students, /teachers/1, /grades, /orders, /anything)
     * Handles GET, POST, PUT, PATCH, DELETE, OPTIONS seamlessly.
     */
    private fun handleUniversalDatabaseApi(
        output: OutputStream,
        method: String,
        path: String,
        queryString: String,
        body: String,
        clientIp: String
    ) {
        val dao = database.sharedRecordDao()

        val cleanPath = path.removePrefix("/").removeSuffix("/")
        val segments = cleanPath.split("/").filter { it.isNotBlank() }

        val collection = when {
            getQueryParam(queryString, "collection") != null -> getQueryParam(queryString, "collection")!!
            segments.size >= 2 && segments[0] == "api" -> segments[1]
            segments.size >= 2 && segments[0] == "data" -> segments[1]
            segments.size >= 2 && segments[0] == "db" -> segments[1]
            segments.isNotEmpty() -> segments[0]
            else -> "records"
        }

        val pathId = segments.lastOrNull()?.toLongOrNull()

        when (method) {
            "GET" -> {
                runBlocking {
                    if (pathId != null) {
                        val record = dao.getRecordById(pathId)
                        if (record != null) {
                            val json = recordToJsonObject(record).toString(2)
                            sendJsonResponse(output, json, 200)
                        } else {
                            sendJsonResponse(output, "{\"error\": \"Record not found\", \"id\": $pathId}", 404)
                        }
                    } else {
                        val records = if (collection != "general" && collection != "api" && collection != "records") {
                            dao.getRecordsByCollection(collection)
                        } else {
                            dao.getAllRecords()
                        }

                        val jsonArray = JSONArray()
                        records.forEach { record ->
                            jsonArray.put(recordToJsonObject(record))
                        }

                        val responseJson = JSONObject().apply {
                            put("status", "success")
                            put("collection", collection)
                            put("count", records.size)
                            put("records", jsonArray)
                            put("data", jsonArray)
                            put("results", jsonArray)
                            put("items", jsonArray)
                        }.toString(2)

                        sendJsonResponse(output, responseJson, 200)
                    }
                }
            }

            "POST" -> {
                runBlocking {
                    try {
                        var author = "مستخدم ($clientIp)"
                        var content = ""
                        var title: String? = null
                        var targetCollection = collection
                        val rawJson = body.trim()

                        if (rawJson.startsWith("{")) {
                            val obj = JSONObject(rawJson)
                            if (obj.has("author")) author = obj.optString("author", author)
                            if (obj.has("studentName")) author = obj.optString("studentName", author)
                            if (obj.has("teacherName")) author = obj.optString("teacherName", author)
                            if (obj.has("name")) author = obj.optString("name", author)
                            if (obj.has("username")) author = obj.optString("username", author)
                            if (obj.has("title")) title = obj.optString("title")
                            if (obj.has("grade")) title = "درجة: " + obj.optString("grade")
                            if (obj.has("subject")) title = "مادة: " + obj.optString("subject")
                            if (obj.has("content")) content = obj.optString("content")
                            if (obj.has("text")) content = obj.optString("text")
                            if (obj.has("score")) content = "الدرجة: " + obj.optString("score")
                            if (obj.has("status")) content = "الحالة: " + obj.optString("status")
                            if (obj.has("message")) content = obj.optString("message")
                            if (obj.has("collection")) targetCollection = obj.optString("collection", collection)
                            if (content.isBlank() && obj.has("data")) content = obj.get("data").toString()
                            if (content.isBlank()) content = rawJson
                        } else if (rawJson.startsWith("[")) {
                            content = "مجموعة بيانات (${rawJson.length} حرف)"
                        } else {
                            content = rawJson
                        }

                        val record = SharedRecordEntity(
                            collection = targetCollection,
                            author = author,
                            title = title,
                            content = content,
                            jsonData = if (rawJson.isNotBlank()) rawJson else "{}",
                            clientIp = clientIp
                        )

                        val newId = dao.insertRecord(record)
                        val responseJson = JSONObject().apply {
                            put("status", "success")
                            put("id", newId)
                            put("message", "تم حفظ السجل بنجاح")
                            put("record", recordToJsonObject(record.copy(id = newId)))
                            put("data", recordToJsonObject(record.copy(id = newId)))
                        }.toString(2)

                        sendJsonResponse(output, responseJson, 201)
                        broadcastRealtimeChange("insert", targetCollection, newId)
                        onLog(
                            ServerLog(
                                clientIp = clientIp,
                                requestPath = "💾 POST $path (حفظ سجل جديد #$newId في [$targetCollection])",
                                statusCode = 201
                            )
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        val errJson = JSONObject().apply {
                            put("status", "error")
                            put("message", "خطأ في معالجة البيانات: ${e.message}")
                        }.toString()
                        sendJsonResponse(output, errJson, 400)
                    }
                }
            }

            "PUT", "PATCH" -> {
                runBlocking {
                    try {
                        val recordId = pathId
                        if (recordId != null) {
                            val existing = dao.getRecordById(recordId)
                            if (existing != null) {
                                val updated = existing.copy(
                                    content = if (body.isNotBlank()) body else existing.content,
                                    jsonData = if (body.isNotBlank()) body else existing.jsonData
                                )
                                dao.insertRecord(updated)
                                broadcastRealtimeChange("update", existing.collection, recordId)
                                sendJsonResponse(output, "{\"status\": \"updated\", \"id\": $recordId, \"message\": \"تم تحديث البيانات بنجاح\"}", 200)
                                onLog(
                                    ServerLog(
                                        clientIp = clientIp,
                                        requestPath = "✏️ PUT $path (تعديل السجل #$recordId في [${existing.collection}])",
                                        statusCode = 200
                                    )
                                )
                            } else {
                                sendJsonResponse(output, "{\"error\": \"Record not found\"}", 404)
                            }
                        } else {
                            sendJsonResponse(output, "{\"error\": \"Missing record ID\"}", 400)
                        }
                    } catch (e: Exception) {
                        sendJsonResponse(output, "{\"error\": \"${e.message}\"}", 500)
                    }
                }
            }

            "DELETE" -> {
                runBlocking {
                    if (pathId != null) {
                        dao.deleteRecordById(pathId)
                        broadcastRealtimeChange("delete", collection, pathId)
                        val res = JSONObject().apply {
                            put("status", "success")
                            put("message", "تم حذف السجل رقم $pathId بنجاح")
                        }.toString()
                        sendJsonResponse(output, res, 200)
                        onLog(
                            ServerLog(
                                clientIp = clientIp,
                                requestPath = "🗑️ DELETE $path (حذف السجل #$pathId من [$collection])",
                                statusCode = 200
                            )
                        )
                    } else if (collection != "general" && collection != "api" && collection != "records") {
                        dao.deleteRecordsByCollection(collection)
                        broadcastRealtimeChange("clear", collection, 0)
                        sendJsonResponse(output, "{\"status\": \"success\", \"message\": \"تم تفريغ سجلات $collection بالكامل\"}", 200)
                    } else {
                        val res = JSONObject().apply {
                            put("status", "error")
                            put("message", "يرجى تحديد معرف السجل المراد حذفه")
                        }.toString()
                        sendJsonResponse(output, res, 400)
                    }
                }
            }

            else -> {
                sendJsonResponse(output, "{\"error\": \"Method not allowed\"}", 405)
            }
        }
    }

    private fun recordToJsonObject(record: SharedRecordEntity): JSONObject {
        return JSONObject().apply {
            put("id", record.id)
            put("collection", record.collection)
            put("author", record.author)
            put("title", record.title ?: "")
            put("content", record.content)
            put("timestamp", record.timestamp)
            put("clientIp", record.clientIp)
            put("jsonData", try {
                if (record.jsonData.startsWith("{")) JSONObject(record.jsonData)
                else if (record.jsonData.startsWith("[")) JSONArray(record.jsonData)
                else record.jsonData
            } catch (e: Exception) {
                record.jsonData
            })
        }
    }

    private fun getQueryParam(queryString: String, paramName: String): String? {
        if (queryString.isBlank()) return null
        return queryString.split("&").firstOrNull { it.startsWith("$paramName=") }?.substringAfter("=")
    }

    private fun sendJsonResponse(output: OutputStream, json: String, statusCode: Int) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        val statusMsg = when (statusCode) {
            200 -> "200 OK"
            201 -> "201 Created"
            400 -> "400 Bad Request"
            404 -> "404 Not Found"
            405 -> "405 Method Not Allowed"
            else -> "500 Internal Server Error"
        }
        val header = "HTTP/1.1 $statusMsg\r\n" +
                "Content-Type: application/json; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept, Origin\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun sendCorsOk(output: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept, Cache-Control, Origin\r\n" +
                "Access-Control-Max-Age: 86400\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun isAppleProbe(path: String, host: String, userAgent: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        val ua = userAgent.lowercase()
        return h.contains("apple.com") ||
                h.contains("captive.apple.com") ||
                h.contains("airport.us") ||
                h.contains("ibook.info") ||
                h.contains("itools.info") ||
                h.contains("thinkdifferent.us") ||
                h.contains("appleiphonecell.com") ||
                h.contains("icloud.com") ||
                p.contains("hotspot-detect.html") ||
                p.contains("library/test/success.html") ||
                p.contains("canonical.html") ||
                p.contains("bag.xml") ||
                ua.contains("captivenetworksupport") ||
                ua.contains("wispr")
    }

    private fun isAndroidProbe(path: String, host: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        return p.contains("generate_204") ||
                p.contains("gen_204") ||
                p.contains("connectivitycheck") ||
                p.contains("check_network_status") ||
                h.contains("gstatic.com") ||
                h.contains("google.com") ||
                h.contains("android.com") ||
                h.contains("googleapis.com")
    }

    private fun isWindowsOrFirefoxProbe(path: String, host: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        return h.contains("msftconnecttest.com") ||
                h.contains("msftncsi.com") ||
                h.contains("detectportal.firefox.com") ||
                p.contains("ncsi.txt") ||
                p.contains("connecttest.txt") ||
                p.contains("success.txt")
    }

    private fun serveWebRoute(outputStream: OutputStream, clientIp: String, requestPath: String) {
        val rootDir = webRootDirProvider()
        val cleanPath = requestPath.removePrefix("/").ifEmpty { "index.html" }
        var targetFile = File(rootDir, cleanPath)

        if (targetFile.isDirectory) {
            val nestedIndex = File(targetFile, "index.html")
            if (nestedIndex.exists()) {
                targetFile = nestedIndex
            }
        }

        if (targetFile.exists() && targetFile.isFile) {
            serveStaticFile(outputStream, targetFile, clientIp, requestPath)
            return
        }

        val lastSegment = cleanPath.substringAfterLast("/")
        val hasExtension = lastSegment.contains(".") && !lastSegment.startsWith(".")

        if (hasExtension) {
            val foundAsset = findFileRecursively(rootDir, lastSegment)
            if (foundAsset != null) {
                serveStaticFile(outputStream, foundAsset, clientIp, requestPath)
                return
            }
        }

        val rootIndex = File(rootDir, "index.html")
        if (rootIndex.exists() && rootIndex.isFile) {
            serveStaticFile(outputStream, rootIndex, clientIp, requestPath)
        } else {
            send404(outputStream, clientIp, requestPath)
        }
    }

    private fun findFileRecursively(dir: File, targetName: String): File? {
        val files = dir.listFiles() ?: return null
        for (f in files) {
            if (f.isFile && f.name.equals(targetName, ignoreCase = true)) {
                return f
            }
            if (f.isDirectory) {
                val sub = findFileRecursively(f, targetName)
                if (sub != null) return sub
            }
        }
        return null
    }

    private fun serveStaticFile(outputStream: OutputStream, file: File, clientIp: String, requestedPath: String) {
        val mimeType = getMimeType(file.name)
        val isHtml = file.name.endsWith(".html", ignoreCase = true) || file.name.endsWith(".htm", ignoreCase = true)

        if (isHtml) {
            val originalHtml = file.readText(Charsets.UTF_8)
            val injectionScript = "<script>\n${getFirebaseFullSdkJs()}\n</script>"
            val finalHtml = when {
                originalHtml.contains("<head>", ignoreCase = true) -> {
                    originalHtml.replaceFirst("(?i)<head>".toRegex(), "<head>\n$injectionScript")
                }
                originalHtml.contains("<body>", ignoreCase = true) -> {
                    originalHtml.replaceFirst("(?i)<body>".toRegex(), "<body>\n$injectionScript")
                }
                else -> {
                    "$injectionScript\n$originalHtml"
                }
            }

            val bytes = finalHtml.toByteArray(Charsets.UTF_8)
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: text/html; charset=UTF-8\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                    "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                    "Cache-Control: no-cache\r\n" +
                    "Connection: close\r\n\r\n"

            outputStream.write(header.toByteArray(Charsets.UTF_8))
            outputStream.write(bytes)
            outputStream.flush()
        } else {
            val length = file.length()
            val header = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: $mimeType\r\n" +
                    "Content-Length: $length\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                    "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                    "Cache-Control: public, max-age=3600\r\n" +
                    "Connection: close\r\n\r\n"

            outputStream.write(header.toByteArray(Charsets.UTF_8))
            FileInputStream(file).use { fis ->
                fis.copyTo(outputStream, bufferSize = 16384)
            }
            outputStream.flush()
        }

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "📄 $requestedPath (${file.name} - ${file.length() / 1024} KB)",
                statusCode = 200,
                isVideoChunk = false
            )
        )
    }

    private fun serveApplePortal(output: OutputStream, clientIp: String, path: String) {
        val rootDir = webRootDirProvider()
        val indexFile = File(rootDir, "index.html")
        if (indexFile.exists()) {
            serveStaticFile(output, indexFile, clientIp, path)
        } else {
            send404(output, clientIp, path)
        }
    }

    private fun serveAndroidPortalRedirect(output: OutputStream, clientIp: String, path: String, currentPort: Int) {
        val targetUrl = "http://${ipProvider()}:$currentPort"
        val response = "HTTP/1.1 302 Found\r\n" +
                "Location: $targetUrl\r\n" +
                "Content-Length: 0\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun serveGenericCaptiveRedirect(output: OutputStream, clientIp: String, path: String, currentPort: Int) {
        val targetUrl = "http://${ipProvider()}:$currentPort"
        val response = "HTTP/1.1 302 Found\r\n" +
                "Location: $targetUrl\r\n" +
                "Content-Length: 0\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun send404(output: OutputStream, clientIp: String, path: String) {
        val notFoundHtml = "<html><body style='font-family:sans-serif;text-align:center;padding:40px;'>" +
                "<h2>404 - لم يتم العثور على الملف</h2>" +
                "<p>المسار المطلوب: <code>$path</code></p>" +
                "<a href='/'>العودة للصفحة الرئيسية</a>" +
                "</body></html>"
        val bytes = notFoundHtml.toByteArray(Charsets.UTF_8)
        val response = "HTTP/1.1 404 Not Found\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun getMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "html", "htm" -> "text/html; charset=UTF-8"
            "css" -> "text/css; charset=UTF-8"
            "js", "mjs", "jsx", "ts", "tsx" -> "application/javascript; charset=UTF-8"
            "json" -> "application/json; charset=UTF-8"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "svg" -> "image/svg+xml"
            "ico" -> "image/x-icon"
            "webp" -> "image/webp"
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain; charset=UTF-8"
            "xml" -> "application/xml"
            "map" -> "application/json"
            else -> "application/octet-stream"
        }
    }
}
