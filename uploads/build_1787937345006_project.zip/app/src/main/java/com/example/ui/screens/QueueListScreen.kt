package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.CallingState
import com.example.data.model.Patient
import com.example.ui.components.ClinicBottomNavBar
import com.example.ui.components.TvDisplayDialog
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.QueueFilterType

@Composable
fun QueueListScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val pagedPatients by viewModel.pagedPatients.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val liveTotalCount by viewModel.liveTotalCount.collectAsState()
    val waitingCount by viewModel.waitingCount.collectAsState()
    val postponedCount by viewModel.postponedCount.collectAsState()
    val servedCount by viewModel.servedCount.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()
    val totalPages by viewModel.totalPages.collectAsState()
    val currentFilterCount by viewModel.currentFilterCount.collectAsState()
    val pageSize by viewModel.pageSize.collectAsState()
    val nextNumber by viewModel.nextQueueNumber.collectAsState()

    val currentPatient by viewModel.currentPatient.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val callingState by viewModel.callingState.collectAsState()
    val activeCallingPatient by viewModel.activeCallingPatient.collectAsState()

    val showAddDialog by viewModel.showAddPatientDialog.collectAsState()
    val previewPatient by viewModel.previewTicketPatient.collectAsState()
    val showTvDialog by viewModel.showTvDialog.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()

    val isTvServerRunning by viewModel.isTvServerRunning.collectAsState()
    val tvServerUrl by viewModel.tvServerUrl.collectAsState()
    val isTvConnected by viewModel.isTvConnected.collectAsState()
    val isPrinterConnected by viewModel.isPrinterConnected.collectAsState()
    val isHotspotActive by viewModel.isHotspotActive.collectAsState()
    val hotspotSsid by viewModel.hotspotSsid.collectAsState()
    val hotspotPassword by viewModel.hotspotPassword.collectAsState()
    val hotspotStatusMessage by viewModel.hotspotStatusMessage.collectAsState()
    val isHotspotLoading by viewModel.isHotspotLoading.collectAsState()
    val isTvAudioOnly by viewModel.isTvAudioOnly.collectAsState()
    val isQueueStarted by viewModel.isQueueStarted.collectAsState()

    var patientToDelete by remember { mutableStateOf<Patient?>(null) }

    // ضبط اتجاه الواجهة من اليمين إلى اليسار (RTL) لمطابقة التصميم المرفق بالصورة بدقة 100%
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FAFC))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // =========================================================
                // 1. الهيدر العلوي: اسم العيادة والطبيب، زر الحذف، زر +100، ومؤشرات الأجهزة
                // =========================================================
                TopClinicHeaderExact(
                    clinicName = settings.clinicName.ifBlank { "عيادة الشفاء التخصصية" },
                    doctorName = settings.doctorName.ifBlank { "د. أحمد عبدالله" },
                    isTvConnected = isTvConnected,
                    isPrinterConnected = isPrinterConnected,
                    onDeleteAllClick = { viewModel.onOpenResetDialog() },
                    onTvClick = { viewModel.onOpenTvDialog() },
                    onPrinterClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) }
                )

                // شريط النداء الصوتي الحي
                AnimatedVisibility(
                    visible = callingState != CallingState.IDLE,
                    enter = slideInVertically() + fadeIn(),
                    exit = slideOutVertically() + fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(15.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جاري النداء الصوتي للمراجع رقم ${activeCallingPatient?.formattedNumber ?: (currentPatient?.formattedNumber ?: "")}...",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = Color(0xFF22C55E),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // =========================================================
                // 2. بطاقة وضع الاستعداد / البدء (مطابقة للصورة 100%)
                // =========================================================
                StandbyControlCard(
                    waitingCount = waitingCount,
                    isQueueStarted = isQueueStarted,
                    currentPatient = currentPatient,
                    onStartClick = { viewModel.onStartQueueClicked() },
                    onPauseClick = { viewModel.onPauseQueue() },
                    onPostponeCurrentClick = { viewModel.onPostponeCurrentPatient() },
                    onRecallCurrentClick = { viewModel.onRecallCurrentPatient() }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // =========================================================
                // 3. أزرار الفلترة الأفقية (الكل 100 ، في الانتظار 64 ، المؤجلين 14 ، تم استدعاء 22)
                // =========================================================
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterButtonExact(
                        label = "الكل",
                        count = liveTotalCount,
                        isSelected = selectedFilter == QueueFilterType.ALL,
                        onClick = { viewModel.onSelectFilter(QueueFilterType.ALL) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterButtonExact(
                        label = "في الانتظار",
                        count = waitingCount,
                        isSelected = selectedFilter == QueueFilterType.WAITING,
                        onClick = { viewModel.onSelectFilter(QueueFilterType.WAITING) },
                        modifier = Modifier.weight(1.3f)
                    )
                    FilterButtonExact(
                        label = "المؤجلين",
                        count = postponedCount,
                        isSelected = selectedFilter == QueueFilterType.POSTPONED,
                        onClick = { viewModel.onSelectFilter(QueueFilterType.POSTPONED) },
                        modifier = Modifier.weight(1.1f)
                    )
                    FilterButtonExact(
                        label = "تم استدعاء",
                        count = servedCount,
                        isSelected = selectedFilter == QueueFilterType.SERVED,
                        onClick = { viewModel.onSelectFilter(QueueFilterType.SERVED) },
                        modifier = Modifier.weight(1.3f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // =========================================================
                // 4. قائمة بطاقات المراجعين مطابقة للصورة بدقة تامة
                // =========================================================
                if (pagedPatients.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0F172A).copy(alpha = 0.05f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FormatListNumbered,
                                    contentDescription = null,
                                    tint = Color(0xFF0F172A).copy(alpha = 0.5f),
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = when (selectedFilter) {
                                    QueueFilterType.ALL -> "قائمة المراجعين فارغة"
                                    QueueFilterType.WAITING -> "لا يوجد مراجعين في الانتظار"
                                    QueueFilterType.POSTPONED -> "لا يوجد مراجعين مؤجلين"
                                    QueueFilterType.SERVED -> "لم يتم استدعاء أي مراجع بعد"
                                },
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "اضغط على زر (+) لإضافة مراجع جديد",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(pagedPatients, key = { it.id }) { patient ->
                            val isActive = (currentPatient?.id == patient.id) || (activeCallingPatient?.id == patient.id)
                            PatientCardExactMatch(
                                patient = patient,
                                isActive = isActive,
                                onCardClick = { viewModel.onCallSpecificPatient(patient) },
                                onCalendarClick = { viewModel.onOpenTicketPreview(patient) },
                                onDeleteClick = { patientToDelete = patient },
                                onPostponeClick = { viewModel.onPostponeSpecificPatient(patient) },
                                onRestoreClick = { viewModel.onRestorePostponedToQueue(patient) }
                            )
                        }
                        item {
                            Spacer(modifier = Modifier.height(130.dp))
                        }
                    }
                }

                // =========================================================
                // 5. شريط الترقيم المماثل للصورة (التالي | صفحة 1 من 5 | السابق)
                // =========================================================
                if (totalPages > 1 || currentFilterCount > 0) {
                    PaginationBarExactMatch(
                        currentPage = currentPage,
                        totalPages = if (totalPages < 1) 1 else totalPages,
                        totalCount = currentFilterCount,
                        onPrevClick = { viewModel.onPrevPage() },
                        onNextClick = { viewModel.onNextPage() }
                    )
                }

                // =========================================================
                // 6. شريط التنقل السفلي: قائمة المراجعين + الإعدادات
                // =========================================================
                ClinicBottomNavBar(
                    activeScreen = AppScreen.QUEUE_LIST,
                    onQueueClick = { /* Already here */ },
                    onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
                )
            }

            // =========================================================
            // زر الإضافة العائم (+) على جهة اليسار مثل الصورة تماماً
            // =========================================================
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .navigationBarsPadding()
                    .padding(start = 20.dp, bottom = 136.dp)
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1E293B))
                    .clickable { viewModel.onAddPatientClicked() }
                    .shadow(elevation = 6.dp, shape = RoundedCornerShape(16.dp), spotColor = Color(0x55000000))
                    .testTag("fab_add_patient"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "إضافة مراجع",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }

    // =========================================================
    // النوافذ المنبثقة
    // =========================================================
    if (showAddDialog) {
        AddPatientDialog(
            nextQueueNumber = nextNumber,
            initialAutoPrint = settings.autoPrintOnAdd,
            onConfirm = { name, note, shouldPrint ->
                viewModel.onConfirmAddPatient(name, note, shouldPrint)
            },
            onDismiss = { viewModel.onDismissAddPatientDialog() }
        )
    }

    if (previewPatient != null) {
        TicketPreviewDialog(
            patient = previewPatient!!,
            settings = settings,
            onPrintClick = { viewModel.onPrintPreviewTicket() },
            onDismiss = { viewModel.onDismissTicketPreview() }
        )
    }

    if (showTvDialog) {
        TvDisplayDialog(
            isRunning = isTvServerRunning,
            serverUrl = tvServerUrl,
            isHotspotActive = isHotspotActive,
            hotspotSsid = hotspotSsid,
            hotspotPassword = hotspotPassword,
            hotspotStatusMessage = hotspotStatusMessage,
            isHotspotLoading = isHotspotLoading,
            isTvAudioOnly = isTvAudioOnly,
            onToggleServer = { viewModel.onToggleTvServer(it) },
            onToggleHotspot = { viewModel.onToggleLocalHotspot(it) },
            onToggleTvAudioOnly = { viewModel.onToggleTvAudioOnly(it) },
            onRefreshIp = { viewModel.onRefreshTvIp() },
            onDismiss = { viewModel.onDismissTvDialog() }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.onDismissResetDialog() },
            modifier = Modifier.testTag("delete_all_confirm_dialog"),
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFFEF2F2)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = "حذف جميع المراجعين",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف جميع المراجعين من قائمة الدور؟ سيتم ترحيل بيانات الجلسة الحالية تلقائياً إلى صفحة التقارير، وتفريغ القائمة للبدء من جديد.",
                    fontSize = 14.sp,
                    color = Color(0xFF475569),
                    lineHeight = 22.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.onConfirmResetQueue() },
                    modifier = Modifier
                        .height(44.dp)
                        .testTag("confirm_delete_all_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text(
                        text = "تأكيد حذف الجميع",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.onDismissResetDialog() },
                    modifier = Modifier.height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Text(
                        text = "إلغاء",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF475569)
                    )
                }
            }
        )
    }

    patientToDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientToDelete = null },
            title = {
                Text(
                    text = "حذف المراجع",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = NavyDark
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف المراجع رقم ${patient.formattedNumber}${if (patient.name.isNotBlank()) " (${patient.name})" else ""} من القائمة؟",
                    fontSize = 14.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeletePatient(patient)
                        patientToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "حذف", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { patientToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "إلغاء", color = NavyDark, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

/**
 * الشريط العلوي المتطابق مع الصورة:
 * - اليمين: عيادة الشفاء التخصصية وتحتها د. أحمد عبدالله
 * - اليسار: زر حذف الجميع وزر +100 تجريبي
 * - السطر الثاني: كبسولتا حالة شاشة غير متصلة و طابعة غير متصلة مع النقطة على اليسار
 */
@Composable
private fun TopClinicHeaderExact(
    clinicName: String,
    doctorName: String,
    isTvConnected: Boolean,
    isPrinterConnected: Boolean,
    onDeleteAllClick: () -> Unit,
    onTvClick: () -> Unit,
    onPrinterClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 0.5.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // الصف الأول: اسم العيادة والطبيب في اليمين بشكل مريح وكامل، وزر حذف الجميع في أقصى اليسار
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 12.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = clinicName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = doctorName,
                        fontSize = 13.5.sp,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // زر حذف الجميع في أقصى اليسار
                Surface(
                    onClick = onDeleteAllClick,
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFFEE2E2).copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, Color(0xFFFECACA)),
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("delete_all_patients_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "حذف الجميع",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف الجميع",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // الصف الثاني: كبسولتا الأجهزة المتطابقة مع الصورة تماماً
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // كبسولة الشاشة
                DeviceChipExact(
                    label = if (isTvConnected) "شاشة متصلة" else "شاشة غير متصلة",
                    icon = Icons.Default.Tv,
                    isConnected = isTvConnected,
                    onClick = onTvClick,
                    modifier = Modifier.weight(1f)
                )

                // كبسولة الطابعة
                DeviceChipExact(
                    label = if (isPrinterConnected) "طابعة متصلة" else "طابعة غير متصلة",
                    icon = Icons.Default.Print,
                    isConnected = isPrinterConnected,
                    onClick = onPrinterClick,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * كبسولة الأجهزة كما في الصورة (أيقونة على اليمين مع النص، ونقطة رمادية/خضراء على اليسار)
 */
@Composable
private fun DeviceChipExact(
    label: String,
    icon: ImageVector,
    isConnected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
        modifier = modifier.height(38.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // النقطة في أقصى اليسار
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isConnected) Color(0xFF22C55E) else Color(0xFF94A3B8))
            )

            // الأيقونة والنص على اليمين
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF475569)
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(17.dp)
                )
            }
        }
    }
}

/**
 * بطاقة وضع الاستعداد / البدء مع أزرار التحكم بالتأجيل والتشغيل:
 * - اليمين: زر الإيقاف المؤقت الدائري البرتقالي
 * - الوسط: "وضع الاستعداد (الأرقام مخفية)" أو "الدور نشط" مع زر تأجيل المراجع الحالي
 * - اليسار: زر "بدء ▶" الأخضر (أو إيقاف ⏸ عند التشغيل) + زر تأجيل المراجع الحالي
 */
@Composable
private fun StandbyControlCard(
    waitingCount: Int,
    isQueueStarted: Boolean,
    currentPatient: Patient?,
    onStartClick: () -> Unit,
    onPauseClick: () -> Unit,
    onPostponeCurrentClick: () -> Unit,
    onRecallCurrentClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shadowElevation = 0.5.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // اليسار: أزرار البدء / الإيقاف والتأجيل
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // زر البدء الأخضر / الإيقاف البرتقالي
                Button(
                    onClick = {
                        if (isQueueStarted) {
                            onPauseClick()
                        } else {
                            onStartClick()
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isQueueStarted) Color(0xFFD97706) else Color(0xFF16A34A)
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("start_queue_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isQueueStarted) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isQueueStarted) "إيقاف مؤقت" else "بدء",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (isQueueStarted) "إيقاف" else "بدء",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // زر تأجيل المراجع الحالي (يظهر عندما يكون هناك دور نشط)
                if (currentPatient != null) {
                    OutlinedButton(
                        onClick = onPostponeCurrentClick,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color(0xFFFFFBEB),
                            contentColor = Color(0xFFD97706)
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("postpone_current_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FastForward,
                                contentDescription = "تأجيل",
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "تأجيل",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD97706)
                            )
                        }
                    }
                }
            }

            // الوسط: العنوان والعدد
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = if (isQueueStarted && currentPatient != null) {
                        "المراجع الحالي: #${currentPatient.formattedNumber} ${currentPatient.name}"
                    } else if (isQueueStarted) {
                        "الدور نشط (يتم عرض الأسماء)"
                    } else {
                        "وضع الاستعداد (الأرقام مخفية)"
                    },
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (isQueueStarted) {
                        "$waitingCount مراجع في الانتظار"
                    } else {
                        "$waitingCount مراجع بانتظار البدء"
                    },
                    fontSize = 11.5.sp,
                    color = Color(0xFF64748B)
                )
            }

            // اليمين: زر الإيقاف المؤقت الدائري المماثل للصورة
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (isQueueStarted) Color(0xFFDCFCE7) else Color(0xFFFEF3C7))
                    .clickable {
                        if (isQueueStarted) onPauseClick() else onStartClick()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isQueueStarted) Icons.Default.PlayArrow else Icons.Default.Pause,
                    contentDescription = if (isQueueStarted) "نشط الآن" else "وضع الاستعداد",
                    tint = if (isQueueStarted) Color(0xFF16A34A) else Color(0xFFD97706),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

/**
 * زر الفلترة (الكل 100 | في الانتظار 64 | المؤجلين 14 | تم استدعاء 22) متطابق 100% مع الصورة
 */
@Composable
private fun FilterButtonExact(
    label: String,
    count: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) Color(0xFF0F172A) else Color.White,
        border = BorderStroke(1.dp, if (isSelected) Color(0xFF0F172A) else Color(0xFFE2E8F0)),
        modifier = modifier.height(40.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$label $count",
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFF0F172A),
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * بطاقة المراجع المطابقة 100% للتصميم في الصورة المرفقة:
 * - اليمين: مربع الرقم (أزرق داكن للنشط، ورمادي للباقي)
 * - الوسط: "المراجع [الاسم] #[الرقم] ([الرقم])" وتحتها الملاحظة
 * - اليسار: الشارة (نشط الآن / في الانتظار / تم الاستدعاء) بجانبها أيقونة الحذف والتقويم
 */
@Composable
private fun PatientCardExactMatch(
    patient: Patient,
    isActive: Boolean,
    onCardClick: () -> Unit,
    onCalendarClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onPostponeClick: () -> Unit,
    onRestoreClick: () -> Unit
) {
    val isPostponed = patient.isPostponed
    val isCalled = patient.isCalled && !isPostponed

    val borderColor = if (isActive) Color(0xFF93C5FD) else Color(0xFFE2E8F0)
    val borderWidth = if (isActive) 1.5.dp else 1.dp

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() },
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(borderWidth, borderColor),
        shadowElevation = if (isActive) 1.dp else 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // القسم الأيمن: مربع الرقم ومعلومات المراجع
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // مربع الرقم
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isActive) Color(0xFF2563EB) else Color(0xFFF1F5F9)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = patient.formattedNumber,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) Color.White else Color(0xFF0F172A)
                    )
                }

                // اسم المراجع والملاحظة
                Column {
                    val displayName = if (patient.name.isNotBlank()) patient.name else "مراجع بدون اسم"
                    Text(
                        text = "المراجع $displayName #${patient.formattedNumber} (${patient.formattedNumber})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = patient.note.ifBlank { "استشارة طبية" },
                        fontSize = 12.5.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }

            // القسم الأيسر: الشارة وأزرار التأجيل/الإرجاع وأيقونات الإجراءات
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // زر التأجيل أو إعادة الإرجاع للانتظار
                if (isPostponed) {
                    Surface(
                        onClick = onRestoreClick,
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFEFF6FF),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "إرجاع للانتظار",
                                tint = Color(0xFF2563EB),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "إرجاع",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2563EB)
                            )
                        }
                    }
                } else if (!isCalled || isActive) {
                    Surface(
                        onClick = onPostponeClick,
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFFFBEB),
                        border = BorderStroke(1.dp, Color(0xFFFDE68A))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FastForward,
                                contentDescription = "تأجيل المراجع",
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "تأجيل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD97706)
                            )
                        }
                    }
                }

                // الشارة
                when {
                    isActive -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFDCFCE7))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "نشط الآن",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF16A34A)
                            )
                        }
                    }
                    isPostponed -> {
                        Text(
                            text = "مؤجل",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD97706)
                        )
                    }
                    isCalled -> {
                        Text(
                            text = "تم الاستدعاء",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF64748B)
                        )
                    }
                    else -> {
                        Text(
                            text = "في الانتظار",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2563EB)
                        )
                    }
                }

                // أيقونة الحذف
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "حذف",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier
                        .size(20.dp)
                        .clickable { onDeleteClick() }
                )

                // أيقونة التقويم / التذكرة
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = "تذكرة",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier
                        .size(20.dp)
                        .clickable { onCalendarClick() }
                )
            }
        }
    }
}

/**
 * شريط الترقيم المتطابق 100% مع الصورة:
 * - اليمين: زر "السابق →"
 * - الوسط: "صفحة 1 من 5" وتحتها "(100 مراجع)"
 * - اليسار: زر "← التالي"
 */
@Composable
private fun PaginationBarExactMatch(
    currentPage: Int,
    totalPages: Int,
    totalCount: Int,
    onPrevClick: () -> Unit,
    onNextClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // اليمين: زر السابق
            Surface(
                onClick = onPrevClick,
                enabled = currentPage > 1,
                shape = RoundedCornerShape(10.dp),
                color = Color.White,
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.height(38.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "السابق",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (currentPage > 1) Color(0xFF475569) else Color(0xFFCBD5E1)
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "السابق",
                        tint = if (currentPage > 1) Color(0xFF475569) else Color(0xFFCBD5E1),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // الوسط: صفحة X من Y
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "صفحة $currentPage من $totalPages",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = "($totalCount مراجع)",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }

            // اليسار: زر التالي
            Surface(
                onClick = onNextClick,
                enabled = currentPage < totalPages,
                shape = RoundedCornerShape(10.dp),
                color = if (currentPage < totalPages) Color(0xFF0F172A) else Color(0xFF94A3B8),
                modifier = Modifier.height(38.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "التالي",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "التالي",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
