# Firebase & Firestore Keep Rules
-keep class com.google.firebase.** { *; }
-keepclassmembers class com.google.firebase.** { *; }
-keep enum com.google.firebase.** { *; }

-keep class com.google.firestore.** { *; }
-keepclassmembers class com.google.firestore.** { *; }

-keep class com.google.android.gms.** { *; }
-keepclassmembers class com.google.android.gms.** { *; }

-dontwarn com.google.firebase.**
-dontwarn com.google.firestore.**
-dontwarn com.google.android.gms.**

# App Data Models & Room Keep Rules
-keep class com.example.data.** { *; }
-keepclassmembers class com.example.data.** { *; }
-keep enum com.example.data.** { *; }

-keep class com.example.aldion.** { *; }
-keepclassmembers class com.example.aldion.** { *; }

-keep class com.example.Aldion** { *; }
-keepclassmembers class com.example.Aldion** { *; }

-keep class com.example.BabyConfig { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
-keep class androidx.room.** { *; }
-keepclassmembers class androidx.room.** { *; }
-dontwarn androidx.room.**

# Kotlin Coroutines & Moshi
-keep class kotlinx.coroutines.** { *; }
-keepclassmembers class kotlinx.coroutines.** { *; }
-keep class com.squareup.moshi.** { *; }
-keepclassmembers class com.squareup.moshi.** { *; }

# Keep annotations for Firestore POJO serialization
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

