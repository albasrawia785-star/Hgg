package com.example.ui.screens.late

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.LateCustomer
import com.example.data.model.OperationType
import com.example.data.model.OperationWithCustomer
import com.example.data.repository.DebtRepository
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LateCustomersViewModel(
    private val repository: DebtRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiEvent = MutableSharedFlow<String>()
    val uiEvent: SharedFlow<String> = _uiEvent.asSharedFlow()

    val lateCustomers: StateFlow<List<LateCustomer>> = combine(
        repository.allCustomers,
        repository.allOperationsWithCustomer,
        settingsRepository.overdueDays
    ) { customers: List<Customer>, operationsWithCustomer: List<OperationWithCustomer>, threshold: Int ->
        val now = System.currentTimeMillis()
        val oneDayMs = 1000L * 60 * 60 * 24

        customers
            .filter { it.debtAmount > 0 }
            .mapNotNull { customer ->
                val customerDebtOps = operationsWithCustomer
                    .map { it.operation }
                    .filter { it.customerId == customer.id && it.type == OperationType.DEBT }

                val lastDebtTime = customerDebtOps.maxOfOrNull { it.dateTime }

                if (lastDebtTime != null) {
                    val daysPassed = ((now - lastDebtTime) / oneDayMs).toInt().coerceAtLeast(0)
                    if (daysPassed > threshold) {
                        LateCustomer(
                            customer = customer,
                            daysOverdue = daysPassed,
                            lastDebtDate = lastDebtTime
                        )
                    } else null
                } else null
            }
            .sortedByDescending { it.daysOverdue }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun addOperation(
        customerId: Long,
        type: OperationType,
        amount: Long,
        note: String,
        onSuccess: () -> Unit,
        onError: ((String) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val result = repository.addOperation(
                customerId = customerId,
                type = type,
                amount = amount,
                note = note
            )

            result.onSuccess { opResult ->
                val typeStr = if (type == OperationType.DEBT) "دين جديد" else "تسديد"
                _uiEvent.emit("تم إضافـة $typeStr بنجاح للمدين ${opResult.updatedCustomer.name}")
                onSuccess()
            }.onFailure { e ->
                val err = e.message ?: "فشلت العملية"
                _uiEvent.emit("خطأ: $err")
                onError?.invoke(err)
            }
        }
    }

    class Factory(
        private val repository: DebtRepository,
        private val settingsRepository: SettingsRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LateCustomersViewModel(repository, settingsRepository) as T
        }
    }
}
