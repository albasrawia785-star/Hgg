package com.example.ui.screens.login

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.Aldion
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Color Palette for World-Class Fintech UI
private val BluePrimary = Color(0xFF2563EB)
private val PurpleAccent = Color(0xFF7C3AED)
private val GlassBg = Color(0xFAF8FAFC)
private val BorderGlass = Color(0xFFE2E8F0)
private val BorderGlassFocused = Color(0xFF8B5CF6)

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val coroutineScope = rememberCoroutineScope()

    var usernameInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var isUsernameFocused by remember { mutableStateOf(false) }
    var isPasswordFocused by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var isSuccess by remember { mutableStateOf(false) }
    var isError by remember { mutableStateOf(false) }

    fun performLogin() {
        if (isLoading || isSuccess) return
        focusManager.clearFocus()

        if (usernameInput.isBlank() || passwordInput.isBlank()) {
            errorMessage = "يرجى إدخال اسم المستخدم وكلمة السر"
            isError = true
            return
        }

        coroutineScope.launch {
            isLoading = true
            isError = false
            errorMessage = null

            val app = context.applicationContext as? com.example.DebtApplication
            val firebaseMgr = app?.firebaseManager ?: com.example.AldionFirebaseManager()
            val loginResult = firebaseMgr.loginManager(usernameInput, passwordInput)

            isLoading = false
            when (loginResult) {
                is com.example.data.model.LoginResult.Success -> {
                    isSuccess = true
                    app?.settingsRepository?.saveUserSession(loginResult.manager)
                    Toast.makeText(context, "أهلاً بك، تم تسجيل الدخول بنجاح", Toast.LENGTH_SHORT).show()
                    delay(800)
                    onLoginSuccess()
                }
                is com.example.data.model.LoginResult.Disabled -> {
                    isError = true
                    errorMessage = "حسابك معطل، يرجى التواصل مع المدير العام"
                }
                is com.example.data.model.LoginResult.InvalidCredentials -> {
                    isError = true
                    errorMessage = "اسم المستخدم أو كلمة السر غير صحيحة"
                }
                is com.example.data.model.LoginResult.Error -> {
                    isError = true
                    errorMessage = loginResult.message
                }
            }
        }
    }

    Surface(
        color = Color.White,
        modifier = modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Futuristic Soft Ambient Background Canvas (Subtle Geometric Orbs & Gradients)
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Top Left Purple Orb
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x187C3AED), Color.Transparent),
                        center = Offset(w * 0.15f, h * 0.12f),
                        radius = w * 0.55f
                    )
                )

                // Top Right Blue Orb
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x182563EB), Color.Transparent),
                        center = Offset(w * 0.85f, h * 0.25f),
                        radius = w * 0.60f
                    )
                )

                // Bottom Ambient Glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x108B5CF6), Color.Transparent),
                        center = Offset(w * 0.5f, h * 0.9f),
                        radius = w * 0.7f
                    )
                )
            }

            // Main Scrollable Content Container (Vertically Centered Layout)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // --- TOP AREA: App Logo Pill ---
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Spacer(modifier = Modifier.height(8.dp))

                    // Sleek Brand Pill Badge
                    Box(
                        modifier = Modifier
                            .shadow(2.dp, shape = CircleShape, ambientColor = Color(0x1A2563EB))
                            .clip(CircleShape)
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(Color(0xFFEFF6FF), Color(0xFFF3E8FF))
                                )
                            )
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(
                                        brush = Brush.linearGradient(
                                            listOf(BluePrimary, PurpleAccent)
                                        ),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = Aldion.SHOP_NAME,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3D AI Financial Assistant Mascot
                    InteractiveMascotCharacter(
                        isUsernameFocused = isUsernameFocused,
                        usernameLength = usernameInput.length,
                        isPasswordFocused = isPasswordFocused,
                        isPasswordVisible = passwordVisible,
                        isLoading = isLoading,
                        isSuccess = isSuccess,
                        isError = isError,
                        characterSize = 140.dp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Welcome Headline & Subtitle
                    Text(
                        text = "مرحباً بعودتك",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimaryDark
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "سجل الدخول للوصول إلى بياناتك المالية بكل أمان.",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal,
                        color = TextSecondaryDark
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- MIDDLE AREA: Glassmorphism Input Fields ---
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Username Field (Glassmorphism Style with 24dp Corners)
                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = {
                            usernameInput = it
                            errorMessage = null
                            isError = false
                        },
                        placeholder = {
                            Text("اسم المستخدم", color = TextSecondaryDark.copy(alpha = 0.7f), fontSize = 14.sp)
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = if (isUsernameFocused) PurpleAccent else TextSecondaryDark
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(2.dp, shape = RoundedCornerShape(24.dp), ambientColor = Color(0x0F000000))
                            .onFocusChanged { state ->
                                isUsernameFocused = state.isFocused
                            },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = GlassBg,
                            focusedBorderColor = BorderGlassFocused,
                            unfocusedBorderColor = BorderGlass,
                            focusedLabelColor = PurpleAccent
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Password Field (Glassmorphism Style with 24dp Corners)
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            errorMessage = null
                            isError = false
                        },
                        placeholder = {
                            Text("كلمة السر", color = TextSecondaryDark.copy(alpha = 0.7f), fontSize = 14.sp)
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (isPasswordFocused) PurpleAccent else TextSecondaryDark
                            )
                        },
                        trailingIcon = {
                            val image = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = image,
                                    contentDescription = if (passwordVisible) "إخفاء كلمة السر" else "إظهار كلمة السر",
                                    tint = TextSecondaryDark
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = { performLogin() }
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(2.dp, shape = RoundedCornerShape(24.dp), ambientColor = Color(0x0F000000))
                            .onFocusChanged { state ->
                                isPasswordFocused = state.isFocused
                            },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = GlassBg,
                            focusedBorderColor = BorderGlassFocused,
                            unfocusedBorderColor = BorderGlass,
                            focusedLabelColor = PurpleAccent
                        )
                    )

                    // Error Toast Message
                    AnimatedVisibility(
                        visible = errorMessage != null,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        if (errorMessage != null) {
                            Text(
                                text = errorMessage!!,
                                color = CrimsonRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(top = 10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Gradient Login Button (#2563EB -> #7C3AED, 58dp height, 28dp pill)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .shadow(
                                elevation = if (isLoading || isSuccess) 2.dp else 6.dp,
                                shape = RoundedCornerShape(28.dp),
                                spotColor = Color(0x407C3AED)
                            )
                            .clip(RoundedCornerShape(28.dp))
                            .background(
                                brush = if (isSuccess) {
                                    Brush.horizontalGradient(listOf(EmeraldGreen, Color(0xFF059669)))
                                } else {
                                    Brush.horizontalGradient(listOf(BluePrimary, PurpleAccent))
                                }
                            )
                            .clickable(
                                enabled = !isLoading && !isSuccess,
                                onClick = { performLogin() }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.White,
                                strokeWidth = 2.5.dp
                            )
                        } else if (isSuccess) {
                            Text(
                                text = "تم التسجيل بنجاح! ✓",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                        } else {
                            Text(
                                text = "تسجيل الدخول",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Forgot Password Button
                    TextButton(onClick = {
                        Toast.makeText(context, "تواصل مع مسؤول النظام لإعادة تعيين كلمة السر", Toast.LENGTH_SHORT).show()
                    }) {
                        Text(
                            text = "نسيت كلمة المرور؟",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = PurpleAccent
                        )
                    }
                }
            }
        }
    }
}
