package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Requirement: 12dp rounded edges across cards and controls
val AppShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

private val LightColorScheme = lightColorScheme(
    primary = RoyalBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEFF6FF),
    onPrimaryContainer = TextPrimaryDark,
    secondary = EmeraldGreen,
    onSecondary = Color.White,
    tertiary = OrangeDebt,
    onTertiary = Color.White,
    error = CrimsonRed,
    onError = Color.White,
    background = SurfaceLight,
    onBackground = TextPrimaryDark,
    surface = CardSurfaceLight,
    onSurface = TextPrimaryDark,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = TextSecondaryDark,
    outline = BorderLight
)

@Composable
fun DebtTrackerTheme(
    darkTheme: Boolean = false, // Dark mode disabled completely per user requirement
    content: @Composable () -> Unit
) {
    // Always force LightColorScheme
    MaterialTheme(
        colorScheme = LightColorScheme,
        shapes = AppShapes,
        typography = Typography,
        content = content
    )
}
