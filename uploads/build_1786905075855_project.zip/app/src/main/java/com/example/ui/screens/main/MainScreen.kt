package com.example.ui.screens.main

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Tune
import com.example.util.formatDateOnly
import com.example.util.sendWhatsAppReminder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.Aldion
import com.example.BabyConfig

import com.example.data.model.Customer
import com.example.data.model.Operation
import com.example.data.model.OperationType
import com.example.util.formatDateTime
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DangerRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GradientEndBlue
import com.example.ui.theme.GradientStartBlue
import com.example.ui.theme.OrangeDebt
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceLight
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.WarningAmber
import com.example.util.formatCurrency
import com.example.util.formatWithCommas

import androidx.compose.material.icons.filled.WorkspacePremium

enum class FilterTab(val title: String) {
    ALL("الكل"),
    ACTIVE_DEBT("عليها ديون"),
    ZERO_DEBT("خالي من الدين"),
    HIGH_DEBT("ديون مرتفعة")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val totalDebt by viewModel.totalDebt.collectAsStateWithLifecycle()
    val customerCount by viewModel.customerCount.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isNotificationsEnabled by viewModel.isNotificationsEnabled.collectAsStateWithLifecycle()
    val highDebtThreshold by viewModel.highDebtThreshold.collectAsStateWithLifecycle()

    var selectedFilterTab by remember { mutableStateOf(FilterTab.ALL) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showSubscriptionDialog by remember { mutableStateOf(false) }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }
    var customerForOperation by remember { mutableStateOf<Pair<Customer, OperationType>?>(null) }
    var customerForStatement by remember { mutableStateOf<Customer?>(null) }
    var zeroDebtCustomerToDelete by remember { mutableStateOf<Customer?>(null) }

    val filteredCustomers = remember(customers, selectedFilterTab, highDebtThreshold) {
        val baseList = when (selectedFilterTab) {
            FilterTab.ALL -> customers
            FilterTab.ACTIVE_DEBT -> customers.filter { it.debtAmount > 0 }
            FilterTab.ZERO_DEBT -> customers.filter { it.debtAmount == 0L }
            FilterTab.HIGH_DEBT -> customers.filter { it.debtAmount >= highDebtThreshold }
        }
        baseList.sortedWith(
            compareBy<Customer> { it.debtAmount == 0L }
                .thenByDescending { it.debtAmount }
                .thenByDescending { it.id }
        )
    }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { event ->
            when (event) {
                is UiMessage.ShowToast -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
                is UiMessage.PromptZeroDebtDelete -> {
                    zeroDebtCustomerToDelete = event.customer
                }
                is UiMessage.ShowSubscriptionDialog -> {
                    showSubscriptionDialog = true
                }
            }
        }
    }

    Scaffold(
        containerColor = SurfaceLight,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // 1. Header (Welcome + Profile + Notifications)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Bell Notification Toggle (Left)
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.clickable { viewModel.toggleNotifications() }
                    ) {
                        Icon(
                            imageVector = if (isNotificationsEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                            contentDescription = if (isNotificationsEnabled) "إيقاف التنبيهات" else "تشغيل التنبيهات",
                            tint = if (isNotificationsEnabled) RoyalBlue else TextSecondaryDark,
                            modifier = Modifier.size(20.dp)
                        )
                        if (isNotificationsEnabled) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .background(RoyalBlue, CircleShape)
                                    .align(Alignment.TopEnd)
                                    .padding(2.dp)
                            )
                        }
                    }
                }

                // Title / Greeting (Right)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = Aldion.WELCOME_TEXT,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextPrimaryDark
                            )
                        )
                        Text(
                            text = Aldion.SHOP_NAME,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                color = TextSecondaryDark
                            )
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = CircleShape,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = RoyalBlue,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }

            // 2. Ultra-Compact FinTech Total Debt Banner (Slim & Space Efficient)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFF0F172A),
                                Color(0xFF1E3A8A),
                                Color(0xFF2563EB)
                            )
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Right Side: Total Debt Amount
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF22C55E), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "إجمالي الديون",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = totalDebt.formatWithCommas(),
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "د.ع",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    }

                    // Left Side: Active Debtors Pill
                    val activeCount = customers.count { it.debtAmount > 0 }
                    Surface(
                        color = Color.White.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "النشطون: $activeCount / $customerCount",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3. Compact Search Bar + Add Customer Button Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Search Field (Expanded)
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp),
                    placeholder = {
                        Text("بحث باسم المدين...", color = TextSecondaryDark, fontSize = 12.sp)
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "مسح",
                                    tint = TextSecondaryDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                // Add Customer Button
                Button(
                    onClick = {
                        if (Aldion.canAddCustomer(customerCount)) {
                            showAddCustomerDialog = true
                        } else {
                            showSubscriptionDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RoyalBlue,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    modifier = Modifier.height(46.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "+ إضافة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 4. Horizontal Filter Chips (تصفية سريعة)
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(FilterTab.values()) { tab ->
                    val count = when (tab) {
                        FilterTab.ALL -> customers.size
                        FilterTab.ACTIVE_DEBT -> customers.count { it.debtAmount > 0 }
                        FilterTab.ZERO_DEBT -> customers.count { it.debtAmount == 0L }
                        FilterTab.HIGH_DEBT -> customers.count { it.debtAmount >= highDebtThreshold }
                    }
                    val isSelected = tab == selectedFilterTab
                    val chipBg = if (isSelected) RoyalBlue else Color.White
                    val chipText = if (isSelected) Color.White else TextPrimaryDark
                    val chipBorder = if (isSelected) RoyalBlue else BorderLight

                    Surface(
                        onClick = { selectedFilterTab = tab },
                        color = chipBg,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, chipBorder),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${tab.title} ($count)",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = chipText
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 6. Customer List
            if (filteredCustomers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = CircleShape,
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = RoyalBlue,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (searchQuery.isNotEmpty()) "لا توجد نتائج تطابق البحث" else "لا يوجد مدينين في هذه القائمة حالياً",
                            color = TextSecondaryDark,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        if (searchQuery.isEmpty() && selectedFilterTab == FilterTab.ALL) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    if (Aldion.canAddCustomer(customerCount)) {
                                        showAddCustomerDialog = true
                                    } else {
                                        showSubscriptionDialog = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إضافة أول مدين", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 80.dp)
                ) {
                    items(
                        items = filteredCustomers,
                        key = { it.id }
                    ) { customer ->
                        CustomerCard(
                            customer = customer,
                            highDebtThreshold = highDebtThreshold,
                            onAddDebt = {
                                customerForOperation = Pair(customer, OperationType.DEBT)
                            },
                            onPayment = {
                                customerForOperation = Pair(customer, OperationType.PAYMENT)
                            },
                            onEdit = { customerToEdit = customer },
                            onDelete = { customerToDelete = customer },
                            onDeleteZeroDebt = { zeroDebtCustomerToDelete = customer },
                            onViewOperations = { customerForStatement = customer }
                        )
                    }
                }
            }
        }
    }

    // 1. Add Customer Dialog Sheet (Matches Reference Image)
    if (showAddCustomerDialog) {
        AddCustomerDialog(
            onDismiss = { showAddCustomerDialog = false },
            onConfirm = { name, phone, initialDebt, onSuccess, onError ->
                viewModel.addCustomer(
                    name = name,
                    phone = phone,
                    initialDebt = initialDebt,
                    onSuccess = {
                        showAddCustomerDialog = false
                        onSuccess()
                    },
                    onError = onError
                )
            }
        )
    }

    // 1.5 Subscription Required Dialog (Max 3 Customers)
    if (showSubscriptionDialog) {
        AlertDialog(
            onDismissRequest = { showSubscriptionDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = null,
                    tint = RoyalBlue,
                    modifier = Modifier.size(38.dp)
                )
            },
            title = {
                Text(
                    text = "النسخة الكاملة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimaryDark
                )
            },
            text = {
                Text(
                    text = Aldion.SUBSCRIPTION_REQUIRED_MESSAGE + " للتمتع بكافة مميزات البرنامج بإضافة عدد غير محدود من المدينين.",
                    fontSize = 14.sp,
                    color = TextSecondaryDark,
                    lineHeight = 22.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = { showSubscriptionDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("حسناً، فهمت", fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(22.dp)
        )
    }

    // 2. Edit Customer Dialog
    customerToEdit?.let { customer ->
        EditCustomerDialog(
            customer = customer,
            onDismiss = { customerToEdit = null },
            onConfirm = { updatedCustomer, onSuccess, onError ->
                viewModel.updateCustomer(
                    updatedCustomer,
                    onSuccess = {
                        customerToEdit = null
                        onSuccess()
                    },
                    onError = onError
                )
            }
        )
    }

    // 3. Delete Customer Confirmation Dialog
    customerToDelete?.let { customer ->
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = { Text("تأكيد الحذف", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت تأكد من حذف المدين \"${customer.name}\" وكل سجل عملياته؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomer(customer)
                        customerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToDelete = null }) {
                    Text("إلغاء")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }

    // 4. Add Operation Dialog (Matches "دين جديد" Card in Reference Image)
    customerForOperation?.let { (customer, type) ->
        OperationDialog(
            customer = customer,
            type = type,
            onDismiss = { customerForOperation = null },
            onSave = { amount, note, onSuccess, onError ->
                viewModel.addOperation(
                    customerId = customer.id,
                    type = type,
                    amount = amount,
                    note = note,
                    onSuccess = {
                        customerForOperation = null
                        onSuccess()
                    },
                    onError = onError
                )
            }
        )
    }


    // 5. Zero Debt Delete Confirmation Dialog
    zeroDebtCustomerToDelete?.let { customer ->
        AlertDialog(
            onDismissRequest = { zeroDebtCustomerToDelete = null },
            title = { Text("تم تسديد جميع الديون!", fontWeight = FontWeight.Bold) },
            text = {
                Text("وصل إجمالي دين المدين \"${customer.name}\" إلى صفر (0 ${BabyConfig.CURRENCY}).\nهل ترغب في حذف المدين أم الإبقاء عليه؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomer(customer)
                        zeroDebtCustomerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text("حذف المدين")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { zeroDebtCustomerToDelete = null }) {
                    Text("الاحتفاظ بالمدين")
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }

    // 6. Customer Operations / Account Statement Dialog
    customerForStatement?.let { customer ->
        CustomerOperationsDialog(
            customer = customer,
            viewModel = viewModel,
            onDismiss = { customerForStatement = null }
        )
    }
}

@Composable
fun CustomerCard(
    customer: Customer,
    highDebtThreshold: Long = 100000L,
    onAddDebt: () -> Unit,
    onPayment: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onDeleteZeroDebt: () -> Unit,
    onViewOperations: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val isZero = customer.debtAmount == 0L
    val isHighDebt = customer.debtAmount >= highDebtThreshold
    val statusColor = when {
        isZero -> SuccessGreen
        isHighDebt -> DangerRed
        else -> WarningAmber
    }

    val cardGradient = when {
        isZero -> Brush.verticalGradient(
            colors = listOf(
                Color.White,
                Color(0xFFF0FDF4)
            )
        )
        isHighDebt -> Brush.verticalGradient(
            colors = listOf(
                Color.White,
                Color(0xFFFFF1F2)
            )
        )
        else -> Brush.verticalGradient(
            colors = listOf(
                Color.White,
                Color(0xFFF8FAFC)
            )
        )
    }

    val cardBorderColor = statusColor.copy(alpha = 0.25f)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onViewOperations() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, cardBorderColor)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(brush = cardGradient)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Vertical Colored Status Indicator Bar
                Box(
                    modifier = Modifier
                        .width(5.dp)
                        .height(118.dp)
                        .background(statusColor)
                )

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    // Top Row: Avatar + Name + Phone + Options Menu
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            // Avatar Circle with gradient background
                            val isEven = customer.id % 2L == 0L
                            val avatarGradient = if (isEven) {
                                Brush.linearGradient(colors = listOf(Color(0xFFDCFCE7), Color(0xFFBBF7D0)))
                            } else {
                                Brush.linearGradient(colors = listOf(Color(0xFFEFF6FF), Color(0xFFDBEAFE)))
                            }
                            val avatarTint = if (isEven) SuccessGreen else PrimaryBlue

                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(avatarGradient),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = avatarTint,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = customer.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark,
                                        fontSize = 15.sp
                                    ),
                                    maxLines = 1
                                )
                                if (!customer.phone.isNullOrBlank()) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(top = 1.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Phone,
                                            contentDescription = null,
                                            modifier = Modifier.size(11.dp),
                                            tint = TextSecondaryDark
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = customer.phone ?: "",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondaryDark,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Options Menu Button
                        Box {
                            IconButton(
                                onClick = { showMenu = true },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "خيارات",
                                    tint = TextSecondaryDark,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("كشف حساب") },
                                    onClick = {
                                        showMenu = false
                                        onViewOperations()
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.History,
                                            contentDescription = null,
                                            tint = PrimaryBlue
                                        )
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("تذكير واتساب") },
                                    onClick = {
                                        showMenu = false
                                        sendWhatsAppReminder(
                                            context = context,
                                            phone = customer.phone,
                                            customerName = customer.name,
                                            debtAmount = customer.debtAmount,
                                            dueDate = System.currentTimeMillis().formatDateOnly()
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Send,
                                            contentDescription = null,
                                            tint = Color(0xFF25D366)
                                        )
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("تعديل") },
                                    onClick = {
                                        showMenu = false
                                        onEdit()
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = null,
                                            tint = PrimaryBlue
                                        )
                                    }
                                )
                                if (customer.debtAmount == 0L) {
                                    DropdownMenuItem(
                                        text = { Text("حذف المدين") },
                                        onClick = {
                                            showMenu = false
                                            onDeleteZeroDebt()
                                        },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = null,
                                                tint = SuccessGreen
                                            )
                                        }
                                    )
                                } else {
                                    DropdownMenuItem(
                                        text = { Text("حذف النهائي") },
                                        onClick = {
                                            showMenu = false
                                            onDelete()
                                        },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = null,
                                                tint = DangerRed
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Middle Row: Debt Amount + Status Badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val amountColor = if (isZero) SuccessGreen else DangerRed

                        Text(
                            text = customer.debtAmount.formatWithCommas() + " د.ع",
                            color = amountColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )

                        // Status Badge Pill with subtle tinting
                        Surface(
                            color = statusColor.copy(alpha = 0.12f),
                            shape = CircleShape
                        ) {
                            Text(
                                text = if (isZero) "خالي من الدين" else if (isHighDebt) "دين مرتفع" else "مطلوب",
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Action Buttons Row ("+ دين" & "تسديد")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Right Button: "+ إضافة دين"
                        Button(
                            onClick = onAddDebt,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFEFF6FF),
                                contentColor = PrimaryBlue
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = PrimaryBlue
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة دين", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Left Button: "تسديد"
                        Button(
                            onClick = onPayment,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFDCFCE7),
                                contentColor = SuccessGreen
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Payment,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = SuccessGreen
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تسديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// 1. Add Customer Dialog Sheet (Matches Bottom-Middle Image Exactly)
@Composable
fun AddCustomerDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, phone: String?, initialDebt: Long, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var initialDebt by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = { if (!isLoading) onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Title Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إضافة مدين جديد",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    )
                    IconButton(
                        onClick = onDismiss,
                        enabled = !isLoading
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "إغلاق",
                            tint = if (isLoading) BorderLight else TextSecondaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Error Message Banner
                if (errorMessage != null) {
                    Surface(
                        color = Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = CrimsonRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = errorMessage!!,
                                color = CrimsonRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Field 1: Customer Name
                Text("اسم المدين", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    enabled = !isLoading,
                    placeholder = { Text("اكتب اسم المدين", color = TextSecondaryDark) },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = TextSecondaryDark) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Field 2: Phone Number
                Text("رقم الهاتف (اختياري)", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    enabled = !isLoading,
                    placeholder = { Text("اكتب رقم الهاتف", color = TextSecondaryDark) },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = TextSecondaryDark) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Field 3: Initial Debt Amount (Mandatory)
                Text("مبلغ الدين الأولي", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CrimsonRed)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = initialDebt,
                    onValueChange = { input ->
                        val cleanDigits = input.replace(",", "").filter { it.isDigit() }
                        if (cleanDigits.isEmpty()) {
                            initialDebt = ""
                        } else if (cleanDigits.length <= 15) {
                            cleanDigits.toLongOrNull()?.let { number ->
                                initialDebt = number.formatWithCommas()
                            }
                        }
                    },
                    enabled = !isLoading,
                    placeholder = { Text("أدخل مبلغ الدين الأولي", color = TextSecondaryDark) },
                    leadingIcon = {
                        Text(
                            text = BabyConfig.CURRENCY,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondaryDark,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                val parsedInitialDebt = initialDebt.replace(",", "").toLongOrNull() ?: 0L
                val isValid = name.isNotBlank()

                // Action Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        enabled = !isLoading,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = TextSecondaryDark)
                    }

                    Button(
                        onClick = {
                            if (isLoading) return@Button
                            Log.d("AldionUI", ">>> [UI] User clicked Save Customer Button | Name: '$name', Phone: '$phone', InitialDebt: $parsedInitialDebt")
                            isLoading = true
                            errorMessage = null
                            onConfirm(name, phone, parsedInitialDebt, {
                                Log.d("AldionUI", ">>> [UI] Customer save confirmed. Closing dialog...")
                                isLoading = false
                            }, { error ->
                                Log.e("AldionUI", ">>> [UI] Customer save failed. Displaying error inside dialog: '$error'")
                                isLoading = false
                                errorMessage = error
                            })
                        },
                        enabled = isValid && !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري الحفظ...", fontWeight = FontWeight.Bold)
                        } else {
                            Text("حفظ", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditCustomerDialog(
    customer: Customer,
    onDismiss: () -> Unit,
    onConfirm: (updatedCustomer: Customer, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit
) {
    var name by remember { mutableStateOf(customer.name) }
    var phone by remember { mutableStateOf(customer.phone ?: "") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = { if (!isLoading) onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تعديل بيانات المدين",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    )
                    IconButton(onClick = onDismiss, enabled = !isLoading) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "إغلاق",
                            tint = if (isLoading) BorderLight else TextSecondaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (errorMessage != null) {
                    Surface(
                        color = Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = errorMessage!!, color = CrimsonRed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    enabled = !isLoading,
                    label = { Text("اسم المدين") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    enabled = !isLoading,
                    label = { Text("رقم الهاتف") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        enabled = !isLoading,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = TextSecondaryDark)
                    }

                    Button(
                        onClick = {
                            if (isLoading) return@Button
                            isLoading = true
                            errorMessage = null
                            onConfirm(
                                customer.copy(name = name, phone = phone),
                                {
                                    isLoading = false
                                    onDismiss()
                                },
                                { err ->
                                    isLoading = false
                                    errorMessage = err
                                }
                            )
                        },
                        enabled = name.isNotBlank() && !isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري التحديث...", fontWeight = FontWeight.Bold)
                        } else {
                            Text("تحديث", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// 4. Operation Dialog Sheet (Matches "دين جديد" Card in Top-Right Reference Image)
@Composable
fun OperationDialog(
    customer: Customer,
    type: OperationType,
    onDismiss: () -> Unit,
    onSave: (amount: Long, note: String, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val isDebt = type == OperationType.DEBT
    val titleStr = if (isDebt) "دين جديد" else "تسديد دين"

    Dialog(onDismissRequest = { if (!isLoading) onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = titleStr,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    )
                    IconButton(onClick = onDismiss, enabled = !isLoading) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "إغلاق",
                            tint = if (isLoading) BorderLight else TextSecondaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (errorText != null) {
                    Surface(
                        color = Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = errorText!!, color = CrimsonRed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                // Customer Field Box
                Text("المدين", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = SurfaceLight,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = TextSecondaryDark,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = customer.name,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Amount Input
                Text("المبلغ", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { input ->
                        val cleanDigits = input.replace(",", "").filter { it.isDigit() }
                        if (cleanDigits.isEmpty()) {
                            amountText = ""
                            errorText = null
                        } else if (cleanDigits.length <= 15) {
                            cleanDigits.toLongOrNull()?.let { number ->
                                amountText = number.formatWithCommas()
                                errorText = null
                            }
                        }
                    },
                    enabled = !isLoading,
                    placeholder = { Text("0", color = TextSecondaryDark) },
                    leadingIcon = {
                        Text(
                            text = BabyConfig.CURRENCY,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondaryDark,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    isError = errorText != null,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Note Input
                Text("ملاحظات (اختياري)", fontWeight = FontWeight.Medium, fontSize = 13.sp, color = TextSecondaryDark)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    enabled = !isLoading,
                    placeholder = { Text("اكتب ملاحظة...", color = TextSecondaryDark) },
                    leadingIcon = { Icon(Icons.Default.EditNote, contentDescription = null, tint = TextSecondaryDark) },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = RoyalBlue,
                        unfocusedBorderColor = BorderLight
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                val parsedAmount = amountText.replace(",", "").toLongOrNull() ?: 0L

                // Save Button
                Button(
                    onClick = {
                        if (isLoading) return@Button
                        if (type == OperationType.PAYMENT && parsedAmount > customer.debtAmount) {
                            errorText = "المبلغ المراد تسديده أكبر من الدين الحالي"
                        } else {
                            isLoading = true
                            errorText = null
                            onSave(
                                parsedAmount,
                                note,
                                {
                                    isLoading = false
                                    onDismiss()
                                },
                                { err ->
                                    isLoading = false
                                    errorText = err
                                }
                            )
                        }
                    },
                    enabled = parsedAmount > 0 && !isLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري الحفظ...", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    } else {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("حفظ العملية", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}


@Composable
fun CustomerOperationsDialog(
    customer: Customer,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val operations by viewModel.getOperationsForCustomer(customer.id).collectAsStateWithLifecycle(initialValue = emptyList())

    val lastDebtTime = operations.filter { it.type == OperationType.DEBT }.maxOfOrNull { it.dateTime } ?: System.currentTimeMillis()
    val dueDateFormatted = lastDebtTime.formatDateOnly()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .height(520.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "كشف حساب: ${customer.name}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                        )
                        customer.phone?.let {
                            Text(text = it, fontSize = 12.sp, color = TextSecondaryDark)
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Customer Debt Summary Card with Due Date
                Surface(
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("الدين المتبقي الحالي:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimaryDark)
                            Text(
                                customer.debtAmount.formatCurrency(),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (customer.debtAmount > 0) CrimsonRed else EmeraldGreen
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("تاريخ الاستحقاق (آخر دين):", fontSize = 11.sp, color = TextSecondaryDark)
                            Text(dueDateFormatted, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextPrimaryDark)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "سجل عمليات المدين (${operations.size} عملية):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondaryDark
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (operations.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("لا توجد عمليات مسجلة للمدين", color = TextSecondaryDark)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(operations, key = { it.id }) { op ->
                            val isDebt = op.type == OperationType.DEBT
                            val cardBg = if (isDebt) Color(0xFFFEF2F2) else Color(0xFFECFDF5)
                            val typeColor = if (isDebt) CrimsonRed else EmeraldGreen
                            val typeTitle = if (op.note == "دين أولي") "دين أولي" else if (isDebt) "دين جديد (+)" else "تسديد (-)"

                            Surface(
                                color = cardBg,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = typeTitle,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = typeColor
                                        )
                                        Text(
                                            text = op.dateTime.formatDateTime(),
                                            fontSize = 10.sp,
                                            color = TextSecondaryDark
                                        )
                                        if (op.note.isNotBlank() && op.note != "دين أولي") {
                                            Text(
                                                text = op.note,
                                                fontSize = 11.sp,
                                                color = TextPrimaryDark
                                            )
                                        }
                                    }

                                    Text(
                                        text = op.amount.formatCurrency(),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = typeColor
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action buttons: WhatsApp Reminder + Close Statement
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            sendWhatsAppReminder(
                                context = context,
                                phone = customer.phone,
                                customerName = customer.name,
                                debtAmount = customer.debtAmount,
                                dueDate = dueDateFormatted
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF25D366),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "واتساب",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تذكير واتساب", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("إغلاق الكشف", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

            }
        }
    }
}
