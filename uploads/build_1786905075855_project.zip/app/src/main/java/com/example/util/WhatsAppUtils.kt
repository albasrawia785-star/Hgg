package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * دالة لإرسال رسالة تذكير بالدين وتاريخ الاستحقاق عبر تطبيق واتساب (WhatsApp Intent)
 */
fun sendWhatsAppReminder(
    context: Context,
    phone: String?,
    customerName: String,
    debtAmount: Long,
    dueDate: String
) {
    val formattedDebt = debtAmount.formatCurrency()
    val message = "مرحباً $customerName،\nنود تذكيركم بأن إجمالي الدين المستحق عليكم هو: $formattedDebt\nيرجى التسديد في أقرب وقت ممكن. وشكراً لكم!"
    val encodedMessage = Uri.encode(message)
    val formattedPhone = formatPhoneForWhatsApp(phone)

    val url = if (formattedPhone.isNotEmpty()) {
        "https://api.whatsapp.com/send?phone=$formattedPhone&text=$encodedMessage"
    } else {
        "https://api.whatsapp.com/send?text=$encodedMessage"
    }

    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "تطبيق واتساب غير مثبت على الجهاز", Toast.LENGTH_SHORT).show()
    }
}

/**
 * تحويل أرقام الهواتف المحلية (مثل التي تبدأ بـ 0781 أو 07) تلقائياً إلى الصيغة الدولية (+964) بالخفاء للواتساب
 */
private fun formatPhoneForWhatsApp(phone: String?): String {
    if (phone.isNullOrBlank()) return ""
    val digits = phone.filter { it.isDigit() }
    if (digits.isEmpty()) return ""

    return when {
        // الرقم العراقي المحلي يبدأ بـ 07 (مثل 0781..., 077..., 075...)
        digits.startsWith("07") -> "964" + digits.substring(1)
        // رقم يتكون من 10 أرقام ويبدأ بـ 7 (بدون الصفر الأولي)
        digits.startsWith("7") && digits.length == 10 -> "964$digits"
        // يبدأ بـ 00964
        digits.startsWith("00964") -> digits.substring(2)
        // رقم دولي مسبقاً أو صيغ أخرى
        else -> digits
    }
}
