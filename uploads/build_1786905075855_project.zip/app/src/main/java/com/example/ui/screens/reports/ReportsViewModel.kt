package com.example.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.OperationType
import com.example.data.model.OperationWithCustomer
import com.example.data.repository.DebtRepository
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class ReportsUiState(
    val totalDebt: Long = 0L,
    val customerCount: Int = 0,
    val lateCustomersCount: Int = 0,
    val totalDebtAdded: Long = 0L,
    val totalPayments: Long = 0L,
    val netDebt: Long = 0L,
    val collectionRatePercentage: Float = 0f,
    val topDebtors: List<Customer> = emptyList()
)

private data class PrimaryStats(
    val totalDebt: Long?,
    val customerCount: Int,
    val customers: List<Customer>,
    val operationsWithCustomer: List<OperationWithCustomer>
)

private data class SecondaryStats(
    val threshold: Int,
    val totalAdded: Long?,
    val totalPayments: Long?
)

class ReportsViewModel(
    private val repository: DebtRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val primaryStatsFlow = combine(
        repository.totalDebtSum,
        repository.customerCount,
        repository.allCustomers,
        repository.allOperationsWithCustomer
    ) { totalDebt, customerCount, customers, operations ->
        PrimaryStats(totalDebt, customerCount, customers, operations)
    }

    private val secondaryStatsFlow = combine(
        settingsRepository.overdueDays,
        repository.totalDebtAddedSum,
        repository.totalPaymentsSum
    ) { threshold, totalAdded, totalPayments ->
        SecondaryStats(threshold, totalAdded, totalPayments)
    }

    val uiState: StateFlow<ReportsUiState> = combine(
        primaryStatsFlow,
        secondaryStatsFlow
    ) { primary, secondary ->
        val now = System.currentTimeMillis()
        val oneDayMs = 1000L * 60 * 60 * 24

        val activeCustomers = primary.customers
        val activeCustomerIds = activeCustomers.map { it.id }.toSet()

        val opsByCustomer = primary.operationsWithCustomer
            .map { it.operation }
            .filter { it.customerId in activeCustomerIds }
            .groupBy { it.customerId }

        var calculatedTotalAdded = 0L
        var calculatedTotalPayments = 0L

        for (customer in activeCustomers) {
            val customerOps = opsByCustomer[customer.id] ?: emptyList()
            val paidForCustomer = customerOps
                .filter { it.type == OperationType.PAYMENT }
                .sumOf { it.amount }
            val debtOpsForCustomer = customerOps
                .filter { it.type == OperationType.DEBT }
                .sumOf { it.amount }

            val addedForCustomer = maxOf(debtOpsForCustomer, customer.debtAmount + paidForCustomer)

            calculatedTotalPayments += paidForCustomer
            calculatedTotalAdded += addedForCustomer
        }

        val calculatedTotalDebt = activeCustomers.sumOf { it.debtAmount }
        val calculatedNetDebt = calculatedTotalDebt

        val collectionRate = if (calculatedTotalAdded > 0L) {
            ((calculatedTotalPayments.toFloat() / calculatedTotalAdded.toFloat()) * 100f).coerceIn(0f, 100f)
        } else {
            0f
        }

        val topDebtorsList = activeCustomers
            .filter { it.debtAmount > 0 }
            .sortedByDescending { it.debtAmount }
            .take(5)

        val lateCount = activeCustomers
            .filter { it.debtAmount > 0 }
            .count { customer ->
                val customerDebtOps = opsByCustomer[customer.id]
                    ?.filter { it.type == OperationType.DEBT } ?: emptyList()
                val lastDebtTime = customerDebtOps.maxOfOrNull { it.dateTime }

                if (lastDebtTime != null) {
                    val daysPassed = ((now - lastDebtTime) / oneDayMs).toInt().coerceAtLeast(0)
                    daysPassed > secondary.threshold
                } else false
            }

        ReportsUiState(
            totalDebt = calculatedTotalDebt,
            customerCount = activeCustomers.size,
            lateCustomersCount = lateCount,
            totalDebtAdded = calculatedTotalAdded,
            totalPayments = calculatedTotalPayments,
            netDebt = calculatedNetDebt,
            collectionRatePercentage = collectionRate,
            topDebtors = topDebtorsList
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ReportsUiState()
    )

    class Factory(
        private val repository: DebtRepository,
        private val settingsRepository: SettingsRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReportsViewModel(repository, settingsRepository) as T
        }
    }
}
