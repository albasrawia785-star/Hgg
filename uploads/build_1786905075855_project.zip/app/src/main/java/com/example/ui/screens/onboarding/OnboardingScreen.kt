package com.example.ui.screens.onboarding

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import kotlinx.coroutines.launch

data class OnboardingPageData(
    val emoji: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val badgeColor: Color
)

@Composable
fun OnboardingScreen(
    onFinish: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    val pages = listOf(
        OnboardingPageData(
            emoji = "📒",
            title = "إدارة الديون",
            description = "سجل ديون الزبائن بسهولة ورتبها بشكل منظم مع ألوان توضيحية لسهولة المتابعة.",
            icon = Icons.Default.MenuBook,
            badgeColor = Color(0xFFE5C158)
        ),
        OnboardingPageData(
            emoji = "💰",
            title = "متابعة التسديدات",
            description = "أضف الدفعات واعرف المتبقي تلقائياً لكل زبون وبدون الحاجة للحسابات اليدوية.",
            icon = Icons.Default.Payments,
            badgeColor = Color(0xFF22C55E)
        ),
        OnboardingPageData(
            emoji = "☁️",
            title = "حفظ سحابي",
            description = "حتى لو خرب جهازك أو غيرته، تبقى كل معلوماتك محفوظة وتگدر تفتحها من أي مكان بعد تسجيل الدخول.",
            icon = Icons.Default.CloudSync,
            badgeColor = Color(0xFF3B82F6)
        ),
        OnboardingPageData(
            emoji = "📊",
            title = "تقارير واضحة",
            description = "اعرض جميع الديون والمدفوعات بطريقة مرتبة وسريعة مع تفاصيل كشوفات الحساب.",
            icon = Icons.Default.Analytics,
            badgeColor = Color(0xFFA855F7)
        ),
        OnboardingPageData(
            emoji = "🔒",
            title = "حماية وأمان",
            description = "بياناتك مرتبطة بحسابك ومحمية، ولا يمكن الوصول إليها إلا بعد تسجيل الدخول بالرقم والرمز السرّي.",
            icon = Icons.Default.Security,
            badgeColor = Color(0xFF10B981)
        )
    )

    val pagerState = rememberPagerState(pageCount = { pages.size })

    val darkNavyBg = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF0B132B),
            Color(0xFF1C2541),
            Color(0xFF0F172A)
        )
    )

    val goldBrush = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFFF5C142),
            Color(0xFFE5C158),
            Color(0xFFD4AF37)
        )
    )

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFF0B132B)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(darkNavyBg)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {

                // Top Header Section: Large App Icon + Title + Subtitle
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 16.dp)
                ) {
                    // App Icon Wrapper with Glowing Gold Accent Ring
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(92.dp)
                            .shadow(12.dp, CircleShape, spotColor = Color(0xFFE5C158))
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        Color(0xFF1E293B),
                                        Color(0xFF0F172A)
                                    )
                                )
                            )
                            .border(2.dp, goldBrush, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_launcher_foreground),
                            contentDescription = "دفتر ديوني",
                            modifier = Modifier.size(80.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "دفتر ديوني",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            fontSize = 28.sp
                        ),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "نظم ديونك، تابع التسديدات، وخلي بياناتك محفوظة بالسحابة حتى تگدر توصل إلها من أي جهاز.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }

                // Middle Section: Swipeable Cards (HorizontalPager)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 12.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxWidth()
                    ) { pageIndex ->
                        val item = pages[pageIndex]

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp)
                                .shadow(8.dp, RoundedCornerShape(24.dp), spotColor = Color(0xFFE5C158).copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFF1E293B).copy(alpha = 0.95f)
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                width = 1.dp,
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFFE5C158).copy(alpha = 0.4f),
                                        Color(0xFF334155)
                                    )
                                )
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 22.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Badge Icon Circle
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(item.badgeColor.copy(alpha = 0.15f))
                                        .border(1.5.dp, item.badgeColor.copy(alpha = 0.5f), CircleShape)
                                ) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = null,
                                        tint = item.badgeColor,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = item.emoji,
                                        fontSize = 20.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            fontSize = 20.sp
                                        )
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = item.description,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 14.sp,
                                        lineHeight = 21.sp
                                    ),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                // Bottom Section: Page Indicator + Actions
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Page Indicator Dots
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 16.dp)
                    ) {
                        repeat(pages.size) { iteration ->
                            val isSelected = pagerState.currentPage == iteration
                            val width by animateDpAsState(
                                targetValue = if (isSelected) 24.dp else 8.dp,
                                animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
                                label = "dotWidth"
                            )
                            val color = if (isSelected) Color(0xFFE5C158) else Color(0xFF475569)

                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 4.dp)
                                    .height(8.dp)
                                    .width(width)
                                    .clip(CircleShape)
                                    .background(color)
                            )
                        }
                    }

                    // Action Buttons Row: "تخطي" and "متابعة"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Skip Button
                        TextButton(
                            onClick = onFinish
                        ) {
                            Text(
                                text = "تخطي",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = Color(0xFF94A3B8),
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 15.sp
                                )
                            )
                        }

                        // Main Button ("متابعة" or "البدء الآن")
                        val isLastPage = pagerState.currentPage == pages.size - 1

                        Button(
                            onClick = {
                                if (isLastPage) {
                                    onFinish()
                                } else {
                                    coroutineScope.launch {
                                        pagerState.animateScrollToPage(pagerState.currentPage + 1)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.Transparent
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .width(if (isLastPage) 150.dp else 125.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(goldBrush)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = if (isLastPage) "البدء الآن" else "متابعة",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = Color(0xFF0B132B),
                                            fontWeight = FontWeight.Black,
                                            fontSize = 15.sp
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.ArrowBack, // RTL arrow points left for forward
                                        contentDescription = null,
                                        tint = Color(0xFF0B132B),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
