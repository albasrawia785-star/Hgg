package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Onboarding : Screen("onboarding", "دليل الاستخدام", Icons.Default.MenuBook)
    object Login : Screen("login", "تسجيل الدخول", Icons.Default.Lock)
    object Main : Screen("main", "الرئيسية", Icons.Default.Home)
    object Reports : Screen("reports", "التقارير", Icons.Default.BarChart)
    object LateCustomers : Screen("late_customers", "المتأخرون", Icons.Default.HourglassTop)
    object Operations : Screen("operations", "العمليات", Icons.Default.History)
    object Settings : Screen("settings", "الإعدادات", Icons.Default.Settings)
}
