package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.lifecycleScope
import com.example.ui.navigation.MainAppNavigation
import com.example.ui.theme.DebtTrackerTheme
import com.example.util.NotificationHelper
import com.example.util.NotificationScheduler
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize local notification channel and scheduler
        try {
            NotificationHelper.createNotificationChannel(this)
            NotificationScheduler.scheduleDailyReminder(this)
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Error scheduling notifications", e)
        }

        // Request notification permission for Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
                }
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error requesting permission", e)
            }
        }

        // Perform initial check on launch
        lifecycleScope.launch {
            try {
                NotificationHelper.checkAndNotifyOverdueDebtors(this@MainActivity)
            } catch (e: Exception) {
                android.util.Log.e("MainActivity", "Error checking overdue debtors", e)
            }
        }

        enableEdgeToEdge()
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                DebtTrackerTheme {
                    MainAppNavigation()
                }
            }
        }
    }
}
