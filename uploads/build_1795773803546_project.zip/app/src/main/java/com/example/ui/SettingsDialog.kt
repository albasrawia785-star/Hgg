package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ClearableOutlinedTextField
import com.example.SettingsManager

/**
 * حوار إعدادات المكتب/المعرض والطباعة
 * يتيح تخصيص اسم المكتب، رقمين للهاتف (07700000000 - 07800000000)، رقم الإجازة الاختياري، والعنوان
 */
@Composable
fun SettingsDialog(
    onDismiss: () -> Unit,
    onOpenPrinterDialog: () -> Unit = {},
    onSettingsSaved: () -> Unit = {}
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager.getInstance(context) }

    var officeName by remember { mutableStateOf(settingsManager.officeName) }
    var officePhone by remember { mutableStateOf(settingsManager.officePhone) }
    var officePhone2 by remember { mutableStateOf(settingsManager.officePhone2) }
    var officeLicenseNo by remember { mutableStateOf(settingsManager.officeLicenseNo) }
    var officeAddress by remember { mutableStateOf(settingsManager.officeAddress) }
    var isSaved by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFEFF6FF),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = null,
                            tint = Color(0xFF1E40AF),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "إعدادات المكتب والترويسة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "تخصيص بيانات الترويسة المطبوعة في أعلى العقود",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. بطاقة البيانات الأساسية للمكتب
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Business,
                                contentDescription = null,
                                tint = Color(0xFF0F387A),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "بيانات المكتب / المعرض",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF0F387A)
                            )
                        }

                        // اسم المكتب
                        ClearableOutlinedTextField(
                            value = officeName,
                            onValueChange = {
                                officeName = it
                                isSaved = false
                            },
                            label = { Text("اسم المكتب / المعرض") },
                            leadingIcon = { Icon(Icons.Default.Store, contentDescription = null, tint = Color(0xFF64748B)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_office_name"),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                        )

                        // رقم الهاتف الأول
                        ClearableOutlinedTextField(
                            value = officePhone,
                            onValueChange = {
                                officePhone = it
                                isSaved = false
                            },
                            label = { Text("رقم الهاتف الأول (الأساسي)") },
                            placeholder = { Text("07700000000") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = Color(0xFF64748B)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_office_phone"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next)
                        )

                        // رقم الهاتف الثاني (اختياري)
                        ClearableOutlinedTextField(
                            value = officePhone2,
                            onValueChange = {
                                officePhone2 = it
                                isSaved = false
                            },
                            label = { Text("رقم الهاتف الثاني (اختياري)") },
                            placeholder = { Text("07800000000") },
                            leadingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = Color(0xFF64748B)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_office_phone2"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next)
                        )

                        // تلميح تنسيق رقمي الهاتف
                        if (officePhone.isNotBlank() || officePhone2.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFEFF6FF),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Call,
                                        contentDescription = null,
                                        tint = Color(0xFF2563EB),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val previewText = when {
                                        officePhone.isNotBlank() && officePhone2.isNotBlank() -> "${officePhone.trim()} - ${officePhone2.trim()}"
                                        officePhone.isNotBlank() -> officePhone.trim()
                                        else -> officePhone2.trim()
                                    }
                                    Text(
                                        text = "المعاينة في الترويسة: $previewText",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF1E40AF)
                                    )
                                }
                            }
                        }

                        // رقم الإجازة (اختياري)
                        ClearableOutlinedTextField(
                            value = officeLicenseNo,
                            onValueChange = {
                                officeLicenseNo = it
                                isSaved = false
                            },
                            label = { Text("رقم الإجازة / الترخيص (اختياري)") },
                            placeholder = { Text("مثال: 10452/أ") },
                            leadingIcon = { Icon(Icons.Default.AssignmentInd, contentDescription = null, tint = Color(0xFF64748B)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_office_license_no"),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                        )
                        Text(
                            text = "في حال توفر رقم الإجازة، سيتم طباعته بشكل أنيق في أعلى ورقة العقد تحت أرقام الهواتف مباشرة.",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B),
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )

                        // عنوان المكتب
                        ClearableOutlinedTextField(
                            value = officeAddress,
                            onValueChange = {
                                officeAddress = it
                                isSaved = false
                            },
                            label = { Text("عنوان المكتب / المحافظة والحي") },
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF64748B)) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_office_address"),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
                        )
                    }
                }

                // 2. بطاقة طابعة البلوتوث A4
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Print,
                                contentDescription = null,
                                tint = Color(0xFF047857),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "الطابعات والاتصال (Wi-Fi / بلوتوث / USB)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF047857)
                            )
                        }
                        Text(
                            text = "البحث التلقائي والاتصال بالطابعات المتاحة عبر الشبكة أو البلوتوث أو كابل USB OTG.",
                            fontSize = 11.sp,
                            color = Color(0xFF334155)
                        )
                        Button(
                            onClick = {
                                onDismiss()
                                onOpenPrinterDialog()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_open_printer_from_settings"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إدارة الطابعات والاتصال", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    settingsManager.saveOfficeDetails(
                        name = officeName,
                        phone = officePhone,
                        phone2 = officePhone2,
                        licenseNo = officeLicenseNo,
                        address = officeAddress
                    )
                    isSaved = true
                    onSettingsSaved()
                    Toast.makeText(context, "تم حفظ بيانات المكتب والإجازة بنجاح!", Toast.LENGTH_SHORT).show()
                    onDismiss()
                },
                modifier = Modifier.testTag("btn_save_office_settings"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("حفظ التغييرات", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("إلغاء")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
