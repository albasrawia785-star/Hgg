package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

enum class PrinterConnectionTab {
    WIFI,
    BLUETOOTH,
    USB
}

data class WifiPrinterDevice(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val serviceType: String,
    val isManual: Boolean = false
) {
    val displaySubtitle: String
        get() = "$host:$port"
}

data class UsbPrinterDevice(
    val deviceId: Int,
    val name: String,
    val vendorId: Int,
    val productId: Int,
    val usbDevice: UsbDevice
) {
    val displaySubtitle: String
        get() = "USB ID ${vendorId.toString(16).uppercase()}:${productId.toString(16).uppercase()}"
}

class UnifiedPrinterManager(
    private val context: Context,
    val bluetoothManager: BluetoothPrinterManager
) {
    companion object {
        private const val PREFS_NAME = "unified_printer_prefs"
        private const val KEY_MANUAL_WIFI_PRINTERS = "manual_wifi_printers"
        private const val ACTION_USB_PERMISSION = "com.example.USB_PRINTER_PERMISSION"
        private val NSD_SERVICE_TYPES = listOf(
            "_ipp._tcp.",
            "_pdl-datastream._tcp.",
            "_printer._tcp."
        )
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val nsdManager: NsdManager? = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
    private val usbManager: UsbManager? = context.getSystemService(Context.USB_SERVICE) as? UsbManager
    private val wifiManager: WifiManager? = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private val resolveMutex = Mutex()
    private var multicastLock: WifiManager.MulticastLock? = null
    private val activeDiscoveryListeners = mutableListOf<NsdManager.DiscoveryListener>()
    private val isDiscoveringWifi = AtomicBoolean(false)

    private val _selectedTab = MutableStateFlow(PrinterConnectionTab.WIFI)
    val selectedTab: StateFlow<PrinterConnectionTab> = _selectedTab.asStateFlow()

    private val _wifiPrinters = MutableStateFlow<List<WifiPrinterDevice>>(emptyList())
    val wifiPrinters: StateFlow<List<WifiPrinterDevice>> = _wifiPrinters.asStateFlow()

    private val _isScanningWifi = MutableStateFlow(false)
    val isScanningWifi: StateFlow<Boolean> = _isScanningWifi.asStateFlow()

    private val _bluetoothDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val bluetoothDevices: StateFlow<List<BluetoothDevice>> = _bluetoothDevices.asStateFlow()

    private val _hasBluetoothPermission = MutableStateFlow(checkBluetoothPermission())
    val hasBluetoothPermission: StateFlow<Boolean> = _hasBluetoothPermission.asStateFlow()

    private val _isBluetoothEnabled = MutableStateFlow(bluetoothManager.isBluetoothEnabled())
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val _usbPrinters = MutableStateFlow<List<UsbPrinterDevice>>(emptyList())
    val usbPrinters: StateFlow<List<UsbPrinterDevice>> = _usbPrinters.asStateFlow()

    private var pendingUsbDeviceForPrint: UsbPrinterDevice? = null
    private var pendingUsbBitmap: Bitmap? = null
    private var usbReceiverRegistered = false

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action != ACTION_USB_PERMISSION) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val device = pendingUsbDeviceForPrint
            val bitmap = pendingUsbBitmap
            pendingUsbDeviceForPrint = null
            pendingUsbBitmap = null

            if (granted && device != null && bitmap != null) {
                scope.launch {
                    executeUsbPrint(device, bitmap)
                }
            } else {
                bluetoothManager.updateExternalState(
                    PrinterState.Error("لم يتم منح إذن الوصول إلى طابعة USB")
                )
            }
        }
    }

    fun selectTab(tab: PrinterConnectionTab) {
        _selectedTab.value = tab
    }

    fun checkBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun isWifiConnected(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    /**
     * فحص تلقائي شامل لجميع المنافذ (Wi-Fi، Bluetooth، USB) وتحديد التبويب الأنسب تلقائياً
     */
    fun scanAllPrinters(autoSelectBestTab: Boolean = true) {
        refreshBluetoothDevices()
        refreshUsbPrinters()
        startWifiDiscovery()

        if (autoSelectBestTab) {
            scope.launch {
                // ننتظر لحظة قصيرة جداً لاكتشاف طابعات الشبكة الأولية ثم نختار التبويب الأجهز
                delay(450)
                val wifiCount = _wifiPrinters.value.size
                val btCount = _bluetoothDevices.value.size
                val usbCount = _usbPrinters.value.size

                val bestTab = when {
                    wifiCount > 0 -> PrinterConnectionTab.WIFI
                    usbCount > 0 -> PrinterConnectionTab.USB
                    btCount > 0 -> PrinterConnectionTab.BLUETOOTH
                    else -> PrinterConnectionTab.WIFI
                }
                _selectedTab.value = bestTab
            }
        }
    }

    fun refreshBluetoothDevices() {
        val granted = checkBluetoothPermission()
        _hasBluetoothPermission.value = granted
        _isBluetoothEnabled.value = bluetoothManager.isBluetoothEnabled()
        _bluetoothDevices.value = if (granted) {
            bluetoothManager.getPairedDevices()
        } else {
            emptyList()
        }
    }

    fun refreshUsbPrinters() {
        val manager = usbManager
        if (manager == null) {
            _usbPrinters.value = emptyList()
            return
        }
        val printers = manager.deviceList.values.mapNotNull { device ->
            val isPrinterClass = device.deviceClass == UsbConstants.USB_CLASS_PRINTER ||
                (0 until device.interfaceCount).any { idx ->
                    device.getInterface(idx).interfaceClass == UsbConstants.USB_CLASS_PRINTER
                }
            if (isPrinterClass) {
                val label = listOfNotNull(
                    device.manufacturerName?.takeIf { it.isNotBlank() },
                    device.productName?.takeIf { it.isNotBlank() }
                ).joinToString(" ").ifBlank { "طابعة USB OTG" }

                UsbPrinterDevice(
                    deviceId = device.deviceId,
                    name = label,
                    vendorId = device.vendorId,
                    productId = device.productId,
                    usbDevice = device
                )
            } else {
                null
            }
        }
        _usbPrinters.value = printers
    }

    fun startWifiDiscovery() {
        stopWifiDiscovery()
        val manualList = loadManualWifiPrinters()
        _wifiPrinters.value = manualList

        val manager = nsdManager ?: return
        if (!isWifiConnected()) {
            _isScanningWifi.value = false
            return
        }

        _isScanningWifi.value = true
        isDiscoveringWifi.set(true)

        try {
            multicastLock = wifiManager?.createMulticastLock("contract_printer_nsd")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (_: Exception) {
        }

        NSD_SERVICE_TYPES.forEach { serviceType ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String) {}

                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    if (!isDiscoveringWifi.get()) return
                    scope.launch {
                        resolveServiceSequentially(manager, serviceInfo)
                    }
                }

                override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                    val lostName = serviceInfo.serviceName
                    _wifiPrinters.value = _wifiPrinters.value.filterNot {
                        !it.isManual && it.name == lostName
                    }
                }

                override fun onDiscoveryStopped(serviceType: String) {}
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            }

            try {
                activeDiscoveryListeners.add(listener)
                manager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener)
            } catch (_: Exception) {
            }
        }

        // إيقاف مؤشر البحث بعد 6 ثوانٍ مع إبقاء النتائج
        scope.launch {
            delay(6000)
            _isScanningWifi.value = false
        }
    }

    @Suppress("DEPRECATION")
    private suspend fun resolveServiceSequentially(manager: NsdManager, serviceInfo: NsdServiceInfo) {
        resolveMutex.withLock {
            val resolved = withTimeoutOrNull(2500L) {
                kotlinx.coroutines.suspendCancellableCoroutine<NsdServiceInfo?> { cont ->
                    try {
                        manager.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                                if (cont.isActive) cont.resume(null)
                            }

                            override fun onServiceResolved(info: NsdServiceInfo) {
                                if (cont.isActive) cont.resume(info)
                            }
                        })
                    } catch (_: Exception) {
                        if (cont.isActive) cont.resume(null)
                    }
                }
            } ?: return@withLock

            val hostAddress = resolved.host?.hostAddress ?: return@withLock
            val port = resolved.port.takeIf { it > 0 } ?: 631
            val name = resolved.serviceName?.ifBlank { "طابعة Wi-Fi" } ?: "طابعة Wi-Fi"
            val id = "$hostAddress:$port"

            val discovered = WifiPrinterDevice(
                id = id,
                name = name,
                host = hostAddress,
                port = port,
                serviceType = resolved.serviceType ?: "_ipp._tcp.",
                isManual = false
            )

            val current = _wifiPrinters.value
            if (current.none { it.host == discovered.host && it.port == discovered.port }) {
                _wifiPrinters.value = current + discovered
            }
        }
    }

    fun stopWifiDiscovery() {
        isDiscoveringWifi.set(false)
        _isScanningWifi.value = false
        val manager = nsdManager
        if (manager != null) {
            activeDiscoveryListeners.forEach { listener ->
                try {
                    manager.stopServiceDiscovery(listener)
                } catch (_: Exception) {
                }
            }
        }
        activeDiscoveryListeners.clear()
        try {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        } catch (_: Exception) {
        }
        multicastLock = null
    }

    fun addManualWifiPrinter(name: String, host: String, port: Int = 9100): Boolean {
        val cleanHost = host.trim()
        if (cleanHost.isBlank()) return false
        val cleanName = name.trim().ifBlank { "طابعة شبكة ($cleanHost)" }
        val validPort = if (port in 1..65535) port else 9100
        val newDevice = WifiPrinterDevice(
            id = "manual_$cleanHost:$validPort",
            name = cleanName,
            host = cleanHost,
            port = validPort,
            serviceType = if (validPort == 631) "_ipp._tcp." else "_pdl-datastream._tcp.",
            isManual = true
        )
        val updatedManual = (loadManualWifiPrinters().filterNot {
            it.host == cleanHost && it.port == validPort
        }) + newDevice
        saveManualWifiPrinters(updatedManual)

        val current = _wifiPrinters.value.filterNot { it.host == cleanHost && it.port == validPort }
        _wifiPrinters.value = listOf(newDevice) + current
        return true
    }

    fun removeManualWifiPrinter(device: WifiPrinterDevice) {
        val updatedManual = loadManualWifiPrinters().filterNot {
            it.host == device.host && it.port == device.port
        }
        saveManualWifiPrinters(updatedManual)
        _wifiPrinters.value = _wifiPrinters.value.filterNot {
            it.isManual && it.host == device.host && it.port == device.port
        }
    }

    private fun loadManualWifiPrinters(): List<WifiPrinterDevice> {
        val raw = prefs.getString(KEY_MANUAL_WIFI_PRINTERS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.getJSONObject(i)
                val host = obj.optString("host", "")
                if (host.isBlank()) null
                else WifiPrinterDevice(
                    id = obj.optString("id", "manual_$host"),
                    name = obj.optString("name", host),
                    host = host,
                    port = obj.optInt("port", 9100),
                    serviceType = obj.optString("serviceType", "_pdl-datastream._tcp."),
                    isManual = true
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveManualWifiPrinters(list: List<WifiPrinterDevice>) {
        val arr = JSONArray()
        list.forEach { dev ->
            arr.put(JSONObject().apply {
                put("id", dev.id)
                put("name", dev.name)
                put("host", dev.host)
                put("port", dev.port)
                put("serviceType", dev.serviceType)
            })
        }
        prefs.edit().putString(KEY_MANUAL_WIFI_PRINTERS, arr.toString()).apply()
    }

    /**
     * الطباعة إلى طابعة Wi-Fi عبر IPP أو Raw TCP Socket مع بديل طباعة أندرويد عند تعذر البروتوكول المباشر
     */
    suspend fun printToWifiPrinter(
        device: WifiPrinterDevice,
        bitmap: Bitmap,
        onNeedSystemPrintFallback: () -> Unit
    ) {
        withContext(Dispatchers.IO) {
            bluetoothManager.updateExternalState(PrinterState.Connecting(device.name))
            try {
                val pdfBytes = buildA4PdfBytes(bitmap)
                bluetoothManager.updateExternalState(PrinterState.Printing(35))

                val isIpp = device.port == 631 || device.serviceType.contains("_ipp", ignoreCase = true)
                val sentDirectly = if (isIpp) {
                    sendPdfViaIpp(device.host, device.port, pdfBytes)
                } else {
                    sendPdfViaRawSocket(device.host, device.port, pdfBytes)
                }

                if (sentDirectly) {
                    bluetoothManager.updateExternalState(
                        PrinterState.Success("تم إرسال العقد بنجاح إلى ${device.name}")
                    )
                } else {
                    bluetoothManager.updateExternalState(PrinterState.Idle)
                    withContext(Dispatchers.Main) {
                        onNeedSystemPrintFallback()
                    }
                }
            } catch (e: Exception) {
                bluetoothManager.updateExternalState(PrinterState.Idle)
                withContext(Dispatchers.Main) {
                    onNeedSystemPrintFallback()
                }
            }
        }
    }

    private fun buildA4PdfBytes(bitmap: Bitmap): ByteArray {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val srcRect = Rect(0, 0, bitmap.width, bitmap.height)
        val destRect = Rect(0, 0, 595, 842)
        page.canvas.drawBitmap(bitmap, srcRect, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
        pdfDocument.finishPage(page)

        return ByteArrayOutputStream().use { baos ->
            pdfDocument.writeTo(baos)
            pdfDocument.close()
            baos.toByteArray()
        }
    }

    private fun sendPdfViaRawSocket(host: String, port: Int, pdfBytes: ByteArray): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(InetAddress.getByName(host), port), 3500)
                socket.soTimeout = 5000
                val out = socket.getOutputStream()
                val chunkSize = 4096
                var offset = 0
                while (offset < pdfBytes.size) {
                    val len = minOf(chunkSize, pdfBytes.size - offset)
                    out.write(pdfBytes, offset, len)
                    offset += len
                    val pct = 35 + (offset.toFloat() / pdfBytes.size * 55).toInt()
                    bluetoothManager.updateExternalState(PrinterState.Printing(pct))
                }
                out.flush()
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun sendPdfViaIpp(host: String, port: Int, pdfBytes: ByteArray): Boolean {
        return try {
            val url = URL("http://$host:$port/ipp/print")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 3500
                readTimeout = 8000
                doOutput = true
                setRequestProperty("Content-Type", "application/ipp")
            }

            val printerUri = "ipp://$host:$port/ipp/print"
            val ippHeader = ByteArrayOutputStream().apply {
                DataOutputStream(this).use { dos ->
                    // IPP version 2.0, operation Print-Job (0x0002), request-id 1
                    dos.writeByte(0x02)
                    dos.writeByte(0x00)
                    dos.writeShort(0x0002)
                    dos.writeInt(1)
                    // operation-attributes-tag
                    dos.writeByte(0x01)
                    writeIppAttr(dos, 0x47, "attributes-charset", "utf-8")
                    writeIppAttr(dos, 0x48, "attributes-natural-language", "ar")
                    writeIppAttr(dos, 0x45, "printer-uri", printerUri)
                    writeIppAttr(dos, 0x42, "requesting-user-name", "AqoodPro")
                    writeIppAttr(dos, 0x42, "job-name", "Contract_A4")
                    writeIppAttr(dos, 0x49, "document-format", "application/pdf")
                    // end-of-attributes-tag
                    dos.writeByte(0x03)
                }
            }.toByteArray()

            conn.outputStream.use { os ->
                os.write(ippHeader)
                os.write(pdfBytes)
                os.flush()
            }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        } catch (_: Exception) {
            false
        }
    }

    private fun writeIppAttr(dos: DataOutputStream, tag: Int, name: String, value: String) {
        val nameBytes = name.toByteArray(StandardCharsets.UTF_8)
        val valBytes = value.toByteArray(StandardCharsets.UTF_8)
        dos.writeByte(tag)
        dos.writeShort(nameBytes.size)
        dos.write(nameBytes)
        dos.writeShort(valBytes.size)
        dos.write(valBytes)
    }

    /**
     * الطباعة عبر كابل USB OTG
     */
    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    fun printToUsbPrinter(device: UsbPrinterDevice, bitmap: Bitmap) {
        val manager = usbManager ?: run {
            bluetoothManager.updateExternalState(PrinterState.Error("خدمة USB غير متوفرة على هذا الجهاز"))
            return
        }

        if (manager.hasPermission(device.usbDevice)) {
            scope.launch {
                executeUsbPrint(device, bitmap)
            }
        } else {
            ensureUsbReceiverRegistered()
            pendingUsbDeviceForPrint = device
            pendingUsbBitmap = bitmap

            val intent = Intent(ACTION_USB_PERMISSION).apply {
                setPackage(context.packageName)
            }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, flags)
            manager.requestPermission(device.usbDevice, pendingIntent)
        }
    }

    private fun ensureUsbReceiverRegistered() {
        if (usbReceiverRegistered) return
        val filter = IntentFilter(ACTION_USB_PERMISSION)
        ContextCompat.registerReceiver(
            context,
            usbPermissionReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        usbReceiverRegistered = true
    }

    private suspend fun executeUsbPrint(device: UsbPrinterDevice, bitmap: Bitmap) {
        withContext(Dispatchers.IO) {
            val manager = usbManager ?: return@withContext
            bluetoothManager.updateExternalState(PrinterState.Connecting(device.name))

            var connection: android.hardware.usb.UsbDeviceConnection? = null
            var claimedInterface: UsbInterface? = null

            try {
                val usbDevice = device.usbDevice
                var targetInterface: UsbInterface? = null
                var outEndpoint: UsbEndpoint? = null

                for (i in 0 until usbDevice.interfaceCount) {
                    val iface = usbDevice.getInterface(i)
                    for (j in 0 until iface.endpointCount) {
                        val ep = iface.getEndpoint(j)
                        if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK &&
                            ep.direction == UsbConstants.USB_DIR_OUT
                        ) {
                            targetInterface = iface
                            outEndpoint = ep
                            break
                        }
                    }
                    if (outEndpoint != null) break
                }

                if (targetInterface == null || outEndpoint == null) {
                    throw IOException("لم يتم العثور على قناة إخراج صالحة في طابعة USB")
                }

                connection = manager.openDevice(usbDevice)
                    ?: throw IOException("تعذر فتح اتصال USB بالطابعة")

                if (!connection.claimInterface(targetInterface, true)) {
                    throw IOException("تعذر حجز واجهة طابعة USB")
                }
                claimedInterface = targetInterface

                bluetoothManager.updateExternalState(PrinterState.Printing(15))

                val initBytes = byteArrayOf(0x1B, 0x40, 0x1B, 0x61, 0x01)
                connection.bulkTransfer(outEndpoint, initBytes, initBytes.size, 3000)

                val rasterBytes = bluetoothManager.convertBitmapToEscPosRaster(
                    bitmap,
                    bluetoothManager.selectedPaperType.value.widthPx
                ) { progress ->
                    bluetoothManager.updateExternalState(PrinterState.Printing(15 + (progress * 70 / 100)))
                }

                val chunkSize = maxOf(512, minOf(4096, outEndpoint.maxPacketSize * 8))
                var offset = 0
                while (offset < rasterBytes.size) {
                    val len = minOf(chunkSize, rasterBytes.size - offset)
                    val slice = rasterBytes.copyOfRange(offset, offset + len)
                    val transferred = connection.bulkTransfer(outEndpoint, slice, len, 5000)
                    if (transferred < 0) {
                        throw IOException("انقطع إرسال البيانات عبر كابل USB")
                    }
                    offset += len
                }

                val feedCut = byteArrayOf(0x1B, 0x64, 0x05, 0x1D, 0x56, 0x00)
                connection.bulkTransfer(outEndpoint, feedCut, feedCut.size, 3000)

                bluetoothManager.updateExternalState(
                    PrinterState.Success("تمت طباعة العقد بنجاح عبر USB إلى ${device.name}")
                )
            } catch (e: Exception) {
                bluetoothManager.updateExternalState(
                    PrinterState.Error("فشل الطباعة عبر USB: ${e.localizedMessage ?: "خطأ غير معروف"}")
                )
            } finally {
                try {
                    if (claimedInterface != null) {
                        connection?.releaseInterface(claimedInterface)
                    }
                    connection?.close()
                } catch (_: Exception) {
                }
            }
        }
    }

    fun cleanup() {
        stopWifiDiscovery()
        if (usbReceiverRegistered) {
            try {
                context.unregisterReceiver(usbPermissionReceiver)
            } catch (_: Exception) {
            }
            usbReceiverRegistered = false
        }
    }
}
