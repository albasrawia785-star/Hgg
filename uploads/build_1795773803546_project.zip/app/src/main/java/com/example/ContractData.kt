package com.example

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * أنواع العقود الرسمية المتاحة في التطبيق
 */
enum class ContractType(val titleAr: String, val iconResName: String) {
    REAL_ESTATE("عقد بيع وشراء عقار", "ic_home"),
    CAR_SALE("عقد بيع وشراء سيارة", "ic_directions_car"),
    RENTAL("عقد إيجار سكني/تجاري", "ic_key"),
    MOTORCYCLE("عقد بيع دراجة/تكتك/ستوتة", "ic_two_wheeler")
}

/**
 * بيانات عقد بيع وشراء العقارات (الدور والأراضي السكنية والزراعية)
 */
data class RealEstateContract(
    val contractNo: String = "0025",
    // الطرف الأول ( البائع )
    val sellerName: String = "",
    val sellerAddress: String = "",
    val sellerIdNumber: String = "",
    val sellerPhone: String = "",
    
    // الطرف الثاني ( المشتري )
    val buyerName: String = "",
    val buyerAddress: String = "",
    val buyerIdNumber: String = "",
    val buyerPhone: String = "",
    
    // تفاصيل العقار والبيع
    val propertyType: String = "دار سكني", // دار سكني / قطعة أرض / زراعي
    val propertyArea: String = "", // المساحة بالمتر المربع
    val plotSequenceNo: String = "", // الرقم والتسلسل
    val neighborhood: String = "", // المحلة / المنطقة
    
    val totalPrice: String = "", // بدل البيع المتفق عليه
    val totalPriceWords: String = "", // بدل البيع كتابةً (المبلغ كتابةً)
    val depositPrice: String = "", // العربون الذي تم قبضه
    val remainingPrice: String = "", // الباقي
    val penaltySellerAmount: String = "", // تضمينات امتناع البائع
    val penaltyBuyerAmount: String = "", // تضمينات امتناع المشتري
    
    val contractPlace: String = "", // مكان تحرير العقد (مثال: البصرة - حي الحسين)
    val contractDate: String = FormatUtils.getTodayDateString(), // تاريخ تحرير العقد
    val additionalNotes: String = "", // ملاحظات أو شروط إضافية
    
    val witness1Name: String = "", // الشاهد الأول
    val witness2Name: String = "" // الشاهد الثاني
)

/**
 * بيانات عقد بيع وشراء السيارات (معارض السيارات)
 */
data class CarSaleContract(
    val galleryName: String = "",
    val galleryPhone: String = "",
    val galleryAddress: String = "",
    val contractNo: String = "000100",
    val carLegalOwner: String = "", // المالك الشرعي للسيارة
    val ownerAddress: String = "",
    
    // الطرف الأول (البائع)
    val sellerName: String = "",
    val sellerAddress: String = "",
    val sellerIdNumber: String = "",
    val sellerPhone: String = "",
    
    // الطرف الثاني (المشتري)
    val buyerName: String = "",
    val buyerAddress: String = "",
    val buyerIdNumber: String = "",
    val buyerPhone: String = "",
    
    // مواصفات المركبة
    val carCategory: String = "خصوصي", // خصوصي / أجرة / حمل
    val carBrandAndType: String = "", // نوع السيارة (مثال: تويوتا لاندكروزر)
    val modelYear: String = "", // الموديل
    val color: String = "", // اللون
    val annualRegNumber: String = "", // رقم السنوية / اللوحة
    val engineNumber: String = "", // رقم المحرك
    val chassisNumber: String = "", // رقم الشاسي
    
    // المبالغ المالية
    val totalPrice: String = "", // بدل قدره
    val totalPriceWords: String = "", // المبلغ كتابةً
    val paidAmount: String = "", // المبلغ المستلم
    val remainingAmount: String = "", // المبلغ المتبقي
    
    val contractDate: String = FormatUtils.getTodayDateString(), // حرر بتاريخ
    val witness1Name: String = "", // الشاهد الأول
    val witness2Name: String = "", // الشاهد الثاني
    val witnessName: String = "", // الشاهد
    val organizerName: String = "" // منظم العقد
)

/**
 * بيانات عقد الإيجار
 */
data class RentalContract(
    val contractNo: String = "1024",
    val sequenceNumber: String = "", // عدد التسلسل
    val doorsNumber: String = "", // رقم الأبواب
    
    val lessorName: String = "", // المؤجر
    val lesseeName: String = "", // المستأجر
    
    val rentedPropertyDescription: String = "", // وصف العين المؤجرة (بعد الرؤية والاطلاع على)
    val propertyLocation: String = "", // الواقع
    val neighborhood: String = "", // في المحلة
    val alleyNumber: String = "", // زقاق / دار
    val leaseDuration: String = "", // لمدة (مثال: سنة واحدة)
    
    val startDate: String = FormatUtils.getTodayDateString(), // ابتداءً من
    val endDate: String = "", // إلى نهاية
    
    val rentAmountWords: String = "", // بدل إيجار فقط (كتابة)
    val rentAmountNumber: String = "", // المبلغ بالأرقام
    val returnToLesseeText: String = "", // العائد إلى المستأجر إليه ببدل إيجار...
    val dwellingRightDetails: String = "", // للمستأجر حق السكن...
    val dailyDelayFee: String = "", // ايجار يومي قدره
    val propertyTaxOwner: String = "", // ضريبة الاملاك على المؤجر أو صاحب
    
    val signDate: String = FormatUtils.getTodayDateString(), // كتبت على نسختين ببد كل من الفريقين... في تاريخ
    val additionalClauses: String = "", // فقرات إضافية
    
    val witness1Name: String = "", // الشاهد الأول
    val witness2Name: String = ""  // الشاهد الثاني
)

/**
 * بيانات عقد بيع وشراء الدراجات والتكتك والستوتات
 */
data class MotorcycleContract(
    val contractNo: String = "004126",
    
    // الطرف الأول ( البائع )
    val sellerName: String = "",
    val sellerAddress: String = "",
    val sellerNeighborhood: String = "",
    val sellerAlley: String = "",
    val sellerHouse: String = "",
    val sellerIdNumber: String = "",
    val sellerIdIssueDate: String = "",
    val sellerRegistry: String = "",
    val sellerPhone: String = "",
    
    // الطرف الثاني ( المشتري )
    val buyerName: String = "",
    val buyerAddress: String = "",
    val buyerNeighborhood: String = "",
    val buyerAlley: String = "",
    val buyerHouse: String = "",
    val buyerIdNumber: String = "",
    val buyerIdIssueDate: String = "",
    val buyerRegistry: String = "",
    val buyerPhone: String = "",
    
    // مواصفات المركبة / الدراجة
    val registeredNumber: String = "", // الدراجة المرقمة
    val vehicleType: String = "دراجة نارية", // نوع: ستوتة / تكتك / دراجة
    val contactPhone: String = "", // موبايل
    val color: String = "", // اللون
    val engineCc: String = "", // الحجم
    val brand: String = "", // الماركة
    val engineNumber: String = "", // رقم المحرك
    val chassisNumber: String = "", // رقم الشاسي
    
    // المالية
    val totalPrice: String = "", // ببدل قدره
    val totalPriceWords: String = "", // المبلغ كتابةً
    val paidAmount: String = "", // قبض البائع مبلغ قدره
    val remainingAmount: String = "", // والباقي
    
    // البائع الحائز
    val possessorName: String = "", // البائع الحائز
    val possessorAddress: String = "",
    val possessorNeighborhood: String = "",
    val possessorAlley: String = "",
    val possessorHouse: String = "",
    val possessorPhone: String = "",
    val possessorIdNumber: String = "",
    
    // ملاحظات وتاريخ والشهود
    val notes: String = "",
    val contractDate: String = FormatUtils.getTodayDateString(),
    val contractTime: String = "",
    val witness1Name: String = "",
    val witness2Name: String = "",
    val witnessName: String = ""
)

/**
 * كيان قاعدة البيانات لحفظ العقد في الأرشيف المحلي (Room Entity)
 */
@Entity(
    tableName = "saved_contracts",
    indices = [
        Index("dateCreated"),
        Index("primaryPartyName"),
        Index("secondaryPartyName")
    ]
)
data class ContractEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contractType: String,
    val title: String,
    val primaryPartyName: String,
    val secondaryPartyName: String,
    val dateCreated: Long = System.currentTimeMillis(),
    val jsonContent: String
)
