package com.example

import android.content.Context
import android.content.SharedPreferences

class SettingsManager private constructor(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("office_settings", Context.MODE_PRIVATE)

    var officeName: String
        get() = prefs.getString("office_name", "مكتب النبلاء للعقارات والسيارات") ?: "مكتب النبلاء للعقارات والسيارات"
        set(value) = prefs.edit().putString("office_name", value).apply()

    var officePhone: String
        get() = prefs.getString("office_phone", "07700000000") ?: "07700000000"
        set(value) = prefs.edit().putString("office_phone", value).apply()

    var officePhone2: String
        get() = prefs.getString("office_phone2", "07800000000") ?: "07800000000"
        set(value) = prefs.edit().putString("office_phone2", value).apply()

    var officeLicenseNo: String
        get() = prefs.getString("office_license_no", "") ?: ""
        set(value) = prefs.edit().putString("office_license_no", value).apply()

    var officeAddress: String
        get() = prefs.getString("office_address", "البصرة - الجزائر") ?: "البصرة - الجزائر"
        set(value) = prefs.edit().putString("office_address", value).apply()

    fun saveOfficeDetails(name: String, phone: String, phone2: String = "", licenseNo: String = "", address: String) {
        prefs.edit()
            .putString("office_name", name)
            .putString("office_phone", phone)
            .putString("office_phone2", phone2)
            .putString("office_license_no", licenseNo)
            .putString("office_address", address)
            .apply()
    }

    fun getOfficeInfo(): OfficeInfo {
        return OfficeInfo(
            officeName = officeName,
            phone = officePhone,
            phone2 = officePhone2,
            licenseNo = officeLicenseNo,
            address = officeAddress
        )
    }

    fun getOfficeDetails(): Triple<String, String, String> {
        return Triple(officeName, officePhone, officeAddress)
    }

    companion object {
        @Volatile
        private var instance: SettingsManager? = null

        fun getInstance(context: Context): SettingsManager {
            return instance ?: synchronized(this) {
                instance ?: SettingsManager(context.applicationContext).also { instance = it }
            }
        }
    }
}

