package com.example.utils

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * UserAliConfig: إعدادات وبيانات المدير العام الثابتة (ali) مع مسارات الفايربيس وتفضيلات التخزين المحتفظ بها.
 * يمكن التعديل اليدوي السريع على هذه البيانات من هنا مباشرة.
 */
object UserAliConfig {
    // 1. حساب المدير العام (Super Admin)
    const val SUPER_ADMIN_USERNAME = "ali"
    const val SUPER_ADMIN_PASSWORD = "19971997"

    // 2. المسار الرئيسي في الفايربيس (Firebase Realtime Database)
    const val FIREBASE_DATABASE_URL = "https://cohesive-bonbon-421722-default-rtdb.europe-west1.firebasedatabase.app"
    const val FIREBASE_NODE_LICENSES = "licenses"

    // 3. مفاتيح الشيرد بريفرنسز (SharedPreferences Keys)
    const val PREFS_NAME = "pos_app_prefs"
    const val KEY_RESTAURANT_NAME = "restaurant_name"
    const val KEY_RESTAURANT_PHONE = "restaurant_phone"
    const val KEY_LOGGED_USER = "logged_username"
    const val KEY_IS_SUPER_ADMIN = "is_super_admin"
}

/**
 * أنواع الاشتراكات المتاحة للمطاعم
 */
enum class LicenseType(val code: String) {
    PERMANENT("PERMANENT"), // اشتراك دائم بدون تاريخ انتهاء (-1)
    TRIAL("TRIAL");         // اشتراك تجريبي ينتهي بعد عدد أيام محدد

    companion object {
        fun fromString(type: String): LicenseType {
            return if (type.equals("TRIAL", ignoreCase = true)) TRIAL else PERMANENT
        }
    }
}

/**
 * نموذج حساب المطعم / بيانات الجلسة (UserAccount / SessionData)
 */
data class UserAccount(
    var keyId: String = "",
    var username: String = "",
    var password: String = "",
    var restaurantName: String = "",
    var phoneNumber: String = "",
    var type: String = LicenseType.PERMANENT.code,
    var expiryDate: Long = -1L,
    var isActive: Boolean = true
) {
    /**
     * تحويل النموذج إلى Map لحفظه في Realtime Database
     */
    fun toMap(): Map<String, Any> {
        return mapOf(
            "username" to username,
            "password" to password,
            "restaurantName" to restaurantName,
            "phoneNumber" to phoneNumber,
            "type" to type,
            "expiry_date" to expiryDate,
            "is_active" to isActive
        )
    }

    companion object {
        private fun parseBool(snapshot: DataSnapshot): Boolean? {
            if (!snapshot.exists()) return null
            val valBool = snapshot.getValue(Boolean::class.java)
            if (valBool != null) return valBool
            val raw = snapshot.value
            if (raw is Boolean) return raw
            if (raw is Number) return raw.toInt() != 0
            if (raw is String) {
                if (raw.equals("false", ignoreCase = true) || raw == "0") return false
                if (raw.equals("true", ignoreCase = true) || raw == "1") return true
            }
            return null
        }

        /**
         * بناء الكائن من DataSnapshot القادم من الفايربيس
         */
        fun fromSnapshot(snapshot: DataSnapshot): UserAccount? {
            return try {
                val key = snapshot.key ?: ""
                val uName = snapshot.child("username").getValue(String::class.java) ?: ""
                val pwd = snapshot.child("password").getValue(String::class.java) ?: ""
                val rName = snapshot.child("restaurantName").getValue(String::class.java)
                    ?: snapshot.child("restaurant_name").getValue(String::class.java) ?: ""
                val rPhone = snapshot.child("phoneNumber").getValue(String::class.java)
                    ?: snapshot.child("phone_number").getValue(String::class.java) ?: ""
                val lType = snapshot.child("type").getValue(String::class.java) ?: LicenseType.PERMANENT.code
                val exp = snapshot.child("expiry_date").getValue(Long::class.java)
                    ?: snapshot.child("expiryDate").getValue(Long::class.java) ?: -1L
                val active = parseBool(snapshot.child("is_active"))
                    ?: parseBool(snapshot.child("isActive")) ?: true

                UserAccount(
                    keyId = key,
                    username = uName,
                    password = pwd,
                    restaurantName = rName,
                    phoneNumber = rPhone,
                    type = lType,
                    expiryDate = exp,
                    isActive = active
                )
            } catch (e: Exception) {
                Log.e("UserAli", "Error parsing UserAccount snapshot: ", e)
                null
            }
        }
    }
}

/**
 * الكائن الرئيسي لإدارة الدخول، الاشتراكات السحابية، والطباعة الحرارية أوفلاين
 */
object UserAli {

    private const val TAG = "UserAli"

    @Synchronized
    fun ensureFirebaseInitialized(context: Context? = null) {
        try {
            if (context != null && FirebaseApp.getApps(context).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApiKey(com.bilda.security.SecurityShield.decode(byteArrayOf((0x1b).toByte(), (0x13).toByte(), (0x20).toByte(), (0x3b).toByte(), (0x9).toByte(), (0x23).toByte(), (0x1e).toByte(), (0x35).toByte(), (0x20).toByte(), (0x22).toByte(), (0x3f).toByte(), (0x36).toByte(), (0x6c).toByte(), (0x3f).toByte(), (0x17).toByte(), (0x2d).toByte(), (0x3c).toByte(), (0x6e).toByte(), (0x5).toByte(), (0x3).toByte(), (0x69).toByte(), (0x6d).toByte(), (0x6d).toByte(), (0xc).toByte(), (0x3c).toByte(), (0x14).toByte(), (0x0).toByte(), (0x6d).toByte(), (0xd).toByte(), (0x15).toByte(), (0x12).toByte(), (0x36).toByte(), (0x2e).toByte(), (0x2).toByte(), (0x23).toByte(), (0x14).toByte(), (0x35).toByte(), (0x28).toByte(), (0x29).toByte()), (0x5a).toByte()))
                    .setApplicationId("1:475485328675:web:0c050cac3160a30c602896")
                    .setDatabaseUrl(UserAliConfig.FIREBASE_DATABASE_URL)
                    .setProjectId("cohesive-bonbon-421722")
                    .setGcmSenderId("475485328675")
                    .setStorageBucket("cohesive-bonbon-421722.firebasestorage.app")
                    .build()
                FirebaseApp.initializeApp(context.applicationContext, options)
                Log.d(TAG, "FirebaseApp initialized programmatically")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in ensureFirebaseInitialized: ", e)
        }
    }

    private fun getDatabase(context: Context? = null): FirebaseDatabase {
        ensureFirebaseInitialized(context)
        return try {
            FirebaseDatabase.getInstance(UserAliConfig.FIREBASE_DATABASE_URL).apply {
                try {
                    setPersistenceEnabled(true)
                } catch (_: Exception) {
                    // Ignore if persistence was already enabled
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting FirebaseDatabase instance, retrying: ", e)
            FirebaseDatabase.getInstance(UserAliConfig.FIREBASE_DATABASE_URL)
        }
    }

    private fun getLicensesRef(context: Context? = null) = getDatabase(context).getReference(UserAliConfig.FIREBASE_NODE_LICENSES)

    /**
     * 1. تسجيل الدخول (login):
     * - يتحقق من دخول المدير العام علي (ali / 1997)
     * - أو يتحقق من حساب المطعم في الفايربيس
     * - يتحقق من تفعيل الحساب (is_active == true)
     * - يتحقق من تاريخ انتهاء الاشتراك التجريبي
     * - يحفظ اسم المطعم ورقم الهاتف محلياً لاستخدامهما في الطباعة بدون إنترنت
     */
    fun login(
        context: Context,
        userInput: String,
        passInput: String,
        onSuccess: (account: UserAccount?, isSuperAdmin: Boolean) -> Unit,
        onError: (errorMessage: String) -> Unit
    ) {
        val trimmedUser = userInput.trim()
        val trimmedPass = passInput.trim()

        if (trimmedUser.isBlank() || trimmedPass.isBlank()) {
            onError("يرجى إدخال اسم المستخدم وكلمة المرور")
            return
        }

        // 1.1 التحقق من حساب المدير العام علي
        if (trimmedUser.equals(UserAliConfig.SUPER_ADMIN_USERNAME, ignoreCase = true) &&
            trimmedPass == UserAliConfig.SUPER_ADMIN_PASSWORD
        ) {
            saveSuperAdminSession(context)
            Log.d(TAG, "Super Admin 'ali' logged in successfully")
            onSuccess(null, true)
            return
        }

        // 1.2 التحقق من حسابات المطاعم من الفايربيس
        try {
            getLicensesRef(context).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var foundAccount: UserAccount? = null

                    for (child in snapshot.children) {
                        val acc = UserAccount.fromSnapshot(child) ?: continue
                        if (acc.username.equals(trimmedUser, ignoreCase = true) && acc.password == trimmedPass) {
                            foundAccount = acc
                            break
                        }
                    }

                    if (foundAccount == null) {
                        onError("اسم المستخدم أو كلمة المرور غير صحيحة")
                        return
                    }

                    // التأكد من أن الحساب نشط
                    if (!foundAccount.isActive) {
                        onError("هذا الحساب معطل حالياً من قبل الإدارة")
                        return
                    }

                    // إذا كان الحساب تجريبياً، يتم التحقق من تاريخ الانتهاء
                    val isTrial = foundAccount.type.equals(LicenseType.TRIAL.code, ignoreCase = true)
                    if (isTrial && foundAccount.expiryDate != -1L) {
                        val currentTime = System.currentTimeMillis()
                        if (currentTime > foundAccount.expiryDate) {
                            onError("انتهت مدة الاشتراك التجريبي لهذا الحساب، يرجى التجديد مع الإدارة")
                            return
                        }
                    }

                    // حفظ البيانات محلياً في SharedPreferences لاستخدامها في ترويسة الوصل الحراري أوفلاين
                    saveRestaurantInfoToPrefs(context, foundAccount.restaurantName, foundAccount.phoneNumber)
                    saveUserSession(context, foundAccount.username)

                    onSuccess(foundAccount, false)
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e(TAG, "Firebase login error: ${error.message}")
                    // في حالة انقطاع الإنترنت، نحاول القراءة من التخزين المحلي الاحتياطي
                    val savedName = getRestaurantNameFromPrefs(context)
                    if (savedName.isNotEmpty()) {
                        val localAccount = UserAccount(
                            username = trimmedUser,
                            restaurantName = savedName,
                            phoneNumber = getRestaurantPhoneFromPrefs(context)
                        )
                        onSuccess(localAccount, false)
                    } else {
                        onError("تعذر الاتصال بالخادم، يرجى التأكد من الإنترنت عند أول تسجيل دخول")
                    }
                }
            })
        } catch (e: Exception) {
            Log.e(TAG, "Login exception: ", e)
            onError("حدث خطأ أثناء تسجيل الدخول: ${e.localizedMessage}")
        }
    }

    /**
     * 2. تسجيل وإنشاء حساب مطعم جديد للعملاء (registerNewClient / createAccount):
     * يُرفع لسيرفر Firebase في المسار "licenses" مع حساب تاريخ الانتهاء إذا كان الاشتراك تجريبياً.
     */
    fun registerNewClient(
        context: Context? = null,
        username: String,
        pass: String,
        restaurantName: String,
        phoneNumber: String,
        licenseType: String = LicenseType.PERMANENT.code,
        trialDays: Int = 30,
        onComplete: (success: Boolean, message: String?) -> Unit
    ) {
        createAccount(context, username, pass, restaurantName, phoneNumber, licenseType, trialDays, onComplete)
    }

    fun createAccount(
        context: Context? = null,
        username: String,
        pass: String,
        restaurantName: String,
        phoneNumber: String,
        licenseType: String = LicenseType.PERMANENT.code,
        trialDays: Int = 30,
        onComplete: (success: Boolean, message: String?) -> Unit
    ) {
        val trimmedUser = username.trim()
        val trimmedPass = pass.trim()
        val trimmedRestName = restaurantName.trim()
        val trimmedPhone = phoneNumber.trim()

        if (trimmedUser.isBlank() || trimmedPass.isBlank() || trimmedRestName.isBlank()) {
            onComplete(false, "يرجى ملء جميع الحقول المطلوبة (اسم المستخدم، كلمة المرور، اسم المطعم)")
            return
        }

        val type = LicenseType.fromString(licenseType).code
        val expiryDate = if (type == LicenseType.PERMANENT.code) {
            -1L
        } else {
            val days = if (trialDays > 0) trialDays else 30
            System.currentTimeMillis() + (days.toLong() * 24 * 60 * 60 * 1000L)
        }

        val newAccount = UserAccount(
            username = trimmedUser,
            password = trimmedPass,
            restaurantName = trimmedRestName,
            phoneNumber = trimmedPhone,
            type = type,
            expiryDate = expiryDate,
            isActive = true
        )

        try {
            val ref = getLicensesRef(context)
            val newKey = ref.push().key ?: trimmedUser
            newAccount.keyId = newKey

            ref.child(newKey).setValue(newAccount.toMap())
                .addOnSuccessListener {
                    Log.d(TAG, "Account created successfully for $trimmedUser")
                    onComplete(true, "تم إنشاء حساب المطعم بنجاح")
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Failed to create account: ", e)
                    onComplete(false, "فشل حفظ الحساب في الفايربيس: ${e.localizedMessage}")
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception creating account: ", e)
            onComplete(false, "حدث خطأ غير متوقع: ${e.localizedMessage}")
        }
    }

    /**
     * 3. جلب جميع حسابات المطاعم للمدير العام (fetchAllAccounts)
     */
    fun fetchAllAccounts(
        context: Context? = null,
        onResult: (accounts: List<UserAccount>) -> Unit,
        onError: (errorMessage: String) -> Unit
    ) {
        try {
            getLicensesRef(context).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val list = mutableListOf<UserAccount>()
                    for (child in snapshot.children) {
                        val acc = UserAccount.fromSnapshot(child)
                        if (acc != null) {
                            list.add(acc)
                        }
                    }
                    onResult(list)
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e(TAG, "fetchAllAccounts error: ${error.message}")
                    onError("فشل جلب قائمة الحسابات: ${error.message}")
                }
            })
        } catch (e: Exception) {
            Log.e(TAG, "fetchAllAccounts exception: ", e)
            onError("حدث خطأ في الاتصال: ${e.localizedMessage}")
        }
    }

    /**
     * 4. تعطيل أو تفعيل أي حساب مطعم عن بُعد (toggleAccountStatus)
     */
    fun toggleAccountStatus(
        context: Context? = null,
        keyId: String,
        currentStatus: Boolean,
        onComplete: (success: Boolean) -> Unit
    ) {
        if (keyId.isBlank()) {
            onComplete(false)
            return
        }

        try {
            val newStatus = !currentStatus
            val updates = mapOf<String, Any>(
                "is_active" to newStatus,
                "isActive" to newStatus
            )
            getLicensesRef(context).child(keyId).updateChildren(updates)
                .addOnSuccessListener {
                    Log.d(TAG, "Account $keyId status toggled to $newStatus")
                    onComplete(true)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Failed to toggle account status: ", e)
                    onComplete(false)
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception toggling status: ", e)
            onComplete(false)
        }
    }

    /**
     * 5. حذف حساب مطعم بشكل نهائي (deleteAccount)
     */
    fun deleteAccount(
        context: Context? = null,
        keyId: String,
        onComplete: (success: Boolean) -> Unit
    ) {
        if (keyId.isBlank()) {
            onComplete(false)
            return
        }

        try {
            getLicensesRef(context).child(keyId).removeValue()
                .addOnSuccessListener {
                    Log.d(TAG, "Account $keyId deleted permanently")
                    onComplete(true)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Failed to delete account: ", e)
                    onComplete(false)
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception deleting account: ", e)
            onComplete(false)
        }
    }

    /**
     * 6. تحديث بيانات حساب مطعم مشترك (مثل اسم المطعم ورقم الهاتف) من قبل المدير العام
     */
    fun updateClientAccountInfo(
        context: Context? = null,
        keyId: String,
        newRestaurantName: String,
        newPhoneNumber: String,
        onComplete: (success: Boolean) -> Unit
    ) {
        if (keyId.isBlank()) {
            onComplete(false)
            return
        }

        try {
            val updates = mapOf<String, Any>(
                "restaurantName" to newRestaurantName.trim(),
                "restaurant_name" to newRestaurantName.trim(),
                "phoneNumber" to newPhoneNumber.trim(),
                "phone_number" to newPhoneNumber.trim()
            )
            getLicensesRef(context).child(keyId).updateChildren(updates)
                .addOnSuccessListener {
                    Log.d(TAG, "Account $keyId updated successfully with name: ${newRestaurantName.trim()}")
                    onComplete(true)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Failed to update account: ", e)
                    onComplete(false)
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception updating account info: ", e)
            onComplete(false)
        }
    }

    /**
     * 7. مراقبة حالة الحساب الحالية وتفاصيله في الوقت الفعلي (Real-time Account Listener):
     * - إذا تم تحديث اسم المطعم، يتم تحديثه محلياً وفي التطبيق فوراً.
     * - إذا تم تعطيل الحساب أو حذفه من قبل المدير من الفايربيس، يتم تسجل الخروج فوراً.
     */
    fun listenToAccountStatus(
        context: Context,
        username: String,
        onAccountUpdated: ((restaurantName: String, phoneNumber: String) -> Unit)? = null,
        onAccountDisabledOrDeleted: (reason: String) -> Unit
    ): ValueEventListener? {
        val trimmedUser = username.trim()
        if (trimmedUser.isBlank() || trimmedUser.equals(UserAliConfig.SUPER_ADMIN_USERNAME, ignoreCase = true)) {
            return null
        }

        try {
            var lastKnownName = getRestaurantNameFromPrefs(context)

            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var foundAccount: UserAccount? = null
                    for (child in snapshot.children) {
                        val acc = UserAccount.fromSnapshot(child) ?: continue
                        if (acc.username.equals(trimmedUser, ignoreCase = true)) {
                            foundAccount = acc
                            break
                        }
                    }

                    if (foundAccount == null) {
                        // الحساب تم حذفه نهائياً
                        Log.w(TAG, "Account $trimmedUser deleted by admin")
                        onAccountDisabledOrDeleted("تم حذف الحساب من قبل الإدارة، يرجى التواصل مع المدير")
                    } else if (!foundAccount.isActive) {
                        // الحساب تم تعطيله
                        Log.w(TAG, "Account $trimmedUser disabled by admin")
                        onAccountDisabledOrDeleted("تم تعطيل حسابك من قبل الإدارة")
                    } else if (foundAccount.type.equals(LicenseType.TRIAL.code, ignoreCase = true) &&
                        foundAccount.expiryDate != -1L &&
                        System.currentTimeMillis() > foundAccount.expiryDate
                    ) {
                        // الاشتراك التجريبي انتهى
                        Log.w(TAG, "Trial expired for $trimmedUser")
                        onAccountDisabledOrDeleted("انتهت مدة الاشتراك التجريبي لهذا الحساب، يرجى التواصل مع الإدارة")
                    } else {
                        val newName = foundAccount.restaurantName.trim()
                        if (lastKnownName.isNotBlank() && newName.isNotBlank() && !newName.equals(lastKnownName, ignoreCase = false)) {
                            // تم تغيير اسم المطعم من قبل المدير العام -> تسجيل خروج إجباري فوراً
                            Log.w(TAG, "Restaurant name changed by admin for $trimmedUser from '$lastKnownName' to '$newName'")
                            lastKnownName = newName
                            saveRestaurantInfoToPrefs(context, newName, foundAccount.phoneNumber)
                            onAccountDisabledOrDeleted("تم تغيير اسم المطعم إلى ($newName) من قبل الإدارة، يرجى إعادة تسجيل الدخول")
                        } else {
                            if (newName.isNotBlank()) {
                                lastKnownName = newName
                                saveRestaurantInfoToPrefs(context, newName, foundAccount.phoneNumber)
                                onAccountUpdated?.invoke(newName, foundAccount.phoneNumber)
                            }
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e(TAG, "listenToAccountStatus cancelled: ${error.message}")
                }
            }

            getLicensesRef(context).addValueEventListener(listener)
            return listener
        } catch (e: Exception) {
            Log.e(TAG, "Exception in listenToAccountStatus: ", e)
            return null
        }
    }

    fun stopListeningToAccountStatus(context: Context, listener: ValueEventListener?) {
        if (listener != null) {
            try {
                getLicensesRef(context).removeEventListener(listener)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing account listener: ", e)
            }
        }
    }

    /**
     * فحص فوري لحالة الحساب للتأكد من وجوده وفعاليته عند فتح أو الرجوع للتطبيق من الخلفية
     */
    fun verifyAccountActiveInFirebase(
        context: Context,
        username: String,
        onValid: (restaurantName: String) -> Unit,
        onInvalid: (reason: String) -> Unit
    ) {
        val trimmedUser = username.trim()
        if (trimmedUser.isBlank() || trimmedUser.equals(UserAliConfig.SUPER_ADMIN_USERNAME, ignoreCase = true)) {
            onValid("")
            return
        }

        try {
            getLicensesRef(context).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    var foundAccount: UserAccount? = null
                    for (child in snapshot.children) {
                        val acc = UserAccount.fromSnapshot(child) ?: continue
                        if (acc.username.equals(trimmedUser, ignoreCase = true)) {
                            foundAccount = acc
                            break
                        }
                    }

                    if (foundAccount == null) {
                        Log.w(TAG, "Account $trimmedUser not found in Firebase check")
                        onInvalid("تم حذف الحساب من قبل الإدارة، يرجى التواصل مع المدير")
                    } else if (!foundAccount.isActive) {
                        Log.w(TAG, "Account $trimmedUser is disabled in Firebase check")
                        onInvalid("تم تعطيل حسابك من قبل الإدارة")
                    } else if (foundAccount.type.equals(LicenseType.TRIAL.code, ignoreCase = true) &&
                        foundAccount.expiryDate != -1L &&
                        System.currentTimeMillis() > foundAccount.expiryDate
                    ) {
                        Log.w(TAG, "Account $trimmedUser trial expired in Firebase check")
                        onInvalid("انتهت مدة الاشتراك التجريبي لهذا الحساب، يرجى التواصل مع الإدارة")
                    } else {
                        val lastKnownName = getRestaurantNameFromPrefs(context)
                        val newName = foundAccount.restaurantName.trim()
                        if (lastKnownName.isNotBlank() && newName.isNotBlank() && !newName.equals(lastKnownName, ignoreCase = false)) {
                            Log.w(TAG, "Restaurant name changed for $trimmedUser from '$lastKnownName' to '$newName'")
                            saveRestaurantInfoToPrefs(context, newName, foundAccount.phoneNumber)
                            onInvalid("تم تغيير اسم المطعم إلى ($newName) من قبل الإدارة، يرجى إعادة تسجيل الدخول")
                        } else {
                            if (newName.isNotBlank()) {
                                saveRestaurantInfoToPrefs(context, newName, foundAccount.phoneNumber)
                            }
                            onValid(newName)
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e(TAG, "verifyAccountActiveInFirebase cancelled: ${error.message}")
                }
            })
        } catch (e: Exception) {
            Log.e(TAG, "Exception verifying account active state: ", e)
        }
    }

    // =========================================================================
    // POS Printing Logic & Local Storage Helpers (تخصيص بيانات الفاتورة أوفلاين)
    // =========================================================================

    /**
     * حفظ اسم المطعم ورقم الهاتف في SharedPreferences
     */
    fun saveRestaurantInfoToPrefs(context: Context, name: String, phone: String) {
        val prefs = context.getSharedPreferences(UserAliConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(UserAliConfig.KEY_RESTAURANT_NAME, name)
            .putString(UserAliConfig.KEY_RESTAURANT_PHONE, phone)
            .apply()

        val posPrefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        posPrefs.edit()
            .putString("restaurant_name", name)
            .putString("restaurant_phone", phone)
            .apply()

        // مزامنة مع AppConfig لاستخدامها المباشر في الطباعة والترويسة
        AppConfig.restaurantName = name.ifBlank { Human.RESTAURANT_NAME }
        AppConfig.restaurantPhone = phone.ifBlank { Human.RESTAURANT_PHONE }
    }

    /**
     * جلب اسم المطعم المخصص للطباعة والترويسة
     */
    fun getRestaurantNameFromPrefs(context: Context): String {
        val prefs = context.getSharedPreferences(UserAliConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val name = prefs.getString(UserAliConfig.KEY_RESTAURANT_NAME, "") ?: ""
        if (name.isNotBlank()) return name

        val posPrefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val posName = posPrefs.getString("restaurant_name", "") ?: ""
        if (posName.isNotBlank()) return posName

        return Human.RESTAURANT_NAME
    }

    /**
     * جلب رقم هاتف المطعم المخصص للطباعة
     */
    fun getRestaurantPhoneFromPrefs(context: Context): String {
        val prefs = context.getSharedPreferences(UserAliConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val phone = prefs.getString(UserAliConfig.KEY_RESTAURANT_PHONE, "") ?: ""
        return phone.ifBlank { Human.RESTAURANT_PHONE }
    }

    private fun saveSuperAdminSession(context: Context) {
        val prefs = context.getSharedPreferences(UserAliConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(UserAliConfig.KEY_LOGGED_USER, UserAliConfig.SUPER_ADMIN_USERNAME)
            .putBoolean(UserAliConfig.KEY_IS_SUPER_ADMIN, true)
            .apply()
    }

    private fun saveUserSession(context: Context, username: String) {
        val prefs = context.getSharedPreferences(UserAliConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(UserAliConfig.KEY_LOGGED_USER, username)
            .putBoolean(UserAliConfig.KEY_IS_SUPER_ADMIN, false)
            .apply()
    }
}
