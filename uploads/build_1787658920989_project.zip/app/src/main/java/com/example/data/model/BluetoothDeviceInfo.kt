package com.example.data.model

enum class DeviceType {
    PRINTER,
    SPEAKER
}

data class BluetoothDeviceInfo(
    val name: String,
    val address: String,
    val isConnected: Boolean = false,
    val isPaired: Boolean = true,
    val type: DeviceType = DeviceType.PRINTER
)
