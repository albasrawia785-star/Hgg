package com.example.bluetooth.printer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BitmapEscPosHelper {

    /**
     * Renders a crisp Arabic ticket matching the mockup design to a Bitmap
     */
    fun renderTicketBitmap(
        patient: Patient,
        clinicName: String,
        paperSize: PaperSize
    ): Bitmap {
        val width = paperSize.widthDots
        val scale = if (paperSize == PaperSize.WIDTH_80MM) 1.0f else 0.75f

        // Estimated height
        val height = (460 * scale).toInt()

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
        }

        var y = 48f * scale

        // 1. Clinic Name
        paint.textSize = 34f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(clinicName, width / 2f, y, paint)
        y += 36f * scale

        // 2. Dashed separator
        val linePaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 2f * scale
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(8f * scale, 6f * scale), 0f)
        }
        val margin = 20f * scale
        canvas.drawLine(margin, y, width - margin, y, linePaint)
        y += 40f * scale

        // 3. "المراجع رقم"
        paint.textSize = 28f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("المراجع رقم", width / 2f, y, paint)
        y += 76f * scale

        // 4. Huge Bold Patient Number e.g. "25"
        paint.textSize = 80f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(patient.formattedNumber, width / 2f, y, paint)
        y += 40f * scale

        // 5. Dashed separator
        canvas.drawLine(margin, y, width - margin, y, linePaint)
        y += 36f * scale

        // 6. Date and Time
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.US)
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.US)
        val dateObj = Date(patient.timestamp)
        val dateText = dateFormat.format(dateObj)
        val timeText = timeFormat.format(dateObj)

        paint.textSize = 22f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(dateText, width / 2f, y, paint)
        y += 28f * scale
        canvas.drawText(timeText, width / 2f, y, paint)
        y += 38f * scale

        // 7. Footer Greeting
        paint.textSize = 22f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("شكراً لزيارتكم", width / 2f, y, paint)
        y += 28f * scale
        paint.textSize = 19f * scale
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("نتمنى لكم الصحة والعافية", width / 2f, y, paint)

        return bitmap
    }

    /**
     * Converts a Bitmap into 1-bit monochrome thresholded bytes for ESC/POS raster command
     */
    fun convertBitmapToMonochromeRaster(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val widthBytes = (width + 7) / 8
        val rasterBytes = ByteArray(widthBytes * height)

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        for (y in 0 until height) {
            for (x in 0 until width) {
                val pixel = pixels[y * width + x]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                val luminance = (r * 0.299 + g * 0.587 + b * 0.114).toInt()

                // Thresholding: dark pixels become 1 (print black dot)
                if (luminance < 160) {
                    val byteIndex = y * widthBytes + (x / 8)
                    val bitIndex = 7 - (x % 8)
                    rasterBytes[byteIndex] = (rasterBytes[byteIndex].toInt() or (1 shl bitIndex)).toByte()
                }
            }
        }
        return rasterBytes
    }

    /**
     * Generates complete ESC/POS raw byte packet for printing ticket
     */
    fun buildTicketPrintBytes(
        patient: Patient,
        clinicName: String,
        paperSize: PaperSize
    ): ByteArray {
        val bitmap = renderTicketBitmap(patient, clinicName, paperSize)
        val raster = convertBitmapToMonochromeRaster(bitmap)
        val imageCommand = EscPosPrinter.createRasterImageCommand(raster, bitmap.width, bitmap.height)

        val out = ByteArrayOutputStream()
        out.write(EscPosPrinter.CMD_INIT)
        out.write(EscPosPrinter.CMD_ALIGN_CENTER)
        out.write(imageCommand)
        out.write(EscPosPrinter.CMD_FEED_5_LINES)
        out.write(EscPosPrinter.CMD_CUT_PAPER_PARTIAL)

        return out.toByteArray()
    }
}
