package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.PaperSize
import com.example.data.model.Patient
import com.example.data.model.SystemSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class QueueRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("clinic_queue_prefs", Context.MODE_PRIVATE)

    private val _patients = MutableStateFlow<List<Patient>>(emptyList())
    val patients: StateFlow<List<Patient>> = _patients.asStateFlow()

    private val _currentPatient = MutableStateFlow<Patient?>(null)
    val currentPatient: StateFlow<Patient?> = _currentPatient.asStateFlow()

    private val _settings = MutableStateFlow(SystemSettings())
    val settings: StateFlow<SystemSettings> = _settings.asStateFlow()

    init {
        loadSettings()
        loadQueue()
    }

    private fun loadSettings() {
        val clinicName = prefs.getString("clinic_name", "العيادة الطبية") ?: "العيادة الطبية"
        val paperSizeName = prefs.getString("paper_size", PaperSize.WIDTH_80MM.name) ?: PaperSize.WIDTH_80MM.name
        val paperSize = try {
            PaperSize.valueOf(paperSizeName)
        } catch (_: Exception) {
            PaperSize.WIDTH_80MM
        }
        val autoPrint = prefs.getBoolean("auto_print", true)
        val callPhrase = prefs.getString("call_phrase", "المُراجِع رَقْم %s") ?: "المُراجِع رَقْم %s"
        val speechRate = prefs.getFloat("speech_rate", 0.85f)
        val pitch = prefs.getFloat("pitch", 1.0f)
        val volume = prefs.getFloat("volume", 1.0f)
        val enableChime = prefs.getBoolean("enable_chime", true)

        val selectedPrinter = prefs.getString("printer_name", "") ?: ""
        val selectedPrinterAddr = prefs.getString("printer_addr", "") ?: ""
        val selectedSpeaker = prefs.getString("speaker_name", "") ?: ""
        val selectedSpeakerAddr = prefs.getString("speaker_addr", "") ?: ""

        _settings.value = SystemSettings(
            clinicName = clinicName,
            paperSize = paperSize,
            autoPrintOnAdd = autoPrint,
            callPhrase = callPhrase,
            speechRate = speechRate,
            pitch = pitch,
            volume = volume,
            enableChime = enableChime,
            selectedPrinterName = selectedPrinter,
            selectedPrinterAddress = selectedPrinterAddr,
            selectedSpeakerName = selectedSpeaker,
            selectedSpeakerAddress = selectedSpeakerAddr
        )
    }

    fun updateSettings(newSettings: SystemSettings) {
        _settings.value = newSettings
        prefs.edit()
            .putString("clinic_name", newSettings.clinicName)
            .putString("paper_size", newSettings.paperSize.name)
            .putBoolean("auto_print", newSettings.autoPrintOnAdd)
            .putString("call_phrase", newSettings.callPhrase)
            .putFloat("speech_rate", newSettings.speechRate)
            .putFloat("pitch", newSettings.pitch)
            .putFloat("volume", newSettings.volume)
            .putBoolean("enable_chime", newSettings.enableChime)
            .putString("printer_name", newSettings.selectedPrinterName)
            .putString("printer_addr", newSettings.selectedPrinterAddress)
            .putString("speaker_name", newSettings.selectedSpeakerName)
            .putString("speaker_addr", newSettings.selectedSpeakerAddress)
            .apply()
    }

    private fun loadQueue() {
        val savedJson = prefs.getString("queue_data", null)
        if (savedJson != null) {
            try {
                val array = JSONArray(savedJson)
                val list = mutableListOf<Patient>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        Patient(
                            id = obj.getInt("id"),
                            queueNumber = obj.getInt("queueNumber"),
                            timestamp = obj.getLong("timestamp"),
                            isCalled = obj.optBoolean("isCalled", false),
                            isCurrent = obj.optBoolean("isCurrent", false)
                        )
                    )
                }
                _patients.value = list
                val current = list.firstOrNull { it.isCurrent } ?: list.firstOrNull { !it.isCalled } ?: list.lastOrNull()
                _currentPatient.value = current
                return
            } catch (_: Exception) {
                // Fallback to default mockup seed
            }
        }

        // Initialize with realistic clinic queue matching mockup (numbers 21..27, current is 25)
        val initialList = mutableListOf<Patient>()
        for (num in 21..27) {
            initialList.add(
                Patient(
                    id = num,
                    queueNumber = num,
                    timestamp = System.currentTimeMillis() - (27 - num) * 180000L,
                    isCalled = num < 25,
                    isCurrent = num == 25
                )
            )
        }
        _patients.value = initialList
        _currentPatient.value = initialList.firstOrNull { it.queueNumber == 25 }
        saveQueue()
    }

    private fun saveQueue() {
        val array = JSONArray()
        for (patient in _patients.value) {
            val obj = JSONObject()
            obj.put("id", patient.id)
            obj.put("queueNumber", patient.queueNumber)
            obj.put("timestamp", patient.timestamp)
            obj.put("isCalled", patient.isCalled)
            obj.put("isCurrent", patient.isCurrent)
            array.put(obj)
        }
        prefs.edit().putString("queue_data", array.toString()).apply()
    }

    fun addPatient(): Patient {
        val currentList = _patients.value
        val nextNumber = if (currentList.isEmpty()) 1 else (currentList.maxOf { it.queueNumber } + 1)
        val newPatient = Patient(
            id = nextNumber,
            queueNumber = nextNumber,
            timestamp = System.currentTimeMillis(),
            isCalled = false,
            isCurrent = currentList.none { it.isCurrent }
        )
        val updatedList = currentList + newPatient
        _patients.value = updatedList
        if (_currentPatient.value == null) {
            _currentPatient.value = newPatient
        }
        saveQueue()
        return newPatient
    }

    fun callCurrentPatient(): Patient? {
        val currentList = _patients.value
        if (currentList.isEmpty()) return null

        val current = _currentPatient.value ?: currentList.firstOrNull { !it.isCalled } ?: currentList.first()
        val updatedList = currentList.map {
            if (it.queueNumber == current.queueNumber) {
                it.copy(isCalled = true, isCurrent = true)
            } else {
                it.copy(isCurrent = false)
            }
        }
        _patients.value = updatedList
        val calledPatient = current.copy(isCalled = true, isCurrent = true)
        _currentPatient.value = calledPatient
        saveQueue()
        return calledPatient
    }

    fun moveToNextPatient(): Patient? {
        val currentList = _patients.value
        if (currentList.isEmpty()) return null

        val currentIndex = _currentPatient.value?.let { curr ->
            currentList.indexOfFirst { it.queueNumber == curr.queueNumber }
        } ?: -1

        val nextIndex = if (currentIndex in 0 until currentList.size - 1) {
            currentIndex + 1
        } else {
            currentList.indexOfFirst { !it.isCalled }.takeIf { it >= 0 } ?: 0
        }

        val nextPatient = currentList[nextIndex]
        val updatedList = currentList.mapIndexed { index, patient ->
            patient.copy(isCurrent = (index == nextIndex))
        }
        _patients.value = updatedList
        val newCurrent = nextPatient.copy(isCurrent = true)
        _currentPatient.value = newCurrent
        saveQueue()
        return newCurrent
    }

    fun selectPatient(patient: Patient) {
        val updatedList = _patients.value.map {
            it.copy(isCurrent = (it.queueNumber == patient.queueNumber))
        }
        _patients.value = updatedList
        _currentPatient.value = patient.copy(isCurrent = true)
        saveQueue()
    }

    fun resetQueue() {
        val initialPatient = Patient(
            id = 1,
            queueNumber = 1,
            timestamp = System.currentTimeMillis(),
            isCalled = false,
            isCurrent = true
        )
        val resetList = listOf(initialPatient)
        _patients.value = resetList
        _currentPatient.value = initialPatient
        saveQueue()
    }
}
