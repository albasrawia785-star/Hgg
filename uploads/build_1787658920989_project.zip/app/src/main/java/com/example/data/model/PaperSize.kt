package com.example.data.model

enum class PaperSize(val label: String, val widthDots: Int, val charsPerLine: Int) {
    WIDTH_58MM("58mm", 384, 32),
    WIDTH_80MM("80mm", 576, 48)
}
