package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BluetoothDeviceInfo
import com.example.ui.components.AppTopBar
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.GreenBorder
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedContainer
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ChoosePrinterScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val isBluetoothEnabled by viewModel.bluetoothDeviceManager.isBluetoothEnabled.collectAsState()
    val pairedPrinters by viewModel.bluetoothDeviceManager.pairedPrinters.collectAsState()
    val discoveredPrinters by viewModel.bluetoothDeviceManager.discoveredPrinters.collectAsState()
    val isScanning by viewModel.bluetoothDeviceManager.isScanning.collectAsState()
    val isPrinterConnected by viewModel.printerManager.isConnected.collectAsState()
    val isConnecting by viewModel.printerManager.isConnecting.collectAsState()
    val currentPrinterName by viewModel.printerManager.connectedDeviceName.collectAsState()

    val filteredPaired = pairedPrinters.filter {
        searchQuery.isEmpty() || it.name.contains(searchQuery, ignoreCase = true) || it.address.contains(searchQuery, ignoreCase = true)
    }

    val filteredDiscovered = discoveredPrinters.filter {
        (searchQuery.isEmpty() || it.name.contains(searchQuery, ignoreCase = true) || it.address.contains(searchQuery, ignoreCase = true)) &&
        pairedPrinters.none { paired -> paired.address == it.address }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Top App Bar
        AppTopBar(
            title = "اختيار طابعة حرارية حقيقية",
            showBackButton = true,
            showMenuButton = false,
            showSettingsButton = false,
            onBackClick = { viewModel.navigateBack() }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            // Bluetooth Disabled Warning Banner
            if (!isBluetoothEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(RedContainer)
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.BluetoothDisabled,
                            contentDescription = null,
                            tint = RedDestructive,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "البلوتوث غير مفعّل",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = RedDestructive
                            )
                            Text(
                                text = "يرجى تفعيل البلوتوث في الهاتف للبحث والاتصال بالطابعة الحرارية",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Search Input Row with Refresh Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "بحث عن طابعة بالاسم أو العنوان...",
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = TextSecondary
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("search_printer_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = NavyDark,
                        unfocusedBorderColor = Color(0xFFF1F5F9)
                    ),
                    singleLine = true
                )

                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = { viewModel.bluetoothDeviceManager.refreshPairedDevices() },
                        modifier = Modifier.size(52.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "تحديث",
                            tint = NavyDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Device Lists
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Section 1: Paired Devices
                item {
                    Text(
                        text = "الطابعات المقترنة بالجهاز (${filteredPaired.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                }

                if (filteredPaired.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White)
                                .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(14.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (searchQuery.isNotEmpty()) "لا توجد نتائج مطابقة للبحث" else "لا توجد طابعات مقترنة حالياً. اضغط على زر 'بحث عن طابعات جديدة' بالأسفل للبحث الفعلي عبر البلوتوث.",
                                fontSize = 12.sp,
                                color = TextMuted,
                                lineHeight = 18.sp
                            )
                        }
                    }
                } else {
                    items(filteredPaired) { device ->
                        val isCurrent = (device.name == currentPrinterName || device.address == viewModel.settings.value.selectedPrinterAddress) && isPrinterConnected
                        RealBluetoothDeviceCard(
                            device = device.copy(isConnected = isCurrent),
                            icon = Icons.Default.Print,
                            isConnecting = isConnecting && device.address == viewModel.settings.value.selectedPrinterAddress,
                            isPairedSection = true,
                            onClick = {
                                if (!isConnecting) {
                                    viewModel.onSelectPrinter(device)
                                }
                            }
                        )
                    }
                }

                // Section 2: Discovered Devices
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "الأجهزة المكتشفة القريبة (${filteredDiscovered.size})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        if (isScanning) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(12.dp),
                                    color = NavyDark,
                                    strokeWidth = 1.5.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "جاري الفحص...",
                                    fontSize = 11.sp,
                                    color = NavyDark,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                if (filteredDiscovered.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color.White)
                                .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(14.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isScanning) "جاري البحث عن طابعات بلوتوث مجاورة..." else "لم يتم اكتشاف أجهزة جديدة بعد. اضغط 'بحث عن طابعات جديدة' للبدء.",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }
                    }
                } else {
                    items(filteredDiscovered) { device ->
                        RealBluetoothDeviceCard(
                            device = device,
                            icon = Icons.Default.Print,
                            isConnecting = false,
                            isPairedSection = false,
                            onClick = {
                                viewModel.onSelectPrinter(device)
                            }
                        )
                    }
                }
            }
        }

        // Bottom Search / Scan Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .border(width = 1.dp, color = BorderSubtle)
                .padding(16.dp)
        ) {
            Button(
                onClick = {
                    if (isScanning) {
                        viewModel.bluetoothDeviceManager.stopDiscovery()
                    } else {
                        viewModel.bluetoothDeviceManager.startDiscovery()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("scan_printers_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isScanning) Color(0xFF475569) else NavyDark
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (isScanning) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إيقاف البحث عن الأجهزة",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextOnNavy
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Bluetooth,
                            contentDescription = null,
                            tint = TextOnNavy,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "بحث عن طابعات جديدة (Scan)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextOnNavy
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RealBluetoothDeviceCard(
    device: BluetoothDeviceInfo,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isConnecting: Boolean,
    isPairedSection: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(
                width = if (device.isConnected) 1.5.dp else 1.dp,
                color = if (device.isConnected) NavyDark else Color(0xFFF1F5F9),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (device.isConnected) NavyDark.copy(alpha = 0.1f) else Color(0xFFF8FAFC)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (device.isConnected) NavyDark else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = device.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (device.address.isNotBlank()) device.address else "Bluetooth",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Right Status Badge or Action
            if (isConnecting) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFFF1F5F9))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(12.dp),
                        color = NavyDark,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "جاري الاتصال...",
                        fontSize = 11.sp,
                        color = NavyDark,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else if (device.isConnected) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(GreenContainer)
                        .border(1.dp, GreenBorder, CircleShape)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(GreenSuccess)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "متصلة حالياً",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GreenText
                    )
                }
            } else if (isPairedSection) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFF1F5F9))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "اتصال",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(NavyDark.copy(alpha = 0.08f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "اقتران وتوصيل",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                }
            }
        }
    }
}
