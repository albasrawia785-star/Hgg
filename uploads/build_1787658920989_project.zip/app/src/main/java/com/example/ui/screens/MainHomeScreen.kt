package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.GreenBorder
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenDark
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedBorder
import com.example.ui.theme.RedContainer
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

@Composable
fun MainHomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentPatient by viewModel.currentPatient.collectAsState()
    val patients by viewModel.patients.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val isPrinterConnected by viewModel.printerManager.isConnected.collectAsState()
    val printerName by viewModel.printerManager.connectedDeviceName.collectAsState()
    val isSpeakerConnected by viewModel.audioRouteManager.isSpeakerConnected.collectAsState()
    val speakerName by viewModel.audioRouteManager.connectedSpeakerName.collectAsState()

    val totalCount = patients.size
    val waitingCount = patients.count { !it.isCalled }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // 1. Top Status Bar & Header (Geometric Balance Header)
        HeaderSection(
            clinicName = settings.clinicName,
            isPrinterConnected = isPrinterConnected,
            printerName = if (printerName.isNotEmpty()) printerName else "58mm",
            isSpeakerConnected = isSpeakerConnected,
            speakerName = if (speakerName.isNotEmpty()) speakerName else "Sony",
            onPrinterClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) },
            onSpeakerClick = { viewModel.navigateTo(AppScreen.CHOOSE_SPEAKER) }
        )

        // 2. Main Scrollable Content
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // 3. Hero Card: Prominent Patient Number (Geometric Balance Canvas)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(24.dp))
                    .shadow(
                        elevation = 2.dp,
                        shape = RoundedCornerShape(24.dp),
                        spotColor = Color(0x0A1B2B48)
                    )
                    .clickable {
                        currentPatient?.let { viewModel.onOpenTicketPreview(it) }
                    }
                    .padding(vertical = 28.dp, horizontal = 20.dp)
                    .testTag("current_patient_card")
            ) {
                // Decorative Geometric Circles in top corners
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .align(Alignment.TopEnd)
                        .background(NavyDark.copy(alpha = 0.025f), CircleShape)
                )

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "المراجع الحالي",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Prominent Huge Number
                    Text(
                        text = currentPatient?.formattedNumber ?: "1",
                        fontSize = 100.sp,
                        fontWeight = FontWeight.Black,
                        color = NavyDark,
                        lineHeight = 100.sp,
                        letterSpacing = (-2).sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Status Pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (currentPatient?.isCalled == true) GreenContainer else Color(0xFFF8FAFC))
                            .border(
                                1.dp,
                                if (currentPatient?.isCalled == true) GreenBorder else Color(0xFFE2E8F0),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = if (currentPatient?.isCalled == true) "تم الاستدعاء" else "بانتظار الاستدعاء...",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (currentPatient?.isCalled == true) GreenText else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 4. Quick Stats / Info Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Total Today Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(18.dp))
                        .clickable { viewModel.navigateTo(AppScreen.QUEUE_LIST) }
                        .padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Column {
                        Text(
                            text = "إجمالي اليوم",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$totalCount",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                }

                // In Waiting Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(18.dp))
                        .clickable { viewModel.navigateTo(AppScreen.QUEUE_LIST) }
                        .padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Column {
                        Text(
                            text = "في الانتظار",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$waitingCount",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 5. Action Controls Section
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Primary Call Button (Navy with soft shadow)
                Button(
                    onClick = { viewModel.onCallCurrentPatientClicked() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .shadow(
                            elevation = 6.dp,
                            shape = RoundedCornerShape(18.dp),
                            spotColor = NavyDark.copy(alpha = 0.3f)
                        )
                        .testTag("call_patient_button"),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "استدعاء المراجع",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "استدعاء المراجع",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Row with "إضافة مراجع" and "تصفير"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Add Patient Button (Outlined with 2dp Navy border)
                    Box(
                        modifier = Modifier
                            .weight(1.1f)
                            .height(52.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color.White)
                            .border(2.dp, NavyDark, RoundedCornerShape(18.dp))
                            .clickable { viewModel.onAddPatientClicked() }
                            .testTag("add_patient_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = "إضافة مراجع",
                                tint = NavyDark,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إضافة مراجع",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NavyDark
                            )
                        }
                    }

                    // Reset Button (Red 50 Container with Red border)
                    Box(
                        modifier = Modifier
                            .weight(0.9f)
                            .height(52.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(RedContainer)
                            .border(1.dp, RedBorder, RoundedCornerShape(18.dp))
                            .clickable { viewModel.onOpenResetDialog() }
                            .testTag("reset_queue_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تصفير",
                                tint = RedDestructive,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تصفير",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = RedDestructive
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // 6. Bottom Navigation Bar (Geometric Balance Nav)
        BottomNavBar(
            activeScreen = AppScreen.HOME,
            onHomeClick = { /* Already here */ },
            onQueueClick = { viewModel.navigateTo(AppScreen.QUEUE_LIST) },
            onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) }
        )
    }
}

@Composable
private fun HeaderSection(
    clinicName: String,
    isPrinterConnected: Boolean,
    printerName: String,
    isSpeakerConnected: Boolean,
    speakerName: String,
    onPrinterClick: () -> Unit,
    onSpeakerClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Clinic branding & system title
        Column {
            Text(
                text = clinicName,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark,
                letterSpacing = (-0.5).sp
            )
            Text(
                text = "نظام إدارة المراجعين",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = TextSecondary
            )
        }

        // Status Badges
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Printer Status Dot
            DeviceStatusPill(
                label = "طابعة $printerName",
                isConnected = isPrinterConnected,
                onClick = onPrinterClick
            )

            // Speaker Status Dot
            DeviceStatusPill(
                label = "سماعة $speakerName",
                isConnected = isSpeakerConnected,
                onClick = onSpeakerClick
            )
        }
    }
}

@Composable
private fun DeviceStatusPill(
    label: String,
    isConnected: Boolean,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (isConnected) GreenContainer else Color(0xFFF1F5F9))
            .border(
                1.dp,
                if (isConnected) GreenBorder else Color(0xFFE2E8F0),
                CircleShape
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(if (isConnected) GreenSuccess else TextMuted)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (isConnected) GreenText else TextSecondary
        )
    }
}

@Composable
fun BottomNavBar(
    activeScreen: AppScreen,
    onHomeClick: () -> Unit,
    onQueueClick: () -> Unit,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White)
            .border(width = 1.dp, color = BorderSubtle)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Home
        BottomNavItem(
            icon = Icons.Default.Home,
            label = "الرئيسية",
            isSelected = activeScreen == AppScreen.HOME,
            onClick = onHomeClick
        )

        // Queue
        BottomNavItem(
            icon = Icons.Default.FormatListNumbered,
            label = "القائمة",
            isSelected = activeScreen == AppScreen.QUEUE_LIST,
            onClick = onQueueClick
        )

        // Settings
        BottomNavItem(
            icon = Icons.Default.Settings,
            label = "الإعدادات",
            isSelected = activeScreen == AppScreen.DEVICE_SETTINGS,
            onClick = onSettingsClick
        )
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) NavyDark else TextMuted,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) NavyDark else TextMuted
        )
    }
}
