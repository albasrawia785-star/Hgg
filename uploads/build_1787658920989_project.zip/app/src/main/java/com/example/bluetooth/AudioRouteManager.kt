package com.example.bluetooth

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioRouteManager(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _isSpeakerConnected = MutableStateFlow(false)
    val isSpeakerConnected: StateFlow<Boolean> = _isSpeakerConnected.asStateFlow()

    private val _connectedSpeakerName = MutableStateFlow("")
    val connectedSpeakerName: StateFlow<String> = _connectedSpeakerName.asStateFlow()

    private val _connectedSpeakerAddress = MutableStateFlow("")
    val connectedSpeakerAddress: StateFlow<String> = _connectedSpeakerAddress.asStateFlow()

    init {
        checkCurrentAudioRouting()
    }

    fun checkCurrentAudioRouting() {
        if (audioManager == null) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val btDevice = devices.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER) ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
            }

            if (btDevice != null) {
                _isSpeakerConnected.value = true
                val name = btDevice.productName?.toString()?.takeIf { it.isNotBlank() } ?: "سماعة بلوتوث"
                _connectedSpeakerName.value = name
                _connectedSpeakerAddress.value = btDevice.address ?: ""
            } else {
                _isSpeakerConnected.value = false
                _connectedSpeakerName.value = ""
                _connectedSpeakerAddress.value = ""
            }
        }
    }

    fun connectSpeaker(name: String, address: String) {
        _connectedSpeakerName.value = name
        _connectedSpeakerAddress.value = address
        _isSpeakerConnected.value = true
        routeToBluetoothA2dp()
    }

    fun disconnectSpeaker() {
        _isSpeakerConnected.value = false
        _connectedSpeakerName.value = ""
        _connectedSpeakerAddress.value = ""
        fallbackToPhoneSpeaker()
    }

    fun routeToBluetoothA2dp() {
        if (audioManager == null) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val devices = audioManager.availableCommunicationDevices
                val btDevice = devices.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                    it.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                }
                if (btDevice != null) {
                    audioManager.setCommunicationDevice(btDevice)
                }
            } catch (_: Exception) {}
        }
    }

    fun fallbackToPhoneSpeaker() {
        if (audioManager == null) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                audioManager.clearCommunicationDevice()
            } catch (_: Exception) {}
        }
    }
}
