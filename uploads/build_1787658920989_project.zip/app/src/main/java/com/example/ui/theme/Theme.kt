package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = NavyDark,
    onPrimary = TextOnNavy,
    primaryContainer = NavyLight,
    onPrimaryContainer = TextOnNavy,
    secondary = GreenSuccess,
    onSecondary = TextOnNavy,
    secondaryContainer = GreenContainer,
    onSecondaryContainer = GreenText,
    tertiary = NavyAccent,
    onTertiary = TextOnNavy,
    background = SurfaceSubtle,
    onBackground = TextPrimary,
    surface = SurfaceLight,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceSubtle,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = BorderLight,
    error = RedDestructive,
    onError = TextOnNavy,
    errorContainer = RedContainer,
    onErrorContainer = RedText
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun ClinicQueueTheme(
    content: @Composable () -> Unit
) {
    // Force RTL layout direction and crisp Light Theme
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = LightColorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content
        )
    }
}
