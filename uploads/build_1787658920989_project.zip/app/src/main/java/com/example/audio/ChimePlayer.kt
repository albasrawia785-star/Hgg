package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.example.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

class ChimePlayer(private val context: Context) {

    /**
     * Plays the embedded hospital chime alert tone from raw resource (res/raw/chime.wav)
     * using standard MediaPlayer initialization sequence (setDataSource -> setAudioAttributes -> prepare -> start)
     * to avoid MediaPlayerNative state warning.
     */
    suspend fun playChime(): Boolean = withContext(Dispatchers.IO) {
        suspendCancellableCoroutine { continuation ->
            val mediaPlayer = MediaPlayer()
            try {
                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()

                mediaPlayer.setAudioAttributes(audioAttributes)

                val afd = context.resources.openRawResourceFd(R.raw.chime)
                if (afd == null) {
                    mediaPlayer.release()
                    if (continuation.isActive) {
                        continuation.resume(false)
                    }
                    return@suspendCancellableCoroutine
                }

                mediaPlayer.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()

                mediaPlayer.setOnCompletionListener { mp ->
                    try {
                        mp.stop()
                        mp.release()
                    } catch (_: Exception) {}
                    if (continuation.isActive) {
                        continuation.resume(true)
                    }
                }

                mediaPlayer.setOnErrorListener { mp, _, _ ->
                    try {
                        mp.stop()
                        mp.release()
                    } catch (_: Exception) {}
                    if (continuation.isActive) {
                        continuation.resume(false)
                    }
                    true
                }

                mediaPlayer.setOnPreparedListener { mp ->
                    try {
                        mp.start()
                    } catch (e: Exception) {
                        if (continuation.isActive) {
                            continuation.resume(false)
                        }
                    }
                }

                continuation.invokeOnCancellation {
                    try {
                        if (mediaPlayer.isPlaying) {
                            mediaPlayer.stop()
                        }
                        mediaPlayer.release()
                    } catch (_: Exception) {}
                }

                mediaPlayer.prepareAsync()
            } catch (e: Exception) {
                e.printStackTrace()
                try {
                    mediaPlayer.release()
                } catch (_: Exception) {}
                if (continuation.isActive) {
                    continuation.resume(false)
                }
            }
        }
    }
}
