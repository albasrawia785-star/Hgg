package com.example.bluetooth.printer

import java.io.ByteArrayOutputStream

object EscPosPrinter {

    val CMD_INIT: ByteArray = byteArrayOf(0x1B, 0x40) // ESC @
    val CMD_ALIGN_LEFT: ByteArray = byteArrayOf(0x1B, 0x61, 0x00) // ESC a 0
    val CMD_ALIGN_CENTER: ByteArray = byteArrayOf(0x1B, 0x61, 0x01) // ESC a 1
    val CMD_ALIGN_RIGHT: ByteArray = byteArrayOf(0x1B, 0x61, 0x02) // ESC a 2
    val CMD_BOLD_ON: ByteArray = byteArrayOf(0x1B, 0x45, 0x01) // ESC E 1
    val CMD_BOLD_OFF: ByteArray = byteArrayOf(0x1B, 0x45, 0x00) // ESC E 0
    val CMD_FEED_LINE: ByteArray = byteArrayOf(0x0A) // LF
    val CMD_FEED_3_LINES: ByteArray = byteArrayOf(0x1B, 0x64, 0x03) // ESC d 3
    val CMD_FEED_5_LINES: ByteArray = byteArrayOf(0x1B, 0x64, 0x05) // ESC d 5
    val CMD_CUT_PAPER_PARTIAL: ByteArray = byteArrayOf(0x1D, 0x56, 0x01) // GS V 1
    val CMD_CUT_PAPER_FULL: ByteArray = byteArrayOf(0x1D, 0x56, 0x41, 0x00) // GS V 65 0

    /**
     * Converts a 1-bit monochrome bitmap byte buffer to ESC/POS GS v 0 raster image command
     * Command format: GS v 0 m xL xH yL yH d1...dk
     * m = 0 (normal)
     * xL, xH = width in bytes (width / 8)
     * yL, yH = height in dots
     */
    fun createRasterImageCommand(rasterBytes: ByteArray, widthDots: Int, heightDots: Int): ByteArray {
        val widthBytes = (widthDots + 7) / 8
        val xL = (widthBytes and 0xFF).toByte()
        val xH = ((widthBytes shr 8) and 0xFF).toByte()
        val yL = (heightDots and 0xFF).toByte()
        val yH = ((heightDots shr 8) and 0xFF).toByte()

        val output = ByteArrayOutputStream()
        output.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00, xL, xH, yL, yH))
        output.write(rasterBytes)
        return output.toByteArray()
    }
}
