package com.example.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.example.data.model.BluetoothDeviceInfo
import com.example.data.model.DeviceType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class BluetoothDeviceManager(private val context: Context) {

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _isBluetoothEnabled = MutableStateFlow(bluetoothAdapter?.isEnabled == true)
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _pairedPrinters = MutableStateFlow<List<BluetoothDeviceInfo>>(emptyList())
    val pairedPrinters: StateFlow<List<BluetoothDeviceInfo>> = _pairedPrinters.asStateFlow()

    private val _pairedSpeakers = MutableStateFlow<List<BluetoothDeviceInfo>>(emptyList())
    val pairedSpeakers: StateFlow<List<BluetoothDeviceInfo>> = _pairedSpeakers.asStateFlow()

    private val _discoveredPrinters = MutableStateFlow<List<BluetoothDeviceInfo>>(emptyList())
    val discoveredPrinters: StateFlow<List<BluetoothDeviceInfo>> = _discoveredPrinters.asStateFlow()

    private val _discoveredSpeakers = MutableStateFlow<List<BluetoothDeviceInfo>>(emptyList())
    val discoveredSpeakers: StateFlow<List<BluetoothDeviceInfo>> = _discoveredSpeakers.asStateFlow()

    private val _discoveredAllDevices = MutableStateFlow<List<BluetoothDeviceInfo>>(emptyList())
    val discoveredAllDevices: StateFlow<List<BluetoothDeviceInfo>> = _discoveredAllDevices.asStateFlow()

    private val receiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    if (device != null) {
                        val name = device.name?.takeIf { it.isNotBlank() } ?: "جهاز بلوتوث (${device.address})"
                        val address = device.address ?: ""
                        val majorClass = device.bluetoothClass?.majorDeviceClass
                        val isAudio = majorClass == BluetoothClass.Device.Major.AUDIO_VIDEO ||
                                isAudioDeviceName(name)
                        val isPrinter = isPrinterClassOrName(device.bluetoothClass, name)

                        val deviceType = when {
                            isAudio -> DeviceType.SPEAKER
                            isPrinter -> DeviceType.PRINTER
                            else -> DeviceType.PRINTER // Default or general
                        }

                        val info = BluetoothDeviceInfo(
                            name = name,
                            address = address,
                            isConnected = false,
                            isPaired = (device.bondState == BluetoothDevice.BOND_BONDED),
                            type = deviceType
                        )

                        // Update all discovered
                        val currentAll = _discoveredAllDevices.value.toMutableList()
                        if (currentAll.none { it.address == address }) {
                            currentAll.add(info)
                            _discoveredAllDevices.value = currentAll
                        }

                        // Update discovered printers
                        if (deviceType == DeviceType.PRINTER || !isAudio) {
                            val currentPrinters = _discoveredPrinters.value.toMutableList()
                            if (currentPrinters.none { it.address == address }) {
                                currentPrinters.add(info.copy(type = DeviceType.PRINTER))
                                _discoveredPrinters.value = currentPrinters
                            }
                        }

                        // Update discovered speakers
                        if (deviceType == DeviceType.SPEAKER || isAudio) {
                            val currentSpeakers = _discoveredSpeakers.value.toMutableList()
                            if (currentSpeakers.none { it.address == address }) {
                                currentSpeakers.add(info.copy(type = DeviceType.SPEAKER))
                                _discoveredSpeakers.value = currentSpeakers
                            }
                        }
                    }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    _isScanning.value = false
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                    _isBluetoothEnabled.value = (state == BluetoothAdapter.STATE_ON)
                    if (state == BluetoothAdapter.STATE_ON) {
                        refreshPairedDevices()
                    } else {
                        _pairedPrinters.value = emptyList()
                        _pairedSpeakers.value = emptyList()
                        _isScanning.value = false
                    }
                }
            }
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        try {
            context.registerReceiver(receiver, filter)
        } catch (_: Exception) {}

        refreshPairedDevices()
    }

    @SuppressLint("MissingPermission")
    fun refreshPairedDevices() {
        val adapter = bluetoothAdapter
        if (adapter == null || !adapter.isEnabled) {
            _pairedPrinters.value = emptyList()
            _pairedSpeakers.value = emptyList()
            return
        }

        val bonded = try {
            adapter.bondedDevices
        } catch (_: SecurityException) {
            emptySet()
        }

        val printers = mutableListOf<BluetoothDeviceInfo>()
        val speakers = mutableListOf<BluetoothDeviceInfo>()

        if (!bonded.isNullOrEmpty()) {
            for (device in bonded) {
                val name = device.name?.takeIf { it.isNotBlank() } ?: "جهاز مقترن (${device.address})"
                val addr = device.address ?: ""
                val majorClass = device.bluetoothClass?.majorDeviceClass

                val isAudio = majorClass == BluetoothClass.Device.Major.AUDIO_VIDEO || isAudioDeviceName(name)
                val isPrinter = isPrinterClassOrName(device.bluetoothClass, name)

                if (isAudio) {
                    speakers.add(
                        BluetoothDeviceInfo(
                            name = name,
                            address = addr,
                            isConnected = false,
                            isPaired = true,
                            type = DeviceType.SPEAKER
                        )
                    )
                } else if (isPrinter) {
                    printers.add(
                        BluetoothDeviceInfo(
                            name = name,
                            address = addr,
                            isConnected = false,
                            isPaired = true,
                            type = DeviceType.PRINTER
                        )
                    )
                } else {
                    // Devices whose class is imaging, uncategorized, or general POS
                    printers.add(
                        BluetoothDeviceInfo(
                            name = name,
                            address = addr,
                            isConnected = false,
                            isPaired = true,
                            type = DeviceType.PRINTER
                        )
                    )
                }
            }
        }

        _pairedPrinters.value = printers
        _pairedSpeakers.value = speakers
    }

    private fun isAudioDeviceName(name: String): Boolean {
        val lower = name.lowercase()
        return lower.contains("speaker") || lower.contains("sound") || lower.contains("audio") ||
                lower.contains("headset") || lower.contains("earphone") || lower.contains("jbl") ||
                lower.contains("sony") || lower.contains("bose") || lower.contains("airpod") ||
                lower.contains("buds") || lower.contains("soundcore") || lower.contains("speaker")
    }

    private fun isPrinterClassOrName(btClass: BluetoothClass?, name: String): Boolean {
        val lower = name.lowercase()
        if (lower.contains("print") || lower.contains("pos") || lower.contains("receipt") ||
            lower.contains("xp") || lower.contains("mpt") || lower.contains("rpp") ||
            lower.contains("esc") || lower.contains("thermal") || lower.contains("bt-") ||
            lower.contains("q90") || lower.contains("58") || lower.contains("80")
        ) {
            return true
        }

        val major = btClass?.majorDeviceClass
        val deviceClass = btClass?.deviceClass
        return major == BluetoothClass.Device.Major.IMAGING ||
                deviceClass == BluetoothClass.Device.Major.IMAGING
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        val adapter = bluetoothAdapter
        if (adapter == null || !adapter.isEnabled) {
            return
        }

        _isScanning.value = true
        _discoveredPrinters.value = emptyList()
        _discoveredSpeakers.value = emptyList()
        _discoveredAllDevices.value = emptyList()

        try {
            if (adapter.isDiscovering) {
                adapter.cancelDiscovery()
            }
            val started = adapter.startDiscovery()
            if (!started) {
                _isScanning.value = false
            }
        } catch (_: SecurityException) {
            _isScanning.value = false
        }
    }

    @SuppressLint("MissingPermission")
    fun stopDiscovery() {
        try {
            bluetoothAdapter?.cancelDiscovery()
        } catch (_: SecurityException) {}
        _isScanning.value = false
    }

    fun getDevice(address: String): BluetoothDevice? {
        if (address.isBlank()) return null
        return try {
            bluetoothAdapter?.getRemoteDevice(address)
        } catch (_: Exception) {
            null
        }
    }
}
