package com.example.server

import com.example.data.local.AppDatabase
import com.example.data.local.SharedRecordEntity
import com.example.model.HostedSite
import com.example.model.ServerLog
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.URLDecoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class LocalHttpServer(
    private val port: Int = 8080,
    private val ipProvider: () -> String = { "192.168.49.1" },
    private val webRootDirProvider: () -> File,
    private val siteMetaProvider: () -> HostedSite,
    private val database: AppDatabase,
    private val onLog: (ServerLog) -> Unit
) {
    private var primaryServerSocket: ServerSocket? = null
    private var port80ServerSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val threadPool = Executors.newCachedThreadPool()

    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)

        // 1. Start Configured Primary Port (e.g. 8080)
        try {
            primaryServerSocket = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(port))
            }
            threadPool.execute {
                listenOnSocket(primaryServerSocket, port)
            }
            onLog(
                ServerLog(
                    clientIp = ipProvider(),
                    requestPath = "خادم الويب وقاعدة البيانات المشتركة يعملان على المنفذ [$port]",
                    statusCode = 200,
                    isVideoChunk = false
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            onLog(
                ServerLog(
                    clientIp = "127.0.0.1",
                    requestPath = "خطأ في تشغيل المنفذ $port: ${e.message}",
                    statusCode = 500,
                    isVideoChunk = false
                )
            )
        }

        // 2. Start Standard HTTP Port 80
        if (port != 80) {
            try {
                port80ServerSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(80))
                }
                threadPool.execute {
                    listenOnSocket(port80ServerSocket, 80)
                }
                onLog(
                    ServerLog(
                        clientIp = ipProvider(),
                        requestPath = "⚡ تم تفعيل المنفذ القياسي [80] لاعتراض الهوت سبوت الفوري",
                        statusCode = 200,
                        isVideoChunk = false
                    )
                )
            } catch (e: Exception) {}
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            primaryServerSocket?.close()
        } catch (e: Exception) {}
        try {
            port80ServerSocket?.close()
        } catch (e: Exception) {}
        primaryServerSocket = null
        port80ServerSocket = null
    }

    fun isServerRunning(): Boolean = isRunning.get()

    private fun listenOnSocket(socketServer: ServerSocket?, currentPort: Int) {
        while (isRunning.get()) {
            try {
                val socket = socketServer?.accept() ?: break
                threadPool.execute {
                    handleClient(socket, currentPort)
                }
            } catch (e: SocketException) {
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun handleClient(socket: Socket, currentPort: Int) {
        val clientIp = socket.inetAddress?.hostAddress ?: "unknown"
        try {
            socket.soTimeout = 20000
            val inputStream = socket.getInputStream()
            val outputStream = socket.getOutputStream()
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))

            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return

            val method = parts[0].uppercase()
            val rawPath = parts[1]
            val path = URLDecoder.decode(rawPath.substringBefore("?"), "UTF-8")
            val queryString = rawPath.substringAfter("?", "")

            // Parse Headers
            val headers = mutableMapOf<String, String>()
            var line: String? = reader.readLine()
            var contentLength = 0
            while (!line.isNullOrEmpty()) {
                val colonIdx = line.indexOf(':')
                if (colonIdx != -1) {
                    val key = line.substring(0, colonIdx).trim().lowercase()
                    val value = line.substring(colonIdx + 1).trim()
                    headers[key] = value
                    if (key == "content-length") {
                        contentLength = value.toIntOrNull() ?: 0
                    }
                }
                line = reader.readLine()
            }

            // Read Body if present
            var body = ""
            if (contentLength > 0) {
                val charBuffer = CharArray(contentLength)
                var readTotal = 0
                while (readTotal < contentLength) {
                    val read = reader.read(charBuffer, readTotal, contentLength - readTotal)
                    if (read == -1) break
                    readTotal += read
                }
                body = String(charBuffer, 0, readTotal)
            }

            val host = headers["host"] ?: ipProvider()
            val userAgent = headers["user-agent"] ?: ""

            // Handle CORS Pre-flight Options for all requests
            if (method == "OPTIONS") {
                sendCorsOk(outputStream)
                return
            }

            when {
                // 1. Universal REST API handler: covers /api/*, /data/*, /db/*, /records/*, /items/*, /todos/*, /users/*
                isApiRequest(path) -> {
                    handleUniversalDatabaseApi(outputStream, method, path, queryString, body, clientIp)
                }

                // 2. Favicon
                path == "/favicon.ico" -> {
                    val favFile = File(webRootDirProvider(), "favicon.ico")
                    if (favFile.exists()) {
                        serveStaticFile(outputStream, favFile, clientIp, path)
                    } else {
                        send404(outputStream, clientIp, path)
                    }
                }

                // 3. Apple Captive Probe
                isAppleProbe(path, host, userAgent) -> {
                    serveApplePortal(outputStream, clientIp, path)
                }

                // 4. Android Captive Probe
                isAndroidProbe(path, host) -> {
                    serveAndroidPortalRedirect(outputStream, clientIp, path, currentPort)
                }

                // 5. Windows / Firefox Probe
                isWindowsOrFirefoxProbe(path, host) -> {
                    serveGenericCaptiveRedirect(outputStream, clientIp, path, currentPort)
                }

                // 6. Normal Static File or React / SPA HTML5 Fallback
                else -> {
                    serveWebRoute(outputStream, clientIp, path)
                }
            }
        } catch (e: Exception) {
            // Client socket disconnect
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {}
        }
    }

    private fun isApiRequest(path: String): Boolean {
        val p = path.lowercase()
        return p.startsWith("/api/") ||
                p == "/api" ||
                p.startsWith("/data/") ||
                p == "/data" ||
                p.startsWith("/db/") ||
                p == "/db" ||
                p.startsWith("/records/") ||
                p == "/records" ||
                p.startsWith("/todos") ||
                p.startsWith("/items") ||
                p.startsWith("/posts") ||
                p.startsWith("/users") ||
                p.startsWith("/messages")
    }

    private fun handleUniversalDatabaseApi(
        output: OutputStream,
        method: String,
        path: String,
        queryString: String,
        body: String,
        clientIp: String
    ) {
        val dao = database.sharedRecordDao()

        val segments = path.split("/").filter { it.isNotBlank() }
        val collection = when {
            getQueryParam(queryString, "collection") != null -> getQueryParam(queryString, "collection")!!
            segments.size >= 2 -> segments[1]
            segments.size == 1 && segments[0] != "api" -> segments[0]
            else -> "general"
        }

        val pathId = segments.lastOrNull()?.toLongOrNull()

        when (method) {
            "GET" -> {
                runBlocking {
                    if (pathId != null) {
                        val record = dao.getRecordById(pathId)
                        if (record != null) {
                            val json = recordToJsonObject(record).toString(2)
                            sendJsonResponse(output, json, 200)
                        } else {
                            sendJsonResponse(output, "{\"error\": \"Record not found\"}", 404)
                        }
                    } else {
                        val records = if (collection != "general" && collection != "api" && collection != "records") {
                            dao.getRecordsByCollection(collection)
                        } else {
                            dao.getAllRecords()
                        }

                        val jsonArray = JSONArray()
                        records.forEach { record ->
                            jsonArray.put(recordToJsonObject(record))
                        }

                        val responseJson = JSONObject().apply {
                            put("status", "success")
                            put("count", records.size)
                            put("records", jsonArray)
                            put("data", jsonArray)
                        }.toString(2)

                        sendJsonResponse(output, responseJson, 200)
                        onLog(
                            ServerLog(
                                clientIp = clientIp,
                                requestPath = "📥 GET $path (قراءة ${records.size} سجل من [$collection])",
                                statusCode = 200
                            )
                        )
                    }
                }
            }

            "POST" -> {
                runBlocking {
                    try {
                        var author = "مستخدم ($clientIp)"
                        var content = ""
                        var title: String? = null
                        var targetCollection = collection
                        val rawJson = body.trim()

                        if (rawJson.startsWith("{")) {
                            val obj = JSONObject(rawJson)
                            if (obj.has("author")) author = obj.optString("author", author)
                            if (obj.has("name")) author = obj.optString("name", author)
                            if (obj.has("username")) author = obj.optString("username", author)
                            if (obj.has("title")) title = obj.optString("title")
                            if (obj.has("content")) content = obj.optString("content")
                            if (obj.has("text")) content = obj.optString("text")
                            if (obj.has("message")) content = obj.optString("message")
                            if (obj.has("collection")) targetCollection = obj.optString("collection", collection)
                            if (content.isBlank() && obj.has("data")) content = obj.get("data").toString()
                            if (content.isBlank()) content = rawJson
                        } else if (rawJson.startsWith("[")) {
                            content = "قائمة عناصر (${rawJson.length} حرف)"
                        } else {
                            content = rawJson
                        }

                        val record = SharedRecordEntity(
                            collection = targetCollection,
                            author = author,
                            title = title,
                            content = content,
                            jsonData = if (rawJson.isNotBlank()) rawJson else "{}",
                            clientIp = clientIp
                        )

                        val newId = dao.insertRecord(record)
                        val responseJson = JSONObject().apply {
                            put("status", "success")
                            put("id", newId)
                            put("message", "تم حفظ البيانات بنجاح في قاعدة بيانات الهاتف")
                            put("record", recordToJsonObject(record.copy(id = newId)))
                        }.toString(2)

                        sendJsonResponse(output, responseJson, 201)
                        onLog(
                            ServerLog(
                                clientIp = clientIp,
                                requestPath = "💾 POST $path (حفظ سجل جديد #$newId في [$targetCollection])",
                                statusCode = 201
                            )
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                        val errJson = JSONObject().apply {
                            put("status", "error")
                            put("message", "خطأ في معالجة البيانات: ${e.message}")
                        }.toString()
                        sendJsonResponse(output, errJson, 400)
                    }
                }
            }

            "PUT", "PATCH" -> {
                runBlocking {
                    try {
                        val recordId = pathId
                        if (recordId != null) {
                            val existing = dao.getRecordById(recordId)
                            if (existing != null) {
                                val updated = existing.copy(
                                    content = if (body.isNotBlank()) body else existing.content,
                                    jsonData = if (body.isNotBlank()) body else existing.jsonData
                                )
                                dao.insertRecord(updated)
                                sendJsonResponse(output, "{\"status\": \"updated\", \"id\": $recordId}", 200)
                            } else {
                                sendJsonResponse(output, "{\"error\": \"Record not found\"}", 404)
                            }
                        } else {
                            sendJsonResponse(output, "{\"error\": \"Missing record ID\"}", 400)
                        }
                    } catch (e: Exception) {
                        sendJsonResponse(output, "{\"error\": \"${e.message}\"}", 500)
                    }
                }
            }

            "DELETE" -> {
                runBlocking {
                    if (pathId != null) {
                        dao.deleteRecordById(pathId)
                        val res = JSONObject().apply {
                            put("status", "success")
                            put("message", "تم حذف السجل رقم $pathId")
                        }.toString()
                        sendJsonResponse(output, res, 200)
                    } else if (collection != "general" && collection != "api" && collection != "records") {
                        dao.deleteRecordsByCollection(collection)
                        sendJsonResponse(output, "{\"status\": \"success\", \"message\": \"تم مسح سجلات $collection\"}", 200)
                    } else {
                        val res = JSONObject().apply {
                            put("status", "error")
                            put("message", "يرجى تحديد معرف السجل المراد حذفه")
                        }.toString()
                        sendJsonResponse(output, res, 400)
                    }
                }
            }

            else -> {
                sendJsonResponse(output, "{\"error\": \"Method not allowed\"}", 405)
            }
        }
    }

    private fun recordToJsonObject(record: SharedRecordEntity): JSONObject {
        return JSONObject().apply {
            put("id", record.id)
            put("collection", record.collection)
            put("author", record.author)
            put("title", record.title ?: "")
            put("content", record.content)
            put("timestamp", record.timestamp)
            put("clientIp", record.clientIp)
            put("jsonData", try {
                if (record.jsonData.startsWith("{")) JSONObject(record.jsonData)
                else if (record.jsonData.startsWith("[")) JSONArray(record.jsonData)
                else record.jsonData
            } catch (e: Exception) {
                record.jsonData
            })
        }
    }

    private fun getQueryParam(queryString: String, paramName: String): String? {
        if (queryString.isBlank()) return null
        return queryString.split("&").firstOrNull { it.startsWith("$paramName=") }?.substringAfter("=")
    }

    private fun sendJsonResponse(output: OutputStream, json: String, statusCode: Int) {
        val bytes = json.toByteArray(Charsets.UTF_8)
        val statusMsg = when (statusCode) {
            200 -> "200 OK"
            201 -> "201 Created"
            400 -> "400 Bad Request"
            404 -> "404 Not Found"
            405 -> "405 Method Not Allowed"
            else -> "500 Internal Server Error"
        }
        val header = "HTTP/1.1 $statusMsg\r\n" +
                "Content-Type: application/json; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun sendCorsOk(output: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept, Cache-Control\r\n" +
                "Access-Control-Max-Age: 86400\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n"
        output.write(header.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun isAppleProbe(path: String, host: String, userAgent: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        val ua = userAgent.lowercase()
        return h.contains("apple.com") ||
                h.contains("captive.apple.com") ||
                h.contains("airport.us") ||
                h.contains("ibook.info") ||
                h.contains("itools.info") ||
                h.contains("thinkdifferent.us") ||
                h.contains("appleiphonecell.com") ||
                h.contains("icloud.com") ||
                p.contains("hotspot-detect.html") ||
                p.contains("library/test/success.html") ||
                p.contains("canonical.html") ||
                p.contains("bag.xml") ||
                ua.contains("captivenetworksupport") ||
                ua.contains("wispr")
    }

    private fun isAndroidProbe(path: String, host: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        return p.contains("generate_204") ||
                p.contains("gen_204") ||
                p.contains("connectivitycheck") ||
                p.contains("check_network_status") ||
                h.contains("gstatic.com") ||
                h.contains("google.com") ||
                h.contains("android.com") ||
                h.contains("googleapis.com")
    }

    private fun isWindowsOrFirefoxProbe(path: String, host: String): Boolean {
        val p = path.lowercase()
        val h = host.lowercase()
        return h.contains("msftconnecttest.com") ||
                h.contains("msftncsi.com") ||
                h.contains("detectportal.firefox.com") ||
                p.contains("ncsi.txt") ||
                p.contains("connecttest.txt") ||
                p.contains("success.txt")
    }

    private fun serveWebRoute(outputStream: OutputStream, clientIp: String, requestPath: String) {
        val rootDir = webRootDirProvider()
        val cleanPath = requestPath.removePrefix("/").ifEmpty { "index.html" }
        var targetFile = File(rootDir, cleanPath)

        if (targetFile.isDirectory) {
            targetFile = File(targetFile, "index.html")
        }

        if (!targetFile.exists()) {
            val hasExtension = cleanPath.substringAfterLast("/", cleanPath).contains(".")
            if (!hasExtension) {
                targetFile = File(rootDir, "index.html")
            }
        }

        if (targetFile.exists() && targetFile.isFile) {
            serveStaticFile(outputStream, targetFile, clientIp, requestPath)
        } else {
            val rootIndex = File(rootDir, "index.html")
            if (rootIndex.exists()) {
                serveStaticFile(outputStream, rootIndex, clientIp, requestPath)
            } else {
                send404(outputStream, clientIp, requestPath)
            }
        }
    }

    private fun serveStaticFile(outputStream: OutputStream, file: File, clientIp: String, requestedPath: String) {
        val mimeType = getMimeType(file.name)
        val length = file.length()

        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: $mimeType\r\n" +
                "Content-Length: $length\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\r\n" +
                "Access-Control-Allow-Headers: Content-Type, Authorization\r\n" +
                "Cache-Control: public, max-age=3600\r\n" +
                "Connection: close\r\n\r\n"

        outputStream.write(header.toByteArray(Charsets.UTF_8))
        FileInputStream(file).use { fis ->
            fis.copyTo(outputStream, bufferSize = 16384)
        }
        outputStream.flush()

        onLog(
            ServerLog(
                clientIp = clientIp,
                requestPath = "📄 $requestedPath (${file.name} - ${length / 1024} KB)",
                statusCode = 200,
                isVideoChunk = false
            )
        )
    }

    private fun serveApplePortal(output: OutputStream, clientIp: String, path: String) {
        val rootDir = webRootDirProvider()
        val indexFile = File(rootDir, "index.html")
        if (indexFile.exists()) {
            serveStaticFile(output, indexFile, clientIp, path)
        } else {
            send404(output, clientIp, path)
        }
    }

    private fun serveAndroidPortalRedirect(output: OutputStream, clientIp: String, path: String, currentPort: Int) {
        val targetUrl = "http://${ipProvider()}:$currentPort"
        val response = "HTTP/1.1 302 Found\r\n" +
                "Location: $targetUrl\r\n" +
                "Content-Length: 0\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun serveGenericCaptiveRedirect(output: OutputStream, clientIp: String, path: String, currentPort: Int) {
        val targetUrl = "http://${ipProvider()}:$currentPort"
        val response = "HTTP/1.1 302 Found\r\n" +
                "Location: $targetUrl\r\n" +
                "Content-Length: 0\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.flush()
    }

    private fun send404(output: OutputStream, clientIp: String, path: String) {
        val notFoundHtml = "<html><body style='font-family:sans-serif;text-align:center;padding:40px;'>" +
                "<h2>404 - لم يتم العثور على الملف</h2>" +
                "<p>المسار المطلوب: <code>$path</code></p>" +
                "<a href='/'>العودة للصفحة الرئيسية</a>" +
                "</body></html>"
        val bytes = notFoundHtml.toByteArray(Charsets.UTF_8)
        val response = "HTTP/1.1 404 Not Found\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Connection: close\r\n\r\n"
        output.write(response.toByteArray(Charsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun getMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "html", "htm" -> "text/html; charset=UTF-8"
            "css" -> "text/css; charset=UTF-8"
            "js", "mjs", "jsx", "ts", "tsx" -> "application/javascript; charset=UTF-8"
            "json" -> "application/json; charset=UTF-8"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "svg" -> "image/svg+xml"
            "ico" -> "image/x-icon"
            "webp" -> "image/webp"
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain; charset=UTF-8"
            "xml" -> "application/xml"
            "map" -> "application/json"
            else -> "application/octet-stream"
        }
    }
}
