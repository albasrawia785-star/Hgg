package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.viewmodel.MainViewModel

/**
 * شاشة تسجيل الدخول والتفعيل المطابقة تماماً للتصميم المرجعي المرفق بدون أي تفاصيل زائدة:
 * - صورة خلفية طبية فاخرة (عيادة طبية ناعمة بالأعلى، تموجات سماوية وسماعة طبيب لامعة بالأسفل)
 * - شعار العيادة المرجعي: تقويم فيروزي وأزرق يتوسطه قلب بنبضات طبية وسماعة تحيط به
 * - اسم التطبيق العريض "عيادتك" مع الشعار الفرعي "إدارة أسهل .. لعيادة أفضل"
 * - عنوان الترحيب "مرحباً بك" مع "سجل الدخول للمتابعة"
 * - حقل إدخال "رمز التفعيل" مع أيقونة القفل على اليمين
 * - زر "دخول" الأزرق الممتد مع سهم أبيض صريح يشير لليسار (دخول ←)
 * - زر "تسجيل دخول تجريبي" بإطار تركوازي ناعم وأيقونة مستخدم على اليمين
 */
@Composable
fun LoginScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var activationCode by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val focusManager = LocalFocusManager.current

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.White)
        ) {
            // 1. صورة الخلفية الطبية الواقعية المطابقة تماماً للأصل
            Image(
                painter = painterResource(id = R.drawable.bg_login_exact),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // 2. طبقة نعومة بيضاء خفيفة تضمن قراءة النصوص والنموذج بأعلى درجات التباين والراحة البصرية
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0.00f to Color.White.copy(alpha = 0.04f),
                            0.22f to Color.White.copy(alpha = 0.72f),
                            0.54f to Color.White.copy(alpha = 0.88f),
                            0.76f to Color.White.copy(alpha = 0.45f),
                            1.00f to Color.Transparent
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .imePadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 28.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // =================================================================
                // 1. الشعار والهوية البصرية العلوية (Clinic Logo + "عيادتك")
                // =================================================================
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // أيقونة الشعار (تقويم + قلب بنبضات + سماعة طبيب بتدرج أزرق/فيروزي)
                    ClinicAppLogoBadge(modifier = Modifier.size(116.dp))

                    Spacer(modifier = Modifier.height(14.dp))

                    // اسم التطبيق: عيادتك (سطر واحد بدون فصل الحروف)
                    Text(
                        text = "عيادتك",
                        fontSize = 35.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF0F395A),
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        softWrap = false
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // الشعار الفرعي: إدارة أسهل .. لعيادة أفضل
                    Text(
                        text = "إدارة أسهل .. لعيادة أفضل",
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF5A738E),
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(34.dp))

                // =================================================================
                // 2. بطاقة الترحيب ونموذج الدخول
                // =================================================================
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "مرحباً بك",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F395A),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "سجل الدخول للمتابعة",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // حقل رمز التفعيل (مع أيقونة القفل على اليمين في RTL)
                    OutlinedTextField(
                        value = activationCode,
                        onValueChange = {
                            activationCode = it
                            errorMessage = null
                        },
                        placeholder = {
                            Text(
                                text = "رمز التفعيل",
                                color = Color(0xFF64748B),
                                fontSize = 15.sp
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "قفل",
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        trailingIcon = {
                            if (activationCode.isNotEmpty()) {
                                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = "إظهار الرمز",
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        isError = errorMessage != null,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focusManager.clearFocus()
                                val success = viewModel.loginWithCode(activationCode)
                                if (!success) {
                                    errorMessage = "رمز التفعيل غير صحيح! تأكد من إدخال رمز المدير العام"
                                }
                            }
                        ),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = Color(0xFF0284C7),
                            unfocusedBorderColor = Color(0xFFCBD5E1),
                            errorBorderColor = Color(0xFFEF4444),
                            focusedTextColor = Color(0xFF0F172A),
                            unfocusedTextColor = Color(0xFF0F172A)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .shadow(3.dp, RoundedCornerShape(16.dp), spotColor = Color(0x12000000))
                            .testTag("activation_code_input")
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage!!,
                            color = Color(0xFFDC2626),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // زر "دخول" الأزرق الممتد مع سهم يشير للأمام (← دخول)
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            val success = viewModel.loginWithCode(activationCode)
                            if (!success) {
                                errorMessage = "رمز التفعيل غير صحيح! تأكد من إدخال رمز المدير العام"
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .shadow(8.dp, RoundedCornerShape(16.dp), spotColor = Color(0x381E88E5))
                            .testTag("submit_login_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1E88E5)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "دخول",
                                fontSize = 17.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            ExactLeftArrow(
                                modifier = Modifier.size(18.dp, 14.dp),
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // زر "تسجيل دخول تجريبي" بالأيقونة والإطار الأخضر التركوازي الفاتح (تسجيل دخول تجريبي 👤)
                    OutlinedButton(
                        onClick = {
                            focusManager.clearFocus()
                            viewModel.loginTrial()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("trial_login_button"),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.6.dp, Color(0xFF14B8A6)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color.White.copy(alpha = 0.95f)
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonOutline,
                                contentDescription = null,
                                tint = Color(0xFF0F766E),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تسجيل دخول تجريبي",
                                fontSize = 15.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F766E)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(36.dp))
            }
        }
    }
}

/**
 * نافذة تنبيه انتهاء حد المراجعين في النسخة التجريبية (3 مراجعين فقط)
 * تطلب من المستخدم التواصل مع الدعم لطلب النسخة الكاملة.
 */
@Composable
fun TrialLimitExceededDialog(
    onDismiss: () -> Unit,
    onContactSupport: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = remember {
        context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            shape = RoundedCornerShape(20.dp),
            containerColor = Color.White,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEF2F2)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "انتهى الحد التجريبي (3 مراجعين)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "النسخة التجريبية الحالية",
                            fontSize = 11.5.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "لقد وصلت إلى الحد الأقصى المسموح به في النسخة التجريبية (3 مراجعين فقط).",
                        fontSize = 13.5.sp,
                        color = Color(0xFF334155),
                        lineHeight = 20.sp
                    )

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF0F9FF),
                        border = BorderStroke(1.dp, Color(0xFFBAE6FD)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "لإضافة عدد غير محدود والاستفادة من كافة خصائص النظام، يرجى التواصل مع الدعم لطلب وتفعيل النسخة الكاملة.",
                                fontSize = 12.sp,
                                color = Color(0xFF0369A1),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onContactSupport()
                        try {
                            val message = "مرحباً، أود ترقية تطبيق إدارة العيادات وطلب النسخة الكاملة"
                            val uri = Uri.parse("https://wa.me/9647810936407?text=${Uri.encode(message)}")
                            val intent = Intent(Intent.ACTION_VIEW, uri)
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            val clip = ClipData.newPlainText("رقم الدعم الفني", "+9647810936407")
                            clipboardManager.setPrimaryClip(clip)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0284C7)
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "طلب النسخة الكاملة (واتساب)",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "إغلاق",
                        color = Color(0xFF64748B),
                        fontSize = 13.sp
                    )
                }
            }
        )
    }
}

/**
 * سهم يشير باتجاه اليسار حصراً مطابق تماماً للتصميم المرجعي (←)
 */
@Composable
private fun ExactLeftArrow(
    modifier: Modifier = Modifier,
    color: Color = Color.White
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val centerY = h / 2f
        val strokeWidth = w * 0.14f

        // الخط الأفقي للسهم من اليمين لليسار
        drawLine(
            color = color,
            start = Offset(w * 0.95f, centerY),
            end = Offset(w * 0.08f, centerY),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
        // رأس السهم العلوي
        drawLine(
            color = color,
            start = Offset(w * 0.08f, centerY),
            end = Offset(w * 0.44f, centerY - h * 0.38f),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
        // رأس السهم السفلي
        drawLine(
            color = color,
            start = Offset(w * 0.08f, centerY),
            end = Offset(w * 0.44f, centerY + h * 0.38f),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
    }
}

/**
 * أيقونة وشعار العيادة المرجعي المطابق للصورة:
 * تقويم بالألوان الفيروزية والزرقاء، يتوسطه قلب بنبضات طبية وسماعة طبيب تحيط به.
 */
@Composable
private fun ClinicAppLogoBadge(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // 1. تقويم/شكل إطار ناعم بزوايا منحنية وتدرج لوني أزرق مخضر
        val outerRadius = w * 0.22f
        val rectTop = h * 0.12f
        val rectHeight = h * 0.78f
        val rectWidth = w * 0.82f
        val rectLeft = (w - rectWidth) / 2f

        // مسار التقويم المفرغ والجميل
        val calendarPath = Path().apply {
            moveTo(rectLeft + outerRadius, rectTop)
            lineTo(rectLeft + rectWidth - outerRadius, rectTop)
            // قوس علوي يمين
            quadraticBezierTo(
                rectLeft + rectWidth, rectTop,
                rectLeft + rectWidth, rectTop + outerRadius
            )
            // نزول لليمين
            lineTo(rectLeft + rectWidth, rectTop + rectHeight - outerRadius)
            // قوس سفلي يمين
            quadraticBezierTo(
                rectLeft + rectWidth, rectTop + rectHeight,
                rectLeft + rectWidth - outerRadius, rectTop + rectHeight
            )
            // سفلي
            lineTo(rectLeft + outerRadius, rectTop + rectHeight)
            // قوس سفلي يسار
            quadraticBezierTo(
                rectLeft, rectTop + rectHeight,
                rectLeft, rectTop + rectHeight - outerRadius
            )
            // صعود يسار
            lineTo(rectLeft, rectTop + outerRadius)
            // قوس علوي يسار
            quadraticBezierTo(
                rectLeft, rectTop,
                rectLeft + outerRadius, rectTop
            )
            close()
        }

        // رسم إطار التقويم بلون فيروزي / أزرق مشرق
        drawPath(
            path = calendarPath,
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF00B4D8), Color(0xFF0284C7)),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            ),
            style = Stroke(width = w * 0.08f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // نتوءات التقويم العلوية (دبابيس التقويم بالأعلى)
        val pinY = rectTop
        val pinWidth = w * 0.07f
        val pinHeight = h * 0.08f
        drawRoundRect(
            color = Color(0xFF0284C7),
            topLeft = Offset(rectLeft + rectWidth * 0.25f - pinWidth / 2f, pinY - pinHeight * 0.6f),
            size = androidx.compose.ui.geometry.Size(pinWidth, pinHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(pinWidth / 2f, pinWidth / 2f)
        )
        drawRoundRect(
            color = Color(0xFF0284C7),
            topLeft = Offset(rectLeft + rectWidth * 0.75f - pinWidth / 2f, pinY - pinHeight * 0.6f),
            size = androidx.compose.ui.geometry.Size(pinWidth, pinHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(pinWidth / 2f, pinWidth / 2f)
        )

        // 2. شكل القلب الطبي باللون الفيروزي داخل المركز
        val centerX = w * 0.5f
        val centerY = h * 0.53f
        val heartScale = w * 0.016f

        val heartPath = Path().apply {
            moveTo(centerX, centerY + 10f * heartScale)
            cubicTo(
                centerX - 16f * heartScale, centerY - 1f * heartScale,
                centerX - 15f * heartScale, centerY - 14f * heartScale,
                centerX, centerY - 8f * heartScale
            )
            cubicTo(
                centerX + 15f * heartScale, centerY - 14f * heartScale,
                centerX + 16f * heartScale, centerY - 1f * heartScale,
                centerX, centerY + 10f * heartScale
            )
            close()
        }

        // رسم القلب بتعبئة لون فيروزي مائل للأزرق
        drawPath(
            path = heartPath,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF2DD4BF), Color(0xFF0EA5E9))
            )
        )

        // رسم نبضة القلب (ECG Pulse Line) باللون الأبيض فوق القلب
        val pulsePath = Path().apply {
            moveTo(centerX - 10f * heartScale, centerY - 2f * heartScale)
            lineTo(centerX - 4f * heartScale, centerY - 2f * heartScale)
            lineTo(centerX - 1.5f * heartScale, centerY - 7.5f * heartScale)
            lineTo(centerX + 1.5f * heartScale, centerY + 4f * heartScale)
            lineTo(centerX + 4f * heartScale, centerY - 2f * heartScale)
            lineTo(centerX + 10f * heartScale, centerY - 2f * heartScale)
        }

        drawPath(
            path = pulsePath,
            color = Color.White,
            style = Stroke(width = w * 0.024f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // 3. مسار سماعة الطبيب (Stethoscope) باللون الكحلي/الأزرق
        val stethPath = Path().apply {
            moveTo(centerX + 10f * heartScale, centerY + 4f * heartScale)
            cubicTo(
                centerX + 17f * heartScale, centerY + 10f * heartScale,
                centerX + 16f * heartScale, centerY + 20f * heartScale,
                centerX + 7f * heartScale, centerY + 18f * heartScale
            )
        }

        drawPath(
            path = stethPath,
            color = Color(0xFF0369A1),
            style = Stroke(width = w * 0.032f, cap = StrokeCap.Round)
        )

        // قرص سماعة الطبيب
        drawCircle(
            color = Color(0xFF0284C7),
            radius = w * 0.045f,
            center = Offset(centerX + 7f * heartScale, centerY + 18f * heartScale)
        )
        drawCircle(
            color = Color.White,
            radius = w * 0.02f,
            center = Offset(centerX + 7f * heartScale, centerY + 18f * heartScale)
        )
    }
}

/**
 * خلفية طبية ديكورية أنيقة بتدرجات ناعمة وتموجات علوية وسفلية متناسقة تماماً مع التصميم المرفق
 */
@Composable
private fun MedicalLoginBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // تموج سماوي ناعم جداً في أعلى اليسار واليمين
        val topPath = Path().apply {
            moveTo(0f, 0f)
            lineTo(w * 0.45f, 0f)
            cubicTo(
                w * 0.35f, h * 0.12f,
                0f, h * 0.18f,
                0f, h * 0.28f
            )
            close()
        }

        drawPath(
            path = topPath,
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFBAE6FD).copy(alpha = 0.45f), Color.Transparent),
                center = Offset(0f, 0f),
                radius = w * 0.6f
            )
        )

        // تموج سماوي ناعم في أسفل الشاشة
        val bottomPath = Path().apply {
            moveTo(0f, h)
            lineTo(w, h)
            lineTo(w, h * 0.78f)
            cubicTo(
                w * 0.6f, h * 0.88f,
                w * 0.3f, h * 0.75f,
                0f, h * 0.82f
            )
            close()
        }

        drawPath(
            path = bottomPath,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFE0F2FE).copy(alpha = 0.35f), Color(0xFFBAE6FD).copy(alpha = 0.7f))
            )
        )

        // انحناء دائري أنيق في أسفل اليسار يمثل حلقة السماعة الطبية
        val stethCircCenter = Offset(w * 0.14f, h * 0.92f)
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF0284C7).copy(alpha = 0.35f), Color(0xFF0369A1).copy(alpha = 0.15f))
            ),
            radius = w * 0.28f,
            center = stethCircCenter,
            style = Stroke(width = 12f)
        )
    }
}
