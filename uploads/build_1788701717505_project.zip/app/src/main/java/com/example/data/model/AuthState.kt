package com.example.data.model

enum class UserAccountType(val titleAr: String, val badgeText: String) {
    FULL("النسخة الكاملة", "النسخة الكاملة (غير محدود)"),
    TRIAL("النسخة التجريبية", "نسخة تجريبية (3 مراجعين كحد أقصى)")
}

data class AuthState(
    val isLoggedIn: Boolean = false,
    val username: String = "طبيب العيادة",
    val accountType: UserAccountType = UserAccountType.TRIAL
)

