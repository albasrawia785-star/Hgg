package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BluetoothDeviceInfo
import com.example.data.model.PaperSize
import com.example.ui.components.AppTopBar
import com.example.ui.components.RealBluetoothDeviceCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.GreenBorder
import com.example.ui.theme.GreenContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.GreenText
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedBorder
import com.example.ui.theme.RedContainer
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNavy
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ChoosePrinterScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val settings by viewModel.settings.collectAsState()
    val isBluetoothEnabled by viewModel.bluetoothDeviceManager.isBluetoothEnabled.collectAsState()
    val pairedPrinters by viewModel.bluetoothDeviceManager.pairedPrinters.collectAsState()
    val isPrinterConnected by viewModel.printerManager.isConnected.collectAsState()
    val isConnecting by viewModel.printerManager.isConnecting.collectAsState()
    val currentPrinterName by viewModel.printerManager.connectedDeviceName.collectAsState()
    val currentPrinterAddress by viewModel.printerManager.connectedDeviceAddress.collectAsState()

    val filteredPaired = pairedPrinters.filter {
        searchQuery.isEmpty() || it.name.contains(searchQuery, ignoreCase = true) || it.address.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Top App Bar
        AppTopBar(
            title = "إعدادات وطباعة البلوتوث",
            subtitle = "اختيار الطابعة ومقاس ورق الوصلات",
            showBackButton = true,
            showMenuButton = false,
            showSettingsButton = false,
            onBackClick = { viewModel.navigateBack() }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            // Bluetooth Disabled Warning Banner
            if (!isBluetoothEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(RedContainer)
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.BluetoothDisabled,
                            contentDescription = null,
                            tint = RedDestructive,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "البلوتوث غير مفعّل",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = RedDestructive
                            )
                            Text(
                                text = "يرجى تفعيل البلوتوث في هاتفك للاتصال بالطابعة المقترنة",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // بطاقة حالة الطابعة الحالية
            val displayName = when {
                currentPrinterName.isNotBlank() -> currentPrinterName
                settings.selectedPrinterName.isNotBlank() -> settings.selectedPrinterName
                else -> "لم يتم تحديد طابعة بعد"
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0284C7).copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Print,
                                    contentDescription = null,
                                    tint = Color(0xFF0284C7),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = displayName,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = if (settings.selectedPrinterAddress.isNotBlank()) settings.selectedPrinterAddress else "اختر طابعة من القائمة أدناه",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        // شارة الحالة
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (isPrinterConnected) GreenContainer else Color(0xFFF1F5F9))
                                .border(
                                    1.dp,
                                    if (isPrinterConnected) GreenBorder else Color(0xFFE2E8F0),
                                    CircleShape
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isPrinterConnected) GreenSuccess else TextMuted)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isPrinterConnected) "متصلة" else "غير متصلة",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPrinterConnected) GreenText else TextSecondary
                            )
                        }
                    }

                    if (isPrinterConnected) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(RedContainer)
                                    .border(1.dp, RedBorder, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.onDisconnectPrinter() }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = null,
                                        tint = RedDestructive,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "قطع الاتصال",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RedDestructive
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ==========================================
            // اختيار مقاس الورق داخل إعدادات الطابعة
            // ==========================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "مقاس رول ورق الطباعة الحرارية",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "اختر المقاس المناسب لطابعتك لضبط هوامش الوصل والباركود بدقة:",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // خيار 58 ملم
                        val is58 = settings.paperSize == PaperSize.WIDTH_58MM
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .border(
                                    width = if (is58) 1.5.dp else 1.dp,
                                    color = if (is58) Color(0xFF0284C7) else Color(0xFFE2E8F0),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .background(if (is58) Color(0xFF0284C7).copy(alpha = 0.08f) else Color(0xFFF8FAFC))
                                .clickable { viewModel.onPaperSizeChanged(PaperSize.WIDTH_58MM) }
                                .padding(vertical = 10.dp, horizontal = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (is58) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (is58) Color(0xFF0284C7) else TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "58 ملم (صغير)",
                                        fontSize = 12.sp,
                                        fontWeight = if (is58) FontWeight.Bold else FontWeight.Medium,
                                        color = if (is58) Color(0xFF0284C7) else Color(0xFF334155)
                                    )
                                    Text(
                                        text = "طابعات الجيب المحمولة",
                                        fontSize = 9.5.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }

                        // خيار 80 ملم
                        val is80 = settings.paperSize == PaperSize.WIDTH_80MM
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .border(
                                    width = if (is80) 1.5.dp else 1.dp,
                                    color = if (is80) Color(0xFF0284C7) else Color(0xFFE2E8F0),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .background(if (is80) Color(0xFF0284C7).copy(alpha = 0.08f) else Color(0xFFF8FAFC))
                                .clickable { viewModel.onPaperSizeChanged(PaperSize.WIDTH_80MM) }
                                .padding(vertical = 10.dp, horizontal = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (is80) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (is80) Color(0xFF0284C7) else TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "80 ملم (قياسي)",
                                        fontSize = 12.sp,
                                        fontWeight = if (is80) FontWeight.Bold else FontWeight.Medium,
                                        color = if (is80) Color(0xFF0284C7) else Color(0xFF334155)
                                    )
                                    Text(
                                        text = "طابعات الكاشير والمكتب",
                                        fontSize = 9.5.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Input Row with Refresh Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "بحث في الطابعات المقترنة...",
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "بحث",
                            tint = TextSecondary
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("search_printer_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = NavyDark,
                        unfocusedBorderColor = Color(0xFFF1F5F9)
                    ),
                    singleLine = true
                )

                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = { viewModel.bluetoothDeviceManager.refreshPairedDevices() },
                        modifier = Modifier.size(52.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "تحديث",
                            tint = NavyDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Header for Paired Printers
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "الطابعات المقترنة بالهاتف (${filteredPaired.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Device List
            if (filteredPaired.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(14.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (searchQuery.isNotEmpty()) "لا توجد نتائج مطابقة للبحث" else "لا توجد أجهزة بلوتوث مقترنة بالهاتف حالياً",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "قم بفتح إعدادات الهاتف > البلوتوث واقترن بالطابعة أولاً، ثم اضغط على زر التحديث بالأسفل.",
                            fontSize = 12.sp,
                            color = TextMuted,
                            lineHeight = 18.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredPaired) { device ->
                        val isCurrent = (device.address == currentPrinterAddress || device.name == currentPrinterName) && isPrinterConnected
                        RealBluetoothDeviceCard(
                            device = device.copy(isConnected = isCurrent),
                            icon = Icons.Default.Print,
                            isConnecting = isConnecting && device.address == viewModel.settings.value.selectedPrinterAddress,
                            isPairedSection = true,
                            onClick = {
                                if (!isConnecting) {
                                    viewModel.onSelectPrinter(device)
                                }
                            }
                        )
                    }
                }
            }
        }

        // Bottom Refresh Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .border(width = 1.dp, color = BorderSubtle)
                .padding(16.dp)
        ) {
            Button(
                onClick = { viewModel.bluetoothDeviceManager.refreshPairedDevices() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("refresh_printers_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = TextOnNavy,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تحديث قائمة الأجهزة المقترنة",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextOnNavy
                    )
                }
            }
        }
    }
}
