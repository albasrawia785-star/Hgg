package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DensityMedium
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.ViewCompact
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AppBackgroundType
import com.example.ui.theme.AppThemePreset
import com.example.ui.theme.NavyDark
import com.example.ui.theme.UiCustomizationConfig
import com.example.ui.theme.UiDensity

/**
 * قسم "تخصيص الواجهة" داخل لوحة الإعدادات
 */
@Composable
fun UiCustomizationSettingsSection(
    config: UiCustomizationConfig,
    onSelectPreset: (AppThemePreset) -> Unit,
    onSelectDensity: (UiDensity) -> Unit,
    onSelectBackgroundType: (AppBackgroundType) -> Unit,
    onChangeBackgroundOpacity: (Float) -> Unit,
    onPickCustomImage: (Uri) -> Unit,
    onRemoveCustomImage: () -> Unit,
    onResetDefaults: () -> Unit
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onPickCustomImage(uri)
        }
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ui_customization_section"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // رأس القسم مع زر استعادة التصميم الأصلي
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "نظام قوالب المظهر وتخصيص الواجهة",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )
                Text(
                    text = "اختر قالباً جاهزاً أو خصص الكثافة والخلفية والشفافية فوراً",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }

            // زر استعادة التصميم الأصلي
            Surface(
                onClick = onResetDefaults,
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFEFF6FF),
                border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                modifier = Modifier.testTag("reset_ui_defaults_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "استعادة التصميم الأصلي",
                        tint = Color(0xFF2563EB),
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "استعادة الأصلي",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2563EB)
                    )
                }
            }
        }

        // ==========================================
        // 1. شريط المعاينة الحية الفورية (Live Mini Preview)
        // ==========================================
        UiMiniLivePreviewCard(config = config)

        // ==========================================
        // 2. اختيار قوالب التصميم (Presets)
        // ==========================================
        Text(
            text = "قوالب التصميم المتاحة:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AppThemePreset.values().forEach { preset ->
                val isSelected = config.themePreset == preset
                ThemePresetItem(
                    preset = preset,
                    isSelected = isSelected,
                    onClick = { onSelectPreset(preset) }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // ==========================================
        // 3. كثافة الواجهة (Ui Density)
        // ==========================================
        Text(
            text = "كثافة عناصر الواجهة وحجم البطاقات:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            UiDensity.values().forEach { density ->
                val isSelected = config.density == density
                DensityChoiceChip(
                    density = density,
                    isSelected = isSelected,
                    onClick = { onSelectDensity(density) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // توضيح للكثافة المختارة
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF8FAFC),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ViewCompact,
                    contentDescription = null,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = config.density.description,
                    fontSize = 11.5.sp,
                    color = Color(0xFF475569)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // ==========================================
        // 4. خيارات الخلفية والشفافية (Background & Opacity)
        // ==========================================
        Text(
            text = "نوع خلفية الشاشة والشفافية:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF334155)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // خيار صورة العيادة الواقعية
            BackgroundTypeChip(
                title = "العيادة الافتراضية",
                icon = Icons.Default.Image,
                isSelected = config.backgroundType == AppBackgroundType.CLINIC_IMAGE,
                onClick = { onSelectBackgroundType(AppBackgroundType.CLINIC_IMAGE) },
                modifier = Modifier.weight(1f)
            )

            // خيار صورة مخصصة من الجهاز
            BackgroundTypeChip(
                title = "صورتك من الجهاز",
                icon = Icons.Default.AddPhotoAlternate,
                isSelected = config.backgroundType == AppBackgroundType.CUSTOM_IMAGE,
                onClick = {
                    if (config.customImagePath == null) {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    } else {
                        onSelectBackgroundType(AppBackgroundType.CUSTOM_IMAGE)
                    }
                },
                modifier = Modifier.weight(1f)
            )

            // خيار لون أو تدرج موحد
            BackgroundTypeChip(
                title = "لون نقي / موحد",
                icon = Icons.Default.ColorLens,
                isSelected = config.backgroundType == AppBackgroundType.SOLID_COLOR,
                onClick = { onSelectBackgroundType(AppBackgroundType.SOLID_COLOR) },
                modifier = Modifier.weight(1f)
            )
        }

        // بطاقة التحكم في الصورة المخصصة عند اختيارها
        if (config.backgroundType == AppBackgroundType.CUSTOM_IMAGE) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF0FDF4),
                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = Color(0xFF16A34A),
                                modifier = Modifier.size(17.dp)
                            )
                            Text(
                                text = "الخلفية المخصصة من جهازك:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF14532D)
                            )
                        }

                        if (config.customImagePath != null) {
                            Text(
                                text = "مُفعلة بنجاح ✓",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF16A34A)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Upload,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (config.customImagePath == null) "اختيار صورة من المعرض" else "تغيير الصورة",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        if (config.customImagePath != null) {
                            OutlinedButton(
                                onClick = onRemoveCustomImage,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                                border = BorderStroke(1.dp, Color(0xFFFECACA))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = null,
                                    tint = Color(0xFFDC2626),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "إزالة واستعادة الأصلية",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFDC2626)
                                )
                            }
                        }
                    }
                }
            }
        }

        // متحكم الشفافية في حال كانت الخلفية صورة (افتراضية أو مخصصة)
        if (config.backgroundType == AppBackgroundType.CLINIC_IMAGE || config.backgroundType == AppBackgroundType.CUSTOM_IMAGE) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "نسبة تغطية وشفافية طبقة الخلفية",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF334155)
                    )
                    Text(
                        text = "${(config.backgroundOpacity * 100).toInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                }

                Slider(
                    value = config.backgroundOpacity,
                    onValueChange = onChangeBackgroundOpacity,
                    valueRange = 0.15f..0.95f,
                    colors = SliderDefaults.colors(
                        thumbColor = NavyDark,
                        activeTrackColor = NavyDark,
                        inactiveTrackColor = Color(0xFFCBD5E1)
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("صورة أوضح (15%)", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    Text("خلفية معتمة وهادئة (95%)", fontSize = 10.sp, color = Color(0xFF94A3B8))
                }
            }
        }
    }
}

/**
 * بطاقة معاينة حية مصغرة تُظهر شكل التصميم المختار فوراً
 */
@Composable
private fun UiMiniLivePreviewCard(
    config: UiCustomizationConfig
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.5.dp, config.primaryColor.copy(alpha = 0.5f)),
        color = config.screenBackgroundColor,
        shadowElevation = 2.dp
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // صورة الخلفية في المعاينة إن وجدت
            when (config.backgroundType) {
                AppBackgroundType.CLINIC_IMAGE -> {
                    Image(
                        painter = painterResource(id = R.drawable.bg_clinic),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(config.screenBackgroundColor.copy(alpha = config.backgroundOpacity))
                    )
                }
                AppBackgroundType.CUSTOM_IMAGE -> {
                    val customBitmap = remember(config.customImagePath) {
                        config.customImagePath?.let { path ->
                            try {
                                android.graphics.BitmapFactory.decodeFile(path)?.asImageBitmap()
                            } catch (e: Exception) {
                                null
                            }
                        }
                    }
                    if (customBitmap != null) {
                        Image(
                            bitmap = customBitmap,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.bg_clinic),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )
                    }
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(config.screenBackgroundColor.copy(alpha = config.backgroundOpacity))
                    )
                }
                AppBackgroundType.SOLID_COLOR -> {
                    // خلفية لون نقي بدون صورة
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                // شريط عنوان المعاينة
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Visibility,
                            contentDescription = null,
                            tint = config.primaryColor,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = "معاينة حية للقالب: ${config.themePreset.title}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = config.textPrimaryColor
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(config.primaryColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = config.density.title.substringBefore(" "),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = config.primaryColor
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // بطاقة مريض نموذجية بالمعاينة
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = config.cardBackground,
                    border = BorderStroke(1.dp, config.cardBorderColor),
                    shadowElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                horizontal = config.density.cardPaddingHorizontalDp.dp,
                                vertical = config.density.cardPaddingVerticalDp.dp
                            ),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // مربع الرقم
                            Box(
                                modifier = Modifier
                                    .size(config.density.numberBoxSizeDp.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(config.primaryColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "14",
                                    fontSize = config.density.numberFontSizeSp.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            Column {
                                Text(
                                    text = "محمد أحمد العلي",
                                    fontSize = config.density.titleFontSizeSp.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = config.textPrimaryColor
                                )
                                Text(
                                    text = "فحص استشاري عام",
                                    fontSize = config.density.noteFontSizeSp.sp,
                                    color = config.textSecondaryColor
                                )
                            }
                        }

                        // زر تجريبي مصغر
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF22C55E).copy(alpha = 0.2f))
                                .border(1.dp, Color(0xFF22C55E), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "استدعاء",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (config.isDark) Color(0xFF4ADE80) else Color(0xFF15803D)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * عنصر عرض خيار القالب (Preset Card Item)
 */
@Composable
private fun ThemePresetItem(
    preset: AppThemePreset,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) Color(0xFFF0F9FF) else Color.White,
        border = BorderStroke(
            width = if (isSelected) 1.8.dp else 1.dp,
            color = if (isSelected) Color(0xFF0284C7) else Color(0xFFE2E8F0)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // دوائر الألوان التي تمثل القالب
                Box(modifier = Modifier.size(34.dp)) {
                    // الدائرة الخلفية
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(preset.previewPrimaryColor)
                            .border(1.dp, Color.White, CircleShape)
                            .align(Alignment.TopStart)
                    )
                    // الدائرة الأمامية
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(preset.previewAccentColor)
                            .border(1.5.dp, Color.White, CircleShape)
                            .align(Alignment.BottomEnd)
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = preset.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color(0xFF0369A1) else Color(0xFF0F172A)
                        )
                        if (preset.isDark) {
                            Icon(
                                imageVector = Icons.Default.DarkMode,
                                contentDescription = "داكن",
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(13.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.LightMode,
                                contentDescription = "فاتح",
                                tint = Color(0xFFEAB308),
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                    Text(
                        text = preset.subtitle,
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        lineHeight = 15.sp
                    )
                }
            }

            // أيقونة الاختيار
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) Color(0xFF0284C7) else Color(0xFFF1F5F9))
                    .border(
                        1.dp,
                        if (isSelected) Color(0xFF0284C7) else Color(0xFFCBD5E1),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * زر كبسولي لاختيار الكثافة (مريح / متوازن / مضغوط)
 */
@Composable
private fun DensityChoiceChip(
    density: UiDensity,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) NavyDark else Color.White,
        border = BorderStroke(1.dp, if (isSelected) NavyDark else Color(0xFFCBD5E1)),
        modifier = modifier.height(42.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = density.title.substringBefore(" "),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color(0xFF334155),
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * زر كبسولي لاختيار نوع الخلفية
 */
@Composable
private fun BackgroundTypeChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) Color(0xFFF0FDF4) else Color.White,
        border = BorderStroke(
            1.5.dp,
            if (isSelected) Color(0xFF16A34A) else Color(0xFFCBD5E1)
        ),
        modifier = modifier.height(44.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color(0xFF16A34A) else Color(0xFF64748B),
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color(0xFF15803D) else Color(0xFF334155)
            )
        }
    }
}
