package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Patient

@Database(
    entities = [Patient::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun queueDao(): QueueDao

    companion object {
        @Volatile
        private var FULL_INSTANCE: AppDatabase? = null

        @Volatile
        private var TRIAL_INSTANCE: AppDatabase? = null

        fun getInstance(context: Context, isTrial: Boolean = false): AppDatabase {
            return if (isTrial) {
                TRIAL_INSTANCE ?: synchronized(this) {
                    TRIAL_INSTANCE ?: Room.databaseBuilder(
                        context.applicationContext,
                        AppDatabase::class.java,
                        "clinic_queue_trial.db"
                    )
                        .fallbackToDestructiveMigration()
                        .fallbackToDestructiveMigrationOnDowngrade()
                        .build().also { TRIAL_INSTANCE = it }
                }
            } else {
                FULL_INSTANCE ?: synchronized(this) {
                    FULL_INSTANCE ?: Room.databaseBuilder(
                        context.applicationContext,
                        AppDatabase::class.java,
                        "clinic_queue_database.db"
                    )
                        .fallbackToDestructiveMigration()
                        .fallbackToDestructiveMigrationOnDowngrade()
                        .build().also { FULL_INSTANCE = it }
                }
            }
        }
    }
}
