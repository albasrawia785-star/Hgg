package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.audio.CallingState
import com.example.data.model.Patient
import com.example.ui.components.ClinicBottomNavBar
import com.example.ui.components.TvDisplayDialog
import com.example.ui.theme.AppBackgroundType
import com.example.ui.theme.AppThemePreset
import com.example.ui.theme.NavyDark
import com.example.ui.theme.RedDestructive
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.UiCustomizationConfig
import com.example.ui.theme.UiDensity
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.QueueFilterType

@Composable
fun QueueListScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val pagedPatients by viewModel.pagedPatients.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val liveTotalCount by viewModel.liveTotalCount.collectAsState()
    val waitingCount by viewModel.waitingCount.collectAsState()
    val postponedCount by viewModel.postponedCount.collectAsState()
    val servedCount by viewModel.servedCount.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()
    val totalPages by viewModel.totalPages.collectAsState()
    val currentFilterCount by viewModel.currentFilterCount.collectAsState()
    val pageSize by viewModel.pageSize.collectAsState()
    val nextNumber by viewModel.nextQueueNumber.collectAsState()
    val queueSearchQuery by viewModel.queueSearchQuery.collectAsState()

    val currentPatient by viewModel.currentPatient.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val callingState by viewModel.callingState.collectAsState()
    val activeCallingPatient by viewModel.activeCallingPatient.collectAsState()

    val showAddDialog by viewModel.showAddPatientDialog.collectAsState()
    val showTrialLimitDialog by viewModel.showTrialLimitDialog.collectAsState()
    val previewPatient by viewModel.previewTicketPatient.collectAsState()
    val showTvDialog by viewModel.showTvDialog.collectAsState()
    val showResetDialog by viewModel.showResetDialog.collectAsState()

    val isTvServerRunning by viewModel.isTvServerRunning.collectAsState()
    val tvServerUrl by viewModel.tvServerUrl.collectAsState()
    val isTvConnected by viewModel.isTvConnected.collectAsState()
    val isPrinterConnected by viewModel.isPrinterConnected.collectAsState()
    val isHotspotActive by viewModel.isHotspotActive.collectAsState()
    val hotspotSsid by viewModel.hotspotSsid.collectAsState()
    val hotspotPassword by viewModel.hotspotPassword.collectAsState()
    val hotspotStatusMessage by viewModel.hotspotStatusMessage.collectAsState()
    val isHotspotLoading by viewModel.isHotspotLoading.collectAsState()
    val isTvAudioOnly by viewModel.isTvAudioOnly.collectAsState()
    val isQueueStarted by viewModel.isQueueStarted.collectAsState()
    val allPatientsList by viewModel.patients.collectAsState()
    val uiConfig by viewModel.uiCustomizationConfig.collectAsState()

    var patientToDelete by remember { mutableStateOf<Patient?>(null) }
    var patientToPostpone by remember { mutableStateOf<Patient?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onSetCustomBackgroundImage(uri)
        }
    }

    // ضبط اتجاه الواجهة من اليمين إلى اليسار (RTL) لمطابقة التصميم المرفق بالصورة بدقة 100%
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier.fillMaxSize()
        ) {
            // نوع الخلفية: صورة عيادة واقعية أو صورتك المخصصة من الجهاز أو لون نقي/تدرج
            when (uiConfig.backgroundType) {
                AppBackgroundType.CLINIC_IMAGE -> {
                    Image(
                        painter = painterResource(id = R.drawable.bg_clinic),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    // طبقة تدرج لوني خفيفة وعصرية تضمن ظهور صورة الخلفية بوضوح تام مع تباين ممتاز
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF0F172A).copy(alpha = 0.35f),
                                        Color.Transparent,
                                        uiConfig.screenBackgroundColor.copy(alpha = uiConfig.backgroundOpacity)
                                    )
                                )
                            )
                    )
                }
                AppBackgroundType.CUSTOM_IMAGE -> {
                    val customBitmap = remember(uiConfig.customImagePath) {
                        uiConfig.customImagePath?.let { path ->
                            try {
                                android.graphics.BitmapFactory.decodeFile(path)?.asImageBitmap()
                            } catch (e: Exception) {
                                null
                            }
                        }
                    }
                    if (customBitmap != null) {
                        Image(
                            bitmap = customBitmap,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.bg_clinic),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    // طبقة تدرج لوني خفيفة وعصرية تضمن ظهور صورتك الشخصية بوضوح
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF0F172A).copy(alpha = 0.35f),
                                        Color.Transparent,
                                        uiConfig.screenBackgroundColor.copy(alpha = uiConfig.backgroundOpacity)
                                    )
                                )
                            )
                    )
                }
                AppBackgroundType.SOLID_COLOR -> {
                    // خلفية لون نقي / موحد حسب القالب المختار
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(uiConfig.screenBackgroundColor)
                    )
                }
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // =========================================================
                // 1. الترويسة العلوية المنظمة بدقة: شعار الصيدلية، اسم العيادة والطبيب، زر إضافة مراجع، وزر الإعدادات الجانبي
                // =========================================================
                TopClinicHeaderExact(
                    clinicName = settings.clinicName.ifBlank { "عيادة الشفاء التخصصية" },
                    doctorName = settings.doctorName.ifBlank { "د. أحمد عبدالله" },
                    isTvConnected = isTvConnected,
                    isPrinterConnected = isPrinterConnected,
                    uiConfig = uiConfig,
                    onAddPatientClick = { viewModel.onAddPatientClicked() },
                    onSettingsClick = { viewModel.navigateTo(AppScreen.DEVICE_SETTINGS) },
                    onReportsClick = { viewModel.navigateTo(AppScreen.REPORTS) },
                    onDeleteAllClick = { viewModel.onOpenResetDialog() },
                    onTvClick = { viewModel.onOpenTvDialog() },
                    onPrinterClick = { viewModel.navigateTo(AppScreen.CHOOSE_PRINTER) }
                )

                // شريط النداء الصوتي الحي
                AnimatedVisibility(
                    visible = callingState != CallingState.IDLE,
                    enter = slideInVertically() + fadeIn(),
                    exit = slideOutVertically() + fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 2.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0F172A).copy(alpha = 0.90f))
                            .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جاري النداء الصوتي للمراجع رقم ${activeCallingPatient?.formattedNumber ?: (currentPatient?.formattedNumber ?: "")}...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = Color(0xFF22C55E),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                // =========================================================
                // 2. بطاقة المراجع الحالي Hero Card مع زر النداء الدائري وموجات التموج
                // =========================================================
                CurrentPatientHeroCard(
                    currentPatient = currentPatient,
                    waitingCount = waitingCount,
                    isQueueStarted = isQueueStarted,
                    uiConfig = uiConfig,
                    onTogglePlayPause = {
                        if (isQueueStarted) viewModel.onPauseQueue() else viewModel.onStartQueueClicked()
                    }
                )

                Spacer(modifier = Modifier.height(4.dp))

                // =========================================================
                // 3. كروت التبويبات الإحصائية الأربعة المدمجة في صف واحد
                // =========================================================
                StatTabCardsRow(
                    selectedFilter = selectedFilter,
                    liveTotalCount = liveTotalCount,
                    waitingCount = waitingCount,
                    postponedCount = postponedCount,
                    servedCount = servedCount,
                    onSelectFilter = { viewModel.onSelectFilter(it) }
                )

                Spacer(modifier = Modifier.height(4.dp))

                // =========================================================
                // 4. بطاقة الحاوية الكبرى لقائمة المراجعين (شريط البحث الفوري + أسطر رشيقة تتسع للجميع + الترقيم)
                // =========================================================
                ClinicPatientsMainCard(
                    patients = pagedPatients,
                    totalCount = currentFilterCount,
                    currentPage = currentPage,
                    totalPages = if (totalPages < 1) 1 else totalPages,
                    searchQuery = queueSearchQuery,
                    currentPatient = currentPatient,
                    activeCallingPatient = activeCallingPatient,
                    uiConfig = uiConfig,
                    onSearchChange = { viewModel.onQueueSearchQueryChanged(it) },
                    onPatientClick = { viewModel.onCallSpecificPatient(it) },
                    onPostponeClick = { patientToPostpone = it },
                    onRestoreClick = { viewModel.onRestorePostponedToQueue(it) },
                    onDeleteClick = { patientToDelete = it },
                    onTicketClick = { viewModel.onOpenTicketPreview(it) },
                    onPrevPage = { viewModel.onPrevPage() },
                    onNextPage = { viewModel.onNextPage() },
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }

    // =========================================================
    // النوافذ المنبثقة
    // =========================================================
    if (showTrialLimitDialog) {
        TrialLimitExceededDialog(
            onDismiss = { viewModel.onDismissTrialLimitDialog() },
            onContactSupport = { viewModel.onDismissTrialLimitDialog() }
        )
    }

    if (showAddDialog) {
        AddPatientDialog(
            nextQueueNumber = nextNumber,
            initialAutoPrint = settings.autoPrintOnAdd,
            onConfirm = { name, note, shouldPrint ->
                viewModel.onConfirmAddPatient(name, note, shouldPrint)
            },
            onDismiss = { viewModel.onDismissAddPatientDialog() }
        )
    }

    if (previewPatient != null) {
        TicketPreviewDialog(
            patient = previewPatient!!,
            settings = settings,
            onPrintClick = { viewModel.onPrintPreviewTicket() },
            onDismiss = { viewModel.onDismissTicketPreview() }
        )
    }

    if (showTvDialog) {
        TvDisplayDialog(
            isRunning = isTvServerRunning,
            serverUrl = tvServerUrl,
            isHotspotActive = isHotspotActive,
            hotspotSsid = hotspotSsid,
            hotspotPassword = hotspotPassword,
            hotspotStatusMessage = hotspotStatusMessage,
            isHotspotLoading = isHotspotLoading,
            isTvAudioOnly = isTvAudioOnly,
            onToggleServer = { viewModel.onToggleTvServer(it) },
            onToggleHotspot = { viewModel.onToggleLocalHotspot(it) },
            onToggleTvAudioOnly = { viewModel.onToggleTvAudioOnly(it) },
            onRefreshIp = { viewModel.onRefreshTvIp() },
            onDismiss = { viewModel.onDismissTvDialog() }
        )
    }

    patientToDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientToDelete = null },
            title = {
                Text(
                    text = "حذف المراجع",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = NavyDark
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف المراجع رقم ${patient.formattedNumber}${if (patient.name.isNotBlank()) " (${patient.name})" else ""} من القائمة؟",
                    fontSize = 14.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onDeletePatient(patient)
                        patientToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedDestructive),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "حذف", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { patientToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "إلغاء", color = NavyDark, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }

    patientToPostpone?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientToPostpone = null },
            title = {
                Text(
                    text = "تأجيل المراجع",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color(0xFF0F172A)
                )
            },
            text = {
                val namePart = if (patient.name.isNotBlank()) " (${patient.name})" else ""
                Text(
                    text = "هل أنت متأكد من رغبتك في تأجيل المراجع رقم #${patient.formattedNumber}$namePart ونقله إلى قائمة المؤجلين؟",
                    fontSize = 14.sp,
                    color = Color(0xFF334155),
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.onPostponeSpecificPatient(patient)
                        patientToPostpone = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(text = "تأكيد التأجيل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { patientToPostpone = null },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Text(text = "إلغاء", color = Color(0xFF475569), fontWeight = FontWeight.Medium, fontSize = 13.sp)
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

/**
 * شعار الصيدلية الرسمي (Pharmacy Cross Badge)
 */
@Composable
fun PharmacyLogoBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(36.dp)
            .shadow(elevation = 2.dp, shape = CircleShape, spotColor = Color(0x33000000))
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF0284C7), Color(0xFF0369A1))
                )
            )
            .border(1.2.dp, Color.White.copy(alpha = 0.90f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        // دائرة داخلية بيضاء نقية
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            // صليب الصيدلية الأخضر المعروف عالمياً (Green Pharmacy Cross)
            Canvas(modifier = Modifier.size(17.dp)) {
                val crossWidth = size.width * 0.34f
                val crossColor = Color(0xFF10B981) // الأخضر الصيدلاني الزمردي
                val cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())

                // الذراع الأفقي
                drawRoundRect(
                    color = crossColor,
                    topLeft = Offset(0f, (size.height - crossWidth) / 2f),
                    size = Size(size.width, crossWidth),
                    cornerRadius = cornerRadius
                )
                // الذراع الرأسي
                drawRoundRect(
                    color = crossColor,
                    topLeft = Offset((size.width - crossWidth) / 2f, 0f),
                    size = Size(crossWidth, size.height),
                    cornerRadius = cornerRadius
                )
            }
        }
    }
}

/**
 * الترويسة العلوية المنظمة والمتقنة:
 * - اليمين: شعار الصيدلية الرسمي، اسم العيادة، اسم الطبيب
 * - اليسار: زر إضافة مراجع (+) الأنيق والمرتب، زر الإعدادات الجانبي، وزر التقارير
 * - الصف الثاني: الكبسولات الثلاث (تصفير الدور | حالة الطابعة | حالة الشاشة)
 */
@Composable
private fun TopClinicHeaderExact(
    clinicName: String,
    doctorName: String,
    isTvConnected: Boolean,
    isPrinterConnected: Boolean,
    uiConfig: UiCustomizationConfig = UiCustomizationConfig(),
    onAddPatientClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onReportsClick: () -> Unit,
    onDeleteAllClick: () -> Unit,
    onTvClick: () -> Unit,
    onPrinterClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // الصف الأول: الشعار واسم العيادة والطبيب وأزرار التحكم العلوية
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // اليمين (RTL): شعار الصيدلية الرسمي واسم العيادة والطبيب
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // شعار الصيدلية المعتمد (Pharmacy Cross)
                PharmacyLogoBadge()

                Column {
                    Text(
                        text = clinicName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = doctorName,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.White.copy(alpha = 0.85f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF22C55E))
                                .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape)
                        )
                    }
                }
            }

            // اليسار: زر إضافة مراجع المنظم في الأعلى + زر الإعدادات الجانبي + زر التقارير
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // زر إضافة مراجع المنسق بأعلى درجات الترتيب والجاذبية
                Surface(
                    onClick = onAddPatientClick,
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White,
                    shadowElevation = 2.dp,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.9f)),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("add_patient_top_button")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxHeight()
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0284C7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                        Text(
                            text = "إضافة مراجع",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0284C7)
                        )
                    }
                }

                // زر الإعدادات الجانبي
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.20f))
                        .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                        .clickable { onSettingsClick() }
                        .testTag("settings_top_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات",
                        tint = Color.White,
                        modifier = Modifier.size(17.dp)
                    )
                }

                // زر التقارير
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.20f))
                        .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                        .clickable { onReportsClick() }
                        .testTag("reports_top_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Assessment,
                        contentDescription = "التقارير",
                        tint = Color.White,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
        }

        // الصف الثاني: الكبسولات الثلاث الأفقية الممتدة بعرض الشاشة بتصميم مضغوط وراقي
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            // 1. زر تصفير الدور (وردي / أحمر ناعم)
            Surface(
                onClick = onDeleteAllClick,
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFFEF2F2).copy(alpha = 0.90f),
                border = BorderStroke(1.dp, Color(0xFFFECACA)),
                modifier = Modifier
                    .weight(1f)
                    .height(28.dp)
                    .testTag("delete_all_patients_button")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "تصفير الدور",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFDC2626),
                        maxLines = 1
                    )
                }
            }

            // 2. زر الطابعة
            Surface(
                onClick = onPrinterClick,
                shape = RoundedCornerShape(8.dp),
                color = if (isPrinterConnected) Color(0xFF0284C7) else Color.White.copy(alpha = 0.88f),
                border = BorderStroke(1.dp, if (isPrinterConnected) Color(0xFF38BDF8) else Color(0xFFE2E8F0)),
                modifier = Modifier
                    .weight(1.1f)
                    .height(28.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Print,
                        contentDescription = null,
                        tint = if (isPrinterConnected) Color.White else Color(0xFF64748B),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (isPrinterConnected) "طابعة متصلة" else "طابعة غير متصلة",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPrinterConnected) Color.White else Color(0xFF475569),
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(if (isPrinterConnected) Color(0xFF4ADE80) else Color(0xFF94A3B8))
                            .border(1.dp, Color.White, CircleShape)
                    )
                }
            }

            // 3. زر شاشة TV
            Surface(
                onClick = onTvClick,
                shape = RoundedCornerShape(8.dp),
                color = if (isTvConnected) Color(0xFF0284C7) else Color.White.copy(alpha = 0.88f),
                border = BorderStroke(1.dp, if (isTvConnected) Color(0xFF38BDF8) else Color(0xFFE2E8F0)),
                modifier = Modifier
                    .weight(1.1f)
                    .height(28.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Tv,
                        contentDescription = null,
                        tint = if (isTvConnected) Color.White else Color(0xFF64748B),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (isTvConnected) "شاشة متصلة" else "شاشة غير متصلة",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isTvConnected) Color.White else Color(0xFF475569),
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(if (isTvConnected) Color(0xFF4ADE80) else Color(0xFFCBD5E1))
                            .border(1.dp, Color.White, CircleShape)
                    )
                }
            }
        }
    }
}

/**
 * بطاقة المراجع الحالي Hero Card المطابقة للصورة:
 * - اليمين: "المراجع الحالي"، اسم المراجع والرقم مع أيقونة الشخص، وعدد المراجعين بالانتظار
 * - اليسار: زر دائري أزرق محاط بحلقتين موجيتين متدرجتين لإعطاء إيحاء النداء الصوتي والنبض
 */
@Composable
private fun CurrentPatientHeroCard(
    currentPatient: Patient?,
    waitingCount: Int,
    isQueueStarted: Boolean,
    uiConfig: UiCustomizationConfig = UiCustomizationConfig(),
    onTogglePlayPause: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
        shape = RoundedCornerShape(10.dp),
        color = Color.White.copy(alpha = 0.96f),
        border = BorderStroke(1.5.dp, Color(0xFF0284C7)),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // اليمين (RTL): تفاصيل المراجع الحالي
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 10.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "المراجع الحالي",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF0284C7)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFE0F2FE))
                            .padding(horizontal = 5.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "$waitingCount بالانتظار",
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0369A1)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFBAE6FD)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0284C7).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = Color(0xFF0284C7),
                                modifier = Modifier.size(12.dp)
                            )
                        }
                        Text(
                            text = if (currentPatient != null) {
                                if (currentPatient.name.isNotBlank()) {
                                    "${currentPatient.name} (#${currentPatient.formattedNumber})"
                                } else {
                                    "المراجع رقم ${currentPatient.formattedNumber}"
                                }
                            } else if (isQueueStarted) {
                                "الجلسة نشطة (انقر على مراجع للنداء)"
                            } else {
                                "شاشة العرض في وضع الانتظار"
                            },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // اليسار: زر نداء وتحكم دائري مدمج وراقي
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .shadow(elevation = 2.dp, shape = CircleShape, spotColor = Color(0x330284C7))
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF0284C7), Color(0xFF0369A1))
                    )
                )
                .border(1.2.dp, Color.White, CircleShape)
                .clickable { onTogglePlayPause() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isQueueStarted) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isQueueStarted) "إيقاف مؤقت" else "بدء",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
}

/**
 * كروت التبويبات الإحصائية الأربعة المدمجة:
 * - الكل | في الانتظار | المؤجلين | تم استدعاء
 * - ترويسات مصغرة ورشيقة جداً بارتفاع 32dp فقط بتصميم كبسولات Segmented Chips احترافية
 */
@Composable
private fun StatTabCardsRow(
    selectedFilter: QueueFilterType,
    liveTotalCount: Int,
    waitingCount: Int,
    postponedCount: Int,
    servedCount: Int,
    onSelectFilter: (QueueFilterType) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        StatCardItem(
            label = "الكل",
            count = liveTotalCount,
            icon = Icons.Default.Groups,
            isSelected = selectedFilter == QueueFilterType.ALL,
            onClick = { onSelectFilter(QueueFilterType.ALL) },
            modifier = Modifier.weight(1f)
        )
        StatCardItem(
            label = "في الانتظار",
            count = waitingCount,
            icon = Icons.Default.Schedule,
            isSelected = selectedFilter == QueueFilterType.WAITING,
            onClick = { onSelectFilter(QueueFilterType.WAITING) },
            modifier = Modifier.weight(1.15f)
        )
        StatCardItem(
            label = "المؤجلين",
            count = postponedCount,
            icon = Icons.Default.HourglassEmpty,
            isSelected = selectedFilter == QueueFilterType.POSTPONED,
            onClick = { onSelectFilter(QueueFilterType.POSTPONED) },
            modifier = Modifier.weight(1.05f)
        )
        StatCardItem(
            label = "تم استدعاء",
            count = servedCount,
            icon = Icons.Default.CheckCircle,
            isSelected = selectedFilter == QueueFilterType.SERVED,
            onClick = { onSelectFilter(QueueFilterType.SERVED) },
            modifier = Modifier.weight(1.15f)
        )
    }
}

@Composable
private fun StatCardItem(
    label: String,
    count: Int,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) Color(0xFF0284C7) else Color.White.copy(alpha = 0.86f),
        border = BorderStroke(1.dp, if (isSelected) Color(0xFF38BDF8) else Color.White.copy(alpha = 0.90f)),
        shadowElevation = if (isSelected) 1.5.dp else 0.5.dp,
        modifier = modifier.height(32.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.White else Color(0xFF64748B),
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else Color(0xFF334155),
                maxLines = 1
            )
            Spacer(modifier = Modifier.width(3.dp))
            // شارة العدد المصغرة
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        if (isSelected) Color.White.copy(alpha = 0.22f)
                        else Color(0xFFF1F5F9)
                    )
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = count.toString(),
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else Color(0xFF0F172A)
                )
            }
        }
    }
}

/**
 * البطاقة الكبرى لقائمة المراجعين:
 * - كبسولة عدد المراجعين + شريط البحث الفوري المدمج (🔍 بحث..)
 * - قائمة الأسطر فائقة الرشاقة (PatientRowCompact) بارتفاع 41dp لتتسع لأكبر عدد من الأسماء
 * - شريط الترقيم المدمج داخل أسفل الحاوية
 */
@Composable
private fun ClinicPatientsMainCard(
    patients: List<Patient>,
    totalCount: Int,
    currentPage: Int,
    totalPages: Int,
    searchQuery: String,
    currentPatient: Patient?,
    activeCallingPatient: Patient?,
    uiConfig: UiCustomizationConfig,
    onSearchChange: (String) -> Unit,
    onPatientClick: (Patient) -> Unit,
    onPostponeClick: (Patient) -> Unit,
    onRestoreClick: (Patient) -> Unit,
    onDeleteClick: (Patient) -> Unit,
    onTicketClick: (Patient) -> Unit,
    onPrevPage: () -> Unit,
    onNextPage: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 2.dp),
        shape = RoundedCornerShape(14.dp),
        color = Color.White.copy(alpha = 0.86f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.90f)),
        shadowElevation = 1.5.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            // الترويسة الداخلية للبطاقة: كبسولة عدد المراجعين + حقل البحث المدمج
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // اليمين: كبسولة قائمة المراجعين المصغرة
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFF1F5F9).copy(alpha = 0.90f),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.height(25.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "قائمة المراجعين",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = "($totalCount)",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0284C7)
                        )
                    }
                }

                // اليسار: حقل البحث المدمج البيضاوي الرمادي الفاتح
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier
                        .width(130.dp)
                        .height(25.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            if (searchQuery.isEmpty()) {
                                Text(
                                    text = "بحث..",
                                    fontSize = 10.5.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                            BasicTextField(
                                value = searchQuery,
                                onValueChange = onSearchChange,
                                singleLine = true,
                                textStyle = TextStyle(
                                    fontSize = 10.5.sp,
                                    color = Color(0xFF0F172A),
                                    fontWeight = FontWeight.Medium
                                ),
                                cursorBrush = SolidColor(Color(0xFF0284C7)),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        if (searchQuery.isNotEmpty()) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "مسح",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier
                                    .size(13.dp)
                                    .clickable { onSearchChange("") }
                            )
                        }
                    }
                }
            }

            // قائمة أسطر المراجعين الرشيقة
            if (patients.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (searchQuery.isNotEmpty()) "لا توجد نتائج مطابقة للبحث" else "لا يوجد مراجعين في هذا التبويب",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    items(patients, key = { it.id }) { patient ->
                        val isActive = (currentPatient?.id == patient.id) || (activeCallingPatient?.id == patient.id)
                        PatientRowCompact(
                            patient = patient,
                            isActive = isActive,
                            uiConfig = uiConfig,
                            onRowClick = { onPatientClick(patient) },
                            onPostponeClick = { onPostponeClick(patient) },
                            onRestoreClick = { onRestoreClick(patient) },
                            onDeleteClick = { onDeleteClick(patient) },
                            onTicketClick = { onTicketClick(patient) }
                        )
                    }
                }
            }

            // شريط الترقيم المدمج داخل أسفل البطاقة الحاوية
            if (totalPages > 1 || totalCount > 0) {
                PaginationBarInline(
                    currentPage = currentPage,
                    totalPages = if (totalPages < 1) 1 else totalPages,
                    totalCount = totalCount,
                    displayedCount = patients.size,
                    onPrevClick = onPrevPage,
                    onNextClick = onNextPage
                )
            }
        }
    }
}

/**
 * سطر المراجع فائق الرشاقة (41dp فقط) ليتسع لأكبر عدد ممكن من الأسماء على الشاشة:
 * - مربع الرقم (26x26)
 * - الوقت "10:15 ص"
 * - أيقونة الشخص
 * - اسم المراجع بخط بولد واضح
 * - شارات الحالة (نشط، تأجيل، إرجاع، استدعاء)
 * - زر الحذف وزر التذكرة
 */
@Composable
private fun PatientRowCompact(
    patient: Patient,
    isActive: Boolean,
    uiConfig: UiCustomizationConfig,
    onRowClick: () -> Unit,
    onPostponeClick: () -> Unit,
    onRestoreClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onTicketClick: () -> Unit
) {
    val isPostponed = patient.isPostponed
    val isCalled = patient.isCalled && !isPostponed

    Surface(
        onClick = onRowClick,
        shape = RoundedCornerShape(8.dp),
        color = if (isActive) Color(0xFFF0FDF4) else Color.White,
        border = BorderStroke(
            1.dp,
            if (isActive) Color(0xFF86EFAC) else Color(0xFFE2E8F0)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(41.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // اليمين (RTL): مربع الرقم، الوقت، أيقونة الشخص، والاسم
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                // مربع الرقم المتناسق
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isActive) Color(0xFF0284C7) else Color(0xFFF1F5F9)
                        )
                        .border(
                            1.dp,
                            if (isActive) Color(0xFF0284C7) else Color(0xFFE2E8F0),
                            RoundedCornerShape(6.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = patient.formattedNumber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) Color.White else Color(0xFF1E293B)
                    )
                }

                // وقت الحجز/التسجيل
                Text(
                    text = patient.formattedTime,
                    fontSize = 9.5.sp,
                    color = Color(0xFF94A3B8),
                    maxLines = 1
                )

                // أيقونة الشخص
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = if (isActive) Color(0xFF0284C7) else Color(0xFF94A3B8),
                    modifier = Modifier.size(13.dp)
                )

                // اسم المراجع
                Text(
                    text = patient.displayName,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // اليسار: شارات الحالة وأزرار الإجراءات
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                // شارة الحالة
                when {
                    isActive -> {
                        // كبسولة نشط
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFDCFCE7))
                                .border(0.8.dp, Color(0xFF86EFAC), RoundedCornerShape(6.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "🟢 نشط",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                        }

                        // زر تأجيل أصفر
                        Surface(
                            onClick = onPostponeClick,
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFEF3C7),
                            border = BorderStroke(0.8.dp, Color(0xFFFDE68A)),
                            modifier = Modifier.height(22.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FastForward,
                                    contentDescription = null,
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(10.dp)
                                )
                                Text(
                                    text = "تأجيل",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB45309)
                                )
                            }
                        }
                    }
                    isPostponed -> {
                        Surface(
                            onClick = onRestoreClick,
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFEFF6FF),
                            border = BorderStroke(0.8.dp, Color(0xFFBFDBFE)),
                            modifier = Modifier.height(22.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    tint = Color(0xFF2563EB),
                                    modifier = Modifier.size(10.dp)
                                )
                                Text(
                                    text = "إرجاع",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2563EB)
                                )
                            }
                        }
                    }
                    isCalled -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFF1F5F9))
                                .border(0.8.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "تم استدعاء",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    else -> {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFF8FAFC))
                                .border(0.8.dp, Color(0xFFE2E8F0), RoundedCornerShape(6.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "في الانتظار",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }

                // زر حذف
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFFEF2F2))
                        .clickable { onDeleteClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(13.dp)
                    )
                }

                // زر تقويم/تذكرة
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFF0F9FF))
                        .clickable { onTicketClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "تذكرة",
                        tint = Color(0xFF0284C7),
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}

/**
 * شريط ترقيم وتصفح الصفحات المطور والمنسق بعناية:
 * - أزرار واضحة بنصوص "الصفحة السابقة" و "الصفحة التالية"
 * - أسهم تنقل مكبّرة بحجم 17dp لسهولة النقر والوضوح التام
 */
@Composable
private fun PaginationBarInline(
    currentPage: Int,
    totalPages: Int,
    totalCount: Int,
    displayedCount: Int,
    onPrevClick: () -> Unit,
    onNextClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White.copy(alpha = 0.95f),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp)
            .height(40.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // زر الصفحة السابقة (RTL: السهم لليمين للرجوع للخلف)
            val isPrevEnabled = currentPage > 1
            Surface(
                onClick = onPrevClick,
                enabled = isPrevEnabled,
                shape = RoundedCornerShape(8.dp),
                color = if (isPrevEnabled) Color(0xFFF0F9FF) else Color(0xFFF8FAFC),
                border = BorderStroke(
                    1.dp,
                    if (isPrevEnabled) Color(0xFFBAE6FD) else Color(0xFFE2E8F0)
                ),
                modifier = Modifier.height(32.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "الصفحة السابقة",
                        tint = if (isPrevEnabled) Color(0xFF0284C7) else Color(0xFF94A3B8),
                        modifier = Modifier.size(19.dp)
                    )
                    Text(
                        text = "الصفحة السابقة",
                        fontSize = 11.5.sp,
                        fontWeight = if (isPrevEnabled) FontWeight.Bold else FontWeight.Normal,
                        color = if (isPrevEnabled) Color(0xFF0284C7) else Color(0xFF94A3B8)
                    )
                }
            }

            // النص في الوسط (معلومات الصفحة الحالية)
            Text(
                text = "صفحة $currentPage من $totalPages ($displayedCount من $totalCount مراجع)",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF334155)
            )

            // زر الصفحة التالية (RTL: السهم لليسار للتقدم للأمام)
            val isNextEnabled = currentPage < totalPages
            Surface(
                onClick = onNextClick,
                enabled = isNextEnabled,
                shape = RoundedCornerShape(8.dp),
                color = if (isNextEnabled) Color(0xFFF0F9FF) else Color(0xFFF8FAFC),
                border = BorderStroke(
                    1.dp,
                    if (isNextEnabled) Color(0xFFBAE6FD) else Color(0xFFE2E8F0)
                ),
                modifier = Modifier.height(32.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = "الصفحة التالية",
                        fontSize = 11.5.sp,
                        fontWeight = if (isNextEnabled) FontWeight.Bold else FontWeight.Normal,
                        color = if (isNextEnabled) Color(0xFF0284C7) else Color(0xFF94A3B8)
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الصفحة التالية",
                        tint = if (isNextEnabled) Color(0xFF0284C7) else Color(0xFF94A3B8),
                        modifier = Modifier.size(19.dp)
                    )
                }
            }
        }
    }
}
