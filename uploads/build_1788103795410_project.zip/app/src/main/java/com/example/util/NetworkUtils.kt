package com.example.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object NetworkUtils {

    const val DEFAULT_PORT = 8080

    /**
     * Retrieves the device's local IPv4 address on the Wi-Fi, Ethernet, Hotspot or local network interface.
     * Prefers standard private subnet ranges (192.168.x.x, 10.x.x.x, 172.16-31.x.x).
     */
    fun getLocalIpAddress(): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            
            // Collect all valid non-loopback IPv4 addresses with interface details
            val candidates = mutableListOf<Pair<String, String>>() // interfaceName to IP
            for (networkInterface in interfaces) {
                if (!networkInterface.isUp || networkInterface.isLoopback) continue
                val name = networkInterface.name.lowercase()
                // Skip dummy/virtual p2p/vpn unless nothing else found
                if (name.startsWith("dummy") || name.startsWith("p2p") || name.startsWith("tun")) continue

                for (address in Collections.list(networkInterface.inetAddresses)) {
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val ip = address.hostAddress ?: continue
                        candidates.add(name to ip)
                    }
                }
            }

            // 1. Prefer wlan (Wi-Fi), eth (Ethernet), ap (Hotspot), rndis (USB Tethering)
            val preferredInterfaces = listOf("wlan", "eth", "ap", "rndis", "tiwlan")
            for (prefix in preferredInterfaces) {
                val match = candidates.firstOrNull { (iface, ip) ->
                    iface.startsWith(prefix) && isPrivateOrLanIp(ip)
                }
                if (match != null) return match.second
            }

            // 2. Any private LAN IP (192.168.x.x, 10.x.x.x, 172.16-31.x.x)
            val anyPrivate = candidates.firstOrNull { (_, ip) -> isPrivateOrLanIp(ip) }
            if (anyPrivate != null) return anyPrivate.second

            // 3. Fallback to any candidates
            if (candidates.isNotEmpty()) {
                return candidates.first().second
            }
        } catch (_: Exception) {
            // Handle network discovery exception gracefully
        }
        return null
    }

    private fun isPrivateOrLanIp(ip: String): Boolean {
        if (ip.startsWith("192.168.") || ip.startsWith("10.")) return true
        if (ip.startsWith("172.")) {
            val secondOctet = ip.split(".").getOrNull(1)?.toIntOrNull() ?: 0
            if (secondOctet in 16..31) return true
        }
        return false
    }

    /**
     * Formats full streaming URL for TV browsers.
     */
    fun getStreamUrl(ip: String?, port: Int = DEFAULT_PORT): String {
        val host = ip ?: "127.0.0.1"
        return "http://$host:$port"
    }

    /**
     * Checks if Wi-Fi or Ethernet local connection is active.
     */
    fun isConnectedToLocalNetwork(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    /**
     * Gets Wi-Fi SSID name if available.
     */
    @Suppress("DEPRECATION")
    fun getWifiName(context: Context): String {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val info = wifiManager?.connectionInfo
            val ssid = info?.ssid
            if (!ssid.isNullOrBlank() && ssid != "<unknown ssid>") {
                return ssid.replace("\"", "")
            }
        } catch (_: Exception) {
        }
        return "Wi-Fi Network"
    }
}
