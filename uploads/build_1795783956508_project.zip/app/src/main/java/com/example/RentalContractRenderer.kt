package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/**
 * RentalContractRenderer: محرك رسم عقد إيجار العقارات والدور والمحلات
 * تصميم عراقي رسمي كلاسيكي موحد مع خط أميري/نسخ، جداول حادة، بصمة الإبهام، وختم المكتب.
 */
class RentalContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? RentalContract ?: RentalContract()
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale

        val extraLbl = when {
            data.sequenceNumber.isNotBlank() -> "التسلسل"
            data.doorsNumber.isNotBlank() -> "رقم الأبواب"
            else -> ""
        }
        val extraVal = when {
            data.sequenceNumber.isNotBlank() -> data.sequenceNumber
            data.doorsNumber.isNotBlank() -> data.doorsNumber
            else -> ""
        }

        // ==================== 1. الترويسة العراقية الرسمية ====================
        var curY = drawIraqiOfficialHeader(
            canvas = canvas,
            officeInfo = officeInfo,
            defaultOfficeName = "مكتب الدلالية للعقارات",
            specialtyText = "لتأجير العقارات والدور السكنية والمحلات التجارية",
            contractTitle = "عقد إيجار عقار",
            contractSubtitle = "عقد إيجار رسمي بالتراضي",
            contractNo = data.contractNo.ifBlank { "0001" },
            contractDate = data.signDate,
            extraMetaLabel = extraLbl,
            extraMetaValue = extraVal
        )

        // ==================== 2. شريط المقدمة الإقرارية ====================
        val seqText = if (data.sequenceNumber.isNotBlank()) "التسلسل: ${data.sequenceNumber}" else ""
        val doorText = if (data.doorsNumber.isNotBlank()) "أبواب رقم: ${data.doorsNumber}" else ""
        val barDesc = listOf(seqText, doorText).filter { it.isNotBlank() }.joinToString("  |  ")
        val introText = if (barDesc.isNotBlank()) {
            "عقد إيجار رسمي ($barDesc) — تم الاتفاق بالتراضي التام بين المؤجر والمستأجر على ما يلي:"
        } else {
            "تم الاتفاق بالتراضي التام بين الطرفين المؤجر والمستأجر على إيجار العين المبينة أدناه بالشروط الآتية:"
        }

        val introBarH = 36f
        val introRect = RectF(contentLeft, curY, contentRight, curY + introBarH)
        val barBg = Paint().apply {
            color = tintColor(primary, 14)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val barBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        canvas.drawRect(introRect, barBg)
        canvas.drawRect(introRect, barBorder)

        val introPaint = Paint().apply {
            color = primary
            textSize = 15.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        fitTextToWidth(introPaint, introText, introRect.width() - 20f, 11.5f)
        canvas.drawText(introText, introRect.centerX(), introRect.centerY() + 5.5f, introPaint)

        curY = introRect.bottom + 12f

        // ==================== 3. جدول الطرفين ====================
        curY = drawFormalPartiesTable(
            canvas = canvas,
            topY = curY,
            rightTitle = "الطرف الأول (المؤجر)",
            leftTitle = "الطرف الثاني (المستأجر)",
            rightFields = listOf(
                "المؤجر السيد:" to data.lessorName,
                "العنوان والواقع:" to data.propertyLocation,
                "المحلة:" to data.neighborhood,
                "زقاق / دار:" to data.alleyNumber
            ),
            leftFields = listOf(
                "المستأجر السيد:" to data.lesseeName,
                "حق السكن والصفة:" to data.dwellingRightDetails,
                "مدة الإيجار:" to data.leaseDuration,
                "العائد للمستأجر:" to data.returnToLesseeText
            )
        )

        // ==================== 4. جدول مواصفات العين المؤجرة ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "أولاً: إيجار منفعة العين المؤجرة بالخواص والمواصفات الآتية:",
            topY = curY
        )

        curY += 8f
        val gridH = 92f
        val gridRect = RectF(contentLeft, curY, contentRight, curY + gridH)
        val gridOuter = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val gridInner = Paint().apply {
            color = tintColor(primary, 165)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        canvas.drawRect(gridRect, gridOuter)
        val rowH = gridH / 2f
        val midX = gridRect.centerX()
        canvas.drawLine(gridRect.left, gridRect.top + rowH, gridRect.right, gridRect.top + rowH, gridInner)
        canvas.drawLine(midX, gridRect.top, midX, gridRect.bottom, gridInner)

        val cellW = (gridRect.width() / 2f) - 24f
        val locStr = listOf(data.propertyLocation, data.neighborhood).filter { it.isNotBlank() }.joinToString(" - ")
        val periodStr = listOfNotNull(
            data.startDate.takeIf { it.isNotBlank() }?.let { "من $it" },
            data.endDate.takeIf { it.isNotBlank() }?.let { "إلى $it" }
        ).joinToString(" ")

        drawFieldWithDots(canvas, "العين المؤجرة:", data.rentedPropertyDescription, gridRect.right - 12f, gridRect.top + 31f, cellW)
        drawFieldWithDots(canvas, "الموقع والمحلة:", locStr, midX - 12f, gridRect.top + 31f, cellW)
        drawFieldWithDots(canvas, "مدة الإيجار:", data.leaseDuration, gridRect.right - 12f, gridRect.top + rowH + 31f, cellW)
        drawFieldWithDots(canvas, "الفترة الزمنية:", periodStr, midX - 12f, gridRect.top + rowH + 31f, cellW)

        curY = gridRect.bottom + 12f

        // ==================== 5. المبالغ المالية ====================
        val fmtRent = FormatUtils.formatMoneyInput(data.rentAmountNumber)
        val rentDisp = if (fmtRent.isNotBlank()) "$fmtRent دينار" else data.rentAmountNumber
        val fmtDelay = FormatUtils.formatMoneyInput(data.dailyDelayFee)
        val delayDisp = when {
            fmtDelay.isNotBlank() -> "$fmtDelay دينار"
            data.dailyDelayFee.isNotBlank() -> "${data.dailyDelayFee} دينار"
            else -> "حسب الاتفاق"
        }

        curY = drawFinancialSummaryTable(
            canvas = canvas,
            topY = curY,
            items = listOf(
                Triple("بدل الإيجار الشهري (رقماً)", rentDisp, dark),
                Triple("غرامة التأخير اليومية", delayDisp, primary),
                Triple("ضريبة الأملاك على", data.propertyTaxOwner.ifBlank { "المؤجر" }, COLOR_RED_ACCENT)
            ),
            wordsRowLabel = "بدل الإيجار (كتابةً):",
            wordsRowValue = data.rentAmountWords
        )

        // ==================== 6. البنود والشروط القانونية ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "ثانياً: الشروط القانونية والتزامات المؤجر والمستأجر",
            topY = curY
        )

        curY += 10f
        val delayFeeClause = if (data.dailyDelayFee.isNotBlank()) "غرامة يومية قدرها ($delayDisp)" else "غرامة يومية متفق عليها"
        val taxOwnerText = data.propertyTaxOwner.ifBlank { "المؤجر" }

        val clauses = listOf(
            "ثانياً" to "عند انتهاء مدة الإيجار المحددة، يلتزم الطرف الثاني (المستأجر) بتخلية المأجور وتسليمه إلى المؤجر خالياً من الشواغل وبحالة جيدة.",
            "ثالثاً" to "إذا تأخر المستأجر عن التخلية بعد انتهاء المدة يكون ملزماً بدفع $delayFeeClause عن كل يوم تأخير من غير إنذار.",
            "رابعاً" to "تقع ضريبة الأملاك على ($taxOwnerText)، أما أجور الماء والكهرباء والخدمات والتنظيفات فيلتزم المستأجر بدفعها بانتظام طيلة مدة الإيجار.",
            "خامساً" to "للمستأجر حق السكن والانتفاع بالمأجور طيلة مدة الإيجار المتفق عليها مع التعهد بالمحافظة على العين المؤجرة وعدم إجراء أي تغيير جوهري دون موافقة تحريرية.",
            "سادساً" to "حرر هذا العقد على نسختين بيد كل من الطرفين نسخة واحدة للعمل بموجبها بعد التوقيع."
        )

        curY = drawIraqiLegalClauses(
            canvas = canvas,
            clauses = clauses,
            startY = curY,
            maxBottomY = footerTopY - 125f
        )

        val dateP = Paint().apply {
            color = primary
            textSize = 16f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val dateY = (curY + 14f).coerceAtMost(footerTopY - 90f)
        canvas.drawText("حرر بالتراضي بتاريخ: ${data.signDate}", contentRight, dateY, dateP)

        drawAdditionalNotesBlock(
            canvas = canvas,
            notes = data.additionalClauses,
            startY = dateY + 12f
        )

        // ==================== 7. التواقيع والشهود ====================
        drawIraqiSignaturesFooter(
            canvas = canvas,
            party1Title = "الطرف الأول/المؤجر",
            party2Title = "الطرف الثاني/المستأجر",
            witness1Name = data.witness1Name,
            witness2Name = data.witness2Name
        )
    }
}
