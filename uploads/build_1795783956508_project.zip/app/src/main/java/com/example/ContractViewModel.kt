package com.example

import android.app.Application
import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import org.json.JSONObject

sealed class BackupUiState {
    data object Idle : BackupUiState()
    data class Processing(val message: String) : BackupUiState()
    data class ConfirmRestore(val backupData: BackupData) : BackupUiState()
    data class Success(val message: String) : BackupUiState()
    data class Error(val message: String) : BackupUiState()
}

class ContractViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ContractRepository
    private val officeRepository: OfficeRepository
    val bluetoothPrinterManager: BluetoothPrinterManager
    val unifiedPrinterManager: UnifiedPrinterManager

    private val _officeInfo = MutableStateFlow(OfficeInfo())
    val officeInfo: StateFlow<OfficeInfo> = _officeInfo.asStateFlow()

    private val numberPrefs = application.getSharedPreferences("contract_number_prefs", android.content.Context.MODE_PRIVATE)

    private fun getNextContractNumber(type: ContractType): String {
        val next = numberPrefs.getInt("next_no_${type.name}", 1).coerceAtLeast(1)
        return next.toString().padStart(4, '0')
    }

    private fun advanceContractNumberIfNeeded(type: ContractType, usedContractNo: String) {
        val currentNext = numberPrefs.getInt("next_no_${type.name}", 1).coerceAtLeast(1)
        val usedNum = usedContractNo.trim().toIntOrNull()
        if (usedNum != null && usedNum >= currentNext) {
            numberPrefs.edit().putInt("next_no_${type.name}", usedNum + 1).apply()
        } else if (usedContractNo.isBlank()) {
            numberPrefs.edit().putInt("next_no_${type.name}", currentNext + 1).apply()
        }
    }

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ContractRepository(database.contractDao())
        officeRepository = OfficeRepositoryImpl(SettingsManager.getInstance(application))
        bluetoothPrinterManager = BluetoothPrinterManager(application)
        unifiedPrinterManager = UnifiedPrinterManager(application, bluetoothPrinterManager)
        _officeInfo.value = officeRepository.getOfficeInfo()
        observeSavedContracts()
    }

    private val _backupUiState = MutableStateFlow<BackupUiState>(BackupUiState.Idle)
    val backupUiState: StateFlow<BackupUiState> = _backupUiState.asStateFlow()

    private val _restoreRevision = MutableStateFlow(0)
    val restoreRevision: StateFlow<Int> = _restoreRevision.asStateFlow()

    fun refreshOfficeInfo() {
        _officeInfo.value = officeRepository.getOfficeInfo()
        viewModelScope.launch {
            generateCurrentPreviewBitmapAsync()
        }
    }

    // 1. اختيار نوع العقد المباشر
    private val _selectedContractType = MutableStateFlow(ContractType.REAL_ESTATE)
    val selectedContractType: StateFlow<ContractType> = _selectedContractType.asStateFlow()

    // 2. حالات نماذج الإدخال للعقود الأربعة بأرقام تسلسلية مستقلة تبدأ من 0001
    private val _realEstateContract = MutableStateFlow(
        RealEstateContract(contractNo = getNextContractNumber(ContractType.REAL_ESTATE))
    )
    val realEstateContract: StateFlow<RealEstateContract> = _realEstateContract.asStateFlow()

    private val _carSaleContract = MutableStateFlow(
        CarSaleContract(contractNo = getNextContractNumber(ContractType.CAR_SALE))
    )
    val carSaleContract: StateFlow<CarSaleContract> = _carSaleContract.asStateFlow()

    private val _rentalContract = MutableStateFlow(
        RentalContract(contractNo = getNextContractNumber(ContractType.RENTAL))
    )
    val rentalContract: StateFlow<RentalContract> = _rentalContract.asStateFlow()

    private val _motorcycleContract = MutableStateFlow(
        MotorcycleContract(contractNo = getNextContractNumber(ContractType.MOTORCYCLE))
    )
    val motorcycleContract: StateFlow<MotorcycleContract> = _motorcycleContract.asStateFlow()

    // 3. حالة معاينة العقد وصورة الـ A4 Canvas
    private val _previewBitmap = MutableStateFlow<Bitmap?>(null)
    val previewBitmap: StateFlow<Bitmap?> = _previewBitmap.asStateFlow()

    private val _showPreviewDialog = MutableStateFlow(false)
    val showPreviewDialog: StateFlow<Boolean> = _showPreviewDialog.asStateFlow()

    // 4. حالة مركز الطابعات الموحّد (Wi-Fi / Bluetooth / USB)
    val printerState: StateFlow<PrinterState> = bluetoothPrinterManager.printerState
    val selectedPaperType: StateFlow<PrinterPaperType> = bluetoothPrinterManager.selectedPaperType
    val selectedPrinterTab: StateFlow<PrinterConnectionTab> = unifiedPrinterManager.selectedTab
    val wifiPrinters: StateFlow<List<WifiPrinterDevice>> = unifiedPrinterManager.wifiPrinters
    val isScanningWifi: StateFlow<Boolean> = unifiedPrinterManager.isScanningWifi
    val pairedDevices: StateFlow<List<BluetoothDevice>> = unifiedPrinterManager.bluetoothDevices
    val hasBluetoothPermission: StateFlow<Boolean> = unifiedPrinterManager.hasBluetoothPermission
    val isBluetoothEnabled: StateFlow<Boolean> = unifiedPrinterManager.isBluetoothEnabled
    val usbPrinters: StateFlow<List<UsbPrinterDevice>> = unifiedPrinterManager.usbPrinters

    private val _showPrinterDialog = MutableStateFlow(false)
    val showPrinterDialog: StateFlow<Boolean> = _showPrinterDialog.asStateFlow()

    private val _printCopies = MutableStateFlow(1)
    val printCopies: StateFlow<Int> = _printCopies.asStateFlow()

    fun setPrintCopies(copies: Int) {
        _printCopies.value = copies.coerceIn(1, 20)
    }

    fun setPrinterPaperType(type: PrinterPaperType) {
        bluetoothPrinterManager.setPaperType(type)
    }

    // 5. الأرشيف والعقود المحفوظة
    private val _savedContractsList = MutableStateFlow<List<ContractEntity>>(emptyList())
    val savedContractsList: StateFlow<List<ContractEntity>> = _savedContractsList.asStateFlow()

    private fun observeSavedContracts() {
        viewModelScope.launch {
            repository.allContracts.collectLatest { list ->
                _savedContractsList.value = list
            }
        }
    }

    fun setContractType(type: ContractType) {
        _selectedContractType.value = type
        viewModelScope.launch {
            generateCurrentPreviewBitmapAsync()
        }
    }

    // تحديث بيانات عقد العقارات
    fun updateRealEstateContract(update: (RealEstateContract) -> RealEstateContract) {
        _realEstateContract.value = update(_realEstateContract.value)
    }

    // تحديث بيانات عقد السيارات
    fun updateCarSaleContract(update: (CarSaleContract) -> CarSaleContract) {
        _carSaleContract.value = update(_carSaleContract.value)
    }

    // تحديث بيانات عقد الإيجار
    fun updateRentalContract(update: (RentalContract) -> RentalContract) {
        _rentalContract.value = update(_rentalContract.value)
    }

    // تحديث بيانات عقد الدراجات والتكتك
    fun updateMotorcycleContract(update: (MotorcycleContract) -> MotorcycleContract) {
        _motorcycleContract.value = update(_motorcycleContract.value)
    }

    /**
     * إفراغ جميع حقول العقد الحالي
     */
    fun clearCurrentContractFields() {
        when (_selectedContractType.value) {
            ContractType.REAL_ESTATE -> _realEstateContract.value = RealEstateContract(
                contractNo = getNextContractNumber(ContractType.REAL_ESTATE)
            )
            ContractType.CAR_SALE -> _carSaleContract.value = CarSaleContract(
                contractNo = getNextContractNumber(ContractType.CAR_SALE)
            )
            ContractType.RENTAL -> _rentalContract.value = RentalContract(
                contractNo = getNextContractNumber(ContractType.RENTAL)
            )
            ContractType.MOTORCYCLE -> _motorcycleContract.value = MotorcycleContract(
                contractNo = getNextContractNumber(ContractType.MOTORCYCLE)
            )
        }
        viewModelScope.launch {
            generateCurrentPreviewBitmapAsync()
        }
    }

    /**
     * توليد صورة معاينة A4 في الخلفية (Dispatchers.Default) لمنع تعليق واجهة المستخدم
     */
    suspend fun generateCurrentPreviewBitmapAsync(): Bitmap {
        val currentOffice = _officeInfo.value
        val type = _selectedContractType.value
        val context = getApplication<Application>()
        val realEstate = _realEstateContract.value
        val carSale = _carSaleContract.value
        val rental = _rentalContract.value
        val motorcycle = _motorcycleContract.value

        val bitmap = withContext(Dispatchers.Default) {
            when (type) {
                ContractType.REAL_ESTATE -> FormGenerator.renderRealEstateContractBitmap(realEstate, currentOffice, context)
                ContractType.CAR_SALE -> FormGenerator.renderCarSaleContractBitmap(carSale, currentOffice, context)
                ContractType.RENTAL -> FormGenerator.renderRentalContractBitmap(rental, currentOffice, context)
                ContractType.MOTORCYCLE -> FormGenerator.renderMotorcycleContractBitmap(motorcycle, currentOffice, context)
            }
        }
        _previewBitmap.value = bitmap
        return bitmap
    }

    fun openPreviewDialog() {
        viewModelScope.launch {
            generateCurrentPreviewBitmapAsync()
            _showPreviewDialog.value = true
        }
    }

    fun closePreviewDialog() {
        _showPreviewDialog.value = false
    }

    /**
     * فتح نافذة الطابعات الموحدة وفحص Wi-Fi و Bluetooth و USB تلقائياً
     */
    fun openBluetoothPrinterDialog() {
        _printCopies.value = 1
        unifiedPrinterManager.scanAllPrinters(autoSelectBestTab = true)
        _showPrinterDialog.value = true
    }

    fun closeBluetoothPrinterDialog() {
        _showPrinterDialog.value = false
        unifiedPrinterManager.stopWifiDiscovery()
        bluetoothPrinterManager.resetState()
    }

    fun selectPrinterTab(tab: PrinterConnectionTab) {
        unifiedPrinterManager.selectTab(tab)
        when (tab) {
            PrinterConnectionTab.WIFI -> unifiedPrinterManager.startWifiDiscovery()
            PrinterConnectionTab.BLUETOOTH -> unifiedPrinterManager.refreshBluetoothDevices()
            PrinterConnectionTab.USB -> unifiedPrinterManager.refreshUsbPrinters()
        }
    }

    fun refreshPairedDevices() {
        when (selectedPrinterTab.value) {
            PrinterConnectionTab.WIFI -> unifiedPrinterManager.startWifiDiscovery()
            PrinterConnectionTab.BLUETOOTH -> unifiedPrinterManager.refreshBluetoothDevices()
            PrinterConnectionTab.USB -> unifiedPrinterManager.refreshUsbPrinters()
        }
    }

    fun addManualWifiPrinter(name: String, host: String, port: Int): Boolean {
        return unifiedPrinterManager.addManualWifiPrinter(name, host, port)
    }

    fun removeManualWifiPrinter(device: WifiPrinterDevice) {
        unifiedPrinterManager.removeManualWifiPrinter(device)
    }

    fun printToWifiDevice(device: WifiPrinterDevice, onFallbackToSystemPrint: () -> Unit) {
        val copies = _printCopies.value
        viewModelScope.launch {
            val bitmap = generateCurrentPreviewBitmapAsync()
            unifiedPrinterManager.printToWifiPrinter(device, bitmap, copies, onFallbackToSystemPrint)
        }
    }

    fun printToBluetoothDevice(device: BluetoothDevice) {
        val copies = _printCopies.value
        viewModelScope.launch {
            val bitmap = generateCurrentPreviewBitmapAsync()
            bluetoothPrinterManager.printBitmapToBluetoothPrinter(device, bitmap, copies)
        }
    }

    fun printToUsbDevice(device: UsbPrinterDevice) {
        val copies = _printCopies.value
        viewModelScope.launch {
            val bitmap = generateCurrentPreviewBitmapAsync()
            unifiedPrinterManager.printToUsbPrinter(device, bitmap, copies)
        }
    }

    fun printViaSystemManager(context: android.content.Context) {
        val copies = _printCopies.value
        viewModelScope.launch {
            val bitmap = generateCurrentPreviewBitmapAsync()
            val jobName = when (_selectedContractType.value) {
                ContractType.REAL_ESTATE -> "عقد_بيع_عقار"
                ContractType.CAR_SALE -> "عقد_بيع_سيارة"
                ContractType.RENTAL -> "عقد_إيجار"
                ContractType.MOTORCYCLE -> "عقد_بيع_دراجة"
            }
            FormGenerator.printViaAndroidPrintManager(context, bitmap, jobName, copies)
        }
    }

    override fun onCleared() {
        super.onCleared()
        unifiedPrinterManager.cleanup()
    }

    /**
     * حفظ العقد الحالي في قاعدة بيانات الأرشيف وتحديث الرقم التسلسلي للنوع الحالي
     */
    fun saveContractToArchive() {
        viewModelScope.launch {
            val type = _selectedContractType.value
            val usedNo: String
            val (title, primaryParty, secondaryParty, summaryJson) = when (type) {
                ContractType.REAL_ESTATE -> {
                    val c = _realEstateContract.value
                    usedNo = c.contractNo
                    Quad("عقد عقار #${c.contractNo} - ${c.propertyType.ifBlank { "سكني" }}", c.sellerName, c.buyerName, realEstateToJson(c))
                }
                ContractType.CAR_SALE -> {
                    val c = _carSaleContract.value
                    usedNo = c.contractNo
                    Quad("عقد سيارة #${c.contractNo} - ${c.carBrandAndType.ifBlank { "مركبة" }}", c.sellerName, c.buyerName, carSaleToJson(c))
                }
                ContractType.RENTAL -> {
                    val c = _rentalContract.value
                    usedNo = c.contractNo
                    Quad("عقد إيجار #${c.contractNo} - ${c.propertyLocation.ifBlank { "عقار" }}", c.lessorName, c.lesseeName, rentalToJson(c))
                }
                ContractType.MOTORCYCLE -> {
                    val c = _motorcycleContract.value
                    usedNo = c.contractNo
                    Quad("عقد دراجة/تكتك #${c.contractNo} - ${c.brand.ifBlank { "دراجة" }}", c.sellerName, c.buyerName, motorcycleToJson(c))
                }
            }

            val entity = ContractEntity(
                contractType = type.name,
                title = title,
                primaryPartyName = primaryParty,
                secondaryPartyName = secondaryParty,
                jsonContent = summaryJson
            )
            repository.saveContract(entity)
            advanceContractNumberIfNeeded(type, usedNo)
        }
    }

    /**
     * استرجاع عقد محدد من الأرشيف وتعبئة حقوله للتحرير أو الطباعة
     */
    fun populateContractFromEntity(entity: ContractEntity): ContractType {
        val type = try {
            ContractType.valueOf(entity.contractType)
        } catch (e: Exception) {
            ContractType.REAL_ESTATE
        }
        _selectedContractType.value = type

        when (type) {
            ContractType.REAL_ESTATE -> _realEstateContract.value = jsonToRealEstate(entity.jsonContent)
            ContractType.CAR_SALE -> _carSaleContract.value = jsonToCarSale(entity.jsonContent)
            ContractType.RENTAL -> _rentalContract.value = jsonToRental(entity.jsonContent)
            ContractType.MOTORCYCLE -> _motorcycleContract.value = jsonToMotorcycle(entity.jsonContent)
        }
        return type
    }

    /**
     * استرجاع عقد محدد من الأرشيف وإعادة فتحه للطباعة والمعاينة
     */
    fun loadContractFromArchive(entity: ContractEntity) {
        populateContractFromEntity(entity)
        openPreviewDialog()
    }

    fun deleteSavedContract(id: Long) {
        viewModelScope.launch {
            repository.deleteContract(id)
        }
    }

    /**
     * تصدير نسخة احتياطية محلية تشمل العقود المحفوظة وإعدادات المكتب والترقيم التسلسلي
     */
    fun exportBackupToUri(uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            _backupUiState.value = BackupUiState.Processing("جاري إعداد وحفظ النسخة الاحتياطية...")
            try {
                val contracts = withContext(Dispatchers.IO) {
                    repository.getAllContractsOnce()
                }
                val currentOffice = officeRepository.getOfficeInfo()
                val counters = ContractType.entries.associate { type ->
                    type.name to numberPrefs.getInt("next_no_${type.name}", 1).coerceAtLeast(1)
                }
                val templateManager = TemplateSettingsManager.getInstance(app)
                val jsonContent = withContext(Dispatchers.Default) {
                    BackupManager.buildBackupJson(
                        officeInfo = currentOffice,
                        contracts = contracts,
                        contractCounters = counters,
                        selectedTemplateId = templateManager.selectedTemplateId,
                        templateOptions = templateManager.getCustomizationOptions()
                    )
                }
                val writeResult = BackupManager.writeBackupToUri(app, uri, jsonContent)
                writeResult.fold(
                    onSuccess = {
                        _backupUiState.value = BackupUiState.Success(
                            "تم تصدير النسخة الاحتياطية بنجاح (${contracts.size} عقد وإعدادات المكتب)."
                        )
                    },
                    onFailure = { err ->
                        _backupUiState.value = BackupUiState.Error(
                            err.message ?: "تعذر حفظ ملف النسخة الاحتياطية"
                        )
                    }
                )
            } catch (e: Exception) {
                _backupUiState.value = BackupUiState.Error(
                    "حدث خطأ أثناء إنشاء النسخة الاحتياطية: ${e.localizedMessage ?: "خطأ غير متوقع"}"
                )
            }
        }
    }

    /**
     * فحص وقراءة ملف النسخة الاحتياطية قبل تأكيد الاستعادة
     */
    fun inspectBackupUri(uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            _backupUiState.value = BackupUiState.Processing("جاري فحص ملف النسخة الاحتياطية...")
            val result = BackupManager.readBackupFromUri(app, uri)
            result.fold(
                onSuccess = { backupData ->
                    _backupUiState.value = BackupUiState.ConfirmRestore(backupData)
                },
                onFailure = { err ->
                    _backupUiState.value = BackupUiState.Error(
                        err.message ?: "الملف المحدد غير صالح كنسخة احتياطية"
                    )
                }
            )
        }
    }

    /**
     * تنفيذ استعادة النسخة الاحتياطية (دمج مع الحالي أو استبدال كامل)
     */
    fun confirmRestoreBackup(backupData: BackupData, replaceExisting: Boolean) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            _backupUiState.value = BackupUiState.Processing("جاري استعادة العقود وإعدادات المكتب...")
            try {
                // 1. استعادة إعدادات المكتب
                officeRepository.saveOfficeInfo(backupData.officeInfo)
                _officeInfo.value = officeRepository.getOfficeInfo()

                // 2. استعادة عدادات الترقيم التسلسلي للعقود
                val prefsEditor = numberPrefs.edit()
                ContractType.entries.forEach { type ->
                    val restoredCounter = backupData.contractCounters[type.name]?.coerceAtLeast(1)
                    val currentCounter = numberPrefs.getInt("next_no_${type.name}", 1).coerceAtLeast(1)
                    val finalCounter = when {
                        replaceExisting -> restoredCounter ?: 1
                        restoredCounter != null -> maxOf(currentCounter, restoredCounter)
                        else -> currentCounter
                    }
                    prefsEditor.putInt("next_no_${type.name}", finalCounter)
                }
                prefsEditor.apply()

                // 3. استعادة تخصيصات القوالب إن وُجدت في النسخة
                val templateManager = TemplateSettingsManager.getInstance(app)
                backupData.selectedTemplateId?.let { templateId ->
                    templateManager.selectedTemplateId = templateId
                }
                backupData.templateOptions?.let { options ->
                    templateManager.saveCustomizationOptions(options)
                }

                // 4. استعادة العقود في قاعدة البيانات المحلية (Room)
                val (addedCount, skippedCount) = withContext(Dispatchers.IO) {
                    if (replaceExisting) {
                        val normalized = backupData.contracts.map { it.copy(id = 0) }
                        repository.replaceAllContracts(normalized)
                        normalized.size to 0
                    } else {
                        val existing = repository.getAllContractsOnce()
                        val (toInsert, skipped) = BackupManager.filterNonDuplicateContracts(
                            incoming = backupData.contracts,
                            existing = existing
                        )
                        if (toInsert.isNotEmpty()) {
                            repository.insertContracts(toInsert)
                        }
                        toInsert.size to skipped
                    }
                }

                // تحديث رقم العقد للنماذج الفارغة غير المعدّلة
                syncUntouchedContractNumbers()
                _restoreRevision.value += 1
                generateCurrentPreviewBitmapAsync()

                val summaryMsg = buildString {
                    append("تمت استعادة إعدادات المكتب ")
                    if (replaceExisting) {
                        append("و($addedCount) عقد بنجاح.")
                    } else if (skippedCount > 0) {
                        append("وإضافة ($addedCount) عقد جديد (تم تخطي $skippedCount عقد مكرر).")
                    } else {
                        append("وإضافة ($addedCount) عقد بنجاح.")
                    }
                }
                _backupUiState.value = BackupUiState.Success(summaryMsg)
            } catch (e: Exception) {
                _backupUiState.value = BackupUiState.Error(
                    "فشلت عملية الاستعادة: ${e.localizedMessage ?: "خطأ غير متوقع"}"
                )
            }
        }
    }

    private fun syncUntouchedContractNumbers() {
        val real = _realEstateContract.value
        if (real.sellerName.isBlank() && real.buyerName.isBlank()) {
            _realEstateContract.value = real.copy(contractNo = getNextContractNumber(ContractType.REAL_ESTATE))
        }
        val car = _carSaleContract.value
        if (car.sellerName.isBlank() && car.buyerName.isBlank()) {
            _carSaleContract.value = car.copy(contractNo = getNextContractNumber(ContractType.CAR_SALE))
        }
        val rental = _rentalContract.value
        if (rental.lessorName.isBlank() && rental.lesseeName.isBlank()) {
            _rentalContract.value = rental.copy(contractNo = getNextContractNumber(ContractType.RENTAL))
        }
        val moto = _motorcycleContract.value
        if (moto.sellerName.isBlank() && moto.buyerName.isBlank()) {
            _motorcycleContract.value = moto.copy(contractNo = getNextContractNumber(ContractType.MOTORCYCLE))
        }
    }

    fun clearBackupUiState() {
        _backupUiState.value = BackupUiState.Idle
    }

    private fun realEstateToJson(c: RealEstateContract): String {
        return JSONObject().apply {
            put("contractNo", c.contractNo)
            put("sellerName", c.sellerName)
            put("sellerAddress", c.sellerAddress)
            put("sellerIdNumber", c.sellerIdNumber)
            put("sellerPhone", c.sellerPhone)
            put("buyerName", c.buyerName)
            put("buyerAddress", c.buyerAddress)
            put("buyerIdNumber", c.buyerIdNumber)
            put("buyerPhone", c.buyerPhone)
            put("propertyType", c.propertyType)
            put("propertyArea", c.propertyArea)
            put("plotSequenceNo", c.plotSequenceNo)
            put("neighborhood", c.neighborhood)
            put("totalPrice", c.totalPrice)
            put("totalPriceWords", c.totalPriceWords)
            put("depositPrice", c.depositPrice)
            put("remainingPrice", c.remainingPrice)
            put("penaltySellerAmount", c.penaltySellerAmount)
            put("penaltyBuyerAmount", c.penaltyBuyerAmount)
            put("contractPlace", c.contractPlace)
            put("contractDate", c.contractDate)
            put("additionalNotes", c.additionalNotes)
            put("witness1Name", c.witness1Name)
            put("witness2Name", c.witness2Name)
        }.toString()
    }

    private fun jsonToRealEstate(jsonStr: String): RealEstateContract {
        if (jsonStr.isBlank() || !jsonStr.startsWith("{")) return RealEstateContract()
        return try {
            val j = JSONObject(jsonStr)
            RealEstateContract(
                contractNo = j.optString("contractNo", "0001"),
                sellerName = j.optString("sellerName", ""),
                sellerAddress = j.optString("sellerAddress", ""),
                sellerIdNumber = j.optString("sellerIdNumber", ""),
                sellerPhone = j.optString("sellerPhone", ""),
                buyerName = j.optString("buyerName", ""),
                buyerAddress = j.optString("buyerAddress", ""),
                buyerIdNumber = j.optString("buyerIdNumber", ""),
                buyerPhone = j.optString("buyerPhone", ""),
                propertyType = j.optString("propertyType", "دار سكني"),
                propertyArea = j.optString("propertyArea", ""),
                plotSequenceNo = j.optString("plotSequenceNo", ""),
                neighborhood = j.optString("neighborhood", ""),
                totalPrice = j.optString("totalPrice", ""),
                totalPriceWords = j.optString("totalPriceWords", ""),
                depositPrice = j.optString("depositPrice", ""),
                remainingPrice = j.optString("remainingPrice", ""),
                penaltySellerAmount = j.optString("penaltySellerAmount", ""),
                penaltyBuyerAmount = j.optString("penaltyBuyerAmount", ""),
                contractPlace = j.optString("contractPlace", ""),
                contractDate = j.optString("contractDate", FormatUtils.getTodayDateString()),
                additionalNotes = j.optString("additionalNotes", ""),
                witness1Name = j.optString("witness1Name", ""),
                witness2Name = j.optString("witness2Name", "")
            )
        } catch (e: Exception) {
            RealEstateContract()
        }
    }

    private fun carSaleToJson(c: CarSaleContract): String {
        return JSONObject().apply {
            put("galleryName", c.galleryName)
            put("galleryPhone", c.galleryPhone)
            put("galleryAddress", c.galleryAddress)
            put("contractNo", c.contractNo)
            put("carLegalOwner", c.carLegalOwner)
            put("ownerAddress", c.ownerAddress)
            put("sellerName", c.sellerName)
            put("sellerAddress", c.sellerAddress)
            put("sellerIdNumber", c.sellerIdNumber)
            put("sellerPhone", c.sellerPhone)
            put("buyerName", c.buyerName)
            put("buyerAddress", c.buyerAddress)
            put("buyerIdNumber", c.buyerIdNumber)
            put("buyerPhone", c.buyerPhone)
            put("carCategory", c.carCategory)
            put("carBrandAndType", c.carBrandAndType)
            put("modelYear", c.modelYear)
            put("color", c.color)
            put("annualRegNumber", c.annualRegNumber)
            put("engineNumber", c.engineNumber)
            put("chassisNumber", c.chassisNumber)
            put("totalPrice", c.totalPrice)
            put("totalPriceWords", c.totalPriceWords)
            put("paidAmount", c.paidAmount)
            put("remainingAmount", c.remainingAmount)
            put("contractDate", c.contractDate)
            put("witness1Name", c.witness1Name)
            put("witness2Name", c.witness2Name)
            put("witnessName", c.witnessName)
            put("organizerName", c.organizerName)
            put("notes", c.notes)
        }.toString()
    }

    private fun jsonToCarSale(jsonStr: String): CarSaleContract {
        if (jsonStr.isBlank() || !jsonStr.startsWith("{")) return CarSaleContract()
        return try {
            val j = JSONObject(jsonStr)
            CarSaleContract(
                galleryName = j.optString("galleryName", ""),
                galleryPhone = j.optString("galleryPhone", ""),
                galleryAddress = j.optString("galleryAddress", ""),
                contractNo = j.optString("contractNo", "0001"),
                carLegalOwner = j.optString("carLegalOwner", ""),
                ownerAddress = j.optString("ownerAddress", ""),
                sellerName = j.optString("sellerName", ""),
                sellerAddress = j.optString("sellerAddress", ""),
                sellerIdNumber = j.optString("sellerIdNumber", ""),
                sellerPhone = j.optString("sellerPhone", ""),
                buyerName = j.optString("buyerName", ""),
                buyerAddress = j.optString("buyerAddress", ""),
                buyerIdNumber = j.optString("buyerIdNumber", ""),
                buyerPhone = j.optString("buyerPhone", ""),
                carCategory = j.optString("carCategory", "خصوصي"),
                carBrandAndType = j.optString("carBrandAndType", ""),
                modelYear = j.optString("modelYear", ""),
                color = j.optString("color", ""),
                annualRegNumber = j.optString("annualRegNumber", ""),
                engineNumber = j.optString("engineNumber", ""),
                chassisNumber = j.optString("chassisNumber", ""),
                totalPrice = j.optString("totalPrice", ""),
                totalPriceWords = j.optString("totalPriceWords", ""),
                paidAmount = j.optString("paidAmount", ""),
                remainingAmount = j.optString("remainingAmount", ""),
                contractDate = j.optString("contractDate", FormatUtils.getTodayDateString()),
                witness1Name = j.optString("witness1Name", ""),
                witness2Name = j.optString("witness2Name", ""),
                witnessName = j.optString("witnessName", ""),
                organizerName = j.optString("organizerName", ""),
                notes = j.optString("notes", "")
            )
        } catch (e: Exception) {
            CarSaleContract()
        }
    }

    private fun rentalToJson(c: RentalContract): String {
        return JSONObject().apply {
            put("contractNo", c.contractNo)
            put("sequenceNumber", c.sequenceNumber)
            put("doorsNumber", c.doorsNumber)
            put("lessorName", c.lessorName)
            put("lesseeName", c.lesseeName)
            put("rentedPropertyDescription", c.rentedPropertyDescription)
            put("propertyLocation", c.propertyLocation)
            put("neighborhood", c.neighborhood)
            put("alleyNumber", c.alleyNumber)
            put("leaseDuration", c.leaseDuration)
            put("startDate", c.startDate)
            put("endDate", c.endDate)
            put("rentAmountWords", c.rentAmountWords)
            put("rentAmountNumber", c.rentAmountNumber)
            put("returnToLesseeText", c.returnToLesseeText)
            put("dwellingRightDetails", c.dwellingRightDetails)
            put("dailyDelayFee", c.dailyDelayFee)
            put("propertyTaxOwner", c.propertyTaxOwner)
            put("signDate", c.signDate)
            put("additionalClauses", c.additionalClauses)
            put("witness1Name", c.witness1Name)
            put("witness2Name", c.witness2Name)
        }.toString()
    }

    private fun jsonToRental(jsonStr: String): RentalContract {
        if (jsonStr.isBlank() || !jsonStr.startsWith("{")) return RentalContract()
        return try {
            val j = JSONObject(jsonStr)
            RentalContract(
                contractNo = j.optString("contractNo", "0001"),
                sequenceNumber = j.optString("sequenceNumber", ""),
                doorsNumber = j.optString("doorsNumber", ""),
                lessorName = j.optString("lessorName", ""),
                lesseeName = j.optString("lesseeName", ""),
                rentedPropertyDescription = j.optString("rentedPropertyDescription", ""),
                propertyLocation = j.optString("propertyLocation", ""),
                neighborhood = j.optString("neighborhood", ""),
                alleyNumber = j.optString("alleyNumber", ""),
                leaseDuration = j.optString("leaseDuration", ""),
                startDate = j.optString("startDate", FormatUtils.getTodayDateString()),
                endDate = j.optString("endDate", ""),
                rentAmountWords = j.optString("rentAmountWords", ""),
                rentAmountNumber = j.optString("rentAmountNumber", ""),
                returnToLesseeText = j.optString("returnToLesseeText", ""),
                dwellingRightDetails = j.optString("dwellingRightDetails", ""),
                dailyDelayFee = j.optString("dailyDelayFee", ""),
                propertyTaxOwner = j.optString("propertyTaxOwner", ""),
                signDate = j.optString("signDate", FormatUtils.getTodayDateString()),
                additionalClauses = j.optString("additionalClauses", ""),
                witness1Name = j.optString("witness1Name", ""),
                witness2Name = j.optString("witness2Name", "")
            )
        } catch (e: Exception) {
            RentalContract()
        }
    }

    private fun motorcycleToJson(c: MotorcycleContract): String {
        return JSONObject().apply {
            put("contractNo", c.contractNo)
            put("sellerName", c.sellerName)
            put("sellerAddress", c.sellerAddress)
            put("sellerNeighborhood", c.sellerNeighborhood)
            put("sellerAlley", c.sellerAlley)
            put("sellerHouse", c.sellerHouse)
            put("sellerIdNumber", c.sellerIdNumber)
            put("sellerIdIssueDate", c.sellerIdIssueDate)
            put("sellerRegistry", c.sellerRegistry)
            put("sellerPhone", c.sellerPhone)
            put("buyerName", c.buyerName)
            put("buyerAddress", c.buyerAddress)
            put("buyerNeighborhood", c.buyerNeighborhood)
            put("buyerAlley", c.buyerAlley)
            put("buyerHouse", c.buyerHouse)
            put("buyerIdNumber", c.buyerIdNumber)
            put("buyerIdIssueDate", c.buyerIdIssueDate)
            put("buyerRegistry", c.buyerRegistry)
            put("buyerPhone", c.buyerPhone)
            put("registeredNumber", c.registeredNumber)
            put("vehicleType", c.vehicleType)
            put("contactPhone", c.contactPhone)
            put("color", c.color)
            put("engineCc", c.engineCc)
            put("brand", c.brand)
            put("engineNumber", c.engineNumber)
            put("chassisNumber", c.chassisNumber)
            put("totalPrice", c.totalPrice)
            put("totalPriceWords", c.totalPriceWords)
            put("paidAmount", c.paidAmount)
            put("remainingAmount", c.remainingAmount)
            put("possessorName", c.possessorName)
            put("possessorAddress", c.possessorAddress)
            put("possessorNeighborhood", c.possessorNeighborhood)
            put("possessorAlley", c.possessorAlley)
            put("possessorHouse", c.possessorHouse)
            put("possessorPhone", c.possessorPhone)
            put("possessorIdNumber", c.possessorIdNumber)
            put("notes", c.notes)
            put("contractDate", c.contractDate)
            put("contractTime", c.contractTime)
            put("witness1Name", c.witness1Name)
            put("witness2Name", c.witness2Name)
            put("witnessName", c.witnessName)
        }.toString()
    }

    private fun jsonToMotorcycle(jsonStr: String): MotorcycleContract {
        if (jsonStr.isBlank() || !jsonStr.startsWith("{")) return MotorcycleContract()
        return try {
            val j = JSONObject(jsonStr)
            MotorcycleContract(
                contractNo = j.optString("contractNo", "0001"),
                sellerName = j.optString("sellerName", ""),
                sellerAddress = j.optString("sellerAddress", ""),
                sellerNeighborhood = j.optString("sellerNeighborhood", ""),
                sellerAlley = j.optString("sellerAlley", ""),
                sellerHouse = j.optString("sellerHouse", ""),
                sellerIdNumber = j.optString("sellerIdNumber", ""),
                sellerIdIssueDate = j.optString("sellerIdIssueDate", ""),
                sellerRegistry = j.optString("sellerRegistry", ""),
                sellerPhone = j.optString("sellerPhone", ""),
                buyerName = j.optString("buyerName", ""),
                buyerAddress = j.optString("buyerAddress", ""),
                buyerNeighborhood = j.optString("buyerNeighborhood", ""),
                buyerAlley = j.optString("buyerAlley", ""),
                buyerHouse = j.optString("buyerHouse", ""),
                buyerIdNumber = j.optString("buyerIdNumber", ""),
                buyerIdIssueDate = j.optString("buyerIdIssueDate", ""),
                buyerRegistry = j.optString("buyerRegistry", ""),
                buyerPhone = j.optString("buyerPhone", ""),
                registeredNumber = j.optString("registeredNumber", ""),
                vehicleType = j.optString("vehicleType", "دراجة نارية"),
                contactPhone = j.optString("contactPhone", ""),
                color = j.optString("color", ""),
                engineCc = j.optString("engineCc", ""),
                brand = j.optString("brand", ""),
                engineNumber = j.optString("engineNumber", ""),
                chassisNumber = j.optString("chassisNumber", ""),
                totalPrice = j.optString("totalPrice", ""),
                totalPriceWords = j.optString("totalPriceWords", ""),
                paidAmount = j.optString("paidAmount", ""),
                remainingAmount = j.optString("remainingAmount", ""),
                possessorName = j.optString("possessorName", ""),
                possessorAddress = j.optString("possessorAddress", ""),
                possessorNeighborhood = j.optString("possessorNeighborhood", ""),
                possessorAlley = j.optString("possessorAlley", ""),
                possessorHouse = j.optString("possessorHouse", ""),
                possessorPhone = j.optString("possessorPhone", ""),
                possessorIdNumber = j.optString("possessorIdNumber", ""),
                notes = j.optString("notes", ""),
                contractDate = j.optString("contractDate", FormatUtils.getTodayDateString()),
                contractTime = j.optString("contractTime", ""),
                witness1Name = j.optString("witness1Name", ""),
                witness2Name = j.optString("witness2Name", ""),
                witnessName = j.optString("witnessName", "")
            )
        } catch (e: Exception) {
            MotorcycleContract()
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
