package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/**
 * MotorcycleContractRenderer: محرك رسم عقد بيع وشراء الدراجات والتكتك والستوتات
 * تصميم عراقي رسمي كلاسيكي موحد مع خط أميري/نسخ، جداول حادة، بصمة الإبهام، وختم المعرض.
 */
class MotorcycleContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? MotorcycleContract ?: MotorcycleContract()
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale

        // ==================== 1. الترويسة العراقية الرسمية ====================
        var curY = drawIraqiOfficialHeader(
            canvas = canvas,
            officeInfo = officeInfo,
            defaultOfficeName = "معرض الدراجات والتكتك",
            specialtyText = "لتجارة وبيع وشراء الدراجات النارية والتكتك والستوتات",
            contractTitle = "عقد بيع وشراء دراجة",
            contractSubtitle = "الدراجات النارية والتكتك والستوتات",
            contractNo = data.contractNo.ifBlank { "0001" },
            contractDate = data.contractDate,
            extraMetaLabel = if (data.contractTime.isNotBlank()) "الوقت" else "",
            extraMetaValue = data.contractTime
        )

        // ==================== 2. شريط البائع الحائز ====================
        val posNameText = data.possessorName.ifBlank { data.sellerName }
        val posPhoneText = data.possessorPhone.ifBlank { data.sellerPhone }
        val posIdText = data.possessorIdNumber.ifBlank { data.sellerIdNumber }

        val posBarH = 38f
        val posRect = RectF(contentLeft, curY, contentRight, curY + posBarH)
        val barBg = Paint().apply {
            color = tintColor(primary, 14)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val barBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.6f
            isAntiAlias = true
        }
        val barSplit = Paint().apply {
            color = tintColor(primary, 160)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        canvas.drawRect(posRect, barBg)
        canvas.drawRect(posRect, barBorder)
        val col3W = posRect.width() / 3f
        canvas.drawLine(posRect.right - col3W, posRect.top, posRect.right - col3W, posRect.bottom, barSplit)
        canvas.drawLine(posRect.right - (col3W * 2f), posRect.top, posRect.right - (col3W * 2f), posRect.bottom, barSplit)

        drawFieldWithDots(canvas, "البائع الحائز:", posNameText, posRect.right - 10f, posRect.top + 25f, col3W - 20f)
        drawFieldWithDots(canvas, "هاتفه:", posPhoneText, posRect.right - col3W - 10f, posRect.top + 25f, col3W - 20f)
        drawFieldWithDots(canvas, "البطاقة الوطنية:", posIdText, posRect.right - (col3W * 2f) - 10f, posRect.top + 25f, col3W - 20f)

        curY = posRect.bottom + 12f

        // ==================== 3. جدول الطرفين ====================
        val sellerFullAddress = listOfNotNull(
            data.sellerAddress.takeIf { it.isNotBlank() },
            data.sellerNeighborhood.takeIf { it.isNotBlank() }?.let { "م/$it" },
            data.sellerAlley.takeIf { it.isNotBlank() }?.let { "ز/$it" },
            data.sellerHouse.takeIf { it.isNotBlank() }?.let { "د/$it" }
        ).joinToString(" - ")

        val buyerFullAddress = listOfNotNull(
            data.buyerAddress.takeIf { it.isNotBlank() },
            data.buyerNeighborhood.takeIf { it.isNotBlank() }?.let { "م/$it" },
            data.buyerAlley.takeIf { it.isNotBlank() }?.let { "ز/$it" },
            data.buyerHouse.takeIf { it.isNotBlank() }?.let { "د/$it" }
        ).joinToString(" - ")

        curY = drawFormalPartiesTable(
            canvas = canvas,
            topY = curY,
            rightTitle = "الطرف الأول (البائع)",
            leftTitle = "الطرف الثاني (المشتري)",
            rightFields = listOf(
                "البائع السيد:" to data.sellerName,
                "السكن:" to sellerFullAddress,
                "البطاقة الوطنية:" to data.sellerIdNumber,
                "رقم الهاتف:" to data.sellerPhone
            ),
            leftFields = listOf(
                "المشتري السيد:" to data.buyerName,
                "السكن:" to buyerFullAddress,
                "البطاقة الوطنية:" to data.buyerIdNumber,
                "رقم الهاتف:" to data.buyerPhone
            )
        )

        // ==================== 4. جدول مواصفات الدراجة / المركبة ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "أولاً: باع الطرف الأول إلى الطرف الثاني المركبة المبينة أوصافها أدناه:",
            topY = curY
        )

        curY += 8f
        val gridH = 132f
        val gridRect = RectF(contentLeft, curY, contentRight, curY + gridH)
        val gridOuter = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val gridInner = Paint().apply {
            color = tintColor(primary, 165)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        canvas.drawRect(gridRect, gridOuter)

        val rowH = gridH / 3f
        val colW = gridRect.width() / 3f
        canvas.drawLine(gridRect.left, gridRect.top + rowH, gridRect.right, gridRect.top + rowH, gridInner)
        canvas.drawLine(gridRect.left, gridRect.top + (rowH * 2f), gridRect.right, gridRect.top + (rowH * 2f), gridInner)
        canvas.drawLine(gridRect.right - colW, gridRect.top, gridRect.right - colW, gridRect.top + (rowH * 2f), gridInner)
        canvas.drawLine(gridRect.right - (colW * 2f), gridRect.top, gridRect.right - (colW * 2f), gridRect.bottom, gridInner)

        val c1X = gridRect.right - 10f
        val c2X = gridRect.right - colW - 10f
        val c3X = gridRect.right - (colW * 2f) - 10f
        val cW = colW - 20f

        val r1Y = gridRect.top + 29f
        drawFieldWithDots(canvas, "رقم الدراجة:", data.registeredNumber, c1X, r1Y, cW)
        drawFieldWithDots(canvas, "نوع المركبة:", data.vehicleType, c2X, r1Y, cW)
        drawFieldWithDots(canvas, "الماركة:", data.brand, c3X, r1Y, cW)

        val r2Y = gridRect.top + rowH + 29f
        drawFieldWithDots(canvas, "اللون:", data.color, c1X, r2Y, cW)
        drawFieldWithDots(canvas, "الحجم (CC):", data.engineCc, c2X, r2Y, cW)
        drawFieldWithDots(canvas, "رقم المحرك:", data.engineNumber, c3X, r2Y, cW)

        val r3Y = gridRect.top + (rowH * 2f) + 29f
        drawFieldWithDots(canvas, "رقم الشاصي:", data.chassisNumber, c1X, r3Y, (colW * 2f) - 20f)
        drawFieldWithDots(canvas, "هاتف التواصل:", data.contactPhone, c3X, r3Y, cW)

        curY = gridRect.bottom + 12f

        // ==================== 5. المبالغ المالية ====================
        val fmtTotal = FormatUtils.formatMoneyInput(data.totalPrice)
        val totalDisp = if (fmtTotal.isNotBlank()) "$fmtTotal دينار" else data.totalPrice
        val fmtPaid = FormatUtils.formatMoneyInput(data.paidAmount)
        val paidDisp = if (fmtPaid.isNotBlank()) "$fmtPaid دينار" else data.paidAmount
        val fmtRem = FormatUtils.formatMoneyInput(data.remainingAmount)
        val remDisp = if (fmtRem.isNotBlank()) "$fmtRem دينار" else data.remainingAmount

        curY = drawFinancialSummaryTable(
            canvas = canvas,
            topY = curY,
            items = listOf(
                Triple("مبلغ البيع الكلي (رقماً)", totalDisp, dark),
                Triple("وقد استلم البائع مبلغ قدره", paidDisp, primary),
                Triple("والباقي بذمة المشتري", remDisp, COLOR_RED_ACCENT)
            ),
            wordsRowLabel = "مبلغ البيع الكلي (كتابةً):",
            wordsRowValue = data.totalPriceWords
        )

        // ==================== 6. الشروط القانونية ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "ثانياً: الشروط والأحكام القانونية المتفق عليها",
            topY = curY
        )

        curY += 10f
        val vehicleNoun = getVehicleDefiniteNoun(data.vehicleType)
        val clauses = listOf(
            "ثانياً" to "المباع لا يرجع ولا يبدل بعد توقيع هذا العقد ومعاينة واستلام المركبة أصولياً.",
            "ثالثاً" to "أقر المشتري بشراء $vehicleNoun بعد المعاينة التامة من مالكها الشرعي وتعهد بسداد كامل مستحقاتها.",
            "رابعاً" to "يلتزم الطرفان بتسجيل ونقل ملكية $vehicleNoun حسب القوانين المرورية النافذة، والمعرض غير مسؤول خلاف ذلك.",
            "خامساً" to "الطرف الأول (البائع) مسؤول عن دفع كافة الغرامات المرورية والضرائب المترتبة على $vehicleNoun لغاية تاريخ هذا العقد.",
            "سادساً" to "يعتبر هذا العقد ملغياً بعد تنظيم العقد المروري الأصولي، وأقر الطرفان بصحة العناوين والأرقام المذكورة أعلاه."
        )

        curY = drawIraqiLegalClauses(
            canvas = canvas,
            clauses = clauses,
            startY = curY,
            maxBottomY = footerTopY - 125f
        )

        val dateP = Paint().apply {
            color = primary
            textSize = 16f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        val dateY = (curY + 14f).coerceAtMost(footerTopY - 90f)
        canvas.drawText("حرر بالتراضي بتاريخ: ${data.contractDate}", contentRight, dateY, dateP)

        drawAdditionalNotesBlock(
            canvas = canvas,
            notes = data.notes,
            startY = dateY + 12f
        )

        // ==================== 7. التواقيع والشهود ====================
        val w1 = data.witness1Name.ifBlank { data.witnessName }
        drawIraqiSignaturesFooter(
            canvas = canvas,
            party1Title = "الطرف الأول/البائع",
            party2Title = "الطرف الثاني/المشتري",
            witness1Name = w1,
            witness2Name = data.witness2Name
        )
    }

    companion object {
        fun getVehicleDefiniteNoun(vehicleType: String): String {
            val clean = vehicleType.trim()
            if (clean.isEmpty()) return "المركبة"
            return when {
                clean == "تكتك" -> "التكتك"
                clean == "تك تك" -> "التك تك"
                clean == "ستوتة" || clean == "ستوته" -> "الستوتة"
                clean == "دراجة نارية" || clean == "دراجة" -> "الدراجة"
                clean == "سيارة" -> "السيارة"
                clean.startsWith("ال") -> clean
                else -> "ال$clean"
            }
        }
    }
}
