package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ContractRendererTest {

    private val office = OfficeInfo(
        officeName = "مكتب السلام للعقارات والسيارات",
        phone = "07701234567",
        phone2 = "07809876543",
        licenseNo = "بغداد - 4582",
        address = "بغداد - المنصور - شارع الأميرات"
    )

    @Test
    fun allFourRenderers_produceA4BitmapsWithoutErrors() {
        val context: Context = ApplicationProvider.getApplicationContext()

        val realEstateBmp = RealEstateContractRenderer().renderBitmap(
            RealEstateContract(
                contractNo = "0001",
                sellerName = "علي حسين كريم",
                buyerName = "محمد جاسم عبود",
                totalPrice = "150000000",
                totalPriceWords = "مائة وخمسون مليون دينار عراقي",
                penaltySellerAmount = "25000000",
                penaltyBuyerAmount = "25000000",
                witness1Name = "عبد الرحمن محمد علي جاسم الساعدي",
                witness2Name = "مصطفى عبد الأمير كاظم الحيدري",
                additionalNotes = "يسلم العقار خالياً من الشواغل عند التقدير."
            ),
            office,
            context
        )
        assertNotNull(realEstateBmp)
        assertEquals(1240, realEstateBmp.width)
        assertEquals(1754, realEstateBmp.height)

        val carBmp = CarSaleContractRenderer().renderBitmap(
            CarSaleContract(
                contractNo = "202",
                sellerName = "سعد طارق",
                buyerName = "أحمد فاضل",
                carBrandAndType = "تويوتا لاندكروزر",
                modelYear = "2022",
                totalPrice = "85000000",
                totalPriceWords = "خمسة وثمانون مليون دينار عراقي",
                organizerName = "كريم المندوب",
                notes = "السيارة خالية من الحوادث والصبغ ويتم التحويل خلال أسبوع."
            ),
            office,
            context
        )
        assertNotNull(carBmp)
        assertEquals(1240, carBmp.width)
        assertEquals(1754, carBmp.height)

        val rentalBmp = RentalContractRenderer().renderBitmap(
            RentalContract(
                contractNo = "303",
                lessorName = "حيدر عباس",
                lesseeName = "عمر صباح",
                rentAmountNumber = "750000",
                rentAmountWords = "سبعمائة وخمسون ألف دينار شهرياً",
                additionalClauses = "يلتزم المستأجر بدفع فواتير الكهرباء والماء شهرياً."
            ),
            office,
            context
        )
        assertNotNull(rentalBmp)
        assertEquals(1240, rentalBmp.width)
        assertEquals(1754, rentalBmp.height)

        val motoBmp = MotorcycleContractRenderer().renderBitmap(
            MotorcycleContract(
                contractNo = "404",
                sellerName = "مصطفى رضا",
                buyerName = "زين العابدين",
                vehicleType = "تكتك",
                totalPrice = "4500000",
                totalPriceWords = "أربعة ملايين وخمسمائة ألف دينار",
                notes = "البيع بحالتها الحاضرة مع تسليم كافة الأوليات."
            ),
            office,
            context
        )
        assertNotNull(motoBmp)
        assertEquals(1240, motoBmp.width)
        assertEquals(1754, motoBmp.height)

        assertEquals("0001", RealEstateContract().contractNo)
        assertEquals("0001", CarSaleContract().contractNo)
        assertEquals("0001", RentalContract().contractNo)
        assertEquals("0001", MotorcycleContract().contractNo)
    }
}
