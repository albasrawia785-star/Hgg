package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.HotspotStatus
import com.example.ui.components.*
import com.example.ui.theme.DarkChipBg
import com.example.ui.theme.ElegantLilacPrimary
import com.example.viewmodel.HotspotViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HotspotMainScreen(
    viewModel: HotspotViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hotspotStatus by viewModel.hotspotStatus.collectAsStateWithLifecycle()
    val hotspotInfo by viewModel.hotspotInfo.collectAsStateWithLifecycle()
    val hostedVideo by viewModel.hostedVideo.collectAsStateWithLifecycle()
    val connectedDevices by viewModel.connectedDevices.collectAsStateWithLifecycle()
    val serverLogs by viewModel.serverLogs.collectAsStateWithLifecycle()
    val customSsid by viewModel.customSsid.collectAsStateWithLifecycle()

    var showQrDialog by remember { mutableStateOf(false) }
    var showCaptiveGuide by remember { mutableStateOf(false) }

    // Multi-permission launcher
    val permissionsToRequest = remember {
        mutableListOf<String>().apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.NEARBY_WIFI_DEVICES)
                add(Manifest.permission.READ_MEDIA_VIDEO)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
                add(Manifest.permission.ACCESS_COARSE_LOCATION)
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }.toTypedArray()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        // After permission check, if granted proceed
        val allGranted = results.values.all { it }
        if (allGranted || results.isNotEmpty()) {
            if (hotspotStatus != HotspotStatus.ACTIVE) {
                viewModel.startHotspotAndServer()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(DarkChipBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.WifiTethering,
                                contentDescription = null,
                                tint = ElegantLilacPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "بث الفيديو التلقائي عبر Hotspot",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showQrDialog = true },
                        modifier = Modifier.testTag("top_bar_qr_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = "عرض رمز QR",
                            tint = ElegantLilacPrimary
                        )
                    }
                    IconButton(
                        onClick = { showCaptiveGuide = true },
                        modifier = Modifier.testTag("top_bar_info_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "معلومات التوجيه",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
            .fillMaxSize()
            .testTag("hotspot_main_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Status & Start/Stop Hero Card
            StatusHeroCard(
                status = hotspotStatus,
                info = hotspotInfo,
                onToggleHotspot = {
                    if (hotspotStatus == HotspotStatus.ACTIVE) {
                        viewModel.stopHotspotAndServer()
                    } else {
                        // Check permissions first
                        val hasPermissions = permissionsToRequest.all { perm ->
                            ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
                        }
                        if (hasPermissions) {
                            viewModel.startHotspotAndServer()
                        } else {
                            permissionLauncher.launch(permissionsToRequest)
                        }
                    }
                },
                onStartSystemTethering = {
                    viewModel.startSystemHotspotMode()
                },
                onShowQrClick = { showQrDialog = true }
            )

            // 2. Video Picker & Live Preview Card
            VideoPickerCard(
                video = hostedVideo,
                isServerActive = hotspotStatus == HotspotStatus.ACTIVE,
                serverUrl = hotspotInfo.serverUrl,
                onVideoSelected = { uri -> viewModel.onVideoSelected(uri) }
            )

            // 3. Network Configuration & SSID customization
            NetworkConfigCard(
                currentSsid = customSsid,
                isHotspotActive = hotspotStatus == HotspotStatus.ACTIVE,
                onSsidChange = { newSsid -> viewModel.setCustomSsid(newSsid) },
                onOpenSystemSettings = { viewModel.openTetheringSettings(context) },
                onShowCaptiveGuide = { showCaptiveGuide = true }
            )

            // 4. Connected Devices Card
            ConnectedDevicesCard(
                devices = connectedDevices,
                isHotspotActive = hotspotStatus == HotspotStatus.ACTIVE,
                onRefresh = { viewModel.refreshDevices() }
            )

            // 5. Live Server Logs Card
            LiveLogsCard(
                logs = serverLogs,
                onClearLogs = { viewModel.clearLogs() }
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Dialogs
    if (showQrDialog) {
        QrCodeDialog(
            info = hotspotInfo,
            onDismiss = { showQrDialog = false }
        )
    }

    if (showCaptiveGuide) {
        CaptiveGuideDialog(
            onDismiss = { showCaptiveGuide = false }
        )
    }
}
