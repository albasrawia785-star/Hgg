package com.example.ui.screens.main

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.Operation
import com.example.data.model.OperationType
import com.example.data.repository.DebtRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.Aldion
import com.example.BabyConfig
import kotlinx.coroutines.flow.first

import com.example.data.repository.SettingsRepository

sealed class UiMessage {
    data class ShowToast(val message: String) : UiMessage()
    data class PromptZeroDebtDelete(val customer: Customer) : UiMessage()
    object ShowSubscriptionDialog : UiMessage()
}

class MainViewModel(
    private val repository: DebtRepository,
    private val settingsRepository: SettingsRepository? = null
) : ViewModel() {

    init {
        try {
            viewModelScope.launch {
                try {
                    settingsRepository?.restoreSessionToAldion()
                    repository.startRealtimeSync(viewModelScope)
                    repository.restoreCloudDataIfNeeded()
                } catch (e: Exception) {
                    android.util.Log.e("MainViewModel", "Cloud sync error on launch", e)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("MainViewModel", "Init error", e)
        }
    }

    fun refreshCloudData() {
        viewModelScope.launch {
            try {
                settingsRepository?.restoreSessionToAldion()
                val result = repository.restoreCloudData()
                if (result.isSuccess) {
                    _uiEvent.emit(UiMessage.ShowToast("تم استعادة ومزامنة البيانات السحابية بنجاح ☁️"))
                } else {
                    _uiEvent.emit(UiMessage.ShowToast("تعذر جلب البيانات السحابية: ${result.exceptionOrNull()?.message}"))
                }
            } catch (e: Exception) {
                _uiEvent.emit(UiMessage.ShowToast("حدث خطأ أثناء المزامنة"))
            }
        }
    }

    val isNotificationsEnabled: StateFlow<Boolean> = (settingsRepository?.isNotificationsEnabled ?: MutableStateFlow(true))
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = true
        )

    val highDebtThreshold: StateFlow<Long> = (settingsRepository?.highDebtThreshold ?: MutableStateFlow(100000L))
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = 100000L
        )

    fun toggleNotifications() {
        viewModelScope.launch {
            val currentState = isNotificationsEnabled.value
            val newState = !currentState
            settingsRepository?.saveNotificationsEnabled(newState)
            if (newState) {
                _uiEvent.emit(UiMessage.ShowToast("تم تشغيل الإشعارات والتنبيهات 🔔"))
            } else {
                _uiEvent.emit(UiMessage.ShowToast("تم إيقاف الإشعارات والتنبيهات 🔕"))
            }
        }
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val customers: StateFlow<List<Customer>> = _searchQuery
        .flatMapLatest { query -> repository.searchCustomers(query) }
        .stateIn(
            scope = viewModelScope,
            started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val totalDebt: StateFlow<Long> = repository.totalDebtSum
        .combine(MutableStateFlow(0L)) { sum, _ -> sum ?: 0L }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0L
        )

    val customerCount: StateFlow<Int> = repository.customerCount
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    fun getOperationsForCustomer(customerId: Long) = repository.getOperationsForCustomer(customerId)

    private val _uiEvent = MutableSharedFlow<UiMessage>()
    val uiEvent: SharedFlow<UiMessage> = _uiEvent.asSharedFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addCustomer(
        name: String,
        phone: String?,
        initialDebt: Long,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val currentCount = repository.customerCount.first()
            if (!Aldion.canAddCustomer(currentCount)) {
                val errorMsg = Aldion.SUBSCRIPTION_REQUIRED_MESSAGE
                Log.w("AldionViewModel", ">>> Add customer blocked! User is demo and customer count ($currentCount) >= limit (${Aldion.DEMO_MAX_CUSTOMERS})")
                _uiEvent.emit(UiMessage.ShowSubscriptionDialog)
                onError(errorMsg)
                return@launch
            }

            Log.d("AldionViewModel", ">>> [ViewModel] addCustomer invoked with name: '$name', phone: '$phone', initialDebt: $initialDebt")
            val result = repository.addCustomer(name, phone, initialDebt)
            result.onSuccess {
                Log.d("AldionViewModel", ">>> [ViewModel] addCustomer SUCCESS. Emitting Toast 'تم حفظ المدين بنجاح.'")
                _uiEvent.emit(UiMessage.ShowToast("تم حفظ المدين بنجاح."))
                onSuccess()
            }.onFailure { e ->
                val errorMsg = e.message ?: "حدث خطأ غير معروف أثناء الحفظ"
                Log.e("AldionViewModel", ">>> [ViewModel] addCustomer FAILURE! Error: $errorMsg", e)
                _uiEvent.emit(UiMessage.ShowToast("خطأ: $errorMsg"))
                onError(errorMsg)
            }
        }
    }

    fun updateCustomer(customer: Customer, onSuccess: () -> Unit, onError: ((String) -> Unit)? = null) {
        viewModelScope.launch {
            val result = repository.updateCustomer(customer)
            result.onSuccess {
                _uiEvent.emit(UiMessage.ShowToast("تم تعديل البيانات بنجاح"))
                onSuccess()
            }.onFailure { e ->
                val errorMsg = e.message ?: "حدث خطأ أثناء التعديل"
                _uiEvent.emit(UiMessage.ShowToast(errorMsg))
                onError?.invoke(errorMsg)
            }
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            val result = repository.deleteCustomer(customer)
            result.onSuccess {
                _uiEvent.emit(UiMessage.ShowToast("تم حذف الحساب بنجاح"))
            }.onFailure { e ->
                _uiEvent.emit(UiMessage.ShowToast(e.message ?: "حدث خطأ أثناء الحذف"))
            }
        }
    }

    fun addOperation(
        customerId: Long,
        type: OperationType,
        amount: Long,
        note: String,
        printAfterSave: Boolean = false,
        onSuccess: () -> Unit,
        onError: ((String) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val result = repository.addOperation(customerId, type, amount, note)
            result.onSuccess { opResult ->
                _uiEvent.emit(UiMessage.ShowToast("تمت إضافة البيانات بنجاح"))
                onSuccess()

                if (opResult.isZeroDebtReached) {
                    _uiEvent.emit(UiMessage.PromptZeroDebtDelete(opResult.updatedCustomer))
                }
            }.onFailure { e ->
                val errorMsg = e.message ?: "فشلت العملية"
                _uiEvent.emit(UiMessage.ShowToast(errorMsg))
                onError?.invoke(errorMsg)
            }
        }
    }

    class Factory(
        private val repository: DebtRepository,
        private val settingsRepository: SettingsRepository? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(repository, settingsRepository) as T
        }
    }
}

