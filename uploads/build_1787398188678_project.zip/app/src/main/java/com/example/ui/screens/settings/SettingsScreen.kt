package com.example.ui.screens.settings

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.Whatsapp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.Aldion
import com.example.ConnectionTestResult
import com.example.data.model.Manager
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.SurfaceLight
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import java.net.URLEncoder
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onOpenOnboarding: () -> Unit = {},
    onLogout: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val coroutineScope = rememberCoroutineScope()
    val overdueDaysThreshold by viewModel.overdueDaysThreshold.collectAsStateWithLifecycle()
    val highDebtThreshold by viewModel.highDebtThreshold.collectAsStateWithLifecycle()
    val managers by viewModel.managers.collectAsStateWithLifecycle()
    val isTestingConnection by viewModel.isTestingConnection.collectAsStateWithLifecycle()
    val connectionTestResult by viewModel.connectionTestResult.collectAsStateWithLifecycle()

    var showEditThresholdDialog by remember { mutableStateOf(false) }
    var showEditHighDebtDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }

    var showDbConfigFields by remember { mutableStateOf(false) }
    var projectIdInput by remember { mutableStateOf(Aldion.FIREBASE_PROJECT_ID) }
    var apiKeyInput by remember { mutableStateOf(Aldion.FIREBASE_API_KEY) }
    var appIdInput by remember { mutableStateOf(Aldion.FIREBASE_APP_ID) }

    var showAddManagerDialog by remember { mutableStateOf(false) }
    var editingManager by remember { mutableStateOf<Manager?>(null) }
    var passwordManager by remember { mutableStateOf<Manager?>(null) }
    var deletingManager by remember { mutableStateOf<Manager?>(null) }

    val isSuper = Aldion.isSuperAdminUser() || Aldion.isSuperAdmin

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = Color(0xFFF6F8FA),
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // شريط العنوان العلوي
            item {
                Column(modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)) {
                    Text(
                        text = "الإعدادات",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryDark,
                            fontSize = 24.sp
                        )
                    )
                    Text(
                        text = "تخصيص النظام، التنبيهات، والأمان",
                        fontSize = 13.sp,
                        color = TextSecondaryDark
                    )
                }
            }

            // بطاقة الملف الشخصي وحالة الحساب الحديثة (Profile Header Card)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (isSuper) RoyalBlue.copy(alpha = 0.12f)
                                    else Color(0xFF0284C7).copy(alpha = 0.12f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isSuper) Icons.Default.Shield else Icons.Default.Store,
                                contentDescription = null,
                                tint = if (isSuper) RoyalBlue else Color(0xFF0284C7),
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = Aldion.currentLoggedInUser.ifBlank { Aldion.USERNAME },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = TextPrimaryDark
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSuper) RoyalBlue else Color(0xFF0284C7))
                                        .padding(horizontal = 7.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (isSuper) "المدير العام" else "مدير فرع",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(
                                text = Aldion.SHOP_NAME.ifBlank { "المحل التجاري" },
                                fontSize = 13.sp,
                                color = TextSecondaryDark
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(EmeraldGreen)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "الحفظ السحابي متصل ونشط",
                                    fontSize = 11.sp,
                                    color = EmeraldGreen,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // المجموعة 1: قواعد الديون والتنبيهات (Debt Rules & Limits)
            // =========================================================================
            item {
                SettingsSectionHeader(title = "قواعد الديون والتنبيهات")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // إعداد مدة التأخر
                        ModernSettingItem(
                            icon = Icons.Default.HourglassTop,
                            iconTint = Color(0xFFD97706),
                            iconBg = Color(0xFFFEF3C7),
                            title = "فترة اعتبار المدين متأخراً",
                            subtitle = "يعتبر المدين متأخراً بعد $overdueDaysThreshold يوماً من آخر دين",
                            trailingText = "$overdueDaysThreshold يوم",
                            onClick = { showEditThresholdDialog = true }
                        )

                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = Color(0xFFF1F5F9),
                            thickness = 1.dp
                        )

                        // إعداد حد الديون المرتفعة
                        val formattedHighDebt = remember(highDebtThreshold) {
                            NumberFormat.getNumberInstance(Locale.US).format(highDebtThreshold)
                        }
                        ModernSettingItem(
                            icon = Icons.Default.WarningAmber,
                            iconTint = CrimsonRed,
                            iconBg = CrimsonRed.copy(alpha = 0.12f),
                            title = "حد الديون المرتفعة",
                            subtitle = "تنبيه وتصنيف الديون التي تساوي أو تتجاوز هذا الحد",
                            trailingText = "$formattedHighDebt د.ع",
                            onClick = { showEditHighDebtDialog = true }
                        )
                    }
                }
            }

            // =========================================================================
            // المجموعة 2: إدارة المدراء والنظام (خاص بالمدير العام فقط)
            // =========================================================================
            if (isSuper) {
                item {
                    SettingsSectionHeader(title = "إدارة المدراء والفروع")
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(RoyalBlue.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AdminPanelSettings,
                                            contentDescription = null,
                                            tint = RoyalBlue,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "قائمة مدراء النظام",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = TextPrimaryDark
                                        )
                                        Text(
                                            text = "${managers.size} مدراء مسجلين",
                                            fontSize = 12.sp,
                                            color = TextSecondaryDark
                                        )
                                    }
                                }

                                Button(
                                    onClick = { showAddManagerDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.height(36.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PersonAdd,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إضافة مدير", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            if (managers.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFFF8FAFC))
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "لا يوجد مدراء إضافيون. اضغط \"إضافة مدير\" لإنشاء حساب جديد.",
                                        fontSize = 12.sp,
                                        color = TextSecondaryDark
                                    )
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    managers.forEach { mgr ->
                                        ManagerCardItem(
                                            manager = mgr,
                                            onEdit = { editingManager = mgr },
                                            onChangePassword = { passwordManager = mgr },
                                            onToggleStatus = { viewModel.toggleManagerStatus(mgr) },
                                            onDelete = { deletingManager = mgr }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // المجموعة 3: السحابة وقاعدة البيانات (خاص بالمدير العام)
            // =========================================================================
            if (isSuper) {
                item {
                    SettingsSectionHeader(title = "قاعدة البيانات والسحابة")
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF7C3AED).copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Dns,
                                            contentDescription = null,
                                            tint = Color(0xFF7C3AED),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "خادم Firebase Firestore",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = TextPrimaryDark
                                        )
                                        Text(
                                            text = "المشروع: ${Aldion.FIREBASE_PROJECT_ID}",
                                            fontSize = 11.sp,
                                            color = TextSecondaryDark
                                        )
                                    }
                                }

                                TextButton(
                                    onClick = { showDbConfigFields = !showDbConfigFields },
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = if (showDbConfigFields) "إخفاء" else "تعديل",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalBlue
                                    )
                                }
                            }

                            // تفاصيل تعديل الاتصال
                            AnimatedVisibility(visible = showDbConfigFields) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = projectIdInput,
                                        onValueChange = { projectIdInput = it },
                                        label = { Text("معرف المشروع (Project ID)", fontSize = 12.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = RoyalBlue,
                                            unfocusedBorderColor = BorderLight
                                        )
                                    )

                                    OutlinedTextField(
                                        value = apiKeyInput,
                                        onValueChange = { apiKeyInput = it },
                                        label = { Text("مفتاح API Key", fontSize = 12.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = RoyalBlue,
                                            unfocusedBorderColor = BorderLight
                                        )
                                    )

                                    OutlinedTextField(
                                        value = appIdInput,
                                        onValueChange = { appIdInput = it },
                                        label = { Text("معرف التطبيق App ID", fontSize = 12.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = RoyalBlue,
                                            unfocusedBorderColor = BorderLight
                                        )
                                    )

                                    Button(
                                        onClick = {
                                            focusManager.clearFocus()
                                            keyboardController?.hide()
                                            viewModel.applyFirebaseConfig(
                                                context = context,
                                                projectId = projectIdInput,
                                                apiKey = apiKeyInput,
                                                appId = appIdInput,
                                                onComplete = {
                                                    viewModel.testFirebaseConnection(projectIdInput, apiKeyInput, appIdInput)
                                                }
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(40.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("حفظ وتطبيق القاعدة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // زر فحص الاتصال
                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    keyboardController?.hide()
                                    val testProj = if (showDbConfigFields) projectIdInput else null
                                    val testKey = if (showDbConfigFields) apiKeyInput else null
                                    val testApp = if (showDbConfigFields) appIdInput else null
                                    viewModel.testFirebaseConnection(testProj, testKey, testApp)
                                },
                                enabled = !isTestingConnection,
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                            ) {
                                if (isTestingConnection) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        color = Color.White,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("جاري فحص الاتصال...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(imageVector = Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("فحص الاتصال بقاعدة البيانات", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // نتيجة فحص الاتصال
                            connectionTestResult?.let { result ->
                                Spacer(modifier = Modifier.height(10.dp))
                                when (result) {
                                    is ConnectionTestResult.Success -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(EmeraldGreen.copy(alpha = 0.1f))
                                                .border(1.dp, EmeraldGreen.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                                .padding(10.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = EmeraldGreen,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text("الاتصال ناجح ومستقر ✅", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EmeraldGreen)
                                                    Text(result.message, fontSize = 11.sp, color = TextPrimaryDark)
                                                }
                                            }
                                        }
                                    }
                                    is ConnectionTestResult.Error -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(CrimsonRed.copy(alpha = 0.08f))
                                                .border(1.dp, CrimsonRed.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                                .padding(10.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.ErrorOutline,
                                                    contentDescription = null,
                                                    tint = CrimsonRed,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text(result.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CrimsonRed)
                                                    Text(result.message, fontSize = 11.sp, color = TextPrimaryDark)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // المجموعة 4: حول التطبيق والدعم الفني (About & Support)
            // =========================================================================
            item {
                SettingsSectionHeader(title = "المساعدة وحول التطبيق")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // تواصل مع الدعم الفني
                        ModernSettingItem(
                            icon = Icons.Default.SupportAgent,
                            iconTint = Color(0xFF16A34A),
                            iconBg = Color(0xFFDCFCE7),
                            title = "تواصل مع الدعم الفني",
                            subtitle = "محادثة فورية عبر واتساب للمساعدة والاستفسارات",
                            trailingIcon = Icons.Default.ChevronLeft,
                            onClick = {
                                val phoneNumber = "9647810936407"
                                val message = "السلام عليكم، أحتاج مساعدة أو استفسار بخصوص تطبيق إدارة الديون"
                                try {
                                    val encodedMsg = URLEncoder.encode(message, "UTF-8")
                                    val uri = Uri.parse("https://wa.me/$phoneNumber?text=$encodedMsg")
                                    val intent = Intent(Intent.ACTION_VIEW, uri)
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(
                                        context,
                                        "تعذر فتح تطبيق واتساب، يرجى التأكد من تثبيته على الهاتف",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        )

                        HorizontalDivider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = Color(0xFFF1F5F9),
                            thickness = 1.dp
                        )

                        // حول التطبيق
                        ModernSettingItem(
                            icon = Icons.Default.Info,
                            iconTint = RoyalBlue,
                            iconBg = RoyalBlue.copy(alpha = 0.12f),
                            title = "حول التطبيق والمميزات",
                            subtitle = "الإصدار 1.0.0 • نظام إدارة الديون والحسابات",
                            trailingIcon = Icons.Default.ChevronLeft,
                            onClick = { showAboutDialog = true }
                        )
                    }
                }
            }

            // =========================================================================
            // المجموعة 5: إدارة الجلسة (Logout)
            // =========================================================================
            item {
                SettingsSectionHeader(title = "الحساب والجلسة")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    ModernSettingItem(
                        icon = Icons.Default.ExitToApp,
                        iconTint = CrimsonRed,
                        iconBg = CrimsonRed.copy(alpha = 0.12f),
                        title = "تسجيل الخروج",
                        subtitle = "تسجيل الخروج من الحساب الحالي (${Aldion.currentLoggedInUser})",
                        titleColor = CrimsonRed,
                        trailingIcon = Icons.Default.ChevronLeft,
                        onClick = { showLogoutConfirmDialog = true }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }

    // =========================================================================
    // Dialogs & Sheets
    // =========================================================================

    // نافذة تعديل مدة التأخير
    if (showEditThresholdDialog) {
        var tempDays by remember { mutableStateOf(overdueDaysThreshold.toString()) }
        AlertDialog(
            onDismissRequest = { showEditThresholdDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.HourglassTop, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("مدة اعتبار المدين متأخراً", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "اختر أو اكتب عدد الأيام بعد تاريخ آخر دين ليتم تصنيف الزبون ضمن قائمة المتأخرين:",
                        fontSize = 13.sp,
                        color = TextSecondaryDark,
                        lineHeight = 18.sp
                    )

                    // أزرار سريعة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(15, 30, 45, 60).forEach { days ->
                            val isSelected = tempDays == days.toString()
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) RoyalBlue else Color(0xFFF1F5F9))
                                    .clickable { tempDays = days.toString() }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$days يوم",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else TextPrimaryDark
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = tempDays,
                        onValueChange = { input -> if (input.all { it.isDigit() }) tempDays = input },
                        label = { Text("عدد الأيام مخصص") },
                        suffix = { Text("يوم") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val days = tempDays.toIntOrNull() ?: 30
                        viewModel.updateOverdueDaysThreshold(days)
                        showEditThresholdDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("حفظ التغيير", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditThresholdDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة تعديل حد الديون المرتفعة
    if (showEditHighDebtDialog) {
        var tempAmount by remember { mutableStateOf(highDebtThreshold.toString()) }
        AlertDialog(
            onDismissRequest = { showEditHighDebtDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CrimsonRed.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("حد الديون المرتفعة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "اختر أو اكتب المبلغ الذي يعتبر ما يساويه أو يتجاوزه من الديون المرتفعة للتنبيه والفلترة:",
                        fontSize = 13.sp,
                        color = TextSecondaryDark,
                        lineHeight = 18.sp
                    )

                    // أزرار سريعة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(50000L, 100000L, 250000L, 500000L).forEach { amount ->
                            val isSelected = tempAmount == amount.toString()
                            val label = "${amount / 1000} ألف"
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) RoyalBlue else Color(0xFFF1F5F9))
                                    .clickable { tempAmount = amount.toString() }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else TextPrimaryDark
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = tempAmount,
                        onValueChange = { input -> if (input.all { it.isDigit() }) tempAmount = input },
                        label = { Text("المبلغ بالدينار العراقي") },
                        suffix = { Text("د.ع") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = tempAmount.toLongOrNull() ?: 100000L
                        viewModel.updateHighDebtThreshold(amount)
                        showEditHighDebtDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("حفظ الحد", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditHighDebtDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة حول التطبيق
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حول النظام", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(RoyalBlue.copy(alpha = 0.1f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("الإصدار 1.0.0", color = RoyalBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "نظام متقدم وشامل لإدارة ديون وحسابات الزبائن والمدفوعات المالية للأنشطة التجارية والمحلات، مصمم لتقديم تجربة سريعة، آمنة، ومنظمة بأعلى معايير الدقة والسهولة.",
                        fontSize = 13.sp,
                        color = TextSecondaryDark,
                        lineHeight = 19.sp
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF8FAFC))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("✨ أهم مميزات النظام:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimaryDark)
                            Text("• إدارة دقيقة للديون والمدفوعات والمتبقي مع كشوفات حساب تفصيلية.", fontSize = 12.sp, color = TextSecondaryDark)
                            Text("• نظام مدراء مستقل مع عزل كامل للبيانات لكل مدير ومحل.", fontSize = 12.sp, color = TextSecondaryDark)
                            Text("• حفظ ومزامنة سحابية فورية (Firebase) تضمن بقاء بياناتك بأمان.", fontSize = 12.sp, color = TextSecondaryDark)
                            Text("• كشف المتأخرين عن السداد والديون المرتفعة مع تنبيهات ذكية.", fontSize = 12.sp, color = TextSecondaryDark)
                            Text("• إرسال كشوفات الحساب وتذكيرات السداد للزبائن عبر واتساب.", fontSize = 12.sp, color = TextSecondaryDark)
                            Text("• العمل دون اتصال بالإنترنت (Offline) مع مزامنة تلقائية.", fontSize = 12.sp, color = TextSecondaryDark)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAboutDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إغلاق", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // تأكيد تسجيل الخروج
    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = { Text("تسجيل الخروج", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من رغبتك في تسجيل الخروج من الحساب الحالي؟") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirmDialog = false
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("تسجيل الخروج", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Dialogs لإدارة المدراء
    if (showAddManagerDialog) {
        AddManagerDialog(
            onDismiss = { showAddManagerDialog = false },
            onConfirm = { shopName, managerName, username, pass, phone, status ->
                viewModel.addManager(
                    shopName = shopName,
                    managerName = managerName,
                    username = username,
                    password = pass,
                    phone = phone,
                    status = status,
                    onSuccess = { showAddManagerDialog = false },
                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                )
            }
        )
    }

    editingManager?.let { mgr ->
        EditManagerDialog(
            manager = mgr,
            onDismiss = { editingManager = null },
            onConfirm = { shopName, username, phone, status, role ->
                viewModel.updateManager(
                    managerId = mgr.managerId,
                    shopName = shopName,
                    username = username,
                    phone = phone,
                    status = status,
                    role = role,
                    onSuccess = { editingManager = null },
                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                )
            }
        )
    }

    passwordManager?.let { mgr ->
        ChangePasswordDialog(
            manager = mgr,
            onDismiss = { passwordManager = null },
            onConfirm = { newPass ->
                viewModel.changePassword(
                    managerId = mgr.managerId,
                    newPass = newPass,
                    onSuccess = { passwordManager = null },
                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                )
            }
        )
    }

    deletingManager?.let { mgr ->
        AlertDialog(
            onDismissRequest = { deletingManager = null },
            title = { Text("حذف المدير", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من رغبتك في حذف المدير \"${mgr.username}\" (${mgr.shopName})؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteManager(
                            managerId = mgr.managerId,
                            onSuccess = { deletingManager = null },
                            onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("تأكيد الحذف", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingManager = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

/**
 * عنوان القسم في الإعدادات (iOS/M3 Group Header)
 */
@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.Bold,
            color = TextSecondaryDark,
            fontSize = 13.sp
        ),
        modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 2.dp)
    )
}

/**
 * عنصر إعداد حديث مجمع (Modern Setting List Tile)
 */
@Composable
fun ModernSettingItem(
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    title: String,
    subtitle: String,
    titleColor: Color = TextPrimaryDark,
    trailingText: String? = null,
    trailingIcon: ImageVector? = Icons.Default.ChevronLeft,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = titleColor
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = TextSecondaryDark,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (trailingText != null) {
                Text(
                    text = trailingText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = RoyalBlue
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            if (trailingIcon != null) {
                Icon(
                    imageVector = trailingIcon,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun ManagerCardItem(
    manager: Manager,
    onEdit: () -> Unit,
    onChangePassword: () -> Unit,
    onToggleStatus: () -> Unit,
    onDelete: () -> Unit
) {
    val isActive = manager.isActive()
    val isSuper = manager.isSuperAdmin()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFF8FAFC))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isSuper) RoyalBlue.copy(alpha = 0.12f) else Color(0xFFE2E8F0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = if (isSuper) RoyalBlue else Color(0xFF64748B),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = manager.username,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSuper) RoyalBlue else Color(0xFF64748B))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isSuper) "مدير عام" else "مدير",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Store, contentDescription = null, tint = TextSecondaryDark, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = manager.shopName, fontSize = 11.sp, color = TextSecondaryDark)
                            if (manager.phone.isNotBlank()) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = TextSecondaryDark, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(text = manager.phone, fontSize = 11.sp, color = TextSecondaryDark)
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isActive) EmeraldGreen.copy(alpha = 0.12f) else CrimsonRed.copy(alpha = 0.12f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isActive) "نشط" else "معطل",
                        color = if (isActive) EmeraldGreen else CrimsonRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(34.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تعديل", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = onChangePassword,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1.2f).height(34.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("كلمة المرور", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = onToggleStatus,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(34.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (isActive) CrimsonRed else EmeraldGreen
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) {
                    Icon(
                        imageVector = if (isActive) Icons.Default.Block else Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isActive) "تعطيل" else "تفعيل", fontSize = 11.sp)
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = CrimsonRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddManagerDialog(
    onDismiss: () -> Unit,
    onConfirm: (shopName: String, managerName: String, username: String, pass: String, phone: String, status: String) -> Unit
) {
    var shopName by remember { mutableStateOf("") }
    var managerName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var isActive by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مدير جديد", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMsg != null) {
                    Text(errorMsg!!, color = CrimsonRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it },
                    label = { Text("اسم المحل *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = managerName,
                    onValueChange = { managerName = it },
                    label = { Text("اسم المدير *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("اسم المستخدم *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("كلمة المرور *") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("تأكيد كلمة المرور *") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الهاتف") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حالة الحساب:", fontWeight = FontWeight.Medium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (isActive) "نشط" else "معطل", color = if (isActive) EmeraldGreen else CrimsonRed, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Switch(checked = isActive, onCheckedChange = { isActive = it })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (shopName.isBlank() || managerName.isBlank() || username.isBlank() || password.isBlank()) {
                        errorMsg = "يرجى ملء جميع الحقول المطلوبة (*)"
                        return@Button
                    }
                    if (password != confirmPassword) {
                        errorMsg = "كلمة المرور وتأكيدها غير متطابقين"
                        return@Button
                    }
                    val status = if (isActive) "ACTIVE" else "DISABLED"
                    onConfirm(shopName, managerName, username, password, phone, status)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("تسجيل المدير", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun EditManagerDialog(
    manager: Manager,
    onDismiss: () -> Unit,
    onConfirm: (shopName: String, username: String, phone: String, status: String, role: String) -> Unit
) {
    var shopName by remember { mutableStateOf(manager.shopName) }
    var username by remember { mutableStateOf(manager.username) }
    var phone by remember { mutableStateOf(manager.phone) }
    var isActive by remember { mutableStateOf(manager.isActive()) }
    var isSuperAdmin by remember { mutableStateOf(manager.isSuperAdmin()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل بيانات المدير", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMsg != null) {
                    Text(errorMsg!!, color = CrimsonRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it },
                    label = { Text("اسم المحل") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("اسم المستخدم") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الهاتف") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حالة الحساب:", fontWeight = FontWeight.Medium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (isActive) "نشط" else "معطل", color = if (isActive) EmeraldGreen else CrimsonRed, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Switch(checked = isActive, onCheckedChange = { isActive = it })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (shopName.isBlank() || username.isBlank()) {
                        errorMsg = "اسم المحل واسم المستخدم لا يمكن أن يكونا فارغين"
                        return@Button
                    }
                    val status = if (isActive) "ACTIVE" else "DISABLED"
                    val role = if (isSuperAdmin) "SUPER_ADMIN" else "ADMIN"
                    onConfirm(shopName, username, phone, status, role)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("حفظ التعديلات", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun ChangePasswordDialog(
    manager: Manager,
    onDismiss: () -> Unit,
    onConfirm: (newPass: String) -> Unit
) {
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تغيير كلمة المرور لـ ${manager.username}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (errorMsg != null) {
                    Text(errorMsg!!, color = CrimsonRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("كلمة المرور الجديدة") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("تأكيد كلمة المرور") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPassword.isBlank()) {
                        errorMsg = "يرجى إدخال كلمة المرور"
                        return@Button
                    }
                    if (newPassword != confirmPassword) {
                        errorMsg = "كلمة المرور وتأكيدها غير متطابقين"
                        return@Button
                    }
                    onConfirm(newPassword)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("تحديث كلمة المرور", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
