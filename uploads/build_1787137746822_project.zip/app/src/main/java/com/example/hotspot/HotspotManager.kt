package com.example.hotspot

import android.content.Context
import android.content.Intent
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import com.example.model.ConnectedDevice
import com.example.model.HotspotInfo
import com.example.model.HotspotStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.FileReader
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

class HotspotManager(
    private val context: Context,
    private val onStatusChange: (HotspotStatus, HotspotInfo) -> Unit
) {

    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var currentInfo = HotspotInfo()

    fun isHotspotRunning(): Boolean = reservation != null

    fun startHotspot(customSsid: String = "VideoPortal_Wifi", customPassword: String? = null) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            onStatusChange(
                HotspotStatus.ERROR,
                currentInfo.copy(errorMessage = "يتطلب تشغيل نقطة الاتصال نظام Android 8.0 (API 26) أو أحدث.")
            )
            return
        }

        onStatusChange(HotspotStatus.STARTING, currentInfo)

        try {
            val isSecOpen = customPassword.isNullOrEmpty()
            val fixedPassword = if (isSecOpen) null else (customPassword ?: "00000000")
            val targetSsid = customSsid.ifBlank { "VideoPortal_Wifi" }

            // Android 8.0+ standard startLocalOnlyHotspot
            wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation?) {
                    super.onStarted(res)
                    reservation = res
                    if (res != null) {
                        var actualSsid = targetSsid
                        var actualPassword: String? = fixedPassword

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            val config = res.softApConfiguration
                            if (config != null) {
                                actualSsid = config.ssid ?: targetSsid
                                actualPassword = config.passphrase ?: fixedPassword
                            }
                        } else {
                            @Suppress("DEPRECATION")
                            val config: WifiConfiguration? = res.wifiConfiguration
                            if (config != null) {
                                actualSsid = config.SSID ?: targetSsid
                                actualPassword = config.preSharedKey ?: fixedPassword
                            }
                        }

                        // Use user configured unified password if provided
                        val effectivePassword = fixedPassword ?: actualPassword
                        val secOpen = effectivePassword.isNullOrEmpty()
                        val localIp = getLocalIpAddress()
                        currentInfo = HotspotInfo(
                            ssid = actualSsid,
                            password = effectivePassword,
                            isSecurityOpen = secOpen,
                            ipAddress = localIp,
                            port = 8080,
                            isTetheringMode = false,
                            errorMessage = null
                        )
                        onStatusChange(HotspotStatus.ACTIVE, currentInfo)
                    }
                }

                override fun onStopped() {
                    super.onStopped()
                    reservation = null
                    onStatusChange(HotspotStatus.STOPPED, currentInfo)
                }

                override fun onFailed(reason: Int) {
                    super.onFailed(reason)
                    reservation = null
                    val errorMsg = when (reason) {
                        ERROR_NO_CHANNEL -> "لا توجد قنوات Wi-Fi متاحة حالياً. يرجى إيقاف Wi-Fi وتشغيله مجدداً."
                        ERROR_GENERIC -> "تعذر بدء نقطة الاتصال تلقائياً. تأكد من تفعيل Wi-Fi في هاتفك."
                        ERROR_INCOMPATIBLE_MODE -> "نظام الهاتف يتطلب ضبط نقطة الاتصال عبر إعدادات النظام."
                        ERROR_TETHERING_DISALLOWED -> "مشاركة الشبكة مقيدة في إعدادات النظام."
                        else -> "فشل بدء نقطة الاتصال (كود: $reason)."
                    }
                    onStatusChange(
                        HotspotStatus.ERROR,
                        currentInfo.copy(errorMessage = errorMsg)
                    )
                }
            }, null)
        } catch (e: SecurityException) {
            e.printStackTrace()
            onStatusChange(
                HotspotStatus.ERROR,
                currentInfo.copy(errorMessage = "يرجى منح أذونات Wi-Fi والموقع لتشغيل نقطة الاتصال: ${e.message}")
            )
        } catch (e: Exception) {
            e.printStackTrace()
            onStatusChange(
                HotspotStatus.ERROR,
                currentInfo.copy(errorMessage = "حدث خطأ أثناء تشغيل نقطة الاتصال: ${e.message}")
            )
        }
    }

    fun stopHotspot() {
        try {
            reservation?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        reservation = null
        onStatusChange(HotspotStatus.STOPPED, currentInfo)
    }

    fun updateToSystemTethering(customSsid: String) {
        val localIp = getLocalIpAddress()
        currentInfo = HotspotInfo(
            ssid = customSsid,
            password = null,
            isSecurityOpen = true,
            ipAddress = localIp,
            port = 8080,
            isTetheringMode = true
        )
        onStatusChange(HotspotStatus.ACTIVE, currentInfo)
    }

    fun openSystemTetheringSettings(context: Context) {
        val intents = arrayOf(
            Intent().setComponent(
                android.content.ComponentName(
                    "com.android.settings",
                    "com.android.settings.TetherSettings"
                )
            ),
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
            Intent("android.settings.TETHER_SETTINGS"),
            Intent(Settings.ACTION_WIFI_SETTINGS)
        )

        for (intent in intents) {
            try {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                return
            } catch (e: Exception) {
                // Try next intent
            }
        }
    }

    fun getLocalIpAddress(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            // Priority 1: AP interface (ap0, wlan1, swlan0, rndis)
            for (intf in interfaces) {
                val name = intf.name.lowercase()
                if (name.contains("ap") || name.contains("swlan") || name.contains("wlan1") || name.contains("tether")) {
                    for (addr in Collections.list(intf.inetAddresses)) {
                        if (!addr.isLoopbackAddress && addr is Inet4Address) {
                            return addr.hostAddress ?: "192.168.49.1"
                        }
                    }
                }
            }

            // Priority 2: Any wlan interface
            for (intf in interfaces) {
                val name = intf.name.lowercase()
                if (name.startsWith("wlan")) {
                    for (addr in Collections.list(intf.inetAddresses)) {
                        if (!addr.isLoopbackAddress && addr is Inet4Address) {
                            return addr.hostAddress ?: "192.168.43.1"
                        }
                    }
                }
            }

            // Priority 3: Any non-loopback IPv4
            for (intf in interfaces) {
                for (addr in Collections.list(intf.inetAddresses)) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val host = addr.hostAddress
                        if (host != null && host.startsWith("192.168.")) {
                            return host
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "192.168.49.1"
    }

    suspend fun scanConnectedDevices(): List<ConnectedDevice> = withContext(Dispatchers.IO) {
        val devices = mutableListOf<ConnectedDevice>()
        val localIp = getLocalIpAddress()
        val subnetPrefix = localIp.substringBeforeLast(".")

        // 1. Read real-time ARP table from /proc/net/arp
        try {
            val arpEntries = mutableMapOf<String, String>()
            BufferedReader(FileReader("/proc/net/arp")).use { reader ->
                var line: String? = reader.readLine() // Skip header
                while (reader.readLine().also { line = it } != null) {
                    val tokens = line?.split("\\s+".toRegex()) ?: continue
                    if (tokens.size >= 4) {
                        val ip = tokens[0]
                        val flags = tokens[2]
                        val mac = tokens[3]
                        // flags 0x2 means valid/reachable active entry
                        if (flags != "0x0" && mac != "00:00:00:00:00:00" && ip != localIp && ip.startsWith(subnetPrefix)) {
                            arpEntries[ip] = mac.uppercase()
                        }
                    }
                }
            }

            arpEntries.forEach { (ip, mac) ->
                devices.add(
                    ConnectedDevice(
                        ipAddress = ip,
                        macAddress = mac,
                        deviceName = "جهاز متصل (${ip.substringAfterLast(".")})"
                    )
                )
            }
        } catch (e: Exception) {
            // Handled gracefully if restricted by SELinux
        }

        // 2. Active subnet probe and ICMP/Socket check to update ARP table in real-time
        try {
            val knownIps = devices.map { it.ipAddress }.toSet()
            for (i in 2..35) {
                val targetIp = "$subnetPrefix.$i"
                if (targetIp == localIp || knownIps.contains(targetIp)) continue
                try {
                    val addr = InetAddress.getByName(targetIp)
                    if (addr.isReachable(60)) {
                        devices.add(
                            ConnectedDevice(
                                ipAddress = targetIp,
                                macAddress = "IP-ONLINE",
                                deviceName = "جهاز نشط (.$i)"
                            )
                        )
                    }
                } catch (e: Exception) {}
            }
        } catch (e: Exception) {}

        // 3. Fallback to WifiManager scan results if Wi-Fi client scanning is enabled
        try {
            val scanResults = wifiManager.scanResults
            if (scanResults != null && devices.isEmpty()) {
                // WifiManager reports AP presence or nearby hotspots
            }
        } catch (e: SecurityException) {
            // Handled
        }

        devices
    }
}
