package com.example.data.repository

import android.util.Log
import androidx.room.withTransaction
import com.example.Aldion
import com.example.AldionFirebaseManager
import com.example.data.local.AppDatabase
import com.example.data.model.Customer
import com.example.data.model.Operation
import com.example.data.model.OperationType
import com.example.data.model.OperationWithCustomer
import com.example.util.formatCurrency
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

data class AddOperationResult(
    val operationId: Long,
    val isZeroDebtReached: Boolean,
    val updatedCustomer: Customer,
    val operation: Operation
)

class DebtRepository(
    private val database: AppDatabase,
    val firebaseManager: AldionFirebaseManager = AldionFirebaseManager()
) {
    fun isNetworkAvailable(): Boolean = firebaseManager.isNetworkAvailable()
    private val customerDao = database.customerDao()
    private val operationDao = database.operationDao()

    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    val totalDebtSum: Flow<Long?> = customerDao.getTotalDebtSum()
    val customerCount: Flow<Int> = customerDao.getCustomerCount()
    val totalDebtAddedSum: Flow<Long?> = operationDao.getTotalDebtAddedSum()
    val totalPaymentsSum: Flow<Long?> = operationDao.getTotalPaymentsSum()
    val allOperationsWithCustomer: Flow<List<OperationWithCustomer>> = operationDao.getAllOperationsWithCustomer()

    fun getOperationsForCustomer(customerId: Long): Flow<List<Operation>> {
        return operationDao.getOperationsForCustomer(customerId)
    }

    fun searchCustomers(query: String): Flow<List<Customer>> {
        return if (query.isBlank()) {
            customerDao.getAllCustomers()
        } else {
            customerDao.searchCustomersByName(query.trim())
        }
    }

    suspend fun getCustomerById(id: Long): Customer? = customerDao.getCustomerById(id)

    /**
     * بدء الاستماع المباشر للتغيرات السحابية ومراقبة صلاحية الجلسة
     */
    fun startRealtimeSync(
        scope: kotlinx.coroutines.CoroutineScope,
        onSessionRevoked: ((String) -> Unit)? = null
    ) {
        firebaseManager.setupRealtimeListeners(customerDao, operationDao, scope)
        if (!Aldion.isSuperAdminUser() && !Aldion.isDemoAccount) {
            firebaseManager.setupManagerSessionWatcher(Aldion.currentManagerId) { reason ->
                scope.launch {
                    clearLocalData()
                    onSessionRevoked?.invoke(reason)
                }
            }
        }
    }

    /**
     * مزامنة البيانات السحابية تلقائياً في الخلفية
     */
    suspend fun syncWithCloud() {
        try {
            firebaseManager.syncUnsyncedData(customerDao, operationDao)
        } catch (e: Exception) {
            // Offline or network error handled gracefully
        }
    }

    /**
     * استعادة البيانات السحابية عند الحاجة فقط (إذا كانت قاعدة البيانات المحلية فارغة)
     * لتوفير حصة القراءة في الخطة المجانية لفايربيس
     */
    suspend fun restoreCloudDataIfNeeded(): Result<Unit> {
        return try {
            val count = customerDao.getDirectCustomerCount()
            if (count == 0) {
                // قاعدة البيانات المحلية فارغة تماماً (تثبيت جديد أو تسجيل دخول جديد) -> نجلب من السحابة
                firebaseManager.restoreFromCloud(customerDao, operationDao)
            } else {
                // البيانات موجودة محلياً -> نكتفي بمزامنة العمليات غير المتزامنة دون استهلاك قراءات السحابة
                firebaseManager.syncUnsyncedData(customerDao, operationDao)
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * استعادة البيانات السحابية عند تسجيل الدخول أو التطبيق الجديد
     */
    suspend fun restoreCloudData(): Result<Unit> {
        return try {
            firebaseManager.restoreFromCloud(customerDao, operationDao)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * مسح البيانات المحلية بالكامل عند تسجيل الخروج أو تبديل الحساب
     */
    suspend fun clearLocalData() {
        try {
            firebaseManager.removeRealtimeListeners()
            customerDao.clearAllCustomers()
            operationDao.clearAllOperations()
        } catch (e: Exception) {
            Log.e("AldionRepository", "Error clearing local data", e)
        }
    }

    suspend fun addCustomer(name: String, phone: String?, initialDebt: Long): Result<Long> {
        val trimmedName = name.trim()
        Log.d("AldionRepository", ">>> [Step 1] addCustomer initiated in Repository | Name: '$trimmedName', Phone: '$phone', InitialDebt: $initialDebt")

        if (trimmedName.isEmpty()) {
            val err = "اسم المدين مطلوب"
            Log.e("AldionRepository", ">>> [Step 1.1] Validation Failed: $err")
            return Result.failure(IllegalArgumentException(err))
        }

        val customer = Customer(
            name = trimmedName,
            phone = phone?.trim()?.ifEmpty { null },
            debtAmount = initialDebt.coerceAtLeast(0L),
            isSynced = false
        )

        return try {
            var initialOpToSave: Operation? = null

            val (customerId, createdCustomer) = database.withTransaction {
                val id = customerDao.insertCustomer(customer)
                if (initialDebt > 0L) {
                    val initialOp = Operation(
                        customerId = id,
                        type = OperationType.DEBT,
                        amount = initialDebt,
                        note = "دين أولي",
                        dateTime = System.currentTimeMillis(),
                        isSynced = false
                    )
                    val opId = operationDao.insertOperation(initialOp)
                    initialOpToSave = initialOp.copy(id = opId)
                }
                Pair(id, customer.copy(id = id))
            }

            Log.d("AldionRepository", ">>> [Step 2] Inserted customer locally in Room DB | ID: $customerId.")

            // Check if online and sync if available
            if (firebaseManager.isNetworkAvailable()) {
                val customerSyncResult = firebaseManager.saveCustomerSuspend(createdCustomer)
                if (customerSyncResult.isSuccess) {
                    customerDao.updateCustomer(createdCustomer.copy(isSynced = true))
                    if (initialOpToSave != null) {
                        val opSyncResult = firebaseManager.saveOperationSuspend(initialOpToSave!!)
                        if (opSyncResult.isSuccess) {
                            operationDao.updateSyncStatus(initialOpToSave!!.id, true)
                        }
                    }
                }
            }

            Result.success(customerId)
        } catch (e: Exception) {
            Log.e("AldionRepository", ">>> [Step Error] Exception in addCustomer: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun updateCustomer(customer: Customer): Result<Unit> {
        val trimmedName = customer.name.trim()
        Log.d("AldionRepository", ">>> [UpdateCustomer] Initiated for ID: ${customer.id}, Name: '$trimmedName'")

        if (trimmedName.isEmpty()) {
            return Result.failure(IllegalArgumentException("اسم المدين مطلوب"))
        }

        val existing = customerDao.getCustomerByName(trimmedName)
        if (existing != null && existing.id != customer.id) {
            return Result.failure(IllegalStateException("اسم المدين هذا مستخدم بالفعل"))
        }

        return try {
            val updated = customer.copy(
                name = trimmedName,
                phone = customer.phone?.trim()?.ifEmpty { null },
                isSynced = false
            )
            customerDao.updateCustomer(updated)

            if (firebaseManager.isNetworkAvailable()) {
                val syncResult = firebaseManager.saveCustomerSuspend(updated)
                if (syncResult.isSuccess) {
                    customerDao.updateCustomer(updated.copy(isSynced = true))
                }
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AldionRepository", ">>> [UpdateCustomer] Exception: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun deleteCustomer(customer: Customer): Result<Unit> {
        return try {
            customerDao.deleteCustomer(customer)
            firebaseManager.deleteCustomer(customer.id)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addOperation(
        customerId: Long,
        type: OperationType,
        amount: Long,
        note: String
    ): Result<AddOperationResult> {
        if (amount <= 0) {
            return Result.failure(IllegalArgumentException("يجب أن يكون المبلغ أكبر من صفر"))
        }

        return try {
            val result = database.withTransaction {
                val customer = customerDao.getCustomerById(customerId)
                    ?: throw IllegalStateException("المدين غير موجود")

                val newDebtAmount = when (type) {
                    OperationType.DEBT -> customer.debtAmount + amount
                    OperationType.PAYMENT -> {
                        if (amount > customer.debtAmount) {
                            throw IllegalArgumentException("المبلغ المراد تسديده أكبر من الدين الحالي (${customer.debtAmount.formatCurrency()})")
                        }
                        customer.debtAmount - amount
                    }
                }

                val updatedCustomer = customer.copy(debtAmount = newDebtAmount, isSynced = false)
                customerDao.updateCustomer(updatedCustomer)

                val operation = Operation(
                    customerId = customerId,
                    type = type,
                    amount = amount,
                    note = note.trim(),
                    dateTime = System.currentTimeMillis(),
                    isSynced = false
                )
                val opId = operationDao.insertOperation(operation)

                val isZeroDebt = (type == OperationType.PAYMENT && newDebtAmount == 0L)
                AddOperationResult(
                    operationId = opId,
                    isZeroDebtReached = isZeroDebt,
                    updatedCustomer = updatedCustomer,
                    operation = operation.copy(id = opId)
                )
            }

            if (firebaseManager.isNetworkAvailable()) {
                val custSyncResult = firebaseManager.saveCustomerSuspend(result.updatedCustomer)
                val opSyncResult = firebaseManager.saveOperationSuspend(result.operation)
                if (custSyncResult.isSuccess && opSyncResult.isSuccess) {
                    customerDao.updateCustomer(result.updatedCustomer.copy(isSynced = true))
                    operationDao.updateSyncStatus(result.operation.id, true)
                }
            }

            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteOperation(opWithCustomer: OperationWithCustomer): Result<Unit> {
        val op = opWithCustomer.operation
        val customerId = op.customerId

        return try {
            val updatedCust = database.withTransaction {
                val customer = customerDao.getCustomerById(customerId)
                var updated: Customer? = null
                if (customer != null) {
                    val recalculatedDebt = when (op.type) {
                        OperationType.DEBT -> {
                            (customer.debtAmount - op.amount).coerceAtLeast(0L)
                        }
                        OperationType.PAYMENT -> {
                            customer.debtAmount + op.amount
                        }
                    }
                    updated = customer.copy(debtAmount = recalculatedDebt, isSynced = false)
                    customerDao.updateCustomer(updated)
                }
                operationDao.deleteOperation(op)
                updated
            }

            firebaseManager.deleteOperation(op.id, updatedCust)
            syncWithCloud()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
