package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.Aldion
import com.example.data.model.Manager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "app_settings")

class SettingsRepository(private val context: Context) {

    companion object {
        val OVERDUE_DAYS_KEY = intPreferencesKey("overdue_days_threshold")
        val NOTIFICATIONS_ENABLED_KEY = booleanPreferencesKey("notifications_enabled")
        val HAS_COMPLETED_ONBOARDING_KEY = booleanPreferencesKey("has_completed_onboarding")
        val IS_LOGGED_IN_KEY = booleanPreferencesKey("is_logged_in")
        val CURRENT_ROLE_KEY = stringPreferencesKey("current_role")
        val CURRENT_SHOP_ID_KEY = stringPreferencesKey("current_shop_id")
        val CURRENT_MANAGER_ID_KEY = stringPreferencesKey("current_manager_id")
        val CURRENT_USERNAME_KEY = stringPreferencesKey("current_username")
        val CURRENT_SHOP_NAME_KEY = stringPreferencesKey("current_shop_name")
        val CURRENT_PHONE_KEY = stringPreferencesKey("current_phone")
        val HIGH_DEBT_THRESHOLD_KEY = longPreferencesKey("high_debt_threshold")
        const val DEFAULT_OVERDUE_DAYS = 30
        const val DEFAULT_HIGH_DEBT_THRESHOLD = 100000L
    }

    private val _sessionRevokedEvent = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val sessionRevokedEvent: SharedFlow<String> = _sessionRevokedEvent.asSharedFlow()

    val isLoggedIn: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[IS_LOGGED_IN_KEY] ?: false
    }

    val hasCompletedOnboarding: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[HAS_COMPLETED_ONBOARDING_KEY] ?: false
    }

    suspend fun setHasCompletedOnboarding(completed: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[HAS_COMPLETED_ONBOARDING_KEY] = completed
        }
    }

    suspend fun setLoggedIn(loggedIn: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[IS_LOGGED_IN_KEY] = loggedIn
        }
    }

    suspend fun clearUserSession() {
        context.settingsDataStore.edit { prefs ->
            prefs[IS_LOGGED_IN_KEY] = false
            prefs.remove(CURRENT_ROLE_KEY)
            prefs.remove(CURRENT_SHOP_ID_KEY)
            prefs.remove(CURRENT_MANAGER_ID_KEY)
            prefs.remove(CURRENT_USERNAME_KEY)
            prefs.remove(CURRENT_SHOP_NAME_KEY)
            prefs.remove(CURRENT_PHONE_KEY)
        }
        Aldion.currentRole = "SUPER_ADMIN"
        Aldion.isSuperAdmin = true
        Aldion.currentShopId = "default_shop"
        Aldion.currentManagerId = "default_manager"
        Aldion.currentLoggedInUser = "ali"
        Aldion.USERNAME = "ali"
        Aldion.SHOP_NAME = "محل الديون والخدمات"
    }

    suspend fun revokeCurrentSession(reason: String) {
        clearUserSession()
        _sessionRevokedEvent.emit(reason)
    }

    suspend fun saveUserSession(manager: Manager) {
        context.settingsDataStore.edit { prefs ->
            prefs[IS_LOGGED_IN_KEY] = true
            prefs[CURRENT_ROLE_KEY] = manager.role
            prefs[CURRENT_SHOP_ID_KEY] = manager.shopId
            prefs[CURRENT_MANAGER_ID_KEY] = manager.managerId
            prefs[CURRENT_USERNAME_KEY] = manager.username
            prefs[CURRENT_SHOP_NAME_KEY] = manager.shopName
            prefs[CURRENT_PHONE_KEY] = manager.phone
        }
        Aldion.currentRole = manager.role
        Aldion.isSuperAdmin = manager.isSuperAdmin()
        Aldion.currentShopId = manager.shopId
        Aldion.currentManagerId = manager.managerId
        Aldion.currentLoggedInUser = manager.username
        Aldion.SHOP_NAME = manager.shopName
        Aldion.USERNAME = manager.username
        Aldion.WELCOME_TEXT = "مرحباً، ${manager.username}"
        Aldion.PHONE_NUMBER = manager.phone
    }

    suspend fun restoreSessionToAldion() {
        val prefs = context.settingsDataStore.data.first()
        val role = prefs[CURRENT_ROLE_KEY] ?: "SUPER_ADMIN"
        val shopId = prefs[CURRENT_SHOP_ID_KEY] ?: "default_shop"
        val managerId = prefs[CURRENT_MANAGER_ID_KEY] ?: "default_manager"
        val username = prefs[CURRENT_USERNAME_KEY] ?: "ali"
        val shopName = prefs[CURRENT_SHOP_NAME_KEY] ?: "محل الديون والخدمات"
        val phone = prefs[CURRENT_PHONE_KEY] ?: "07810000000"

        Aldion.currentRole = role
        Aldion.isSuperAdmin = role.equals("SUPER_ADMIN", ignoreCase = true)
        Aldion.currentShopId = shopId
        Aldion.currentManagerId = managerId
        Aldion.currentLoggedInUser = username
        Aldion.SHOP_NAME = shopName
        Aldion.USERNAME = username
        Aldion.WELCOME_TEXT = "مرحباً، $username"
        Aldion.PHONE_NUMBER = phone
    }

    val overdueDays: Flow<Int> = context.settingsDataStore.data.map { prefs ->
        prefs[OVERDUE_DAYS_KEY] ?: DEFAULT_OVERDUE_DAYS
    }

    val isNotificationsEnabled: Flow<Boolean> = context.settingsDataStore.data.map { prefs ->
        prefs[NOTIFICATIONS_ENABLED_KEY] ?: true
    }

    val highDebtThreshold: Flow<Long> = context.settingsDataStore.data.map { prefs ->
        prefs[HIGH_DEBT_THRESHOLD_KEY] ?: DEFAULT_HIGH_DEBT_THRESHOLD
    }

    suspend fun saveOverdueDays(days: Int) {
        context.settingsDataStore.edit { prefs ->
            prefs[OVERDUE_DAYS_KEY] = days
        }
    }

    suspend fun saveHighDebtThreshold(threshold: Long) {
        context.settingsDataStore.edit { prefs ->
            prefs[HIGH_DEBT_THRESHOLD_KEY] = threshold
        }
    }

    suspend fun saveNotificationsEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[NOTIFICATIONS_ENABLED_KEY] = enabled
        }
    }
}
