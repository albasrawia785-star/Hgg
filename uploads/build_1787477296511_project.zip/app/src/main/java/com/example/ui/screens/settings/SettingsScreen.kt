package com.example.ui.screens.settings

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.Aldion
import com.example.ConnectionTestResult
import com.example.data.model.Manager
import com.example.ui.theme.BorderLight
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.RoyalBlue
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import java.net.URLEncoder
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onOpenOnboarding: () -> Unit = {},
    onLogout: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val overdueDaysThreshold by viewModel.overdueDaysThreshold.collectAsStateWithLifecycle()
    val highDebtThreshold by viewModel.highDebtThreshold.collectAsStateWithLifecycle()
    val managers by viewModel.managers.collectAsStateWithLifecycle()
    val isTestingConnection by viewModel.isTestingConnection.collectAsStateWithLifecycle()
    val connectionTestResult by viewModel.connectionTestResult.collectAsStateWithLifecycle()

    var showEditThresholdDialog by remember { mutableStateOf(false) }
    var showEditHighDebtDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showChangeMyPasswordDialog by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }

    var showDbConfigFields by remember { mutableStateOf(false) }
    var projectIdInput by remember { mutableStateOf(Aldion.FIREBASE_PROJECT_ID) }
    var apiKeyInput by remember { mutableStateOf(Aldion.FIREBASE_API_KEY) }
    var appIdInput by remember { mutableStateOf(Aldion.FIREBASE_APP_ID) }

    var showAddManagerDialog by remember { mutableStateOf(false) }
    var editingManager by remember { mutableStateOf<Manager?>(null) }
    var passwordManager by remember { mutableStateOf<Manager?>(null) }
    var deletingManager by remember { mutableStateOf<Manager?>(null) }

    val isSuper = Aldion.isSuperAdminUser()
    val isOnline = Aldion.isNetworkAvailable(context)

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        containerColor = Color(0xFFF8FAFC),
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Column(modifier = Modifier.padding(top = 12.dp, bottom = 2.dp)) {
                    Text(
                        text = "الإعدادات",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryDark,
                            fontSize = 20.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isSuper) "إدارة النظام، القواعد المالية، السحابة، والمدراء" else "تخصيص القواعد المالية، الحساب، والمساعدة",
                        fontSize = 12.sp,
                        color = TextSecondaryDark
                    )
                }
            }

            // Profile Summary Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSuper) RoyalBlue.copy(alpha = 0.10f)
                                    else Color(0xFF0284C7).copy(alpha = 0.10f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isSuper) Icons.Default.Shield else Icons.Default.Store,
                                contentDescription = null,
                                tint = if (isSuper) RoyalBlue else Color(0xFF0284C7),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = Aldion.currentLoggedInUser.ifBlank { Aldion.USERNAME },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimaryDark
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSuper) RoyalBlue else Color(0xFF0284C7))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (isSuper) "المدير العام" else "مدير متجر",
                                        color = Color.White,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = Aldion.SHOP_NAME.ifBlank { "المتجر التجاري" },
                                fontSize = 11.5.sp,
                                color = TextSecondaryDark
                            )

                            Spacer(modifier = Modifier.height(3.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (isOnline) EmeraldGreen else Color(0xFFDC2626))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isOnline) "المزامنة السحابية متصلة" else "وضع العمل المحلي (Offline)",
                                    fontSize = 10.5.sp,
                                    color = if (isOnline) EmeraldGreen else Color(0xFFDC2626),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 1. القسم الأول: عام (General)
            // =========================================================================
            item {
                SettingsCategoryHeader(title = "عام")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // 1. مدة التأخر
                        ModernSettingItem(
                            icon = Icons.Default.HourglassTop,
                            iconTint = Color(0xFFD97706),
                            iconBg = Color(0xFFFEF3C7),
                            title = "فترة اعتبار المدين متأخراً",
                            subtitle = "تصنيف الزبون كمتأخر بعد $overdueDaysThreshold يوماً من آخر عملية",
                            trailingText = "$overdueDaysThreshold يوم",
                            onClick = { showEditThresholdDialog = true }
                        )

                        SettingsItemDivider()

                        // 2. حد الديون المرتفعة
                        val formattedHighDebt = remember(highDebtThreshold) {
                            NumberFormat.getNumberInstance(Locale.US).format(highDebtThreshold)
                        }
                        ModernSettingItem(
                            icon = Icons.Default.WarningAmber,
                            iconTint = CrimsonRed,
                            iconBg = CrimsonRed.copy(alpha = 0.10f),
                            title = "حد الديون المرتفعة",
                            subtitle = "تنبيه وفلترة الديون عند تجاوز هذا السقف المالي",
                            trailingText = "$formattedHighDebt د.ع",
                            onClick = { showEditHighDebtDialog = true }
                        )

                        SettingsItemDivider()

                        // 3. حالة المزامنة السحابية التلقائية
                        ModernSettingItem(
                            icon = Icons.Default.CloudSync,
                            iconTint = RoyalBlue,
                            iconBg = RoyalBlue.copy(alpha = 0.10f),
                            title = "المزامنة السحابية التلقائية",
                            subtitle = if (isOnline) "يتم حفظ العمليات فوراً في السحابة" else "حفظ محلي فوري ومزامنة تلقائية عند الاتصال",
                            trailingText = if (isOnline) "نشطة" else "قيد الانتظار",
                            onClick = {
                                Toast.makeText(
                                    context,
                                    if (isOnline) "المزامنة السحابية تعمل بنجاح وبشكل مستمر" else "النظام يعمل محلياً ويقوم بالحفظ بأمان، وستتم المزامنة تلقائياً عند توفر الإنترنت",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )
                    }
                }
            }

            // فحص واتصال قاعدة البيانات (للمدير العام)
            if (isSuper) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF7C3AED).copy(alpha = 0.10f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Dns,
                                            contentDescription = null,
                                            tint = Color(0xFF7C3AED),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "خادم Firebase السحابي",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = TextPrimaryDark
                                        )
                                        Text(
                                            text = "المشروع: ${Aldion.FIREBASE_PROJECT_ID}",
                                            fontSize = 11.sp,
                                            color = TextSecondaryDark
                                        )
                                    }
                                }

                                TextButton(
                                    onClick = { showDbConfigFields = !showDbConfigFields },
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = if (showDbConfigFields) "إخفاء" else "تعديل",
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RoyalBlue
                                    )
                                }
                            }

                            AnimatedVisibility(visible = showDbConfigFields) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = projectIdInput,
                                        onValueChange = { projectIdInput = it },
                                        label = { Text("معرف المشروع (Project ID)", fontSize = 11.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = RoyalBlue,
                                            unfocusedBorderColor = BorderLight
                                        )
                                    )

                                    OutlinedTextField(
                                        value = apiKeyInput,
                                        onValueChange = { apiKeyInput = it },
                                        label = { Text("مفتاح API Key", fontSize = 11.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = RoyalBlue,
                                            unfocusedBorderColor = BorderLight
                                        )
                                    )

                                    OutlinedTextField(
                                        value = appIdInput,
                                        onValueChange = { appIdInput = it },
                                        label = { Text("معرف التطبيق App ID", fontSize = 11.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = RoyalBlue,
                                            unfocusedBorderColor = BorderLight
                                        )
                                    )

                                    Button(
                                        onClick = {
                                            focusManager.clearFocus()
                                            keyboardController?.hide()
                                            viewModel.applyFirebaseConfig(
                                                context = context,
                                                projectId = projectIdInput,
                                                apiKey = apiKeyInput,
                                                appId = appIdInput,
                                                onComplete = {
                                                    viewModel.testFirebaseConnection(projectIdInput, apiKeyInput, appIdInput)
                                                }
                                            )
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(38.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("حفظ وتطبيق القاعدة", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    focusManager.clearFocus()
                                    keyboardController?.hide()
                                    val testProj = if (showDbConfigFields) projectIdInput else null
                                    val testKey = if (showDbConfigFields) apiKeyInput else null
                                    val testApp = if (showDbConfigFields) appIdInput else null
                                    viewModel.testFirebaseConnection(testProj, testKey, testApp)
                                },
                                enabled = !isTestingConnection,
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(40.dp)
                            ) {
                                if (isTestingConnection) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = Color.White,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("جاري فحص الاتصال...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(imageVector = Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("فحص استقرار الاتصال السحابي", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            connectionTestResult?.let { result ->
                                Spacer(modifier = Modifier.height(10.dp))
                                when (result) {
                                    is ConnectionTestResult.Success -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(EmeraldGreen.copy(alpha = 0.08f))
                                                .border(1.dp, EmeraldGreen.copy(alpha = 0.30f), RoundedCornerShape(10.dp))
                                                .padding(10.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = EmeraldGreen,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text("الاتصال ناجح ومستقر ✅", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = EmeraldGreen)
                                                    Text(result.message, fontSize = 10.5.sp, color = TextPrimaryDark)
                                                }
                                            }
                                        }
                                    }
                                    is ConnectionTestResult.Error -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(CrimsonRed.copy(alpha = 0.08f))
                                                .border(1.dp, CrimsonRed.copy(alpha = 0.30f), RoundedCornerShape(10.dp))
                                                .padding(10.dp)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = Icons.Default.ErrorOutline,
                                                    contentDescription = null,
                                                    tint = CrimsonRed,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Column {
                                                    Text(result.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CrimsonRed)
                                                    Text(result.message, fontSize = 10.5.sp, color = TextPrimaryDark)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // إدارة مدراء الفروع (للمدير العام)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(RoyalBlue.copy(alpha = 0.10f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AdminPanelSettings,
                                            contentDescription = null,
                                            tint = RoyalBlue,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "إدارة مدراء الفروع والمحلات",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = TextPrimaryDark
                                        )
                                        Text(
                                            text = "${managers.size} مدراء مسجلين في النظام",
                                            fontSize = 11.sp,
                                            color = TextSecondaryDark
                                        )
                                    }
                                }

                                Button(
                                    onClick = { showAddManagerDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(32.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PersonAdd,
                                        contentDescription = null,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إضافة مدير", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            if (managers.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFFF8FAFC))
                                        .padding(14.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "لا يوجد مدراء إضافيون. اضغط \"إضافة مدير\" لإنشاء حساب جديد.",
                                        fontSize = 11.sp,
                                        color = TextSecondaryDark
                                    )
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    managers.forEach { mgr ->
                                        ManagerCardItem(
                                            manager = mgr,
                                            onEdit = { editingManager = mgr },
                                            onChangePassword = { passwordManager = mgr },
                                            onToggleStatus = { viewModel.toggleManagerStatus(mgr) },
                                            onDelete = { deletingManager = mgr }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // 2. القسم الثاني: الحساب (Account)
            // =========================================================================
            item {
                SettingsCategoryHeader(title = "الحساب")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // 1. اسم المتجر والحساب
                        ModernSettingItem(
                            icon = Icons.Default.Store,
                            iconTint = Color(0xFF0284C7),
                            iconBg = Color(0xFFE0F2FE),
                            title = "بيانات المتجر والمستخدم",
                            subtitle = "${Aldion.SHOP_NAME} • الحساب: ${Aldion.currentLoggedInUser}",
                            trailingText = if (isSuper) "المدير العام" else "مشترك",
                            onClick = {
                                Toast.makeText(
                                    context,
                                    "المتجر: ${Aldion.SHOP_NAME} | المستخدم: ${Aldion.currentLoggedInUser}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )

                        SettingsItemDivider()

                        // 2. مستوى الصلاحيات
                        ModernSettingItem(
                            icon = Icons.Default.VerifiedUser,
                            iconTint = Color(0xFF6366F1),
                            iconBg = Color(0xFFEEF2FF),
                            title = "مستوى الصلاحية والوصول",
                            subtitle = if (isSuper) "تحكم كامل بجميع الإعدادات والمدراء وقاعدة البيانات" else "إدارة حسابات وديون وعمليات متجرك فقط",
                            trailingText = if (isSuper) "صلاحية شاملة" else "صلاحية فرع",
                            onClick = {
                                Toast.makeText(
                                    context,
                                    if (isSuper) "أنت مسجل بحساب المدير العام مع كامل الصلاحيات" else "أنت مسجل كمدير فرع مع عزل كامل لحسابات المتجر",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )

                        SettingsItemDivider()

                        // 3. أمان الحساب وتغيير كلمة المرور
                        ModernSettingItem(
                            icon = Icons.Default.Lock,
                            iconTint = Color(0xFFEA580C),
                            iconBg = Color(0xFFFFEDD5),
                            title = "أمان الحساب وكلمة المرور",
                            subtitle = "تحديث كلمة المرور لحسابك الحالي لضمان الحماية",
                            trailingIcon = Icons.Default.ChevronLeft,
                            onClick = {
                                showChangeMyPasswordDialog = true
                            }
                        )

                        SettingsItemDivider()

                        // 4. تسجيل الخروج
                        ModernSettingItem(
                            icon = Icons.Default.ExitToApp,
                            iconTint = CrimsonRed,
                            iconBg = CrimsonRed.copy(alpha = 0.10f),
                            title = "تسجيل الخروج",
                            subtitle = "إنهاء الجلسة الحالية والعودة لشاشة الدخول",
                            titleColor = CrimsonRed,
                            trailingIcon = Icons.Default.ChevronLeft,
                            onClick = { showLogoutConfirmDialog = true }
                        )
                    }
                }
            }

            // =========================================================================
            // 3. القسم الثالث: دعم (Support)
            // =========================================================================
            item {
                SettingsCategoryHeader(title = "دعم")
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // 1. الدعم الفني المباشر
                        ModernSettingItem(
                            icon = Icons.Default.SupportAgent,
                            iconTint = Color(0xFF16A34A),
                            iconBg = Color(0xFFDCFCE7),
                            title = "تواصل مع الدعم الفني المباشر",
                            subtitle = "محادثة فورية عبر واتساب للمساعدة الفنية والاستفسار",
                            trailingIcon = Icons.Default.ChevronLeft,
                            onClick = {
                                val phoneNumber = "9647810936407"
                                val message = "السلام عليكم، أحتاج مساعدة أو استفسار بخصوص تطبيق إدارة الديون والحسابات"
                                try {
                                    val encodedMsg = URLEncoder.encode(message, "UTF-8")
                                    val uri = Uri.parse("https://wa.me/$phoneNumber?text=$encodedMsg")
                                    val intent = Intent(Intent.ACTION_VIEW, uri)
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(
                                        context,
                                        "تعذر فتح تطبيق واتساب، يرجى التأكد من تثبيته على الهاتف",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        )

                        SettingsItemDivider()

                        // 2. دليل الاستخدام السريع
                        ModernSettingItem(
                            icon = Icons.Default.Tune,
                            iconTint = Color(0xFF0D9488),
                            iconBg = Color(0xFFCCFBF1),
                            title = "دليل الاستخدام السريع",
                            subtitle = "استعراض جولة تعريفية بكيفية استخدام التطبيق والمميزات",
                            trailingIcon = Icons.Default.ChevronLeft,
                            onClick = onOpenOnboarding
                        )

                        SettingsItemDivider()

                        // 3. حول النظام والإصدار
                        ModernSettingItem(
                            icon = Icons.Default.Info,
                            iconTint = RoyalBlue,
                            iconBg = RoyalBlue.copy(alpha = 0.10f),
                            title = "حول النظام والإصدار",
                            subtitle = "نظام إدارة الديون والمبيعات التجارية • الإصدار 1.0.0",
                            trailingText = "v1.0.0",
                            trailingIcon = Icons.Default.ChevronLeft,
                            onClick = { showAboutDialog = true }
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }

    // =========================================================================
    // Dialogs & Sheets
    // =========================================================================

    // نافذة تعديل مدة التأخير
    if (showEditThresholdDialog) {
        var tempDays by remember { mutableStateOf(overdueDaysThreshold.toString()) }
        AlertDialog(
            onDismissRequest = { showEditThresholdDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.HourglassTop, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("مدة اعتبار المدين متأخراً", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "اختر أو اكتب عدد الأيام بعد تاريخ آخر دين ليتم تصنيف الزبون ضمن قائمة المتأخرين:",
                        fontSize = 12.sp,
                        color = TextSecondaryDark,
                        lineHeight = 17.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(15, 30, 45, 60).forEach { days ->
                            val isSelected = tempDays == days.toString()
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) RoyalBlue else Color(0xFFF1F5F9))
                                    .clickable { tempDays = days.toString() }
                                    .padding(vertical = 7.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$days يوم",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else TextPrimaryDark
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = tempDays,
                        onValueChange = { input -> if (input.all { it.isDigit() }) tempDays = input },
                        label = { Text("عدد الأيام مخصص", fontSize = 11.sp) },
                        suffix = { Text("يوم", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val days = tempDays.toIntOrNull() ?: 30
                        viewModel.updateOverdueDaysThreshold(days)
                        showEditThresholdDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("حفظ التغيير", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditThresholdDialog = false }) {
                    Text("إلغاء", fontSize = 12.sp)
                }
            }
        )
    }

    // نافذة تعديل حد الديون المرتفعة
    if (showEditHighDebtDialog) {
        var tempAmount by remember { mutableStateOf(highDebtThreshold.toString()) }
        AlertDialog(
            onDismissRequest = { showEditHighDebtDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CrimsonRed.copy(alpha = 0.10f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = CrimsonRed, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حد الديون المرتفعة", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "اختر أو اكتب المبلغ الذي يعتبر ما يساويه أو يتجاوزه من الديون المرتفعة للتنبيه والفلترة:",
                        fontSize = 12.sp,
                        color = TextSecondaryDark,
                        lineHeight = 17.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(50000L, 100000L, 250000L, 500000L).forEach { amount ->
                            val isSelected = tempAmount == amount.toString()
                            val label = "${amount / 1000} ألف"
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) RoyalBlue else Color(0xFFF1F5F9))
                                    .clickable { tempAmount = amount.toString() }
                                    .padding(vertical = 7.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else TextPrimaryDark
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = tempAmount,
                        onValueChange = { input -> if (input.all { it.isDigit() }) tempAmount = input },
                        label = { Text("المبلغ بالدينار العراقي", fontSize = 11.sp) },
                        suffix = { Text("د.ع", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = tempAmount.toLongOrNull() ?: 100000L
                        viewModel.updateHighDebtThreshold(amount)
                        showEditHighDebtDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("حفظ الحد", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditHighDebtDialog = false }) {
                    Text("إلغاء", fontSize = 12.sp)
                }
            }
        )
    }

    // نافذة تغيير كلمة المرور للمستخدم الحالي
    if (showChangeMyPasswordDialog) {
        var currentMgrId = Aldion.currentManagerId
        var newPassword by remember { mutableStateOf("") }
        var confirmPassword by remember { mutableStateOf("") }
        var errorMsg by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChangeMyPasswordDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFFFEDD5)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFEA580C), modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تغيير كلمة مرور حسابك", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (errorMsg != null) {
                        Text(errorMsg!!, color = CrimsonRed, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "أدخل كلمة المرور الجديدة لحساب (${Aldion.currentLoggedInUser}):",
                        fontSize = 12.sp,
                        color = TextSecondaryDark
                    )

                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = { Text("كلمة المرور الجديدة", fontSize = 11.sp) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("تأكيد كلمة المرور", fontSize = 11.sp) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPassword.isBlank()) {
                            errorMsg = "يرجى إدخال كلمة المرور"
                            return@Button
                        }
                        if (newPassword != confirmPassword) {
                            errorMsg = "كلمة المرور وتأكيدها غير متطابقين"
                            return@Button
                        }
                        viewModel.changePassword(
                            managerId = currentMgrId.ifBlank { "super_admin_001" },
                            newPass = newPassword,
                            onSuccess = { showChangeMyPasswordDialog = false },
                            onError = { err -> errorMsg = err }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تحديث كلمة المرور", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangeMyPasswordDialog = false }) {
                    Text("إلغاء", fontSize = 12.sp)
                }
            }
        )
    }

    // نافذة حول التطبيق
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حول النظام", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(RoyalBlue.copy(alpha = 0.10f))
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text("الإصدار 1.0.0", color = RoyalBlue, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "نظام متقدم وشامل لإدارة ديون وحسابات الزبائن والمدفوعات المالية للأنشطة التجارية والمحلات، مصمم لتقديم تجربة سريعة، آمنة، ومنظمة بأعلى معايير الدقة والسهولة.",
                        fontSize = 12.sp,
                        color = TextSecondaryDark,
                        lineHeight = 17.sp
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF8FAFC))
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("أهم مميزات النظام:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextPrimaryDark)
                            Text("• إدارة دقيقة للديون والمدفوعات والمتبقي مع كشوفات حساب تفصيلية.", fontSize = 11.sp, color = TextSecondaryDark)
                            Text("• نظام مدراء مستقل مع عزل كامل للبيانات لكل مدير ومحل.", fontSize = 11.sp, color = TextSecondaryDark)
                            Text("• حفظ ومزامنة سحابية فورية (Firebase) تضمن بقاء بياناتك بأمان.", fontSize = 11.sp, color = TextSecondaryDark)
                            Text("• كشف المتأخرين عن السداد والديون المرتفعة مع تنبيهات ذكية.", fontSize = 11.sp, color = TextSecondaryDark)
                            Text("• إرسال كشوفات الحساب وتذكيرات السداد للزبائن عبر واتساب.", fontSize = 11.sp, color = TextSecondaryDark)
                            Text("• العمل دون اتصال بالإنترنت (Offline) مع مزامنة تلقائية فورية.", fontSize = 11.sp, color = TextSecondaryDark)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAboutDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("إغلاق", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        )
    }

    // تأكيد تسجيل الخروج
    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = { Text("تسجيل الخروج", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = { Text("هل أنت متأكد من رغبتك في تسجيل الخروج من الحساب الحالي؟", fontSize = 12.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirmDialog = false
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تسجيل الخروج", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirmDialog = false }) {
                    Text("إلغاء", fontSize = 12.sp)
                }
            }
        )
    }

    // Dialogs لإدارة المدراء
    if (showAddManagerDialog) {
        AddManagerDialog(
            onDismiss = { showAddManagerDialog = false },
            onConfirm = { shopName, managerName, username, pass, phone, status ->
                viewModel.addManager(
                    shopName = shopName,
                    managerName = managerName,
                    username = username,
                    password = pass,
                    phone = phone,
                    status = status,
                    onSuccess = { showAddManagerDialog = false },
                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                )
            }
        )
    }

    editingManager?.let { mgr ->
        EditManagerDialog(
            manager = mgr,
            onDismiss = { editingManager = null },
            onConfirm = { shopName, username, phone, status, role ->
                viewModel.updateManager(
                    managerId = mgr.managerId,
                    shopName = shopName,
                    username = username,
                    phone = phone,
                    status = status,
                    role = role,
                    onSuccess = { editingManager = null },
                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                )
            }
        )
    }

    passwordManager?.let { mgr ->
        ChangePasswordDialog(
            manager = mgr,
            onDismiss = { passwordManager = null },
            onConfirm = { newPass ->
                viewModel.changePassword(
                    managerId = mgr.managerId,
                    newPass = newPass,
                    onSuccess = { passwordManager = null },
                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                )
            }
        )
    }

    deletingManager?.let { mgr ->
        AlertDialog(
            onDismissRequest = { deletingManager = null },
            title = { Text("حذف المدير", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = { Text("هل أنت متأكد من رغبتك في حذف المدير \"${mgr.username}\" (${mgr.shopName})؟", fontSize = 12.sp) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteManager(
                            managerId = mgr.managerId,
                            onSuccess = { deletingManager = null },
                            onError = { err -> Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تأكيد الحذف", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingManager = null }) {
                    Text("إلغاء", fontSize = 12.sp)
                }
            }
        )
    }
}

/**
 * عنوان التصنيف في شاشة الإعدادات (Category Header)
 */
@Composable
fun SettingsCategoryHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color(0xFF64748B),
            fontSize = 11.5.sp
        ),
        modifier = Modifier.padding(start = 6.dp, top = 6.dp, bottom = 1.dp)
    )
}

/**
 * فاصل مخصص لعناصر القائمة داخل البطاقة
 */
@Composable
fun SettingsItemDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 52.dp, end = 14.dp),
        color = Color(0xFFF1F5F9),
        thickness = 1.dp
    )
}

/**
 * عنصر إعداد حديث مجمع (Modern Setting List Tile)
 */
@Composable
fun ModernSettingItem(
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    title: String,
    subtitle: String,
    titleColor: Color = TextPrimaryDark,
    trailingText: String? = null,
    trailingIcon: ImageVector? = Icons.Default.ChevronLeft,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = titleColor
                )
                Spacer(modifier = Modifier.height(1.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextSecondaryDark,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (trailingText != null) {
                Text(
                    text = trailingText,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = RoyalBlue
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            if (trailingIcon != null) {
                Icon(
                    imageVector = trailingIcon,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun ManagerCardItem(
    manager: Manager,
    onEdit: () -> Unit,
    onChangePassword: () -> Unit,
    onToggleStatus: () -> Unit,
    onDelete: () -> Unit
) {
    val isActive = manager.isActive()
    val isSuper = manager.isSuperAdmin()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF8FAFC))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (isSuper) RoyalBlue.copy(alpha = 0.10f) else Color(0xFFE2E8F0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = if (isSuper) RoyalBlue else Color(0xFF64748B),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = manager.username,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = TextPrimaryDark
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(if (isSuper) RoyalBlue else Color(0xFF64748B))
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = if (isSuper) "مدير عام" else "مدير",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(1.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Store, contentDescription = null, tint = TextSecondaryDark, modifier = Modifier.size(11.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = manager.shopName, fontSize = 10.5.sp, color = TextSecondaryDark)
                            if (manager.phone.isNotBlank()) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = TextSecondaryDark, modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(text = manager.phone, fontSize = 10.5.sp, color = TextSecondaryDark)
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isActive) EmeraldGreen.copy(alpha = 0.10f) else CrimsonRed.copy(alpha = 0.10f))
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isActive) "نشط" else "معطل",
                        color = if (isActive) EmeraldGreen else CrimsonRed,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(7.dp),
                    modifier = Modifier.weight(1f).height(30.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("تعديل", fontSize = 10.5.sp)
                }

                OutlinedButton(
                    onClick = onChangePassword,
                    shape = RoundedCornerShape(7.dp),
                    modifier = Modifier.weight(1.2f).height(30.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("كلمة المرور", fontSize = 10.5.sp)
                }

                OutlinedButton(
                    onClick = onToggleStatus,
                    shape = RoundedCornerShape(7.dp),
                    modifier = Modifier.weight(1f).height(30.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (isActive) CrimsonRed else EmeraldGreen
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) {
                    Icon(
                        imageVector = if (isActive) Icons.Default.Block else Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(if (isActive) "تعطيل" else "تفعيل", fontSize = 10.5.sp)
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = CrimsonRed,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddManagerDialog(
    onDismiss: () -> Unit,
    onConfirm: (shopName: String, managerName: String, username: String, pass: String, phone: String, status: String) -> Unit
) {
    var shopName by remember { mutableStateOf("") }
    var managerName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var isActive by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مدير جديد", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (errorMsg != null) {
                    Text(errorMsg!!, color = CrimsonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it },
                    label = { Text("اسم المحل *", fontSize = 11.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = managerName,
                    onValueChange = { managerName = it },
                    label = { Text("اسم المدير *", fontSize = 11.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("اسم المستخدم *", fontSize = 11.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("كلمة المرور *", fontSize = 11.sp) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("تأكيد كلمة المرور *", fontSize = 11.sp) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الهاتف", fontSize = 11.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حالة الحساب:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (isActive) "نشط" else "معطل", color = if (isActive) EmeraldGreen else CrimsonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Switch(checked = isActive, onCheckedChange = { isActive = it })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (shopName.isBlank() || managerName.isBlank() || username.isBlank() || password.isBlank()) {
                        errorMsg = "يرجى ملء جميع الحقول المطلوبة (*)"
                        return@Button
                    }
                    if (password != confirmPassword) {
                        errorMsg = "كلمة المرور وتأكيدها غير متطابقين"
                        return@Button
                    }
                    val status = if (isActive) "ACTIVE" else "DISABLED"
                    onConfirm(shopName, managerName, username, password, phone, status)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("تسجيل المدير", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء", fontSize = 12.sp) }
        }
    )
}

@Composable
fun EditManagerDialog(
    manager: Manager,
    onDismiss: () -> Unit,
    onConfirm: (shopName: String, username: String, phone: String, status: String, role: String) -> Unit
) {
    var shopName by remember { mutableStateOf(manager.shopName) }
    var username by remember { mutableStateOf(manager.username) }
    var phone by remember { mutableStateOf(manager.phone) }
    var isActive by remember { mutableStateOf(manager.isActive()) }
    var isSuperAdmin by remember { mutableStateOf(manager.isSuperAdmin()) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل بيانات المدير", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (errorMsg != null) {
                    Text(errorMsg!!, color = CrimsonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = shopName,
                    onValueChange = { shopName = it },
                    label = { Text("اسم المحل", fontSize = 11.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("اسم المستخدم", fontSize = 11.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الهاتف", fontSize = 11.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حالة الحساب:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (isActive) "نشط" else "معطل", color = if (isActive) EmeraldGreen else CrimsonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Switch(checked = isActive, onCheckedChange = { isActive = it })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (shopName.isBlank() || username.isBlank()) {
                        errorMsg = "اسم المحل واسم المستخدم لا يمكن أن يكونا فارغين"
                        return@Button
                    }
                    val status = if (isActive) "ACTIVE" else "DISABLED"
                    val role = if (isSuperAdmin) "SUPER_ADMIN" else "ADMIN"
                    onConfirm(shopName, username, phone, status, role)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("حفظ التعديلات", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء", fontSize = 12.sp) }
        }
    )
}

@Composable
fun ChangePasswordDialog(
    manager: Manager,
    onDismiss: () -> Unit,
    onConfirm: (newPass: String) -> Unit
) {
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تغيير كلمة المرور لـ ${manager.username}", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (errorMsg != null) {
                    Text(errorMsg!!, color = CrimsonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("كلمة المرور الجديدة", fontSize = 11.sp) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = confirmPassword,
                    onValueChange = { confirmPassword = it },
                    label = { Text("تأكيد كلمة المرور", fontSize = 11.sp) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPassword.isBlank()) {
                        errorMsg = "يرجى إدخال كلمة المرور"
                        return@Button
                    }
                    if (newPassword != confirmPassword) {
                        errorMsg = "كلمة المرور وتأكيدها غير متطابقين"
                        return@Button
                    }
                    onConfirm(newPassword)
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("تحديث كلمة المرور", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء", fontSize = 12.sp) }
        }
    )
}
