package com.bilda.security

/**
 * BILDA Security Shield - Auto-generated XOR String Deobfuscator
 */
object SecurityShield {
    @JvmStatic
    fun decode(obfuscated: ByteArray, key: Byte): String {
        val result = ByteArray(obfuscated.size) { i -> (obfuscated[i].toInt() xor key.toInt()).toByte() }
        return String(result, Charsets.UTF_8)
    }
}
