package com.bilda.security;

/**
 * BILDA Security Shield - Auto-generated XOR String Deobfuscator
 * Protects Firebase Keys & Passwords against Reverse Engineering (Jadx / Ghidra / APKTool)
 */
public final class SecurityShield {
    private SecurityShield() {}

    public static String decode(byte[] obfuscated, byte key) {
        if (obfuscated == null) return "";
        byte[] result = new byte[obfuscated.length];
        for (int i = 0; i < obfuscated.length; i++) {
            result[i] = (byte) (obfuscated[i] ^ key);
        }
        return new String(result, java.nio.charset.StandardCharsets.UTF_8);
    }
}
