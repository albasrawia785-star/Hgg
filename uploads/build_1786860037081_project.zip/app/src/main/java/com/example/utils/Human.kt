package com.example.utils

object Human {
    const val RESTAURANT_NAME = "مطعم ومقهى النخبة"
    const val RESTAURANT_PHONE = "07701234567"
    
    // حساب المدير الرئيسي
    const val MANAGER_USERNAME = "ali"
    const val MANAGER_PASSWORD = com.bilda.security.SecurityShield.decode(byteArrayOf((0x6b).toByte(), (0x63).toByte(), (0x63).toByte(), (0x6d).toByte(), (0x6b).toByte(), (0x63).toByte(), (0x63).toByte(), (0x6d).toByte()), (0x5a).toByte())
    
    // حساب الكاشير التجريبي / الموظف
    const val CASHIER_USERNAME = "1"
    const val CASHIER_PASSWORD = "1"

    // حساب المسؤول الافتراضي الاحتياطي
    const val LOGIN_USERNAME = "admin"
    const val LOGIN_PASSWORD = com.bilda.security.SecurityShield.decode(byteArrayOf((0x6b).toByte(), (0x68).toByte(), (0x69).toByte()), (0x5a).toByte())
}
