package com.example.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupManager {

    suspend fun exportBackup(context: Context, repository: POSRepository): File = withContext(Dispatchers.IO) {
        val rootObj = JSONObject()
        rootObj.put("version", 1)
        rootObj.put("timestamp", System.currentTimeMillis())

        // 1. Export SharedPreferences
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val prefsObj = JSONObject()
        prefs.all.forEach { (key, value) ->
            when (value) {
                is String -> prefsObj.put(key, value)
                is Boolean -> prefsObj.put(key, value)
                is Int -> prefsObj.put(key, value)
                is Long -> prefsObj.put(key, value)
                is Float -> prefsObj.put(key, value.toDouble())
            }
        }
        rootObj.put("preferences", prefsObj)

        // 2. Export Categories
        val categoriesArray = JSONArray()
        val categories = repository.getAllCategoriesList()
        categories.forEach { cat ->
            val obj = JSONObject()
            obj.put("id", cat.id)
            obj.put("name", cat.name)
            categoriesArray.put(obj)
        }
        rootObj.put("categories", categoriesArray)

        // 3. Export Products
        val productsArray = JSONArray()
        val products = repository.getAllProductsList()
        products.forEach { prod ->
            val obj = JSONObject()
            obj.put("id", prod.id)
            obj.put("categoryId", prod.categoryId)
            obj.put("name", prod.name)
            obj.put("price", prod.price)
            obj.put("imageResName", prod.imageResName)
            productsArray.put(obj)
        }
        rootObj.put("products", productsArray)

        // 4. Export Invoices
        val invoicesArray = JSONArray()
        val invoices = repository.getAllInvoicesList()
        invoices.forEach { inv ->
            val obj = JSONObject()
            obj.put("invoiceNumber", inv.invoiceNumber)
            obj.put("orderTime", inv.orderTime)
            obj.put("totalAmount", inv.totalAmount)
            obj.put("paymentMethod", inv.paymentMethod)
            obj.put("amountReceived", inv.amountReceived)
            obj.put("amountChange", inv.amountChange)
            obj.put("status", inv.status)
            obj.put("shiftId", inv.shiftId)
            obj.put("orderType", inv.orderType)
            obj.put("orderTypeDetails", inv.orderTypeDetails)
            obj.put("cancelReason", inv.cancelReason ?: JSONObject.NULL)
            obj.put("customerAddress", inv.customerAddress)
            invoicesArray.put(obj)
        }
        rootObj.put("invoices", invoicesArray)

        // 5. Export Invoice Items
        val itemsArray = JSONArray()
        val invoiceItems = repository.getAllInvoiceItemsList()
        invoiceItems.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("invoiceNumber", item.invoiceNumber)
            obj.put("productName", item.productName)
            obj.put("productPrice", item.productPrice)
            obj.put("productCost", item.productCost)
            obj.put("quantity", item.quantity)
            obj.put("notes", item.notes)
            itemsArray.put(obj)
        }
        rootObj.put("invoiceItems", itemsArray)

        // 6. Export Shift Logs
        val shiftsArray = JSONArray()
        val shiftLogs = repository.getAllShiftLogsList()
        shiftLogs.forEach { shift ->
            val obj = JSONObject()
            obj.put("id", shift.id)
            obj.put("shiftName", shift.shiftName)
            obj.put("startTime", shift.startTime)
            obj.put("endTime", shift.endTime ?: JSONObject.NULL)
            obj.put("status", shift.status)
            obj.put("openingCapital", shift.openingCapital)
            obj.put("totalSales", shift.totalSales)
            obj.put("netProfit", shift.netProfit)
            shiftsArray.put(obj)
        }
        rootObj.put("shiftLogs", shiftsArray)

        // 7. Export Expenses
        val expensesArray = JSONArray()
        val expenses = repository.getAllExpensesList()
        expenses.forEach { exp ->
            val obj = JSONObject()
            obj.put("id", exp.id)
            obj.put("amount", exp.amount)
            obj.put("reason", exp.reason)
            obj.put("timestamp", exp.timestamp)
            obj.put("shiftId", exp.shiftId)
            expensesArray.put(obj)
        }
        rootObj.put("expenses", expensesArray)

        // Generate Zip File
        val dateFormat = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US)
        val fileName = "POS_Backup_${dateFormat.format(Date())}.zip"

        // Save in Downloads or app external files
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!downloadsDir.exists()) {
            downloadsDir.mkdirs()
        }
        val zipFile = File(downloadsDir, fileName)

        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
            // Write data.json
            val jsonBytes = rootObj.toString(2).toByteArray(Charsets.UTF_8)
            val jsonEntry = ZipEntry("data.json")
            zos.putNextEntry(jsonEntry)
            zos.write(jsonBytes)
            zos.closeEntry()

            // Write internal images files
            val filesDir = context.filesDir
            filesDir.listFiles()?.forEach { imageFile ->
                if (imageFile.isFile) {
                    val imgEntry = ZipEntry("images/${imageFile.name}")
                    zos.putNextEntry(imgEntry)
                    FileInputStream(imageFile).use { fis ->
                        fis.copyTo(zos)
                    }
                    zos.closeEntry()
                }
            }
        }

        zipFile
    }

    suspend fun restoreBackup(context: Context, repository: POSRepository, zipUri: Uri): Boolean = withContext(Dispatchers.IO) {
        var jsonContent: String? = null

        val inputStream = context.contentResolver.openInputStream(zipUri)
            ?: throw IllegalArgumentException("تعذر فتح ملف النسخة الاحتياطية")

        ZipInputStream(BufferedInputStream(inputStream)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val entryName = entry.name
                if (entryName == "data.json") {
                    val baos = ByteArrayOutputStream()
                    zis.copyTo(baos)
                    jsonContent = baos.toString("UTF-8")
                } else if (entryName.startsWith("images/")) {
                    val fileName = entryName.removePrefix("images/")
                    if (fileName.isNotBlank()) {
                        val outFile = File(context.filesDir, fileName)
                        FileOutputStream(outFile).use { fos ->
                            zis.copyTo(fos)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        if (jsonContent.isNullOrBlank()) {
            throw IllegalArgumentException("ملف النسخة الاحتياطية غير صالح (لا يحتوي على data.json)")
        }

        val rootObj = JSONObject(jsonContent!!)

        // Restore Preferences
        if (rootObj.has("preferences")) {
            val prefsObj = rootObj.getJSONObject("preferences")
            val prefsEditor = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE).edit()
            val keys = prefsObj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = prefsObj.get(key)
                when (value) {
                    is String -> prefsEditor.putString(key, value)
                    is Boolean -> prefsEditor.putBoolean(key, value)
                    is Int -> prefsEditor.putInt(key, value)
                    is Long -> prefsEditor.putLong(key, value)
                    is Double -> prefsEditor.putFloat(key, value.toFloat())
                }
            }
            prefsEditor.apply()
        }

        // Restore Categories
        val categories = mutableListOf<Category>()
        if (rootObj.has("categories")) {
            val arr = rootObj.getJSONArray("categories")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                categories.add(
                    Category(
                        id = obj.optInt("id", 0),
                        name = obj.optString("name", "")
                    )
                )
            }
        }

        // Restore Products
        val products = mutableListOf<Product>()
        if (rootObj.has("products")) {
            val arr = rootObj.getJSONArray("products")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                products.add(
                    Product(
                        id = obj.optInt("id", 0),
                        categoryId = obj.optInt("categoryId", 0),
                        name = obj.optString("name", ""),
                        price = obj.optDouble("price", 0.0),
                        imageResName = obj.optString("imageResName", "")
                    )
                )
            }
        }

        // Restore Invoices
        val invoices = mutableListOf<Invoice>()
        if (rootObj.has("invoices")) {
            val arr = rootObj.getJSONArray("invoices")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                invoices.add(
                    Invoice(
                        invoiceNumber = obj.optLong("invoiceNumber", 0L),
                        orderTime = obj.optLong("orderTime", System.currentTimeMillis()),
                        totalAmount = obj.optDouble("totalAmount", 0.0),
                        paymentMethod = obj.optString("paymentMethod", "نقدي"),
                        amountReceived = obj.optDouble("amountReceived", 0.0),
                        amountChange = obj.optDouble("amountChange", 0.0),
                        status = obj.optString("status", "مدفوعة"),
                        shiftId = obj.optInt("shiftId", 0),
                        orderType = obj.optString("orderType", "صالة"),
                        orderTypeDetails = obj.optString("orderTypeDetails", ""),
                        cancelReason = if (obj.isNull("cancelReason")) null else obj.optString("cancelReason"),
                        customerAddress = obj.optString("customerAddress", "")
                    )
                )
            }
        }

        // Restore Invoice Items
        val invoiceItems = mutableListOf<InvoiceItem>()
        if (rootObj.has("invoiceItems")) {
            val arr = rootObj.getJSONArray("invoiceItems")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                invoiceItems.add(
                    InvoiceItem(
                        id = obj.optLong("id", 0L),
                        invoiceNumber = obj.optLong("invoiceNumber", 0L),
                        productName = obj.optString("productName", ""),
                        productPrice = obj.optDouble("productPrice", 0.0),
                        productCost = obj.optDouble("productCost", 0.0),
                        quantity = obj.optInt("quantity", 1),
                        notes = obj.optString("notes", "")
                    )
                )
            }
        }

        // Restore Shift Logs
        val shiftLogs = mutableListOf<ShiftLog>()
        if (rootObj.has("shiftLogs")) {
            val arr = rootObj.getJSONArray("shiftLogs")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                shiftLogs.add(
                    ShiftLog(
                        id = obj.optInt("id", 0),
                        shiftName = obj.optString("shiftName", ""),
                        startTime = obj.optLong("startTime", System.currentTimeMillis()),
                        endTime = if (obj.isNull("endTime")) null else obj.optLong("endTime"),
                        status = obj.optString("status", "مغلقة"),
                        openingCapital = obj.optDouble("openingCapital", 0.0),
                        totalSales = obj.optDouble("totalSales", 0.0),
                        netProfit = obj.optDouble("netProfit", 0.0)
                    )
                )
            }
        }

        // Restore Expenses
        val expenses = mutableListOf<ExpenseEntity>()
        if (rootObj.has("expenses")) {
            val arr = rootObj.getJSONArray("expenses")
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                expenses.add(
                    ExpenseEntity(
                        id = obj.optInt("id", 0),
                        amount = obj.optDouble("amount", 0.0),
                        reason = obj.optString("reason", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        shiftId = obj.optInt("shiftId", 0)
                    )
                )
            }
        }

        // Apply Database Restore
        repository.restoreDatabaseData(
            categories = categories,
            products = products,
            invoices = invoices,
            invoiceItems = invoiceItems,
            shiftLogs = shiftLogs,
            expenses = expenses
        )

        true
    }

    fun shareBackupFile(context: Context, zipFile: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            zipFile
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "نسخة احتياطية - نظام نقطة البيع")
            putExtra(Intent.EXTRA_TEXT, "مرفق ملف النسخة الاحتياطية الشاملة لنظام نقطة البيع (${zipFile.name})")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "مشاركة النسخة الاحتياطية عبر")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
