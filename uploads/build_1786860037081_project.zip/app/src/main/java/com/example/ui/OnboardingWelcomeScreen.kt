package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

data class OnboardingItem(
    val title: String,
    val description: String,
    val badgeText: String,
    val icon: ImageVector,
    val primaryColor: Color,
    val lightBgColor: Color,
    val points: List<String>
)

@Composable
fun OnboardingWelcomeScreen(
    onFinish: () -> Unit
) {
    val items = remember {
        listOf(
            OnboardingItem(
                title = "إصدار الفواتير والمبيعات السريعة",
                description = "شاشة كاشير احترافية وسهلة لإدخال الطلبات فوراً، إتمام المبيعات، واحتساب المتبقي بدقة متناهية.",
                badgeText = "سرعة فائقة في البيع",
                icon = Icons.Default.ReceiptLong,
                primaryColor = Color(0xFF2563EB), // Royal Blue
                lightBgColor = Color(0xFFEFF6FF),
                points = listOf(
                    "دعم الدفع النقدي، الشبكة والبيع الآجل",
                    "واجهة تفاعلية مريحة ومصممة لخدمة العملاء",
                    "إدارة الورديات وصندوق العهدة اليومية"
                )
            ),
            OnboardingItem(
                title = "إدارة المنيو والوجبات والأسعار",
                description = "تنظيم الأقسام والمنتجات، إضافة الوجبات وتحديث الأسعار والملاحظات بكل سهولة ومرونة.",
                badgeText = "تحكم كامل وسهل",
                icon = Icons.Default.RestaurantMenu,
                primaryColor = Color(0xFFD97706), // Amber / Gold
                lightBgColor = Color(0xFFFEF3C7),
                points = listOf(
                    "ترتيب الأقسام والوجبات بألوان مميزة",
                    "تعديل الأسعار والمنتجات بنقرة زر واحدة",
                    "بحث سريع وفلترة ذكية للوجبات"
                )
            ),
            OnboardingItem(
                title = "طباعة فواتير البلوتوث الحرارية",
                description = "ربط مباشر وسلس مع طابعات الفواتير الحرارية عبر البلوتوث لطباعة الفواتير وإيصالات المطبخ.",
                badgeText = "طباعة حرارية مباشرة",
                icon = Icons.Default.Print,
                primaryColor = Color(0xFF16A34A), // Emerald Green
                lightBgColor = Color(0xFFDCFCE7),
                points = listOf(
                    "دعم مختلف طابعات البلوتوث الحرارية",
                    "طباعة الشعار ورأس الفاتورة المخصص",
                    "طباعة تلقائية وفورية عند إتمام الدفع"
                )
            ),
            OnboardingItem(
                title = "عمل بدون إنترنت ونسخ احتياطي",
                description = "تطبيق متكامل يعمل 100% أوفلاين بدون حاجة للإنترنت مع حماية فائقة للبيانات والنسخ الاحتياطي.",
                badgeText = "أمان واستمرارية كاملة",
                icon = Icons.Default.CloudSync,
                primaryColor = Color(0xFF7C3AED), // Purple Accent
                lightBgColor = Color(0xFFF3E8FF),
                points = listOf(
                    "تشغيل أوفلاين كلي (Offline-First)",
                    "تصدير واستعادة النسخة الاحتياطية (.zip)",
                    "تقارير مبيعات سريعة وسجل للمصاريف"
                )
            )
        )
    }

    val pagerState = rememberPagerState(pageCount = { items.size })
    val coroutineScope = rememberCoroutineScope()
    val isLastPage = pagerState.currentPage == items.size - 1
    val currentItem = items[pagerState.currentPage]

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFF8FAFC) // Clean light slate background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // --- 1. Top Bar Navigation ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // App Logo & Branding Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .shadow(2.dp, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PointOfSale,
                            contentDescription = null,
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "كاشير .POS.",
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "نظام المبيعات الذكي",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                // Skip Button ("تخطي")
                Surface(
                    onClick = onFinish,
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    modifier = Modifier.testTag("onboarding_skip_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "تخطي",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF64748B)
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // --- 2. HorizontalPager View ---
            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) { page ->
                val item = items[page]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 8.dp)
                        .shadow(4.dp, RoundedCornerShape(28.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(28.dp),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceEvenly
                    ) {
                        // Top Feature Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(30.dp))
                                .background(item.lightBgColor)
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(item.primaryColor, CircleShape)
                                )
                                Text(
                                    text = item.badgeText,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    color = item.primaryColor
                                )
                            }
                        }

                        // Giant Hero Icon Circle
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .shadow(8.dp, CircleShape, ambientColor = item.primaryColor, spotColor = item.primaryColor)
                                .background(
                                    brush = Brush.radialGradient(
                                        colors = listOf(item.lightBgColor, item.primaryColor.copy(alpha = 0.15f))
                                    ),
                                    shape = CircleShape
                                )
                                .border(2.dp, item.primaryColor.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = null,
                                tint = item.primaryColor,
                                modifier = Modifier.size(56.dp)
                            )
                        }

                        // Title and Description
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = item.title,
                                fontWeight = FontWeight.Black,
                                fontSize = 21.sp,
                                color = Color(0xFF0F172A),
                                textAlign = TextAlign.Center,
                                lineHeight = 28.sp
                            )

                            Text(
                                text = item.description,
                                fontWeight = FontWeight.Medium,
                                fontSize = 13.5.sp,
                                color = Color(0xFF475569),
                                textAlign = TextAlign.Center,
                                lineHeight = 21.sp,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        }

                        // Features Checkmark List Card
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF8FAFC), RoundedCornerShape(18.dp))
                                .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(18.dp))
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item.points.forEach { point ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(22.dp)
                                            .background(item.primaryColor.copy(alpha = 0.15f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = item.primaryColor,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                    Text(
                                        text = point,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.5.sp,
                                        color = Color(0xFF334155)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // --- 3. Bottom Controls & Page Indicators ---
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Page Indicator Dots
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(items.size) { index ->
                        val isSelected = pagerState.currentPage == index
                        val width by animateDpAsState(
                            targetValue = if (isSelected) 28.dp else 8.dp,
                            animationSpec = tween(durationMillis = 250),
                            label = "indicator_width"
                        )
                        val color = if (isSelected) currentItem.primaryColor else Color(0xFFCBD5E1)

                        Box(
                            modifier = Modifier
                                .height(8.dp)
                                .width(width)
                                .clip(CircleShape)
                                .background(color)
                        )
                    }
                }

                // Primary Next / Get Started Button
                Button(
                    onClick = {
                        if (isLastPage) {
                            onFinish()
                        } else {
                            coroutineScope.launch {
                                pagerState.animateScrollToPage(pagerState.currentPage + 1)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .shadow(6.dp, RoundedCornerShape(16.dp), spotColor = currentItem.primaryColor)
                        .testTag("onboarding_next_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = currentItem.primaryColor,
                        contentColor = Color.White
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = if (isLastPage) "ابدأ الآن وتسجيل الدخول" else "التالي",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                        Icon(
                            imageVector = if (isLastPage) Icons.Default.CheckCircle else Icons.Default.ArrowBack,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
