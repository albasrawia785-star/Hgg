package com.example.model

import android.net.Uri

enum class HotspotStatus {
    STOPPED,
    STARTING,
    ACTIVE,
    ERROR
}

data class HotspotInfo(
    val ssid: String = "VideoPortal_Open",
    val password: String? = null,
    val isSecurityOpen: Boolean = true,
    val ipAddress: String = "192.168.49.1",
    val port: Int = 8080,
    val isTetheringMode: Boolean = false,
    val errorMessage: String? = null
) {
    val serverUrl: String
        get() = "http://$ipAddress:$port"

    val wifiQrPayload: String
        get() = if (password.isNullOrEmpty() || isSecurityOpen) {
            "WIFI:S:$ssid;T:nopass;;"
        } else {
            "WIFI:S:$ssid;T:WPA;P:$password;;"
        }
}

data class ConnectedDevice(
    val ipAddress: String,
    val macAddress: String,
    val deviceName: String = "جهاز متصل",
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)

data class HostedVideo(
    val uri: Uri? = null,
    val fileName: String = "فيديو تجريبي افتراضي (Default)",
    val fileSizeFormatted: String = "1.2 MB",
    val fileSizeBytes: Long = 0,
    val mimeType: String = "video/mp4",
    val isDefaultSample: Boolean = true
)

data class ServerLog(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val clientIp: String,
    val requestPath: String,
    val statusCode: Int,
    val isVideoChunk: Boolean = false
)
