package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette Colors
val ElegantLilacPrimary = Color(0xFFD0BCFF)
val ElegantLilacDark = Color(0xFF381E72)
val ElegantLilacContainer = Color(0xFF4F378B)
val ElegantLilacOnContainer = Color(0xFFEADDFF)

val ElegantSecondary = Color(0xFFCCC2DC)
val ElegantSecondaryContainer = Color(0xFF4A4458)
val ElegantOnSecondaryContainer = Color(0xFFE8DEF8)

// Status & Accent
val ElegantGlowGreen = Color(0xFFB6EEA0)
val ElegantGlowGreenDark = Color(0xFF1B5E20)
val WarningAmber = Color(0xFFFFD54F)
val ErrorRose = Color(0xFFF2B8B5)
val ErrorRoseDark = Color(0xFF8C1D18)

// Dark Theme Canvas & Surfaces
val DarkBackground = Color(0xFF111318)
val DarkSurface = Color(0xFF1D1B20)
val DarkSurfaceVariant = Color(0xFF2B2930)
val DarkChipBg = Color(0xFF333538)
val DarkCardBorder = Color(0xFF49454F)
val DarkTextPrimary = Color(0xFFE2E2E6)
val DarkTextSecondary = Color(0xFF939099)
val DarkTextMuted = Color(0xFF79747E)

// Legacy aliases for backward compatibility if referenced
val CyanPrimary = ElegantLilacPrimary
val CyanPrimaryDark = ElegantLilacDark
val CyanPrimaryLight = ElegantLilacPrimary
val CyanContainer = ElegantLilacContainer
val OnCyanContainer = ElegantLilacOnContainer

val IndigoSecondary = ElegantSecondary
val IndigoSecondaryLight = ElegantSecondary
val IndigoContainer = ElegantSecondaryContainer
val OnIndigoContainer = ElegantOnSecondaryContainer
val SuccessGreen = ElegantGlowGreen

