package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.ElegantGlowGreen
import com.example.ui.theme.ElegantLilacDark
import com.example.ui.theme.ElegantLilacPrimary

@Composable
fun CaptiveGuideDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(28.dp))
                .padding(8.dp)
                .testTag("captive_guide_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "كيف يعمل توجيه Captive Portal؟",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                GuideItem(
                    title = "1. آلية عمل هواتف Android",
                    description = "عند اتصال هاتف أندرويد بالشبكة، يرسل فحصاً تلقائياً لمسار (generate_204). يستجيب الخادم المحلي بصفحة الفيديو مباشرة ويظهر إشعار «تسجيل الدخول إلى الشبكة» الذي يفتح الفيديو فوراً."
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideItem(
                    title = "2. آلية عمل أجهزة Apple (iPhone & iPad)",
                    description = "أجهزة iOS ترسل طلباً تلقائياً لمسار (hotspot-detect.html). يقوم التطبيق باعتراض الطلب وفتح متصفح Captive Assistant التلقائي عارضاً الفيديو فور الاتصال."
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideItem(
                    title = "3. أجهزة الكمبيوتر (Windows & Mac)",
                    description = "يتم التقاط مسار (ncsi.txt) وتوجيه المتصفح التلقائي مباشرة لصفحة تشغيل الفيديو المحلي."
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideItem(
                    title = "4. تشغيل الفيديو في حلقة مستمرة (Loop)",
                    description = "تم تضمين كود HTML5 عالي الأداء مع دعم تقطيع الفيديو إلى أجزاء (Byte-Range) لضمان سرعة فائقة وعدم تقطيع البث حتى مع وجود عدة أجهزة متصلة في نفس اللحظة."
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(99.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElegantLilacPrimary,
                        contentColor = ElegantLilacDark
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Text("فهمت ذلك", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

@Composable
private fun GuideItem(
    title: String,
    description: String
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = ElegantGlowGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

