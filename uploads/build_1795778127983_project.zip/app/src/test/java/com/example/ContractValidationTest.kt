package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ContractValidationTest {

    @Test
    fun officeInfo_formatsSingleAndDualPhones() {
        val single = OfficeInfo(phone = "07700000000", phone2 = "")
        assertEquals("07700000000", single.formattedPhones())

        val dual = OfficeInfo(phone = "07700000000", phone2 = "07800000000")
        assertEquals("07700000000 - 07800000000", dual.formattedPhones())
    }

    @Test
    fun formatMoneyInput_formatsEasternAndWesternDigits() {
        assertEquals("1,500,000", FormatUtils.formatMoneyInput("1500000"))
        assertEquals("250,000", FormatUtils.formatMoneyInput("٢٥٠٠٠٠"))
    }

    @Test
    fun validateRealEstateContract_detectsMissingNamesAndInvalidId() {
        val invalid = RealEstateContract(
            sellerName = "",
            buyerName = "أحمد علي",
            sellerIdNumber = "12345"
        )
        val result = ContractValidation.validateRealEstateContract(invalid)
        assertFalse(result.isValid)
        assertTrue(result.hasError("sellerName"))
        assertTrue(result.hasError("sellerIdNumber"))
        assertNull(result.getError("buyerName"))
    }

    @Test
    fun validateCarSaleContract_passesWithValidRequiredFields() {
        val valid = CarSaleContract(
            sellerName = "محمد كريم",
            buyerName = "علي حسن",
            sellerPhone = "07701234567",
            sellerIdNumber = "199012345678",
            totalPrice = "15000000"
        )
        val result = ContractValidation.validateCarSaleContract(valid)
        assertTrue(result.isValid)
    }
}
