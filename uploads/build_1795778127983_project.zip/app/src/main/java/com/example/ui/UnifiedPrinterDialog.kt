package com.example.ui

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.PrinterConnectionTab
import com.example.PrinterState
import com.example.UsbPrinterDevice
import com.example.WifiPrinterDevice

@Composable
fun UnifiedPrinterDialog(
    selectedTab: PrinterConnectionTab,
    printerState: PrinterState,
    wifiPrinters: List<WifiPrinterDevice>,
    isScanningWifi: Boolean,
    bluetoothDevices: List<BluetoothDevice>,
    hasBluetoothPermission: Boolean,
    isBluetoothEnabled: Boolean,
    usbPrinters: List<UsbPrinterDevice>,
    printCopies: Int = 1,
    onPrintCopiesChange: (Int) -> Unit = {},
    onSelectTab: (PrinterConnectionTab) -> Unit,
    onRefresh: () -> Unit,
    onSystemPrintOrPdf: () -> Unit,
    onSelectWifiPrinter: (WifiPrinterDevice) -> Unit,
    onAddManualWifiPrinter: (name: String, host: String, port: Int) -> Unit,
    onRemoveManualWifiPrinter: (WifiPrinterDevice) -> Unit,
    onRequestBluetoothPermission: () -> Unit,
    onSelectBluetoothDevice: (BluetoothDevice) -> Unit,
    onSelectUsbDevice: (UsbPrinterDevice) -> Unit,
    onDismiss: () -> Unit
) {
    var showAddIpDialog by remember { mutableStateOf(false) }

    val headerTitle = when (selectedTab) {
        PrinterConnectionTab.WIFI -> "طابعات Wi-Fi"
        PrinterConnectionTab.BLUETOOTH -> "طابعات Bluetooth"
        PrinterConnectionTab.USB -> "طابعات USB"
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .widthIn(max = 520.dp)
                .heightIn(min = 420.dp, max = 600.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // شريط العنوان العلوي وأدوات الفحص
                Surface(
                    color = Color(0xFF091E42),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = headerTitle,
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (selectedTab == PrinterConnectionTab.WIFI) {
                                    IconButton(
                                        onClick = { showAddIpDialog = true },
                                        modifier = Modifier.testTag("btn_add_wifi_ip")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "إضافة طابعة برقم IP",
                                            tint = Color.White
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = onRefresh,
                                    modifier = Modifier.testTag("btn_refresh_printers")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "تحديث الطابعات",
                                        tint = Color.White
                                    )
                                }

                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier.testTag("btn_close_printer_dialog")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "إغلاق",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        // تبويبات الاتصال الثلاثة (Wi-Fi / Bluetooth / USB)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF102A56))
                        ) {
                            PrinterTabItem(
                                icon = Icons.Default.Wifi,
                                contentDescription = "طابعات Wi-Fi",
                                selected = selectedTab == PrinterConnectionTab.WIFI,
                                count = wifiPrinters.size,
                                onClick = { onSelectTab(PrinterConnectionTab.WIFI) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tab_printer_wifi")
                            )
                            PrinterTabItem(
                                icon = Icons.Default.Bluetooth,
                                contentDescription = "طابعات Bluetooth",
                                selected = selectedTab == PrinterConnectionTab.BLUETOOTH,
                                count = bluetoothDevices.size,
                                onClick = { onSelectTab(PrinterConnectionTab.BLUETOOTH) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tab_printer_bluetooth")
                            )
                            PrinterTabItem(
                                icon = Icons.Default.Usb,
                                contentDescription = "طابعات USB",
                                selected = selectedTab == PrinterConnectionTab.USB,
                                count = usbPrinters.size,
                                onClick = { onSelectTab(PrinterConnectionTab.USB) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("tab_printer_usb")
                            )
                        }
                    }
                }

                // شريط حالة الطباعة (يظهر فقط أثناء التنفيذ أو النتيجة)
                AnimatedVisibility(visible = printerState !is PrinterState.Idle) {
                    PrinterStatusBanner(printerState = printerState)
                }

                // شريط تحديد عدد النسخ قبل الطباعة
                PrintCopiesSelectorBar(
                    copies = printCopies,
                    onCopiesChange = onPrintCopiesChange
                )

                // محتوى التبويب المحدد
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                ) {
                    when (selectedTab) {
                        PrinterConnectionTab.WIFI -> {
                            WifiPrintersTabContent(
                                wifiPrinters = wifiPrinters,
                                isScanning = isScanningWifi,
                                onSystemPrintOrPdf = onSystemPrintOrPdf,
                                onSelectWifiPrinter = onSelectWifiPrinter,
                                onRemoveManualWifiPrinter = onRemoveManualWifiPrinter,
                                onAddManualClick = { showAddIpDialog = true }
                            )
                        }

                        PrinterConnectionTab.BLUETOOTH -> {
                            BluetoothPrintersTabContent(
                                devices = bluetoothDevices,
                                hasPermission = hasBluetoothPermission,
                                isBluetoothEnabled = isBluetoothEnabled,
                                onRequestPermission = onRequestBluetoothPermission,
                                onSelectDevice = onSelectBluetoothDevice
                            )
                        }

                        PrinterConnectionTab.USB -> {
                            UsbPrintersTabContent(
                                usbPrinters = usbPrinters,
                                onSelectUsbPrinter = onSelectUsbDevice
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddIpDialog) {
        AddWifiIpDialog(
            onDismiss = { showAddIpDialog = false },
            onConfirm = { name, host, port ->
                onAddManualWifiPrinter(name, host, port)
                showAddIpDialog = false
            }
        )
    }
}

@Composable
private fun PrintCopiesSelectorBar(
    copies: Int,
    onCopiesChange: (Int) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Print,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "عدد النسخ المطبوعة",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilledTonalIconButton(
                        onClick = { if (copies > 1) onCopiesChange(copies - 1) },
                        enabled = copies > 1,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("btn_copies_minus")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "إنقاص عدد النسخ"
                        )
                    }

                    Text(
                        text = copies.toString(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .widthIn(min = 32.dp)
                            .testTag("text_copies_count")
                    )

                    FilledTonalIconButton(
                        onClick = { if (copies < 20) onCopiesChange(copies + 1) },
                        enabled = copies < 20,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("btn_copies_plus")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "زيادة عدد النسخ"
                        )
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun PrinterTabItem(
    icon: ImageVector,
    contentDescription: String,
    selected: Boolean,
    count: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .height(50.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = contentDescription,
                    tint = if (selected) Color.White else Color.White.copy(alpha = 0.58f),
                    modifier = Modifier.size(23.dp)
                )
                if (count > 0) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(
                                if (selected) Color(0xFF1E65FF) else Color.White.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = count.toString(),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .background(if (selected) Color(0xFF60A5FA) else Color.Transparent)
        )
    }
}

@Composable
private fun PrinterStatusBanner(printerState: PrinterState) {
    when (printerState) {
        is PrinterState.Connecting -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFEFF6FF))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "جاري الاتصال بـ ${printerState.deviceName}...",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E3A8A)
                )
            }
        }

        is PrinterState.Printing -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFEFF6FF))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "جاري إرسال العقد للطباعة (${printerState.progress}%)...",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1E3A8A)
                )
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { printerState.progress / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        is PrinterState.Success -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFECFDF5))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF059669),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = printerState.message,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF047857)
                )
            }
        }

        is PrinterState.Error -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFEF2F2))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = null,
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = printerState.errorMessage,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF991B1B)
                )
            }
        }

        else -> {}
    }
}

@Composable
private fun WifiPrintersTabContent(
    wifiPrinters: List<WifiPrinterDevice>,
    isScanning: Boolean,
    onSystemPrintOrPdf: () -> Unit,
    onSelectWifiPrinter: (WifiPrinterDevice) -> Unit,
    onRemoveManualWifiPrinter: (WifiPrinterDevice) -> Unit,
    onAddManualClick: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 4.dp)
    ) {
        // خيار حفظ كملف PDF / طباعة النظام الرسمية (الأول دائماً مثل NokoPrint)
        item {
            PrinterRowItem(
                icon = Icons.Default.PictureAsPdf,
                iconTint = Color(0xFF1E65FF),
                title = "احفظ كملف PDF أو طباعة النظام",
                subtitle = "يدعم طابعات Wi-Fi المثبتة بالنظام وحفظ نسخة PDF",
                onClick = onSystemPrintOrPdf,
                modifier = Modifier.testTag("printer_item_save_pdf")
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
        }

        if (isScanning) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "جاري البحث عن طابعات Wi-Fi على الشبكة...",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(wifiPrinters, key = { it.id }) { printer ->
            PrinterRowItem(
                icon = Icons.Default.Print,
                iconTint = Color(0xFF0F172A),
                title = printer.name,
                subtitle = if (printer.isManual) "${printer.displaySubtitle} • مضافة يدوياً" else printer.displaySubtitle,
                trailingContent = if (printer.isManual) {
                    {
                        IconButton(onClick = { onRemoveManualWifiPrinter(printer) }) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "حذف الطابعة",
                                tint = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                } else null,
                onClick = { onSelectWifiPrinter(printer) },
                modifier = Modifier.testTag("wifi_printer_${printer.host}")
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
        }

        if (!isScanning && wifiPrinters.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "لم يتم العثور على طابعات Wi-Fi تلقائياً على الشبكة",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "استخدم «احفظ كملف PDF أو طباعة النظام» أعلاه أو أضف عنوان IP الطابعة يدوياً.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(onClick = onAddManualClick) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إضافة طابعة برقم IP")
                    }
                }
            }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
private fun BluetoothPrintersTabContent(
    devices: List<BluetoothDevice>,
    hasPermission: Boolean,
    isBluetoothEnabled: Boolean,
    onRequestPermission: () -> Unit,
    onSelectDevice: (BluetoothDevice) -> Unit
) {
    when {
        !hasPermission -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Bluetooth,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "السماح بالوصول إلى طابعات البلوتوث",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "لإظهار طابعات البلوتوث المقترنة والاتصال بها مباشرة، يرجى منح إذن البلوتوث.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onRequestPermission,
                    modifier = Modifier.testTag("btn_grant_bluetooth_permission")
                ) {
                    Text("منح إذن البلوتوث")
                }
            }
        }

        !isBluetoothEnabled -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.BluetoothDisabled,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "البلوتوث متوقف حالياً",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "قم بتشغيل البلوتوث في جهازك وتأكد من اقتران الطابعة ثم اضغط على زر التحديث بالأعلى.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        devices.isEmpty() -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Bluetooth,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "لم يتم العثور على طابعات بلوتوث مقترنة",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "يرجى إقران طابعة البلوتوث من إعدادات النظام أولاً ثم الضغط على تحديث.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        else -> {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(devices, key = { it.address }) { device ->
                    val name = device.name ?: "Bluetooth Printer"
                    PrinterRowItem(
                        icon = Icons.Default.Print,
                        iconTint = Color(0xFF0F172A),
                        title = name,
                        subtitle = device.address,
                        onClick = { onSelectDevice(device) },
                        modifier = Modifier.testTag("printer_device_item_${device.address}")
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                }
            }
        }
    }
}

@Composable
private fun UsbPrintersTabContent(
    usbPrinters: List<UsbPrinterDevice>,
    onSelectUsbPrinter: (UsbPrinterDevice) -> Unit
) {
    if (usbPrinters.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "لم يتم العثور على طابعات",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "الأسباب المحتملة: وضع مضيف USB غير مدعوم أو معطل على جهازك، أو الطابعة متوقفة عن التشغيل أو غير متصلة بواسطة كابل USB OTG.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.outline,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            items(usbPrinters, key = { it.deviceId }) { printer ->
                PrinterRowItem(
                    icon = Icons.Default.Usb,
                    iconTint = Color(0xFF0F172A),
                    title = printer.name,
                    subtitle = printer.displaySubtitle,
                    onClick = { onSelectUsbPrinter(printer) },
                    modifier = Modifier.testTag("usb_printer_item_${printer.deviceId}")
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
            }
        }
    }
}

@Composable
private fun PrinterRowItem(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailingContent: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color(0xFFF1F5F9),
            modifier = Modifier.size(42.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (trailingContent != null) {
            trailingContent()
        }
    }
}

@Composable
private fun AddWifiIpDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, host: String, port: Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("9100") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "إضافة طابعة شبكة (IP)",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الطابعة (اختياري)") },
                    placeholder = { Text("مثال: طابعة المكتب") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it },
                    label = { Text("عنوان الـ IP") },
                    placeholder = { Text("192.168.1.50") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = port,
                    onValueChange = { port = it.filter { ch -> ch.isDigit() } },
                    label = { Text("المنفذ (Port)") },
                    placeholder = { Text("9100 أو 631") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val p = port.toIntOrNull() ?: 9100
                    onConfirm(name, host, p)
                },
                enabled = host.trim().isNotEmpty()
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
