package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ClearableOutlinedTextField
import com.example.FormSectionCard
import com.example.SettingsManager

/**
 * شاشة إعدادات المكتب والترويسة بصفحة كاملة
 * تتيح إدخال اسم المكتب، رقمي الهاتف، رقم الإجازة، والعنوان بحقول واسعة بدون تلميحات
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenPrinterDialog: () -> Unit = {},
    onSettingsSaved: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settingsManager = remember { SettingsManager.getInstance(context) }

    var officeName by remember { mutableStateOf(settingsManager.officeName) }
    var officePhone by remember { mutableStateOf(settingsManager.officePhone) }
    var officePhone2 by remember { mutableStateOf(settingsManager.officePhone2) }
    var officeLicenseNo by remember { mutableStateOf(settingsManager.officeLicenseNo) }
    var officeAddress by remember { mutableStateOf(settingsManager.officeAddress) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                FormSectionCard(
                    title = "بيانات المكتب / المعرض",
                    icon = Icons.Default.Business
                ) {
                    ClearableOutlinedTextField(
                        value = officeName,
                        onValueChange = { officeName = it },
                        label = { Text("اسم المكتب / المعرض") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Store,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_name"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )

                    ClearableOutlinedTextField(
                        value = officePhone,
                        onValueChange = { officePhone = it },
                        label = { Text("رقم الهاتف الأول") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Phone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_phone"),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next
                        )
                    )

                    ClearableOutlinedTextField(
                        value = officePhone2,
                        onValueChange = { officePhone2 = it },
                        label = { Text("رقم الهاتف الثاني") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_phone2"),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone,
                            imeAction = ImeAction.Next
                        )
                    )

                    ClearableOutlinedTextField(
                        value = officeLicenseNo,
                        onValueChange = { officeLicenseNo = it },
                        label = { Text("رقم الإجازة / الترخيص") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.AssignmentInd,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_license_no"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                    )

                    ClearableOutlinedTextField(
                        value = officeAddress,
                        onValueChange = { officeAddress = it },
                        label = { Text("عنوان المكتب") },
                        leadingIcon = {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_office_address"),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
                    )
                }

                FormSectionCard(
                    title = "الطابعات والاتصال",
                    icon = Icons.Default.Print
                ) {
                    OutlinedButton(
                        onClick = onOpenPrinterDialog,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_open_printer_from_settings"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إدارة الطابعات والاتصال",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // شريط حفظ ثابت أسفل الصفحة
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 6.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onBack,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("btn_cancel_office_settings")
                ) {
                    Text("إلغاء", fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        settingsManager.saveOfficeDetails(
                            name = officeName,
                            phone = officePhone,
                            phone2 = officePhone2,
                            licenseNo = officeLicenseNo,
                            address = officeAddress
                        )
                        onSettingsSaved()
                        Toast.makeText(context, "تم حفظ بيانات المكتب بنجاح", Toast.LENGTH_SHORT).show()
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_save_office_settings")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حفظ التغييرات", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

