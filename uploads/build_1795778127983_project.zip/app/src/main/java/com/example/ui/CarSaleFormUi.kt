package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.*

@Composable
fun CarSaleFormUi(
    contract: CarSaleContract,
    onContractChange: ((CarSaleContract) -> CarSaleContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        FormSectionCard(title = "معلومات العقد والمالك الشرعي", icon = Icons.Default.Description) {
            ClearableOutlinedTextField(
                value = contract.contractNo,
                onValueChange = { val s = it; onContractChange { c -> c.copy(contractNo = s) } },
                label = { Text("رقم العقد") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("car_contract_no")
            )
            DatePickerTextField(
                value = contract.contractDate,
                onValueChange = { val s = it; onContractChange { c -> c.copy(contractDate = s) } },
                label = "تاريخ العقد",
                modifier = Modifier.fillMaxWidth(),
                testTag = "car_contract_date"
            )
            ClearableOutlinedTextField(
                value = contract.carLegalOwner,
                onValueChange = { val s = it; onContractChange { c -> c.copy(carLegalOwner = s) } },
                label = { Text("المالك الشرعي حسب السنوية (إن وجد)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.ownerAddress,
                onValueChange = { val s = it; onContractChange { c -> c.copy(ownerAddress = s) } },
                label = { Text("عنوان المالك الشرعي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "بيانات البائع", icon = Icons.Default.Person) {
            ClearableOutlinedTextField(
                value = contract.sellerName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerName = str) } },
                label = { Text("اسم البائع الثلاثي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("car_seller_name")
            )
            ClearableOutlinedTextField(
                value = contract.sellerPhone,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerPhone = str) } },
                label = { Text("رقم الهاتف") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.sellerIdNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerIdNumber = str) } },
                label = { Text("رقم البطاقة الوطنية") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.sellerAddress,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerAddress = str) } },
                label = { Text("عنوان البائع") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "بيانات المشتري", icon = Icons.Default.PersonOutline) {
            ClearableOutlinedTextField(
                value = contract.buyerName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerName = str) } },
                label = { Text("اسم المشتري الثلاثي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("car_buyer_name")
            )
            ClearableOutlinedTextField(
                value = contract.buyerPhone,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerPhone = str) } },
                label = { Text("رقم الهاتف") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.buyerIdNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerIdNumber = str) } },
                label = { Text("رقم البطاقة الوطنية") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.buyerAddress,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerAddress = str) } },
                label = { Text("عنوان المشتري") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "مواصفات المركبة", icon = Icons.Default.DirectionsCar) {
            ClearableOutlinedTextField(
                value = contract.carBrandAndType,
                onValueChange = { val str = it; onContractChange { c -> c.copy(carBrandAndType = str) } },
                label = { Text("نوع وماركة السيارة") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.carCategory,
                onValueChange = { val str = it; onContractChange { c -> c.copy(carCategory = str) } },
                label = { Text("الصفة (خصوصي / أجرة / حمل)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.modelYear,
                onValueChange = { val str = it; onContractChange { c -> c.copy(modelYear = str) } },
                label = { Text("الموديل") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.color,
                onValueChange = { val str = it; onContractChange { c -> c.copy(color = str) } },
                label = { Text("اللون") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.annualRegNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(annualRegNumber = str) } },
                label = { Text("رقم اللوحة / السنوية") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.chassisNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(chassisNumber = str) } },
                label = { Text("رقم الشاصي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.engineNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(engineNumber = str) } },
                label = { Text("رقم المحرك") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "المبالغ المالية", icon = Icons.Default.Payments) {
            ClearableOutlinedTextField(
                value = contract.totalPrice,
                onValueChange = { val str = it; onContractChange { c -> c.copy(totalPrice = str) } },
                label = { Text("السعر الكلي (أرقاماً)") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.totalPriceWords,
                onValueChange = { val str = it; onContractChange { c -> c.copy(totalPriceWords = str) } },
                label = { Text("السعر كتابةً") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.paidAmount,
                onValueChange = { val str = it; onContractChange { c -> c.copy(paidAmount = str) } },
                label = { Text("المبلغ المستلم") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.remainingAmount,
                onValueChange = { val str = it; onContractChange { c -> c.copy(remainingAmount = str) } },
                label = { Text("المبلغ المتبقي") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "الشهود ومنظم العقد", icon = Icons.Default.VerifiedUser) {
            ClearableOutlinedTextField(
                value = contract.witness1Name,
                onValueChange = { val str = it; onContractChange { c -> c.copy(witness1Name = str) } },
                label = { Text("اسم الشاهد الأول") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { val str = it; onContractChange { c -> c.copy(witness2Name = str) } },
                label = { Text("اسم الشاهد الثاني") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.organizerName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(organizerName = str) } },
                label = { Text("اسم منظم العقد") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.notes,
                onValueChange = { val str = it; onContractChange { c -> c.copy(notes = str) } },
                label = { Text("الشروط والملاحظات الإضافية") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth().testTag("car_notes")
            )
        }
    }
}
