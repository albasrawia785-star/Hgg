package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.*

@Composable
fun RentalFormUi(
    contract: RentalContract,
    onContractChange: ((RentalContract) -> RentalContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        FormSectionCard(title = "معلومات العقد والتاريخ", icon = Icons.Default.Description) {
            ClearableOutlinedTextField(
                value = contract.contractNo,
                onValueChange = { val s = it; onContractChange { c -> c.copy(contractNo = s) } },
                label = { Text("رقم العقد") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("rental_contract_no")
            )
            DatePickerTextField(
                value = contract.signDate,
                onValueChange = { val s = it; onContractChange { c -> c.copy(signDate = s) } },
                label = "تاريخ التوقيع",
                modifier = Modifier.fillMaxWidth(),
                testTag = "rental_sign_date"
            )
            ClearableOutlinedTextField(
                value = contract.sequenceNumber,
                onValueChange = { val s = it; onContractChange { c -> c.copy(sequenceNumber = s) } },
                label = { Text("عدد التسلسل") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.doorsNumber,
                onValueChange = { val s = it; onContractChange { c -> c.copy(doorsNumber = s) } },
                label = { Text("رقم الأبواب") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "بيانات المؤجر والمستأجر", icon = Icons.Default.People) {
            ClearableOutlinedTextField(
                value = contract.lessorName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(lessorName = str) } },
                label = { Text("اسم المؤجر (الطرف الأول)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("rental_lessor_name")
            )
            ClearableOutlinedTextField(
                value = contract.lesseeName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(lesseeName = str) } },
                label = { Text("اسم المستأجر (الطرف الثاني)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("rental_lessee_name")
            )
        }

        FormSectionCard(title = "تفاصيل العين المؤجرة والمدة", icon = Icons.Default.Apartment) {
            ClearableOutlinedTextField(
                value = contract.rentedPropertyDescription,
                onValueChange = { val str = it; onContractChange { c -> c.copy(rentedPropertyDescription = str) } },
                label = { Text("وصف العين المؤجرة") },
                placeholder = { Text("مثال: دار سكنية / محل تجاري") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.propertyLocation,
                onValueChange = { val str = it; onContractChange { c -> c.copy(propertyLocation = str) } },
                label = { Text("الموقع / العنوان") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.neighborhood,
                onValueChange = { val str = it; onContractChange { c -> c.copy(neighborhood = str) } },
                label = { Text("المحلة") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.alleyNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(alleyNumber = str) } },
                label = { Text("الزقاق / الدار") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.leaseDuration,
                onValueChange = { val str = it; onContractChange { c -> c.copy(leaseDuration = str) } },
                label = { Text("مدة الإيجار") },
                placeholder = { Text("مثال: سنة واحدة") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            DatePickerTextField(
                value = contract.startDate,
                onValueChange = { val str = it; onContractChange { c -> c.copy(startDate = str) } },
                label = "ابتداءً من",
                modifier = Modifier.fillMaxWidth(),
                testTag = "rental_start_date"
            )
            DatePickerTextField(
                value = contract.endDate,
                onValueChange = { val str = it; onContractChange { c -> c.copy(endDate = str) } },
                label = "إلى نهاية",
                modifier = Modifier.fillMaxWidth(),
                testTag = "rental_end_date"
            )
        }

        FormSectionCard(title = "البدل المالي والضرائب", icon = Icons.Default.Payments) {
            ClearableOutlinedTextField(
                value = contract.rentAmountNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(rentAmountNumber = str) } },
                label = { Text("بدل الإيجار بالأرقام") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.rentAmountWords,
                onValueChange = { val str = it; onContractChange { c -> c.copy(rentAmountWords = str) } },
                label = { Text("بدل الإيجار كتابةً") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.dailyDelayFee,
                onValueChange = { val str = it; onContractChange { c -> c.copy(dailyDelayFee = str) } },
                label = { Text("غرامة التأخير اليومي") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.propertyTaxOwner,
                onValueChange = { val str = it; onContractChange { c -> c.copy(propertyTaxOwner = str) } },
                label = { Text("ضريبة الأملاك على") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "الشهود والشروط والملاحظات", icon = Icons.Default.VerifiedUser) {
            ClearableOutlinedTextField(
                value = contract.witness1Name,
                onValueChange = { val str = it; onContractChange { c -> c.copy(witness1Name = str) } },
                label = { Text("اسم الشاهد الأول") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { val str = it; onContractChange { c -> c.copy(witness2Name = str) } },
                label = { Text("اسم الشاهد الثاني") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.additionalClauses,
                onValueChange = { val str = it; onContractChange { c -> c.copy(additionalClauses = str) } },
                label = { Text("الشروط والملاحظات الإضافية") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth().testTag("rental_notes")
            )
        }
    }
}
