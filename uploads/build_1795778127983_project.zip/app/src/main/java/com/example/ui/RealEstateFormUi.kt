package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.*

@Composable
fun RealEstateFormUi(
    contract: RealEstateContract,
    onContractChange: ((RealEstateContract) -> RealEstateContract) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        FormSectionCard(title = "معلومات العقد الأساسية", icon = Icons.Default.Description) {
            ClearableOutlinedTextField(
                value = contract.contractNo,
                onValueChange = { val s = it; onContractChange { c -> c.copy(contractNo = s) } },
                label = { Text("رقم العقد") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("re_contract_no")
            )
            DatePickerTextField(
                value = contract.contractDate,
                onValueChange = { val s = it; onContractChange { c -> c.copy(contractDate = s) } },
                label = "تاريخ التحرير",
                modifier = Modifier.fillMaxWidth(),
                testTag = "re_contract_date"
            )
            ClearableOutlinedTextField(
                value = contract.contractPlace,
                onValueChange = { val s = it; onContractChange { c -> c.copy(contractPlace = s) } },
                label = { Text("مكان تحرير العقد") },
                placeholder = { Text("مثال: البصرة - الجزائر") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "بيانات الطرف الأول (البائع)", icon = Icons.Default.Person) {
            ClearableOutlinedTextField(
                value = contract.sellerName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerName = str) } },
                label = { Text("اسم البائع الثلاثي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("re_seller_name")
            )
            ClearableOutlinedTextField(
                value = contract.sellerPhone,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerPhone = str) } },
                label = { Text("رقم الهاتف") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("re_seller_phone")
            )
            ClearableOutlinedTextField(
                value = contract.sellerIdNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerIdNumber = str) } },
                label = { Text("رقم البطاقة الوطنية") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("re_seller_id")
            )
            ClearableOutlinedTextField(
                value = contract.sellerAddress,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerAddress = str) } },
                label = { Text("عنوان السكن") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "بيانات الطرف الثاني (المشتري)", icon = Icons.Default.PersonOutline) {
            ClearableOutlinedTextField(
                value = contract.buyerName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerName = str) } },
                label = { Text("اسم المشتري الثلاثي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("re_buyer_name")
            )
            ClearableOutlinedTextField(
                value = contract.buyerPhone,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerPhone = str) } },
                label = { Text("رقم الهاتف") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("re_buyer_phone")
            )
            ClearableOutlinedTextField(
                value = contract.buyerIdNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerIdNumber = str) } },
                label = { Text("رقم البطاقة الوطنية") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("re_buyer_id")
            )
            ClearableOutlinedTextField(
                value = contract.buyerAddress,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerAddress = str) } },
                label = { Text("عنوان السكن") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "تفاصيل العقار والموقع", icon = Icons.Default.HomeWork) {
            ClearableOutlinedTextField(
                value = contract.propertyType,
                onValueChange = { val str = it; onContractChange { c -> c.copy(propertyType = str) } },
                label = { Text("جنس العقار") },
                placeholder = { Text("دار سكني / قطعة أرض / زراعي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.propertyArea,
                onValueChange = { val str = it; onContractChange { c -> c.copy(propertyArea = str) } },
                label = { Text("المساحة (م²)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.plotSequenceNo,
                onValueChange = { val str = it; onContractChange { c -> c.copy(plotSequenceNo = str) } },
                label = { Text("رقم القطعة / التسلسل") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.neighborhood,
                onValueChange = { val str = it; onContractChange { c -> c.copy(neighborhood = str) } },
                label = { Text("المحلة / المقاطعة") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "التفاصيل المالية والشرط الجزائي", icon = Icons.Default.Payments) {
            ClearableOutlinedTextField(
                value = contract.totalPrice,
                onValueChange = { val str = it; onContractChange { c -> c.copy(totalPrice = str) } },
                label = { Text("السعر الكلي (أرقاماً)") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.totalPriceWords,
                onValueChange = { val str = it; onContractChange { c -> c.copy(totalPriceWords = str) } },
                label = { Text("السعر الكلي كتابةً") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.depositPrice,
                onValueChange = { val str = it; onContractChange { c -> c.copy(depositPrice = str) } },
                label = { Text("المبلغ المقبوض / العربون") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.remainingPrice,
                onValueChange = { val str = it; onContractChange { c -> c.copy(remainingPrice = str) } },
                label = { Text("المبلغ المتبقي") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.penaltySellerAmount,
                onValueChange = { val str = it; onContractChange { c -> c.copy(penaltySellerAmount = str) } },
                label = { Text("غرامة نكول البائع") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.penaltyBuyerAmount,
                onValueChange = { val str = it; onContractChange { c -> c.copy(penaltyBuyerAmount = str) } },
                label = { Text("غرامة نكول المشتري") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "الشهود والملاحظات", icon = Icons.Default.VerifiedUser) {
            ClearableOutlinedTextField(
                value = contract.witness1Name,
                onValueChange = { val str = it; onContractChange { c -> c.copy(witness1Name = str) } },
                label = { Text("اسم الشاهد الأول") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { val str = it; onContractChange { c -> c.copy(witness2Name = str) } },
                label = { Text("اسم الشاهد الثاني") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.additionalNotes,
                onValueChange = { val str = it; onContractChange { c -> c.copy(additionalNotes = str) } },
                label = { Text("الشروط والملاحظات الإضافية") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth().testTag("re_notes")
            )
        }
    }
}
