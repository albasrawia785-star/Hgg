package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.*

@Composable
fun MotorcycleFormUi(
    contract: MotorcycleContract,
    onContractChange: ((MotorcycleContract) -> MotorcycleContract) -> Unit,
    modifier: Modifier = Modifier
) {
    var showPossessorSection by remember {
        mutableStateOf(contract.possessorName.isNotBlank() || contract.possessorPhone.isNotBlank())
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        FormSectionCard(title = "معلومات العقد", icon = Icons.Default.Description) {
            ClearableOutlinedTextField(
                value = contract.contractNo,
                onValueChange = { val s = it; onContractChange { c -> c.copy(contractNo = s) } },
                label = { Text("رقم العقد") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("moto_contract_no")
            )
            DatePickerTextField(
                value = contract.contractDate,
                onValueChange = { val s = it; onContractChange { c -> c.copy(contractDate = s) } },
                label = "تاريخ العقد",
                modifier = Modifier.fillMaxWidth(),
                testTag = "moto_contract_date"
            )
        }

        FormSectionCard(title = "بيانات البائع", icon = Icons.Default.Person) {
            ClearableOutlinedTextField(
                value = contract.sellerName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerName = str) } },
                label = { Text("اسم البائع الثلاثي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("moto_seller_name")
            )
            ClearableOutlinedTextField(
                value = contract.sellerPhone,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerPhone = str) } },
                label = { Text("رقم الهاتف") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.sellerIdNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerIdNumber = str) } },
                label = { Text("رقم البطاقة الوطنية") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.sellerAddress,
                onValueChange = { val str = it; onContractChange { c -> c.copy(sellerAddress = str) } },
                label = { Text("عنوان البائع") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "بيانات المشتري", icon = Icons.Default.PersonOutline) {
            ClearableOutlinedTextField(
                value = contract.buyerName,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerName = str) } },
                label = { Text("اسم المشتري الثلاثي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth().testTag("moto_buyer_name")
            )
            ClearableOutlinedTextField(
                value = contract.buyerPhone,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerPhone = str) } },
                label = { Text("رقم الهاتف") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.buyerIdNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerIdNumber = str) } },
                label = { Text("رقم البطاقة الوطنية") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.buyerAddress,
                onValueChange = { val str = it; onContractChange { c -> c.copy(buyerAddress = str) } },
                label = { Text("عنوان المشتري") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "بيانات الدراجة / التكتك / الستوتة", icon = Icons.Default.TwoWheeler) {
            ClearableOutlinedTextField(
                value = contract.vehicleType,
                onValueChange = { val str = it; onContractChange { c -> c.copy(vehicleType = str) } },
                label = { Text("النوع (دراجة / تكتك / ستوتة)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.brand,
                onValueChange = { val str = it; onContractChange { c -> c.copy(brand = str) } },
                label = { Text("الماركة") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.registeredNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(registeredNumber = str) } },
                label = { Text("رقم اللوحة / التسجيل") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.color,
                onValueChange = { val str = it; onContractChange { c -> c.copy(color = str) } },
                label = { Text("اللون") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.chassisNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(chassisNumber = str) } },
                label = { Text("رقم الشاصي") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.engineNumber,
                onValueChange = { val str = it; onContractChange { c -> c.copy(engineNumber = str) } },
                label = { Text("رقم المحرك") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.engineCc,
                onValueChange = { val str = it; onContractChange { c -> c.copy(engineCc = str) } },
                label = { Text("حجم المحرك (CC)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        FormSectionCard(title = "التفاصيل المالية", icon = Icons.Default.Payments) {
            ClearableOutlinedTextField(
                value = contract.totalPrice,
                onValueChange = { val str = it; onContractChange { c -> c.copy(totalPrice = str) } },
                label = { Text("السعر الكلي (أرقاماً)") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.totalPriceWords,
                onValueChange = { val str = it; onContractChange { c -> c.copy(totalPriceWords = str) } },
                label = { Text("السعر كتابةً") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.paidAmount,
                onValueChange = { val str = it; onContractChange { c -> c.copy(paidAmount = str) } },
                label = { Text("المبلغ المقبوض") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.remainingAmount,
                onValueChange = { val str = it; onContractChange { c -> c.copy(remainingAmount = str) } },
                label = { Text("المبلغ المتبقي") },
                singleLine = true,
                visualTransformation = MoneyVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // قسم البائع الحائز (اختياري قابل للطي)
        FormSectionCard(title = "البائع الحائز (اختياري)", icon = Icons.Default.Badge) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showPossessorSection = !showPossessorSection }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (showPossessorSection) "إخفاء بيانات البائع الحائز" else "إضافة بيانات البائع الحائز",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
                Icon(
                    imageVector = if (showPossessorSection) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            AnimatedVisibility(visible = showPossessorSection) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    ClearableOutlinedTextField(
                        value = contract.possessorName,
                        onValueChange = { val str = it; onContractChange { c -> c.copy(possessorName = str) } },
                        label = { Text("اسم الحائز") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        modifier = Modifier.fillMaxWidth()
                    )
                    ClearableOutlinedTextField(
                        value = contract.possessorPhone,
                        onValueChange = { val str = it; onContractChange { c -> c.copy(possessorPhone = str) } },
                        label = { Text("هاتف الحائز") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                        modifier = Modifier.fillMaxWidth()
                    )
                    ClearableOutlinedTextField(
                        value = contract.possessorIdNumber,
                        onValueChange = { val str = it; onContractChange { c -> c.copy(possessorIdNumber = str) } },
                        label = { Text("بطاقة الحائز الوطنية") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        modifier = Modifier.fillMaxWidth()
                    )
                    ClearableOutlinedTextField(
                        value = contract.possessorAddress,
                        onValueChange = { val str = it; onContractChange { c -> c.copy(possessorAddress = str) } },
                        label = { Text("عنوان الحائز") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        FormSectionCard(title = "الشهود والملاحظات", icon = Icons.Default.VerifiedUser) {
            ClearableOutlinedTextField(
                value = contract.witness1Name,
                onValueChange = { val str = it; onContractChange { c -> c.copy(witness1Name = str) } },
                label = { Text("اسم الشاهد الأول") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.witness2Name,
                onValueChange = { val str = it; onContractChange { c -> c.copy(witness2Name = str) } },
                label = { Text("اسم الشاهد الثاني") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )
            ClearableOutlinedTextField(
                value = contract.notes,
                onValueChange = { val str = it; onContractChange { c -> c.copy(notes = str) } },
                label = { Text("الشروط والملاحظات الإضافية") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth().testTag("moto_notes")
            )
        }
    }
}
