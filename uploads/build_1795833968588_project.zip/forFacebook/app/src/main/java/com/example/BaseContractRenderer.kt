package com.example

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.annotation.ColorInt
import androidx.core.content.res.ResourcesCompat

/**
 * BaseContractRenderer: المحرك الأساسي الموحد لرسم العقود العراقية الرسمية على ورقة A4.
 * يوفر:
 * 1. خط أميري (Amiri) للعناوين الرسمية وخط النسخ (Noto Naskh Arabic) للنصوص القانونية.
 * 2. إطار عراقي رسمي مزدوج بزوايا هندسية كلاسيكية.
 * 3. ترويسة ثلاثية الأعمدة تتضمن البسملة وبيانات المكتب ورقم الإجازة والهواتف بدون إيموجي.
 * 4. جداول رسمية وخطوط منقطة متصلة (Vector Dash) ومربعات بصمة الإبهام وختم المكتب.
 * 5. علامة مائية خفيفة في منتصف الورقة تحترم ألوان القالب المختار.
 */
abstract class BaseContractRenderer {

    companion object {
        const val A4_WIDTH = 1240f
        const val A4_HEIGHT = 1754f

        @ColorInt val COLOR_PRIMARY = Color.parseColor("#0F172A")
        @ColorInt val COLOR_SECONDARY = Color.parseColor("#1E3A8A")
        @ColorInt val COLOR_TEXT = Color.parseColor("#111827")
        @ColorInt val COLOR_LABEL = Color.parseColor("#334155")
        @ColorInt val COLOR_BORDER = Color.parseColor("#64748B")
        @ColorInt val COLOR_BG_LIGHT = Color.parseColor("#F8FAFC")
        @ColorInt val COLOR_RED_ACCENT = Color.parseColor("#991B1B")
    }

    protected var displayTypeface: Typeface = Typeface.SERIF
    protected var displayBoldTypeface: Typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    protected var bodyTypeface: Typeface = Typeface.DEFAULT
    protected var bodyBoldTypeface: Typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

    protected val framePaint = Paint().apply {
        color = COLOR_PRIMARY
        style = Paint.Style.STROKE
        strokeWidth = 3.2f
        isAntiAlias = true
    }

    protected val innerFramePaint = Paint().apply {
        color = COLOR_BORDER
        style = Paint.Style.STROKE
        strokeWidth = 1.1f
        isAntiAlias = true
    }

    protected val titlePaint = Paint().apply {
        color = COLOR_PRIMARY
        textSize = 32f
        typeface = displayBoldTypeface
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    protected val subtitlePaint = Paint().apply {
        color = COLOR_LABEL
        textSize = 18f
        typeface = bodyBoldTypeface
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    protected val labelPaint = Paint().apply {
        color = COLOR_LABEL
        textSize = 17f
        typeface = bodyBoldTypeface
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val valuePaint = Paint().apply {
        color = COLOR_TEXT
        textSize = 18f
        typeface = bodyBoldTypeface
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val bodyTextPaint = Paint().apply {
        color = COLOR_TEXT
        textSize = 17f
        typeface = bodyTypeface
        textAlign = Paint.Align.RIGHT
        isAntiAlias = true
    }

    protected val dotPaint = Paint().apply {
        color = COLOR_BORDER
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        pathEffect = DashPathEffect(floatArrayOf(2.5f, 4.5f), 0f)
        isAntiAlias = true
    }

    protected var activeTemplate: ContractTemplate = ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE

    protected val outerMargin: Float
        get() = activeTemplate.marginDp.coerceIn(28f, 56f)

    protected val innerMargin: Float
        get() = outerMargin + 8f

    protected val contentLeft: Float
        get() = innerMargin + 16f

    protected val contentRight: Float
        get() = A4_WIDTH - innerMargin - 16f

    protected val contentWidth: Float
        get() = contentRight - contentLeft

    protected val footerBottomY: Float
        get() = A4_HEIGHT - innerMargin - 18f

    protected val footerTopY: Float
        get() = footerBottomY - 126f

    protected fun primaryColorInt(): Int = parseColorSafe(activeTemplate.primaryColorHex, COLOR_PRIMARY)
    protected fun secondaryColorInt(): Int = parseColorSafe(activeTemplate.secondaryColorHex, COLOR_SECONDARY)
    protected fun textColorInt(): Int = parseColorSafe(activeTemplate.textColorHex, COLOR_TEXT)
    protected fun borderColorInt(): Int = parseColorSafe(activeTemplate.borderColorHex, COLOR_BORDER)
    protected fun titleColorInt(): Int = parseColorSafe(activeTemplate.titleColorHex, primaryColorInt())

    protected fun parseColorSafe(hex: String, fallback: Int): Int {
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }

    protected fun tintColor(baseColor: Int, alpha: Int): Int {
        return Color.argb(
            alpha.coerceIn(0, 255),
            Color.red(baseColor),
            Color.green(baseColor),
            Color.blue(baseColor)
        )
    }

    private fun loadFonts(context: Context?) {
        val loadedAmiri = if (context != null) {
            try {
                ResourcesCompat.getFont(context, R.font.amiri)
            } catch (_: Exception) {
                null
            }
        } else null

        val loadedNaskh = if (context != null) {
            try {
                ResourcesCompat.getFont(context, R.font.noto_naskh_arabic)
            } catch (_: Exception) {
                null
            }
        } else null

        displayTypeface = loadedAmiri ?: Typeface.SERIF
        displayBoldTypeface = Typeface.create(displayTypeface, Typeface.BOLD)
        bodyTypeface = loadedNaskh ?: Typeface.DEFAULT
        bodyBoldTypeface = Typeface.create(bodyTypeface, Typeface.BOLD)
    }

    fun renderBitmap(
        contractData: Any,
        officeInfo: OfficeInfo = OfficeInfo(),
        context: Context? = null,
        overrideTemplate: ContractTemplate? = null
    ): Bitmap {
        activeTemplate = overrideTemplate ?: (
            context?.let { TemplateSettingsManager.getInstance(it).getEffectiveTemplate() }
                ?: ContractTemplateLibrary.DEFAULT_ORIGINAL_TEMPLATE
        )

        loadFonts(context)
        applyTemplatePaints(activeTemplate)

        val bitmap = Bitmap.createBitmap(A4_WIDTH.toInt(), A4_HEIGHT.toInt(), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgColor = parseColorSafe(activeTemplate.backgroundColorHex, Color.WHITE)
        canvas.drawColor(bgColor)

        // 1. علامة مائية خفيفة خلف محتوى العقد
        drawContractWatermark(canvas, officeInfo)

        // 2. الإطار العراقي الرسمي المزدوج
        if (activeTemplate.hasFrame) {
            drawA4Borders(canvas)
        }

        // 3. محتوى العقد
        drawContractContent(canvas, contractData, officeInfo, context)

        // 4. التذييل السفلي
        if (activeTemplate.showPageNumber) {
            drawFooterPageNumber(canvas)
        }

        return bitmap
    }

    protected fun applyTemplatePaints(template: ContractTemplate) {
        val primary = primaryColorInt()
        val secondary = secondaryColorInt()
        val textColor = textColorInt()
        val borderColor = borderColorInt()
        val titleColor = titleColorInt()

        framePaint.color = primary
        framePaint.strokeWidth = (3.2f * template.borderWidth).coerceAtLeast(1.2f)

        innerFramePaint.color = if (borderColor == Color.WHITE) primary else borderColor
        innerFramePaint.strokeWidth = (1.1f * template.borderWidth).coerceAtLeast(0.8f)

        titlePaint.color = titleColor
        titlePaint.typeface = displayBoldTypeface
        titlePaint.textSize = template.headerTextSize * template.fontScale

        subtitlePaint.color = secondary
        subtitlePaint.typeface = bodyBoldTypeface
        subtitlePaint.textSize = 18f * template.fontScale

        labelPaint.color = primary
        labelPaint.typeface = bodyBoldTypeface
        labelPaint.textSize = 18.5f * template.fontScale

        valuePaint.color = textColor
        valuePaint.typeface = bodyBoldTypeface
        valuePaint.textSize = 19.5f * template.fontScale

        bodyTextPaint.color = textColor
        bodyTextPaint.typeface = bodyTypeface
        bodyTextPaint.textSize = 18.5f * template.fontScale

        dotPaint.color = borderColor
    }

    protected open fun drawContractWatermark(canvas: Canvas, officeInfo: OfficeInfo) {
        val watermarkText = officeInfo.officeName.trim().ifEmpty { "وثيقة عقد رسمي" }
        val wmPaint = Paint().apply {
            color = tintColor(primaryColorInt(), 12)
            textSize = 72f
            typeface = displayBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val maxWmWidth = A4_WIDTH * 0.72f
        while (wmPaint.measureText(watermarkText) > maxWmWidth && wmPaint.textSize > 32f) {
            wmPaint.textSize -= 2f
        }
        canvas.save()
        canvas.rotate(-26f, A4_WIDTH / 2f, A4_HEIGHT / 2f)
        canvas.drawText(watermarkText, A4_WIDTH / 2f, A4_HEIGHT / 2f, wmPaint)
        canvas.restore()
    }

    /**
     * إطار عراقي هندسي كلاسيكي بزوايا حادة وإطار مزدوج وزوايا زخرفية رصينة
     */
    protected open fun drawA4Borders(canvas: Canvas) {
        val outer = outerMargin
        val outerRect = RectF(outer, outer, A4_WIDTH - outer, A4_HEIGHT - outer)
        canvas.drawRect(outerRect, framePaint)

        if (activeTemplate.isDoubleFrame) {
            val inner = innerMargin
            val innerRect = RectF(inner, inner, A4_WIDTH - inner, A4_HEIGHT - inner)
            val darkInnerPaint = Paint(innerFramePaint).apply {
                color = primaryColorInt()
                strokeWidth = (1.1f * activeTemplate.borderWidth).coerceAtLeast(0.8f)
            }
            canvas.drawRect(innerRect, darkInnerPaint)

            // زخرفة زوايا هندسية كلاسيكية بسيطة
            val cornerSize = 18f
            val cornerPaint = Paint().apply {
                color = primaryColorInt()
                style = Paint.Style.STROKE
                strokeWidth = 2f
                isAntiAlias = true
            }
            val corners = listOf(
                Pair(inner, inner) to Pair(1f, 1f),
                Pair(A4_WIDTH - inner, inner) to Pair(-1f, 1f),
                Pair(inner, A4_HEIGHT - inner) to Pair(1f, -1f),
                Pair(A4_WIDTH - inner, A4_HEIGHT - inner) to Pair(-1f, -1f)
            )
            for ((pt, dir) in corners) {
                val (cx, cy) = pt
                val (dx, dy) = dir
                canvas.drawLine(cx, cy + (cornerSize * dy), cx + (cornerSize * dx), cy + (cornerSize * dy), cornerPaint)
                canvas.drawLine(cx + (cornerSize * dx), cy, cx + (cornerSize * dx), cy + (cornerSize * dy), cornerPaint)
            }
        }
    }

    protected open fun drawFooterPageNumber(canvas: Canvas) {
        val footerPaint = Paint().apply {
            color = tintColor(textColorInt(), 170)
            textSize = 13.5f * activeTemplate.fontScale
            typeface = bodyTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val y = A4_HEIGHT - outerMargin + 18f
        val safeY = y.coerceAtMost(A4_HEIGHT - 12f)
        canvas.drawText("نسخة رسمية مطبوعة • صفحة ١ من ١", A4_WIDTH / 2f, safeY, footerPaint)
    }

    protected abstract fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    )

    /**
     * الترويسة العراقية الرسمية الموحدة (ثلاثية الأعمدة + البسملة + رقم الإجازة + الهواتف بدون إيموجي)
     */
    protected fun drawIraqiOfficialHeader(
        canvas: Canvas,
        officeInfo: OfficeInfo,
        defaultOfficeName: String,
        specialtyText: String,
        contractTitle: String,
        contractSubtitle: String,
        contractNo: String,
        contractDate: String,
        extraMetaLabel: String = "",
        extraMetaValue: String = "",
        overrideOfficeName: String = "",
        overrideOfficePhone: String = "",
        overrideOfficeAddress: String = ""
    ): Float {
        val primary = primaryColorInt()
        val secondary = secondaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale
        val isMonochrome = activeTemplate.id == "monochrome_bw"

        var curY = innerMargin + 30f

        // 1. البسملة في أعلى المنتصف بشكل رسمي أنيق (مثل الكتب الرسمية والكتب القضائية)
        val bismillahPaint = Paint().apply {
            color = primary
            textSize = 25f * scale
            typeface = displayBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("بسم الله الرحمن الرحيم", A4_WIDTH / 2f, curY + 6f, bismillahPaint)

        curY += 18f
        val ornamentPaint = Paint().apply {
            color = tintColor(primary, 120)
            strokeWidth = 1.5f
            isAntiAlias = true
        }
        canvas.drawLine(A4_WIDTH / 2f - 140f, curY, A4_WIDTH / 2f + 140f, curY, ornamentPaint)
        val dotPaint = Paint().apply {
            color = primary
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawCircle(A4_WIDTH / 2f, curY, 3f, dotPaint)

        curY += 6f

        val headerTop = curY + 12f
        val headerHeight = 148f
        val headerBottom = headerTop + headerHeight

        val rightColW = contentWidth * 0.305f
        val centerColW = contentWidth * 0.35f
        val leftColW = contentWidth * 0.305f

        val rightColRight = contentRight
        val centerCenterX = A4_WIDTH / 2f
        val leftColLeft = contentLeft
        val leftColRight = leftColLeft + leftColW

        // ==================== العمود الأيمن: بيانات المكتب / المعرض ====================
        val effectiveName = overrideOfficeName.trim().ifEmpty {
            officeInfo.officeName.trim().ifEmpty { defaultOfficeName }
        }
        val effectiveAddress = overrideOfficeAddress.trim().ifEmpty {
            officeInfo.address.trim().ifEmpty { "العراق" }
        }
        val licenseNo = officeInfo.licenseNo.trim()
        val p1 = officeInfo.phone.trim()
        val p2 = officeInfo.phone2.trim()
        val phonesDisplay = overrideOfficePhone.trim().ifEmpty {
            officeInfo.formattedPhones()
        }

        var rY = headerTop + 26f
        val officeNamePaint = Paint().apply {
            color = primary
            textSize = 27f * scale
            typeface = displayBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        fitTextToWidth(officeNamePaint, effectiveName, rightColW - 8f, 16f)
        canvas.drawText(effectiveName, rightColRight, rY, officeNamePaint)

        rY += 27f
        val specPaint = Paint().apply {
            color = if (isMonochrome) dark else secondary
            textSize = 15.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        fitTextToWidth(specPaint, specialtyText, rightColW - 8f, 11.5f)
        canvas.drawText(specialtyText, rightColRight, rY, specPaint)

        val metaRightPaint = Paint().apply {
            color = dark
            textSize = 14.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }

        if (licenseNo.isNotBlank()) {
            rY += 23f
            val licText = "إجازة ممارسة المهنة: $licenseNo"
            fitTextToWidth(metaRightPaint, licText, rightColW - 8f, 11f)
            canvas.drawText(licText, rightColRight, rY, metaRightPaint)
        }

        rY += 23f
        val addrText = "العنوان: $effectiveAddress"
        val addrPaint = Paint(metaRightPaint)
        fitTextToWidth(addrPaint, addrText, rightColW - 8f, 11f)
        canvas.drawText(addrText, rightColRight, rY, addrPaint)

        if (overrideOfficePhone.isBlank() && p1.isNotBlank() && p2.isNotBlank()) {
            rY += 23f
            val dualPhonesText = "هاتف: $p1  |  $p2"
            val phonePaint = Paint(metaRightPaint)
            if (phonePaint.measureText(dualPhonesText) <= rightColW - 8f) {
                canvas.drawText(dualPhonesText, rightColRight, rY, phonePaint)
            } else {
                canvas.drawText("هاتف ١: $p1", rightColRight, rY, phonePaint)
                rY += 20f
                canvas.drawText("هاتف ٢: $p2", rightColRight, rY, phonePaint)
            }
        } else if (phonesDisplay.isNotBlank()) {
            rY += 23f
            val phoneText = "هاتف: $phonesDisplay"
            val phonePaint = Paint(metaRightPaint)
            fitTextToWidth(phonePaint, phoneText, rightColW - 8f, 11f)
            canvas.drawText(phoneText, rightColRight, rY, phonePaint)
        }

        // ==================== العمود الأوسط: لوحة عنوان العقد الرسمي ====================
        val plaqueTop = if (activeTemplate.hasLogo) headerTop + 26f else headerTop + 10f
        if (activeTemplate.hasLogo) {
            // شعار هندسي كلاسيكي بسيط جداً ورصين
            val emblemY = headerTop + 12f
            val embPaint = Paint().apply {
                color = primary
                style = Paint.Style.STROKE
                strokeWidth = 1.6f
                isAntiAlias = true
            }
            val diamond = Path().apply {
                moveTo(centerCenterX, emblemY - 9f)
                lineTo(centerCenterX + 10f, emblemY)
                lineTo(centerCenterX, emblemY + 9f)
                lineTo(centerCenterX - 10f, emblemY)
                close()
            }
            canvas.drawPath(diamond, embPaint)
            canvas.drawLine(centerCenterX - 52f, emblemY, centerCenterX - 16f, emblemY, embPaint)
            canvas.drawLine(centerCenterX + 16f, emblemY, centerCenterX + 52f, emblemY, embPaint)
        }

        val plaqueHalfW = (centerColW / 2f) - 10f
        val plaqueHeight = 76f
        val plaqueRect = RectF(
            centerCenterX - plaqueHalfW,
            plaqueTop,
            centerCenterX + plaqueHalfW,
            plaqueTop + plaqueHeight
        )
        val plaqueBg = Paint().apply {
            color = tintColor(primary, 14)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val plaqueBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 2.2f
            isAntiAlias = true
        }
        val plaqueInnerBorder = Paint().apply {
            color = tintColor(primary, 150)
            style = Paint.Style.STROKE
            strokeWidth = 0.9f
            isAntiAlias = true
        }
        canvas.drawRect(plaqueRect, plaqueBg)
        canvas.drawRect(plaqueRect, plaqueBorder)
        canvas.drawRect(
            RectF(plaqueRect.left + 4f, plaqueRect.top + 4f, plaqueRect.right - 4f, plaqueRect.bottom - 4f),
            plaqueInnerBorder
        )

        val mainTitlePaint = Paint().apply {
            color = titleColorInt()
            textSize = 29f * scale
            typeface = displayBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        fitTextToWidth(mainTitlePaint, contractTitle, plaqueRect.width() - 22f, 18f)
        canvas.drawText(contractTitle, centerCenterX, plaqueRect.centerY() + (mainTitlePaint.textSize * 0.32f), mainTitlePaint)

        val subPaint = Paint().apply {
            color = if (isMonochrome) dark else secondary
            textSize = 15.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        fitTextToWidth(subPaint, contractSubtitle, centerColW - 12f, 11.5f)
        canvas.drawText(contractSubtitle, centerCenterX, plaqueRect.bottom + 24f, subPaint)

        // ==================== العمود الأيسر: جدول التوثيق (الرقم والتاريخ) ====================
        val metaRows = mutableListOf(
            "رقم العقد" to contractNo.ifBlank { "—" },
            "التاريخ" to contractDate.ifBlank { "—/—/2026" }
        )
        if (extraMetaLabel.isNotBlank()) {
            metaRows.add(extraMetaLabel to extraMetaValue.ifBlank { "—" })
        }
        val rowH = if (metaRows.size == 3) 40f else 48f
        val metaTableTop = headerTop + 12f
        val metaTableH = rowH * metaRows.size
        val metaRect = RectF(leftColLeft, metaTableTop, leftColRight, metaTableTop + metaTableH)

        val metaBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val metaThin = Paint().apply {
            color = tintColor(primary, 170)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        val labelColSplit = metaRect.right - (leftColW * 0.36f)
        val metaLabelBg = Paint().apply {
            color = tintColor(primary, 16)
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        canvas.drawRect(RectF(labelColSplit, metaRect.top, metaRect.right, metaRect.bottom), metaLabelBg)
        canvas.drawRect(metaRect, metaBorder)
        canvas.drawLine(labelColSplit, metaRect.top, labelColSplit, metaRect.bottom, metaThin)

        val mLblPaint = Paint().apply {
            color = primary
            textSize = 14.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val mValPaint = Paint().apply {
            color = dark
            textSize = 15.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        metaRows.forEachIndexed { idx, (lbl, valText) ->
            val rTop = metaRect.top + (idx * rowH)
            if (idx > 0) {
                canvas.drawLine(metaRect.left, rTop, metaRect.right, rTop, metaThin)
            }
            val textY = rTop + (rowH / 2f) + 5.5f
            val lblP = Paint(mLblPaint)
            fitTextToWidth(lblP, lbl, (metaRect.right - labelColSplit) - 8f, 10.5f)
            canvas.drawText(lbl, (labelColSplit + metaRect.right) / 2f, textY, lblP)

            val valP = Paint(mValPaint).apply {
                color = if (idx == 0 && !isMonochrome) COLOR_RED_ACCENT else dark
            }
            fitTextToWidth(valP, valText, (labelColSplit - metaRect.left) - 10f, 10.5f)
            canvas.drawText(valText, (metaRect.left + labelColSplit) / 2f, textY, valP)
        }

        // خط فاصل مزدوج بعرض الصفحة أسفل الترويسة
        val divY = headerBottom + 4f
        val thickDiv = Paint().apply {
            color = primary
            strokeWidth = 2.4f
            isAntiAlias = true
        }
        val thinDiv = Paint().apply {
            color = tintColor(primary, 160)
            strokeWidth = 1f
            isAntiAlias = true
        }
        canvas.drawLine(contentLeft, divY, contentRight, divY, thickDiv)
        canvas.drawLine(contentLeft, divY + 4.5f, contentRight, divY + 4.5f, thinDiv)

        return divY + 18f
    }

    /**
     * عنوان قسم رسمي حاد الزوايا بشريط علوي وسفلي وتظليل خفيف
     */
    protected fun drawIraqiSectionBanner(
        canvas: Canvas,
        title: String,
        topY: Float,
        height: Float = 36f,
        alignCenter: Boolean = false
    ): Float {
        val primary = primaryColorInt()
        val rect = RectF(contentLeft, topY, contentRight, topY + height)
        val bg = Paint().apply {
            color = tintColor(primary, 20)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val border = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
            isAntiAlias = true
        }
        canvas.drawRect(rect, bg)
        canvas.drawLine(rect.left, rect.top, rect.right, rect.top, border)
        canvas.drawLine(rect.left, rect.bottom, rect.right, rect.bottom, border)
        canvas.drawLine(rect.left, rect.top, rect.left, rect.bottom, border)
        canvas.drawLine(rect.right, rect.top, rect.right, rect.bottom, border)

        val textP = Paint().apply {
            color = primary
            textSize = 18.5f * activeTemplate.fontScale
            typeface = bodyBoldTypeface
            textAlign = if (alignCenter) Paint.Align.CENTER else Paint.Align.RIGHT
            isAntiAlias = true
        }
        val textX = if (alignCenter) rect.centerX() else rect.right - 14f
        fitTextToWidth(textP, title, rect.width() - 28f, 14f)
        canvas.drawText(title, textX, rect.centerY() + (textP.textSize * 0.34f), textP)
        return rect.bottom
    }

    /**
     * جدول الطرفين الرسمي (عمودان متجاوران بحدود حادة وخطوط منقطة متصلة)
     */
    protected fun drawFormalPartiesTable(
        canvas: Canvas,
        topY: Float,
        rightTitle: String,
        leftTitle: String,
        rightFields: List<Pair<String, String>>,
        leftFields: List<Pair<String, String>>,
        rowSpacing: Float = 38f
    ): Float {
        val rowCount = maxOf(rightFields.size, leftFields.size)
        val headerH = 36f
        val bodyPadTop = 18f
        val bodyPadBottom = 14f
        val tableHeight = headerH + bodyPadTop + (rowCount * rowSpacing) + bodyPadBottom

        val tableRect = RectF(contentLeft, topY, contentRight, topY + tableHeight)
        val midX = tableRect.centerX()

        val primary = primaryColorInt()
        val headerBg = Paint().apply {
            color = tintColor(primary, 24)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val outerBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        val divider = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
            isAntiAlias = true
        }

        // خلفية صف العناوين
        canvas.drawRect(RectF(tableRect.left, tableRect.top, tableRect.right, tableRect.top + headerH), headerBg)
        canvas.drawRect(tableRect, outerBorder)
        canvas.drawLine(tableRect.left, tableRect.top + headerH, tableRect.right, tableRect.top + headerH, divider)
        canvas.drawLine(midX, tableRect.top, midX, tableRect.bottom, divider)

        val hdrPaint = Paint().apply {
            color = primary
            textSize = 19.5f * activeTemplate.fontScale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(rightTitle, (midX + tableRect.right) / 2f, tableRect.top + 24f, hdrPaint)
        canvas.drawText(leftTitle, (tableRect.left + midX) / 2f, tableRect.top + 24f, hdrPaint)

        val colW = (tableRect.width() / 2f) - 24f
        val rStartX = tableRect.right - 12f
        val lStartX = midX - 12f

        rightFields.forEachIndexed { idx, (label, value) ->
            val y = tableRect.top + headerH + bodyPadTop + 16f + (idx * rowSpacing)
            drawFieldWithDots(canvas, label, value, rStartX, y, colW)
        }
        leftFields.forEachIndexed { idx, (label, value) ->
            val y = tableRect.top + headerH + bodyPadTop + 16f + (idx * rowSpacing)
            drawFieldWithDots(canvas, label, value, lStartX, y, colW)
        }

        return tableRect.bottom
    }

    /**
     * رسم حقل مع تسمية وخط منقط متصل أسفل المساحة المتبقية (جاهز للكتابة أو الطباعة)
     */
    protected fun drawFieldWithDots(
        canvas: Canvas,
        label: String,
        value: String,
        x: Float,
        y: Float,
        totalWidth: Float,
        labelWidth: Float = 0f
    ) {
        var currentX = x
        if (label.isNotEmpty()) {
            labelPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(label, currentX, y, labelPaint)
            val computedLabelWidth = if (labelWidth > 0f) labelWidth else labelPaint.measureText(label) + 10f
            currentX -= computedLabelWidth
        }

        val leftEdgeX = x - totalWidth
        val spaceWidth = (currentX - leftEdgeX).coerceAtLeast(24f)

        // خط منقط رسمي متصل أسفل قيمة الحقل
        canvas.drawLine(leftEdgeX, y + 5f, currentX, y + 5f, dotPaint)

        if (value.isNotBlank()) {
            drawRtlText(
                canvas = canvas,
                text = value,
                x = currentX - 2f,
                y = y,
                maxWidth = spaceWidth - 4f,
                paint = valuePaint,
                align = Paint.Align.RIGHT,
                maxLines = 1
            )
        }
    }

    protected fun drawRtlText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        maxWidth: Float,
        paint: Paint = valuePaint,
        align: Paint.Align = Paint.Align.RIGHT,
        maxLines: Int = 3,
        lineSpacingMultiplier: Float = 1.32f
    ) {
        if (text.isEmpty() || maxWidth <= 0f) return

        val originalSize = paint.textSize
        val currentPaint = Paint(paint).apply { textAlign = align }
        val minTextSize = (originalSize * 0.78f).coerceAtLeast(13.5f)

        while (currentPaint.measureText(text) > maxWidth && currentPaint.textSize > minTextSize) {
            currentPaint.textSize -= 0.5f
        }

        if (maxLines > 1 && currentPaint.measureText(text) > maxWidth) {
            val words = text.split(" ")
            val lines = mutableListOf<String>()
            var currentLine = ""

            for (word in words) {
                val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
                if (currentPaint.measureText(testLine) <= maxWidth) {
                    currentLine = testLine
                } else {
                    if (currentLine.isNotEmpty()) lines.add(currentLine)
                    currentLine = word
                }
                if (lines.size >= maxLines - 1) break
            }
            if (currentLine.isNotEmpty() && lines.size < maxLines) {
                lines.add(currentLine)
            }

            var currentY = y
            val lineStep = currentPaint.textSize * lineSpacingMultiplier
            for (line in lines) {
                canvas.drawText(line, x, currentY, currentPaint)
                currentY += lineStep
            }
        } else {
            canvas.drawText(text, x, y, currentPaint)
        }

        paint.textSize = originalSize
    }

    /**
     * رسم نص عربي متعدد الأسطر باستخدام StaticLayout بمحاذاة RTL حقيقية لمنع أي قص أو تداخل
     */
    protected fun drawRtlParagraph(
        canvas: Canvas,
        text: String,
        leftX: Float,
        topY: Float,
        width: Float,
        textSize: Float = 16.5f * activeTemplate.fontScale,
        color: Int = textColorInt(),
        typeface: Typeface = bodyTypeface,
        lineSpacingMult: Float = 1.18f
    ): Float {
        if (text.isBlank() || width <= 20f) return 0f
        val tp = TextPaint().apply {
            this.color = color
            this.textSize = textSize
            this.typeface = typeface
            isAntiAlias = true
        }
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, tp, width.toInt())
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setLineSpacing(0f, lineSpacingMult)
            .setIncludePad(false)
            .build()

        canvas.save()
        canvas.translate(leftX, topY)
        layout.draw(canvas)
        canvas.restore()
        return layout.height.toFloat()
    }

    /**
     * رسم قائمة البنود القانونية العراقية المرقمة بترتيب رسمي نظيف بدون تداخل العنوان مع النص
     */
    protected fun drawIraqiLegalClauses(
        canvas: Canvas,
        clauses: List<Pair<String, String>>,
        startY: Float,
        maxBottomY: Float
    ): Float {
        var curY = startY
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale
        val paragraphGap = activeTemplate.paragraphSpacingDp.coerceIn(6f, 14f)

        val dividerPaint = Paint().apply {
            color = tintColor(borderColorInt(), 110)
            strokeWidth = 0.8f
            isAntiAlias = true
        }

        // دمج التسمية مع النص في فقرة متصلة بعرض الصفحة الكامل لمنع أي تداخل ولتمكين خط أكبر وأوضح
        val spannedClauses = clauses.map { (label, body) ->
            val prefix = "$label: "
            val full = "$prefix$body"
            SpannableString(full).apply {
                setSpan(ForegroundColorSpan(primary), 0, prefix.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(StyleSpan(Typeface.BOLD), 0, prefix.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }

        var bodySize = 19.5f * scale
        val availHeight = (maxBottomY - startY).coerceAtLeast(120f)
        val layoutWidth = contentWidth.toInt().coerceAtLeast(100)
        while (bodySize > 15.5f) {
            var estHeight = 0f
            val tp = TextPaint().apply {
                this.textSize = bodySize
                this.typeface = bodyBoldTypeface
            }
            for (spanned in spannedClauses) {
                val sl = StaticLayout.Builder
                    .obtain(spanned, 0, spanned.length, tp, layoutWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setLineSpacing(0f, 1.16f)
                    .setIncludePad(false)
                    .build()
                estHeight += sl.height + paragraphGap + 4f
            }
            if (estHeight <= availHeight) break
            bodySize -= 0.5f
        }

        val tp = TextPaint().apply {
            color = dark
            textSize = bodySize
            typeface = bodyBoldTypeface
            isAntiAlias = true
        }

        spannedClauses.forEachIndexed { idx, spanned ->
            val layout = StaticLayout.Builder
                .obtain(spanned, 0, spanned.length, tp, layoutWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setLineSpacing(0f, 1.16f)
                .setIncludePad(false)
                .build()

            canvas.save()
            canvas.translate(contentLeft, curY)
            layout.draw(canvas)
            canvas.restore()

            curY += layout.height.toFloat() + (paragraphGap * 0.5f)
            if (idx < spannedClauses.lastIndex) {
                canvas.drawLine(contentLeft, curY, contentRight, curY, dividerPaint)
            }
            curY += (paragraphGap * 0.5f) + 2f
        }

        return curY
    }

    /**
     * رسم قسم الشروط والملاحظات الإضافية أسفل البنود في جميع العقود
     */
    protected fun drawAdditionalNotesBlock(
        canvas: Canvas,
        notes: String,
        startY: Float,
        maxBottomY: Float = footerTopY - 10f
    ): Float {
        if (startY >= maxBottomY - 24f) return startY
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale

        val labelPaintNotes = Paint().apply {
            color = primary
            textSize = 17.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        canvas.drawText("شروط وملاحظات إضافية:", contentRight, startY + 16f, labelPaintNotes)
        var curY = startY + 25f

        val cleanNotes = notes.trim()
        if (cleanNotes.isNotBlank()) {
            val availH = (maxBottomY - curY).coerceAtLeast(24f)
            var noteSize = 17.5f * scale
            val tp = TextPaint().apply {
                color = dark
                typeface = bodyBoldTypeface
                isAntiAlias = true
            }
            var layout: StaticLayout
            while (true) {
                tp.textSize = noteSize
                layout = StaticLayout.Builder
                    .obtain(cleanNotes, 0, cleanNotes.length, tp, contentWidth.toInt())
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .setLineSpacing(0f, 1.16f)
                    .setIncludePad(false)
                    .build()
                if (layout.height <= availH || noteSize <= 14f) break
                noteSize -= 0.5f
            }
            canvas.save()
            canvas.translate(contentLeft, curY)
            layout.draw(canvas)
            canvas.restore()
            curY += layout.height.toFloat() + 6f
        } else {
            if (curY + 14f < maxBottomY) {
                canvas.drawLine(contentLeft, curY + 14f, contentRight, curY + 14f, dotPaint)
                curY += 24f
            }
            if (curY + 14f < maxBottomY) {
                canvas.drawLine(contentLeft, curY + 14f, contentRight, curY + 14f, dotPaint)
                curY += 22f
            }
        }
        return curY
    }

    data class FinancialBoxItem(
        val label: String,
        val numberValue: String,
        val wordsValue: String = "",
        val accentColor: Int
    )

    /**
     * رسم الشريط المالي الرسمي (3 خانات متساوية بحدود حادة مع عرض المبالغ رقماً وكتابةً)
     */
    protected fun drawFinancialSummaryTable(
        canvas: Canvas,
        topY: Float,
        items: List<Triple<String, String, Int>>,
        wordsRowLabel: String = "",
        wordsRowValue: String = ""
    ): Float {
        return drawFinancialSummaryTableWithWords(
            canvas = canvas,
            topY = topY,
            items = items.map { (lbl, num, col) -> FinancialBoxItem(lbl, num, "", col) },
            wordsRowLabel = wordsRowLabel,
            wordsRowValue = wordsRowValue
        )
    }

    protected fun drawFinancialSummaryTableWithWords(
        canvas: Canvas,
        topY: Float,
        items: List<FinancialBoxItem>,
        wordsRowLabel: String = "",
        wordsRowValue: String = ""
    ): Float {
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale
        val isMonochrome = activeTemplate.id == "monochrome_bw"

        var curY = topY
        val outerBorder = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 2f
            isAntiAlias = true
        }
        val innerLine = Paint().apply {
            color = tintColor(primary, 170)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        val headerBg = Paint().apply {
            color = tintColor(primary, 20)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        val wordsSubBg = Paint().apply {
            color = tintColor(primary, 8)
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        if (wordsRowLabel.isNotBlank()) {
            val cleanWords = wordsRowValue.trim()
            val rightPad = 12f
            val leftPad = 12f
            labelPaint.textAlign = Paint.Align.RIGHT
            val lblW = labelPaint.measureText(wordsRowLabel) + 12f
            val availWordsW = (contentWidth - rightPad - leftPad - lblW).toInt().coerceAtLeast(140)

            var wordsLayout: StaticLayout? = null
            var wordsTextSize = 18f * scale
            if (cleanWords.isNotBlank()) {
                val tp = TextPaint().apply {
                    color = dark
                    typeface = bodyBoldTypeface
                    isAntiAlias = true
                }
                while (true) {
                    tp.textSize = wordsTextSize
                    wordsLayout = StaticLayout.Builder
                        .obtain(cleanWords, 0, cleanWords.length, tp, availWordsW)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setLineSpacing(0f, 1.12f)
                        .setMaxLines(2)
                        .setIncludePad(false)
                        .build()
                    if ((wordsLayout.lineCount <= 2 && wordsLayout.height <= 48) || wordsTextSize <= 13f) break
                    wordsTextSize -= 0.5f
                }
            }

            val wordsH = if (wordsLayout != null && wordsLayout.lineCount > 1) {
                (wordsLayout.height + 22f).coerceIn(54f, 68f)
            } else {
                40f
            }

            val wordsRect = RectF(contentLeft, curY, contentRight, curY + wordsH)
            canvas.drawRect(wordsRect, headerBg)
            canvas.drawRect(wordsRect, outerBorder)

            val labelX = wordsRect.right - rightPad
            val labelY = wordsRect.top + 26f
            canvas.drawText(wordsRowLabel, labelX, labelY, labelPaint)

            val valueRightX = labelX - lblW
            val valueLeftX = wordsRect.left + leftPad

            if (wordsLayout != null) {
                val textTopY = if (wordsLayout.lineCount > 1) {
                    wordsRect.top + ((wordsH - wordsLayout.height) / 2f)
                } else {
                    wordsRect.top + ((wordsH - wordsLayout.height) / 2f)
                }
                canvas.save()
                canvas.translate(valueLeftX, textTopY)
                wordsLayout.draw(canvas)
                canvas.restore()
            } else {
                canvas.drawLine(valueLeftX, labelY + 5f, valueRightX, labelY + 5f, dotPaint)
            }

            curY = wordsRect.bottom + 8f
        }

        val cols = items.size.coerceAtLeast(1)
        val hasAnyColumnWords = items.any { it.wordsValue.isNotBlank() }
        val lblH = 28f
        val numH = 38f
        val wordsAreaH = if (hasAnyColumnWords) 54f else 12f
        val boxH = lblH + numH + wordsAreaH

        val tableRect = RectF(contentLeft, curY, contentRight, curY + boxH)
        val colW = tableRect.width() / cols

        canvas.drawRect(RectF(tableRect.left, tableRect.top, tableRect.right, tableRect.top + lblH), headerBg)
        if (hasAnyColumnWords) {
            canvas.drawRect(
                RectF(tableRect.left, tableRect.top + lblH + numH, tableRect.right, tableRect.bottom),
                wordsSubBg
            )
        }
        canvas.drawRect(tableRect, outerBorder)
        canvas.drawLine(tableRect.left, tableRect.top + lblH, tableRect.right, tableRect.top + lblH, innerLine)
        if (hasAnyColumnWords) {
            val sepY = tableRect.top + lblH + numH
            val subSepPaint = Paint().apply {
                color = tintColor(primary, 90)
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
                isAntiAlias = true
            }
            canvas.drawLine(tableRect.left, sepY, tableRect.right, sepY, subSepPaint)
        }

        val lblP = Paint().apply {
            color = primary
            textSize = 15.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        items.forEachIndexed { i, item ->
            val colRight = tableRect.right - (i * colW)
            val colLeft = colRight - colW
            val cx = (colLeft + colRight) / 2f
            if (i > 0) {
                canvas.drawLine(colRight, tableRect.top, colRight, tableRect.bottom, innerLine)
            }
            val headerPaint = Paint(lblP)
            fitTextToWidth(headerPaint, item.label, colW - 14f, 12f)
            canvas.drawText(item.label, cx, tableRect.top + 20f, headerPaint)

            val valP = Paint().apply {
                color = if (isMonochrome) dark else item.accentColor
                textSize = 20f * scale
                typeface = bodyBoldTypeface
                textAlign = Paint.Align.CENTER
                isAntiAlias = true
            }
            val displayVal = item.numberValue.ifBlank { "............................" }
            drawRtlText(
                canvas = canvas,
                text = displayVal,
                x = cx,
                y = tableRect.top + lblH + 26f,
                maxWidth = colW - 16f,
                paint = valP,
                align = Paint.Align.CENTER,
                maxLines = 1
            )

            if (hasAnyColumnWords && item.wordsValue.isNotBlank()) {
                val cellWords = item.wordsValue.trim()
                val availW = (colW - 16f).toInt().coerceAtLeast(80)
                val availH = wordsAreaH - 6f
                var wSize = 13.5f * scale
                val wTp = TextPaint().apply {
                    color = dark
                    typeface = bodyBoldTypeface
                    isAntiAlias = true
                }
                var wLayout: StaticLayout
                while (true) {
                    wTp.textSize = wSize
                    wLayout = StaticLayout.Builder
                        .obtain(cellWords, 0, cellWords.length, wTp, availW)
                        .setAlignment(Layout.Alignment.ALIGN_CENTER)
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setLineSpacing(0f, 1.08f)
                        .setMaxLines(3)
                        .setIncludePad(false)
                        .build()
                    if ((wLayout.lineCount <= 3 && wLayout.height <= availH) || wSize <= 10f) break
                    wSize -= 0.5f
                }
                val wordsTopY = tableRect.top + lblH + numH + ((wordsAreaH - wLayout.height) / 2f).coerceAtLeast(2f)
                canvas.save()
                canvas.translate(colLeft + 8f, wordsTopY)
                wLayout.draw(canvas)
                canvas.restore()
            }
        }

        return tableRect.bottom
    }

    /**
     * تذييل التوثيق البسيط داخل مستطيل واحد بحواف دائرية بدون تقسيمات داخلية وبدون خانة منظم العقد:
     * الطرف الأول (يمين) | الشاهد الأول | الشاهد الثاني | الطرف الثاني (يسار)
     */
    protected fun drawIraqiSignaturesFooter(
        canvas: Canvas,
        party1Title: String,
        party2Title: String,
        witness1Name: String = "",
        witness2Name: String = "",
        organizerName: String = "",
        stampTitle: String = "",
        topY: Float = footerTopY,
        bottomY: Float = footerBottomY
    ) {
        val primary = primaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale

        val rect = RectF(contentLeft, topY, contentRight, bottomY)
        val borderPaint = Paint().apply {
            color = dark
            style = Paint.Style.STROKE
            strokeWidth = 1.6f
            isAntiAlias = true
        }
        canvas.drawRoundRect(rect, 18f, 18f, borderPaint)

        val hasAnyWitnessName = witness1Name.isNotBlank() || witness2Name.isNotBlank()
        val titleY = if (hasAnyWitnessName) rect.top + 38f else rect.centerY() + 6f
        val colW = rect.width() / 4f

        val p1Paint = Paint().apply {
            color = primary
            textSize = 19.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        val otherPaint = Paint().apply {
            color = dark
            textSize = 19.5f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        val items = listOf(
            Triple(party1Title, "", p1Paint),
            Triple("الشاهد الأول", witness1Name.trim(), otherPaint),
            Triple("الشاهد الثاني", witness2Name.trim(), otherPaint),
            Triple(party2Title, "", otherPaint)
        )

        items.forEachIndexed { idx, (title, nameVal, basePaint) ->
            val colRight = rect.right - (idx * colW)
            val colLeft = colRight - colW
            val cx = (colLeft + colRight) / 2f

            val titleP = Paint(basePaint)
            fitTextToWidth(titleP, title, colW - 18f, 14f)
            canvas.drawText(title, cx, titleY, titleP)

            if (nameVal.isNotBlank()) {
                val availW = (colW - 18f).toInt().coerceAtLeast(80)
                var nameSize = 20.5f * scale
                val tp = TextPaint().apply {
                    color = dark
                    typeface = bodyBoldTypeface
                    isAntiAlias = true
                }
                var layout: StaticLayout
                while (true) {
                    tp.textSize = nameSize
                    layout = StaticLayout.Builder
                        .obtain(nameVal, 0, nameVal.length, tp, availW)
                        .setAlignment(Layout.Alignment.ALIGN_CENTER)
                        .setTextDirection(TextDirectionHeuristics.RTL)
                        .setLineSpacing(0f, 1.08f)
                        .setMaxLines(2)
                        .setIncludePad(false)
                        .build()
                    if (layout.lineCount <= 2 && layout.height <= (rect.bottom - titleY - 14f) || nameSize <= 13f) break
                    nameSize -= 0.5f
                }
                canvas.save()
                canvas.translate(colLeft + 9f, titleY + 12f)
                layout.draw(canvas)
                canvas.restore()
            }
        }
    }

    protected fun fitTextToWidth(paint: Paint, text: String, maxWidth: Float, minSize: Float) {
        if (text.isEmpty() || maxWidth <= 0f) return
        while (paint.measureText(text) > maxWidth && paint.textSize > minSize) {
            paint.textSize -= 0.5f
        }
    }

    // دوال التوافق مع أي استدعاءات سابقة
    protected fun drawSideBySidePartyBoxes(
        canvas: Canvas,
        topY: Float,
        boxHeight: Float,
        rightTitle: String,
        leftTitle: String
    ): Pair<RectF, RectF> {
        val margin = 50f
        val boxWidth = (A4_WIDTH - (margin * 2) - 30f) / 2f
        val rightBox = RectF(A4_WIDTH - margin - boxWidth, topY, A4_WIDTH - margin, topY + boxHeight)
        val leftBox = RectF(margin, topY, margin + boxWidth, topY + boxHeight)
        return Pair(rightBox, leftBox)
    }

    protected fun drawOptionalHeaderImage(
        canvas: Canvas,
        context: Context?,
        assetOrDrawableName: String,
        destRect: RectF
    ) {
        if (context == null) return
        try {
            val resId = context.resources.getIdentifier(assetOrDrawableName, "drawable", context.packageName)
            if (resId != 0) {
                val bitmap = BitmapFactory.decodeResource(context.resources, resId)
                if (bitmap != null) {
                    canvas.drawBitmap(bitmap, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
                    return
                }
            }
            val inputStream = context.assets.open(assetOrDrawableName)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            if (bitmap != null) {
                canvas.drawBitmap(bitmap, null, destRect, Paint(Paint.FILTER_BITMAP_FLAG))
            }
        } catch (_: Exception) {
        }
    }

    protected fun drawSignatures(
        canvas: Canvas,
        titles: List<String>,
        bottomY: Float = A4_HEIGHT - 185f
    ) {
        val p1 = titles.firstOrNull() ?: "الطرف الأول"
        val p2 = titles.lastOrNull() ?: "الطرف الثاني"
        drawIraqiSignaturesFooter(
            canvas = canvas,
            party1Title = p1,
            party2Title = p2,
            topY = bottomY - 130f,
            bottomY = bottomY + 50f
        )
    }
}
