package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF

/**
 * RealEstateContractRenderer: محرك رسم عقد بيع وشراء الدور والأراضي السكنية والزراعية
 * تصميم عراقي رسمي كلاسيكي موحد مع خط أميري/نسخ، جداول حادة، بصمة الإبهام، وختم المكتب.
 */
class RealEstateContractRenderer : BaseContractRenderer() {

    override fun drawContractContent(
        canvas: Canvas,
        contractData: Any,
        officeInfo: OfficeInfo,
        context: Context?
    ) {
        val data = contractData as? RealEstateContract ?: RealEstateContract()
        val primary = primaryColorInt()
        val secondary = secondaryColorInt()
        val dark = textColorInt()
        val scale = activeTemplate.fontScale
        val officePlace = officeInfo.address.trim()

        // ==================== 1. الترويسة العراقية الرسمية ====================
        var curY = drawIraqiOfficialHeader(
            canvas = canvas,
            officeInfo = officeInfo,
            defaultOfficeName = "مكتب الدلالية العقاري",
            specialtyText = "لبيع وشراء العقارات والأراضي السكنية والزراعية",
            contractTitle = "عقد بيع وشراء عقار",
            contractSubtitle = "الدور والأراضي السكنية والزراعية",
            contractNo = data.contractNo.ifBlank { "0001" },
            contractDate = data.contractDate
        )

        // ==================== 2. جدول بيانات الطرفين ====================
        curY = drawFormalPartiesTable(
            canvas = canvas,
            topY = curY,
            rightTitle = "الطرف الأول (البائع)",
            leftTitle = "الطرف الثاني (المشتري)",
            rightFields = listOf(
                "الاسم الكامل:" to data.sellerName,
                "السكن والعنوان:" to data.sellerAddress,
                "البطاقة الوطنية / الهوية:" to data.sellerIdNumber,
                "رقم الهاتف:" to data.sellerPhone
            ),
            leftFields = listOf(
                "الاسم الكامل:" to data.buyerName,
                "السكن والعنوان:" to data.buyerAddress,
                "البطاقة الوطنية / الهوية:" to data.buyerIdNumber,
                "رقم الهاتف:" to data.buyerPhone
            )
        )

        curY += 26f
        val introText = "أقرّ الطرفان بأهليتهما القانونية الكاملة، وتم الاتفاق بالتراضي التام على انعقاد هذا العقد وفق الأوصاف والشروط الآتية:"
        val introP = Paint().apply {
            color = dark
            textSize = 18f * scale
            typeface = bodyBoldTypeface
            textAlign = Paint.Align.RIGHT
            isAntiAlias = true
        }
        fitTextToWidth(introP, introText, contentWidth, 14f)
        canvas.drawText(introText, contentRight, curY, introP)

        // ==================== 3. أوصاف الملك ومشتملاته ====================
        curY += 16f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "أولاً: يعترف الطرف الأول (البائع) بأنه قد باع للطرف الثاني (المشتري) الملك المفصل أدناه:",
            topY = curY
        )

        curY += 8f
        val propGridH = 88f
        val propRect = RectF(contentLeft, curY, contentRight, curY + propGridH)
        val gridOuter = Paint().apply {
            color = primary
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
            isAntiAlias = true
        }
        val gridInner = Paint().apply {
            color = tintColor(primary, 165)
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }
        canvas.drawRect(propRect, gridOuter)
        val midX = propRect.centerX()
        val rowH = propGridH / 2f
        canvas.drawLine(propRect.left, propRect.top + rowH, propRect.right, propRect.top + rowH, gridInner)
        canvas.drawLine(midX, propRect.top, midX, propRect.bottom, gridInner)

        val cellW = (propRect.width() / 2f) - 24f
        drawFieldWithDots(canvas, "نوع الملك:", data.propertyType.ifBlank { "دار سكني" }, propRect.right - 12f, propRect.top + 30f, cellW)
        drawFieldWithDots(canvas, "المساحة:", data.propertyArea, midX - 12f, propRect.top + 30f, cellW)
        drawFieldWithDots(canvas, "الرقم والتسلسل:", data.plotSequenceNo, propRect.right - 12f, propRect.top + rowH + 30f, cellW)
        drawFieldWithDots(canvas, "المحلة / المنطقة:", data.neighborhood, midX - 12f, propRect.top + rowH + 30f, cellW)

        curY = propRect.bottom + 12f

        // ==================== 4. البدل المالي والعربون ====================
        val formattedTotal = FormatUtils.formatMoneyInput(data.totalPrice)
        val totalDisplay = if (formattedTotal.isNotBlank()) "$formattedTotal دينار" else data.totalPrice
        val totalWords = data.totalPriceWords.trim().ifBlank { FormatUtils.convertNumberToArabicWords(data.totalPrice) }

        val formattedDeposit = FormatUtils.formatMoneyInput(data.depositPrice)
        val depositDisplay = if (formattedDeposit.isNotBlank()) "$formattedDeposit دينار" else data.depositPrice
        val depositWords = FormatUtils.convertNumberToArabicWords(data.depositPrice)

        val formattedRemaining = FormatUtils.formatMoneyInput(data.remainingPrice)
        val remainingDisplay = if (formattedRemaining.isNotBlank()) "$formattedRemaining دينار" else data.remainingPrice
        val remainingWords = FormatUtils.convertNumberToArabicWords(data.remainingPrice)

        curY = drawFinancialSummaryTableWithWords(
            canvas = canvas,
            topY = curY,
            items = listOf(
                FinancialBoxItem("بدل البيع الكلي (رقماً)", totalDisplay, totalWords, dark),
                FinancialBoxItem("العربون الذي تم قبضه", depositDisplay, depositWords, primary),
                FinancialBoxItem("الباقي بذمة المشتري", remainingDisplay, remainingWords, COLOR_RED_ACCENT)
            ),
            wordsRowLabel = "بدل البيع المتفق عليه (كتابةً):",
            wordsRowValue = totalWords
        )

        // ==================== 5. الشروط القانونية والتراضي ====================
        curY += 14f
        curY = drawIraqiSectionBanner(
            canvas = canvas,
            title = "ثانياً: الشروط القانونية والتزامات الطرفين",
            topY = curY
        )

        curY += 10f
        val pSellerFmt = FormatUtils.formatMoneyInput(data.penaltySellerAmount)
        val pSellerWords = FormatUtils.convertNumberToArabicWords(data.penaltySellerAmount)
        val pSellerText = when {
            pSellerWords.isNotBlank() -> "$pSellerFmt دينار ($pSellerWords)"
            pSellerFmt.isNotBlank() -> "$pSellerFmt دينار عراقي"
            data.penaltySellerAmount.isNotBlank() -> data.penaltySellerAmount
            else -> "........................................"
        }
        val pBuyerFmt = FormatUtils.formatMoneyInput(data.penaltyBuyerAmount)
        val pBuyerWords = FormatUtils.convertNumberToArabicWords(data.penaltyBuyerAmount)
        val pBuyerText = when {
            pBuyerWords.isNotBlank() -> "$pBuyerFmt دينار ($pBuyerWords)"
            pBuyerFmt.isNotBlank() -> "$pBuyerFmt دينار عراقي"
            data.penaltyBuyerAmount.isNotBlank() -> data.penaltyBuyerAmount
            else -> "........................................"
        }

        val clauses = listOf(
            "نكول البائع" to "إذا امتنع الطرف الأول (البائع) عن إجراء التقدير أو إتمام البيع بأي صورة، فإنه ملزم بإعادة العربون كاملاً ودفع تعويض اتفاقي للطرف الثاني (المشتري) قدره ($pSellerText).",
            "نكول المشتري" to "يعترف الطرف الثاني (المشتري) بأنه قبل الشراء بعد المعاينة التامة، وفي حالة النكول أو عدم تأدية قصور البدل يتعهد بدفع تعويض اتفاقي للطرف الأول (البائع) قدره ($pBuyerText).",
            "التقدير" to "يحق للطرف الثاني (المشتري) تقدير الملك وتسجيله باسمه أو لمن يشاء بعد إتمام دفع كامل البدل المتفق عليه.",
            "الدلالية" to "نسبة الدلالية المتعارف عليها (٢٪)، ولا تسترجع عند حصول أي خلاف بين الطرفين بعد إبرام هذا العقد، والمكتب غير مسؤول بعد التقدير عن أي فقرات أو اتفاقات إضافية.",
            "التوثيق" to if (officePlace.isNotBlank()) {
                "كل مكاتبة أو عقد غير مختوم بختم المكتب الرسمي يعتبر باطلاً ولا يعتد به، وحرر هذا العقد بالتراضي والإيجاب والقبول في ($officePlace) بتاريخ (${data.contractDate})."
            } else {
                "كل مكاتبة أو عقد غير مختوم بختم المكتب الرسمي يعتبر باطلاً ولا يعتد به، وحرر هذا العقد بالتراضي والإيجاب والقبول بتاريخ (${data.contractDate})."
            }
        )

        val notesAreaReserve = 96f
        curY = drawIraqiLegalClauses(
            canvas = canvas,
            clauses = clauses,
            startY = curY,
            maxBottomY = footerTopY - notesAreaReserve
        )

        // ==================== 6. الملاحظات الإضافية ====================
        drawAdditionalNotesBlock(
            canvas = canvas,
            notes = data.additionalNotes,
            startY = curY + 8f
        )

        // ==================== 7. التواقيع والشهود ====================
        drawIraqiSignaturesFooter(
            canvas = canvas,
            party1Title = "الطرف الأول/البائع",
            party2Title = "الطرف الثاني/المشتري",
            witness1Name = data.witness1Name,
            witness2Name = data.witness2Name
        )
    }
}
