package com.example.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

object NetworkUtils {

    const val DEFAULT_PORT = 8080

    /**
     * Retrieves the device's local IPv4 address on the Wi-Fi or local network interface.
     * Prefers standard private subnet ranges (192.168.x.x, 10.x.x.x, 172.16-31.x.x).
     */
    fun getLocalIpAddress(): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            // First priority: wlan / wifi interfaces
            val sortedInterfaces = interfaces.sortedByDescending { 
                it.name.startsWith("wlan", ignoreCase = true) || it.name.startsWith("eth", ignoreCase = true)
            }
            
            for (networkInterface in sortedInterfaces) {
                if (!networkInterface.isUp || networkInterface.isLoopback) continue

                val addresses = Collections.list(networkInterface.inetAddresses)
                for (address in addresses) {
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val ip = address.hostAddress ?: continue
                        // Return private IP address
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip
                        }
                    }
                }
            }

            // Fallback: any non-loopback IPv4
            for (networkInterface in interfaces) {
                if (!networkInterface.isUp || networkInterface.isLoopback) continue
                for (address in Collections.list(networkInterface.inetAddresses)) {
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        return address.hostAddress
                    }
                }
            }
        } catch (_: Exception) {
            // Handle network discovery exception gracefully
        }
        return null
    }

    /**
     * Formats full streaming URL for TV browsers.
     */
    fun getStreamUrl(ip: String?, port: Int = DEFAULT_PORT): String {
        val host = ip ?: "127.0.0.1"
        return "http://$host:$port"
    }

    /**
     * Checks if Wi-Fi or Ethernet local connection is active.
     */
    fun isConnectedToLocalNetwork(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    /**
     * Gets Wi-Fi SSID name if available.
     */
    @Suppress("DEPRECATION")
    fun getWifiName(context: Context): String {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val info = wifiManager?.connectionInfo
            val ssid = info?.ssid
            if (!ssid.isNullOrBlank() && ssid != "<unknown ssid>") {
                return ssid.replace("\"", "")
            }
        } catch (_: Exception) {
        }
        return "Wi-Fi Network"
    }
}
