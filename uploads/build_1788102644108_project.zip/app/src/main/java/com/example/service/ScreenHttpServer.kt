package com.example.service

import android.util.Log
import com.example.quality.StreamQualityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

class ScreenHttpServer(
    private val port: Int,
    private val qualityManager: StreamQualityManager,
    private val latestFrame: AtomicReference<ByteArray?>,
    private val onViewerCountChanged: (Int) -> Unit,
    private val htmlSupplier: () -> String
) {
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private val activeClients = AtomicInteger(0)

    fun start(scope: CoroutineScope) {
        serverJob = scope.launch(Dispatchers.IO) {
            try {
                serverSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress("0.0.0.0", port))
                }

                while (isActive && serverSocket?.isClosed == false) {
                    val socket = try {
                        serverSocket?.accept() ?: break
                    } catch (e: Exception) {
                        break
                    }

                    launch(Dispatchers.IO) {
                        handleClient(socket, scope)
                    }
                }
            } catch (e: Exception) {
                Log.e("ScreenHttpServer", "Server error: ${e.message}")
            }
        }
    }

    private suspend fun handleClient(socket: Socket, scope: CoroutineScope) {
        socket.use { client ->
            client.tcpNoDelay = true
            client.soTimeout = 10000

            val reader = BufferedReader(InputStreamReader(client.getInputStream()))
            val output: OutputStream = BufferedOutputStream(client.getOutputStream())

            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return

            val method = parts[0]
            val rawPath = parts[1]
            val path = rawPath.substringBefore("?")

            when {
                path == "/" || path.isEmpty() -> {
                    val html = htmlSupplier().toByteArray(Charsets.UTF_8)
                    val header = ("HTTP/1.1 200 OK\r\n" +
                            "Content-Type: text/html; charset=utf-8\r\n" +
                            "Content-Length: ${html.size}\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Connection: close\r\n\r\n").toByteArray(Charsets.UTF_8)
                    output.write(header)
                    output.write(html)
                    output.flush()
                }

                path == "/stream" -> {
                    client.soTimeout = 0 // Infinite timeout for long-lived MJPEG stream
                    val header = ("HTTP/1.1 200 OK\r\n" +
                            "Server: ScreenCastTV/1.0\r\n" +
                            "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n" +
                            "Pragma: no-cache\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Connection: close\r\n" +
                            "Content-Type: multipart/x-mixed-replace; boundary=--frame\r\n\r\n")
                        .toByteArray(Charsets.UTF_8)
                    output.write(header)
                    output.flush()

                    val count = activeClients.incrementAndGet()
                    onViewerCountChanged(count)
                    qualityManager.updateActiveClients(count)

                    try {
                        var lastSentFrame: ByteArray? = null
                        while (scope.isActive && !client.isClosed && client.isConnected) {
                            val frame = latestFrame.get()
                            if (frame != null && frame !== lastSentFrame) {
                                lastSentFrame = frame
                                val frameHeader = ("--frame\r\n" +
                                        "Content-Type: image/jpeg\r\n" +
                                        "Content-Length: ${frame.size}\r\n\r\n")
                                    .toByteArray(Charsets.UTF_8)

                                output.write(frameHeader)
                                output.write(frame)
                                output.write("\r\n".toByteArray(Charsets.UTF_8))
                                output.flush()
                            }
                            delay(qualityManager.getTargetFrameIntervalMs())
                        }
                    } catch (_: Exception) {
                        // Client disconnected (e.g. browser tab closed or refreshed)
                    } finally {
                        val current = activeClients.decrementAndGet().coerceAtLeast(0)
                        onViewerCountChanged(current)
                        qualityManager.updateActiveClients(current)
                    }
                }

                path == "/api/status" -> {
                    val metrics = qualityManager.metrics.value
                    val json = """
                        {
                          "status": "online",
                          "fps": ${metrics.currentFps},
                          "quality": ${metrics.jpegQuality},
                          "bitrateKbps": ${metrics.bitrateKbps},
                          "viewers": ${metrics.activeViewers}
                        }
                    """.trimIndent().toByteArray(Charsets.UTF_8)

                    val header = ("HTTP/1.1 200 OK\r\n" +
                            "Content-Type: application/json; charset=utf-8\r\n" +
                            "Content-Length: ${json.size}\r\n" +
                            "Access-Control-Allow-Origin: *\r\n" +
                            "Connection: close\r\n\r\n").toByteArray(Charsets.UTF_8)
                    output.write(header)
                    output.write(json)
                    output.flush()
                }

                else -> {
                    val notFound = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
                        .toByteArray(Charsets.UTF_8)
                    output.write(notFound)
                    output.flush()
                }
            }
        }
    }

    fun stop() {
        try {
            serverJob?.cancel()
            serverSocket?.close()
        } catch (_: Exception) {
        } finally {
            serverSocket = null
            serverJob = null
            activeClients.set(0)
            onViewerCountChanged(0)
            qualityManager.updateActiveClients(0)
        }
    }
}
