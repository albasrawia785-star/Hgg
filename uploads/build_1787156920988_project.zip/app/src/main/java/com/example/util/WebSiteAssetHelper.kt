package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.HostedContentType
import com.example.model.HostedSite
import java.io.*
import java.text.DecimalFormat
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

object WebSiteAssetHelper {

    private const val WEB_ROOT_DIR = "hosted_web_root"

    fun getWebRootDir(context: Context): File {
        val dir = File(context.filesDir, WEB_ROOT_DIR)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun saveWebsiteFromUri(context: Context, uri: Uri): HostedSite {
        var originalFileName = "website.zip"
        var fileSize: Long = 0

        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex != -1) originalFileName = cursor.getString(nameIndex) ?: "website.zip"
                if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
            }
        }

        val rootDir = getWebRootDir(context)
        // Clear previous files
        rootDir.deleteRecursively()
        rootDir.mkdirs()

        val isZip = originalFileName.endsWith(".zip", ignoreCase = true) ||
                originalFileName.endsWith(".tar", ignoreCase = true) ||
                originalFileName.endsWith(".gz", ignoreCase = true)
        val isHtml = originalFileName.endsWith(".html", ignoreCase = true) ||
                originalFileName.endsWith(".htm", ignoreCase = true)

        var totalFiles = 0
        var totalBytes = 0L

        if (isZip) {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val (count, bytes) = unzipToDirectory(inputStream, rootDir)
                totalFiles = count
                totalBytes = bytes
            }
        } else {
            // Single HTML or standalone file
            val targetFile = File(rootDir, if (isHtml) "index.html" else originalFileName)
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(targetFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            totalFiles = 1
            totalBytes = targetFile.length()
        }

        // Post-processing: Normalize React / Vite / Next export builds
        normalizeWebRoot(rootDir)

        // Recount files
        var verifiedCount = 0
        var verifiedBytes = 0L
        rootDir.walkTopDown().forEach { file ->
            if (file.isFile) {
                verifiedCount++
                verifiedBytes += file.length()
            }
        }

        val detectedType = if (isZip) HostedContentType.STATIC_SITE else HostedContentType.SINGLE_HTML

        return HostedSite(
            uri = uri,
            name = originalFileName,
            contentType = detectedType,
            sizeFormatted = formatFileSize(if (verifiedBytes > 0) verifiedBytes else totalBytes),
            fileCount = if (verifiedCount > 0) verifiedCount else totalFiles,
            isDefaultSample = false
        )
    }

    fun ensureDefaultWebsite(context: Context): HostedSite {
        val rootDir = getWebRootDir(context)
        val indexFile = File(rootDir, "index.html")
        if (!indexFile.exists() || indexFile.length() == 0L) {
            createDefaultWebPortal(rootDir)
        }

        var count = 0
        var totalBytes = 0L
        rootDir.walkTopDown().forEach { file ->
            if (file.isFile) {
                count++
                totalBytes += file.length()
            }
        }

        return HostedSite(
            uri = null,
            name = "بوابة تفاعلية مع قاعدة بيانات حية (Realtime DB)",
            contentType = HostedContentType.STATIC_SITE,
            sizeFormatted = formatFileSize(totalBytes),
            fileCount = count,
            isDefaultSample = true
        )
    }

    private fun createDefaultWebPortal(rootDir: File) {
        rootDir.mkdirs()
        val indexHtml = """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>قاعدة بيانات محلية حية (Realtime DB)</title>
    <!-- مكتبة الربط المباشرة مثل Firestore -->
    <script src="/local-db.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: #0f172a;
            color: #f8fafc;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 24px 16px;
        }
        .card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 20px;
            padding: 28px 20px;
            max-width: 540px;
            width: 100%;
            text-align: center;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            margin-bottom: 20px;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(52, 211, 153, 0.15);
            color: #34d399;
            padding: 6px 14px;
            border-radius: 99px;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 16px;
        }
        .badge-dot {
            width: 8px;
            height: 8px;
            background: #34d399;
            border-radius: 50%;
        }
        h1 {
            font-size: 22px;
            font-weight: 800;
            margin-bottom: 8px;
            color: #ffffff;
        }
        p {
            font-size: 14px;
            color: #94a3b8;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .db-box {
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 20px;
            text-align: right;
        }
        .db-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .db-title {
            font-size: 14px;
            font-weight: 700;
            color: #a78bfa;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 14px;
        }
        input, textarea {
            background: #1e293b;
            border: 1px solid #475569;
            border-radius: 10px;
            padding: 12px 14px;
            color: #ffffff;
            font-size: 14px;
            outline: none;
            width: 100%;
            font-family: inherit;
        }
        input:focus, textarea:focus {
            border-color: #8b5cf6;
        }
        .btn {
            background: #8b5cf6;
            color: #ffffff;
            border: none;
            padding: 12px 20px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 700;
            width: 100%;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn:hover { background: #7c3aed; }
        .records-list {
            margin-top: 14px;
            max-height: 220px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .record-item {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 10px 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .record-info {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .record-author {
            font-size: 13px;
            font-weight: 700;
            color: #e2e8f0;
        }
        .record-text {
            font-size: 12px;
            color: #94a3b8;
        }
        .record-time {
            font-size: 10px;
            color: #64748b;
        }
        .footer {
            font-size: 12px;
            color: #64748b;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">
            <span class="badge-dot"></span>
            Realtime DB • Live Sync Active
        </div>
        <h1>بوابة الويب وقاعدة البيانات الحية ⚡</h1>
        <p>البيانات متصلة بشكل لحظي (Live onSnapshot). أي تغيير يحدث في الهاتف أو من أي جهاز آخر يظهر مباشرة على الشاشة فوراً دون إعادة تحميل الصفحة.</p>
        
        <div class="db-box">
            <div class="db-header">
                <span class="db-title">إرسال بيان (مثل Firestore):</span>
                <span id="recordsCount" style="font-size: 12px; color: #a78bfa;">0 سجلات</span>
            </div>
            <div class="form-group">
                <input type="text" id="authorInput" placeholder="الاسم أو المعرف..." />
                <textarea id="contentInput" rows="2" placeholder="البيانات أو المحتوى المراد حفظه..."></textarea>
                <button class="btn" onclick="saveRecord()">حفظ في قاعدة البيانات 💾</button>
            </div>

            <div class="db-title" style="margin-top: 16px;">المزامنة اللحظية الحية (Live):</div>
            <div class="records-list" id="recordsList">
                <div style="text-align: center; color: #64748b; font-size: 12px; padding: 12px;">جاري الاستماع للبيانات...</div>
            </div>
        </div>

        <div class="footer">Firestore & Realtime API Compatible • Local Offline</div>
    </div>

    <script>
        // 1. الاستماع الحي والتحديث الفوري عند أي تغيير (مثل Firestore تماماً)
        db.collection('messages').onSnapshot((snapshot) => {
            renderSnapshot(snapshot);
        });

        function renderSnapshot(snapshot) {
            const list = document.getElementById('recordsList');
            const countEl = document.getElementById('recordsCount');
            countEl.innerText = snapshot.size + ' سجل';

            if (snapshot.empty) {
                list.innerHTML = '<div style="text-align: center; color: #64748b; font-size: 12px; padding: 12px;">لا توجد سجلات بعد.</div>';
                return;
            }

            let html = '';
            snapshot.forEach(doc => {
                const data = doc.data();
                const author = data.author || data.name || 'مستخدم متصل';
                const text = data.content || data.text || data.message || JSON.stringify(data);
                const timeStr = data.timestamp ? new Date(data.timestamp).toLocaleTimeString('ar-EG', {hour:'2-digit', minute:'2-digit'}) : 'الآن';

                html += '<div class="record-item">' +
                    '<div class="record-info">' +
                        '<div class="record-author">👤 ' + escapeHtml(author) + '</div>' +
                        '<div class="record-text">' + escapeHtml(text) + '</div>' +
                    '</div>' +
                    '<div class="record-time">' + timeStr + '</div>' +
                '</div>';
            });
            list.innerHTML = html;
        }

        // 2. إضافة مستند جديد
        async function saveRecord() {
            const author = document.getElementById('authorInput').value.trim() || 'مستخدم متصل';
            const content = document.getElementById('contentInput').value.trim();
            if (!content) return;

            try {
                await db.collection('messages').add({
                    author: author,
                    content: content
                });
                document.getElementById('contentInput').value = '';
            } catch (e) {
                console.error('Save failed:', e);
            }
        }

        function escapeHtml(text) {
            if (!text) return '';
            return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }
    </script>
</body>
</html>
        """.trimIndent()

        File(rootDir, "index.html").writeText(indexHtml, Charsets.UTF_8)
    }

    private fun unzipToDirectory(zipStream: InputStream, targetDir: File): Pair<Int, Long> {
        var fileCount = 0
        var totalBytes = 0L
        val zis = ZipInputStream(BufferedInputStream(zipStream))
        var entry: ZipEntry? = zis.nextEntry

        while (entry != null) {
            val entryName = entry.name
            val cleanName = entryName.replace('\\', '/')
            val file = File(targetDir, cleanName)
            val canonicalDestinationPath = targetDir.canonicalPath
            val canonicalTargetFile = file.canonicalPath

            if (!canonicalTargetFile.startsWith(canonicalDestinationPath + File.separator) && canonicalTargetFile != canonicalDestinationPath) {
                entry = zis.nextEntry
                continue
            }

            if (entry.isDirectory || cleanName.endsWith("/")) {
                file.mkdirs()
            } else {
                file.parentFile?.mkdirs()
                FileOutputStream(file).use { fos ->
                    val buffer = ByteArray(8192)
                    var len: Int
                    while (zis.read(buffer).also { len = it } > 0) {
                        fos.write(buffer, 0, len)
                        totalBytes += len
                    }
                }
                fileCount++
            }
            zis.closeEntry()
            entry = zis.nextEntry
        }
        zis.close()

        return Pair(fileCount, totalBytes)
    }

    private fun normalizeWebRoot(rootDir: File) {
        val directIndex = File(rootDir, "index.html")
        if (directIndex.exists()) return

        val standardBuildFolders = listOf("dist", "build", "out", "public")
        for (folderName in standardBuildFolders) {
            val buildDir = File(rootDir, folderName)
            if (buildDir.exists() && buildDir.isDirectory) {
                val candidate = File(buildDir, "index.html")
                if (candidate.exists()) {
                    moveContentsToRoot(buildDir, rootDir)
                    return
                }
            }
        }

        var foundIndexDir: File? = null
        rootDir.walkTopDown().forEach { file ->
            if (foundIndexDir == null && file.isFile && file.name.equals("index.html", ignoreCase = true)) {
                foundIndexDir = file.parentFile
            }
        }

        foundIndexDir?.let { subDir ->
            if (subDir.canonicalPath != rootDir.canonicalPath) {
                moveContentsToRoot(subDir, rootDir)
            }
        }
    }

    private fun moveContentsToRoot(sourceDir: File, rootDir: File) {
        val tempDir = File(rootDir.parentFile, "temp_move_${System.currentTimeMillis()}")
        sourceDir.renameTo(tempDir)
        rootDir.deleteRecursively()
        rootDir.mkdirs()

        tempDir.listFiles()?.forEach { file ->
            file.renameTo(File(rootDir, file.name))
        }
        tempDir.deleteRecursively()
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val formatted = DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble()))
        return "$formatted ${units[digitGroups.coerceIn(0, units.size - 1)]}"
    }
}
