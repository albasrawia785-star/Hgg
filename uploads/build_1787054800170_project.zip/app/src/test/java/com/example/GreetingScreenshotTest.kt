package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.sandbox.model.SandboxStorageMetrics
import com.example.sandbox.model.VirtualProcessState
import com.example.sandbox.model.ProcessStatus
import com.example.sandbox.ui.components.ContainerMetricsCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun greeting_screenshot() {
    composeTestRule.setContent {
      MyApplicationTheme {
        ContainerMetricsCard(
          processState = VirtualProcessState(
            pid = 1234,
            processName = "com.virtual.sandbox",
            status = ProcessStatus.RUNNING,
            heapMemoryMb = 24.5,
            threadCount = 4,
            uptimeSeconds = 120,
            activePackage = "com.cyber.sandbox.toolkit"
          ),
          storageMetrics = SandboxStorageMetrics(
            totalBytes = 2048,
            dataBytes = 1024,
            cacheBytes = 512,
            databaseBytes = 256,
            prefsBytes = 256,
            dexBytes = 0,
            apkBytes = 0,
            fileCount = 3
          ),
          isHookingActive = true,
          onRestart = {},
          onPurgeCache = {},
          onToggleHooking = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}

