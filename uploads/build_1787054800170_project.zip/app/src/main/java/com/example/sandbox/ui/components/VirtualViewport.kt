package com.example.sandbox.ui.components

import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.sandbox.engine.VirtualGuestRuntime
import com.example.sandbox.model.VirtualAppInfo
import com.example.ui.theme.SandboxOutline
import com.example.ui.theme.SandboxOutlineVariant
import com.example.ui.theme.SandboxPrimary
import com.example.ui.theme.SandboxSurfaceVariant
import com.example.ui.theme.StatusActive

/**
 * Integrated High-Performance Container Viewport.
 * Embeds and displays the active virtual application UI via AndroidView.
 */
@Composable
fun VirtualViewport(
  runningApp: VirtualAppInfo?,
  guestRuntime: VirtualGuestRuntime,
  onBackPressed: () -> Unit,
  onHomePressed: () -> Unit,
  onRestartApp: () -> Unit,
  onOpenPackages: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("virtual_viewport_card"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, SandboxOutlineVariant),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      // Viewport Status Bar & Controls
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
          .background(Color(0xFF0F172A))
          .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(if (runningApp != null) StatusActive else Color.Gray)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = runningApp?.appName ?: "الحاوية في وضع الانتظار",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "60 FPS • Isolated",
            fontSize = 10.sp,
            color = Color(0xFF94A3B8)
          )
          Spacer(modifier = Modifier.width(6.dp))
          IconButton(
            onClick = onRestartApp,
            modifier = Modifier
              .size(26.dp)
              .testTag("viewport_refresh_button")
          ) {
            Icon(
              imageVector = Icons.Default.Refresh,
              contentDescription = "Restart App",
              tint = Color.White,
              modifier = Modifier.size(16.dp)
            )
          }
        }
      }

      // Live Container Screen Viewport (AndroidView)
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(380.dp)
          .background(Color(0xFFF1F5F9))
          .border(1.dp, SandboxOutlineVariant)
          .testTag("viewport_screen_box"),
        contentAlignment = Alignment.Center
      ) {
        if (runningApp != null) {
          androidx.compose.runtime.key(runningApp.packageName) {
            AndroidView(
              factory = { context ->
                FrameLayout(context).apply {
                  layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                  )
                  addView(guestRuntime.buildGuestView(runningApp))
                }
              },
              modifier = Modifier.fillMaxSize()
            )
          }
        } else {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Apps,
              contentDescription = null,
              tint = Color(0xFF94A3B8),
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "لا يوجد تطبيق مشغل حالياً داخل الحاوية",
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = Color(0xFF475569)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
              onClick = onOpenPackages,
              colors = ButtonDefaults.buttonColors(containerColor = SandboxPrimary),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.testTag("launch_package_button")
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("اختر حزمة لتشغيلها", fontSize = 13.sp)
            }
          }
        }
      }

      // Guest Virtual Navigation Bar (Back, Home, Overview)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
          .background(Color(0xFF0F172A))
          .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onBackPressed,
          modifier = Modifier.testTag("virtual_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
          )
        }

        IconButton(
          onClick = onHomePressed,
          modifier = Modifier.testTag("virtual_home_button")
        ) {
          Icon(
            imageVector = Icons.Default.FiberManualRecord,
            contentDescription = "Home",
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
        }

        IconButton(
          onClick = onOpenPackages,
          modifier = Modifier.testTag("virtual_tasks_button")
        ) {
          Icon(
            imageVector = Icons.Default.CropSquare,
            contentDescription = "Switch App",
            tint = Color.White,
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}
