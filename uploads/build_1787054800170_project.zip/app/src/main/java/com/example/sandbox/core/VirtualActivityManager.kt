package com.example.sandbox.core

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.sandbox.model.HookSubsystem
import com.example.sandbox.model.VirtualAppInfo
import com.example.sandbox.model.VirtualTaskRecord
import java.util.Stack
import java.util.concurrent.atomic.AtomicInteger

/**
 * Virtual Activity Manager & Task Stack Coordinator.
 * Simulates Android's ActivityStack within the container viewport,
 * tracking back-stack transitions, launch modes, and lifecycles.
 */
class VirtualActivityManager(
  private val context: Context,
  private val hookManager: VirtualHookManager
) {
  private val TAG = "VirtualActivityManager"
  private val taskIdGenerator = AtomicInteger(1001)
  
  private var currentTask: VirtualTaskRecord? = null
  private val backStack = Stack<String>()
  
  var currentActivityName: String = ""
    private set

  /**
   * Starts a virtual activity inside the container task stack.
   */
  fun startActivity(appInfo: VirtualAppInfo, targetActivityName: String? = null): VirtualTaskRecord {
    val start = System.currentTimeMillis()
    val activityToLaunch = targetActivityName ?: appInfo.mainActivity
    
    currentActivityName = activityToLaunch
    backStack.push(activityToLaunch)

    val task = VirtualTaskRecord(
      taskId = taskIdGenerator.getAndIncrement(),
      packageName = appInfo.packageName,
      rootActivity = appInfo.mainActivity,
      topActivity = activityToLaunch,
      activityStack = backStack.toList(),
      startTime = System.currentTimeMillis()
    )

    currentTask = task

    hookManager.recordLog(
      subsystem = HookSubsystem.ACTIVITY_MANAGER,
      method = "startActivity",
      targetClass = "VirtualActivityManager",
      callerPackage = appInfo.packageName,
      details = "Dispatched Activity transition -> $activityToLaunch (Task #${task.taskId}, Stack depth: ${backStack.size})",
      outcome = "ACTIVITY_LAUNCHED",
      durationMs = System.currentTimeMillis() - start
    )

    return task
  }

  /**
   * Handles back press inside the virtual container.
   * Returns true if handled (navigated back), false if task stack is empty (should close container/app).
   */
  fun handleBackPressed(): Boolean {
    if (backStack.size > 1) {
      val popped = backStack.pop()
      currentActivityName = backStack.peek()
      currentTask = currentTask?.copy(
        topActivity = currentActivityName,
        activityStack = backStack.toList()
      )

      hookManager.recordLog(
        subsystem = HookSubsystem.ACTIVITY_MANAGER,
        method = "finishActivity",
        targetClass = "VirtualActivityManager",
        callerPackage = currentTask?.packageName ?: "unknown",
        details = "Popped $popped -> Resumed $currentActivityName",
        outcome = "BACK_NAVIGATED"
      )
      return true
    }
    return false
  }

  fun getCurrentTask(): VirtualTaskRecord? = currentTask

  fun resetTask() {
    backStack.clear()
    currentTask = null
    currentActivityName = ""
  }
}
