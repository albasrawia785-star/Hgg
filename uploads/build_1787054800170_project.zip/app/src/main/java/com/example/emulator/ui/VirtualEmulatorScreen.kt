package com.example.emulator.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.emulator.controller.VirtualSystemController
import com.example.emulator.guest.VmPowerState
import com.example.emulator.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualEmulatorScreen(
  viewModel: VirtualSystemController,
  modifier: Modifier = Modifier
) {
  val powerState by viewModel.powerState.collectAsStateWithLifecycle()
  val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
  val hardwareProfile by viewModel.hardwareProfile.collectAsStateWithLifecycle()
  val bootProgress by viewModel.bootProgress.collectAsStateWithLifecycle()
  val currentBootStep by viewModel.currentBootStep.collectAsStateWithLifecycle()
  val activeApp by viewModel.activeApp.collectAsStateWithLifecycle()
  val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
  val currentRootFsPath by viewModel.currentRootFsPath.collectAsStateWithLifecycle()
  val directoryNodes by viewModel.currentDirectoryNodes.collectAsStateWithLifecycle()
  val terminalHistory by viewModel.terminalHistory.collectAsStateWithLifecycle()
  val notificationMessage by viewModel.notificationMessage.collectAsStateWithLifecycle()

  var showRootFsDialog by remember { mutableStateOf(false) }
  var showTerminalDialog by remember { mutableStateOf(false) }
  var showSettingsDialog by remember { mutableStateOf(false) }
  var showApkDialog by remember { mutableStateOf(false) }

  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(notificationMessage) {
    notificationMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.dismissNotification()
    }
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.PhoneAndroid,
              contentDescription = null,
              tint = Color(0xFF38BDF8),
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "Android 14 Micro-VM",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "ARM64 RootFS & Linux Container Engine",
                fontSize = 10.sp,
                color = Color(0xFF94A3B8)
              )
            }
          }
        },
        actions = {
          // VM State Indicator badge
          Surface(
            color = when (powerState) {
              VmPowerState.RUNNING -> Color(0xFF16A34A)
              VmPowerState.BOOTING -> Color(0xFF0284C7)
              VmPowerState.PAUSED -> Color(0xFFD97706)
              else -> Color(0xFFDC2626)
            },
            shape = RoundedCornerShape(12.dp)
          ) {
            Text(
              text = powerState.label,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          IconButton(onClick = { viewModel.togglePauseVm() }) {
            Icon(
              imageVector = if (powerState == VmPowerState.PAUSED) Icons.Default.PlayArrow else Icons.Default.Pause,
              contentDescription = "Pause/Resume",
              tint = Color(0xFFCBD5E1)
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = Color(0xFF090D16),
          titleContentColor = Color.White
        )
      )
    },
    bottomBar = {
      if (powerState == VmPowerState.RUNNING || powerState == VmPowerState.PAUSED) {
        VmToolbar(
          powerState = powerState,
          telemetry = telemetry,
          onBack = { viewModel.pressVirtualBack() },
          onHome = { viewModel.pressVirtualHome() },
          onRecents = { viewModel.pressVirtualRecents() },
          onRestart = { viewModel.startBootSequence() },
          onOpenTerminal = { showTerminalDialog = true },
          onOpenRootFs = { showRootFsDialog = true },
          onOpenApkInstaller = { showApkDialog = true },
          onOpenSettings = { showSettingsDialog = true }
        )
      }
    },
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .background(Color(0xFF020617))
    ) {
      when (powerState) {
        VmPowerState.BOOTING -> {
          BootAnimationView(
            bootProgress = bootProgress,
            currentStep = currentBootStep
          )
        }
        VmPowerState.RUNNING, VmPowerState.PAUSED -> {
          GuestOsViewport(
            activeApp = activeApp,
            installedApps = installedApps,
            hardwareProfile = hardwareProfile,
            storeCatalog = viewModel.packageManager.availableStoreCatalog,
            onLaunchApp = { viewModel.launchApp(it) },
            onInstallStoreApp = { viewModel.installStoreApp(it) },
            onOpenApkPicker = { showApkDialog = true },
            onExecuteCommand = { viewModel.shellEngine.execute(it) }
          )
        }
        VmPowerState.POWERED_OFF, VmPowerState.SHUTTING_DOWN -> {
          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center,
              modifier = Modifier.padding(24.dp)
            ) {
              Icon(
                imageVector = Icons.Default.PowerSettingsNew,
                contentDescription = null,
                tint = Color(0xFF64748B),
                modifier = Modifier.size(72.dp)
              )
              Spacer(modifier = Modifier.height(16.dp))
              Text(
                text = "النظام الافتراضي متوقف",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
              Text(
                text = "اضغط على زر التشغيل للإقلاع وتحميل بارتشنات RootFS وخدمات Zygote",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8),
                modifier = Modifier.padding(top = 6.dp)
              )
              Spacer(modifier = Modifier.height(24.dp))
              Button(
                onClick = { viewModel.startBootSequence() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth(0.7f)
                  .height(48.dp)
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تشغيل النظام الافتراضي (Boot VM)", fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }

  // Modals
  if (showRootFsDialog) {
    RootFsExplorerDialog(
      currentPath = currentRootFsPath,
      nodes = directoryNodes,
      onNavigateTo = { viewModel.browseRootFsPath(it) },
      onNavigateUp = { viewModel.navigateUpRootFs() },
      onRefresh = { viewModel.refreshRootFsDirectory() },
      onDismiss = { showRootFsDialog = false }
    )
  }

  if (showTerminalDialog) {
    GuestTerminalDialog(
      terminalHistory = terminalHistory,
      onExecuteCommand = { viewModel.executeTerminalCommand(it) },
      onClear = { viewModel.clearTerminal() },
      onDismiss = { showTerminalDialog = false }
    )
  }

  if (showSettingsDialog) {
    VmSettingsDialog(
      currentProfile = hardwareProfile,
      onSaveProfile = { viewModel.updateHardwareProfile(it) },
      onDismiss = { showSettingsDialog = false }
    )
  }

  if (showApkDialog) {
    ApkInstallerDialog(
      installedApps = installedApps,
      onInstallApkUri = { uri, name -> viewModel.installApk(uri, name) },
      onLaunchApp = { viewModel.launchApp(it) },
      onUninstallApp = { viewModel.uninstallApp(it) },
      onDismiss = { showApkDialog = false }
    )
  }
}
