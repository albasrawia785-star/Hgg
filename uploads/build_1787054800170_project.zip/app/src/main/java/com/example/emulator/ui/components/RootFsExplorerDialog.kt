package com.example.emulator.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.emulator.guest.RootFsNode

@Composable
fun RootFsExplorerDialog(
  currentPath: String,
  nodes: List<RootFsNode>,
  onNavigateTo: (String) -> Unit,
  onNavigateUp: () -> Unit,
  onRefresh: () -> Unit,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color(0xFF0F172A),
      modifier = Modifier
        .fillMaxWidth()
        .height(580.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp)
      ) {
        // Header
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("مستعرض ملفات RootFS الافتراضي", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
              Text("chroot & Linux Namespaces Storage", fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Path Navigation bar
        Surface(
          color = Color(0xFF1E293B),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
          ) {
            IconButton(onClick = onNavigateUp, modifier = Modifier.size(28.dp)) {
              Icon(Icons.Default.ArrowUpward, contentDescription = "Up", tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
            }
            Text(
              text = currentPath.substringAfter("microvm_rootfs").ifEmpty { "/" },
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              color = Color(0xFFE2E8F0),
              maxLines = 1,
              modifier = Modifier.weight(1f).padding(horizontal = 6.dp)
            )
            IconButton(onClick = onRefresh, modifier = Modifier.size(28.dp)) {
              Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // File Nodes List
        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
        ) {
          items(nodes, key = { it.absolutePath }) { node ->
            Surface(
              color = Color(0xFF1E293B).copy(alpha = 0.6f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
                .clickable {
                  if (node.isDirectory) {
                    onNavigateTo(node.absolutePath)
                  }
                }
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(10.dp)
              ) {
                Icon(
                  imageVector = if (node.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                  contentDescription = null,
                  tint = if (node.isDirectory) Color(0xFFF59E0B) else Color(0xFF38BDF8),
                  modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = node.name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                  )
                  Text(
                    text = "${node.permissions} • ${node.owner}:${node.group} • " +
                        if (node.isDirectory) "${node.childrenCount} عناصر" else "${node.sizeBytes} B",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF94A3B8)
                  )
                }
                if (node.isDirectory) {
                  Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("إغلاق", color = Color.White)
        }
      }
    }
  }
}
