package com.example.sandbox.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.sandbox.model.ComponentType
import com.example.sandbox.model.VirtualAppInfo
import com.example.ui.theme.SandboxOutlineVariant
import com.example.ui.theme.SandboxPrimary
import com.example.ui.theme.SandboxSecondary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusActiveBg

/**
 * Detailed APK Manifest & Virtual Package Inspector Modal.
 */
@Composable
fun ApkInspectorDialog(
  appInfo: VirtualAppInfo,
  onDismiss: () -> Unit,
  onLaunch: (VirtualAppInfo) -> Unit
) {
  var selectedInspectorTab by remember { mutableStateOf(0) }
  val tabs = listOf("نظرة عامة", "المكونات (${appInfo.components.size})", "الصلاحيات (${appInfo.permissions.size})")

  Dialog(onDismissRequest = onDismiss) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .height(540.dp)
        .testTag("apk_inspector_dialog"),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      border = androidx.compose.foundation.BorderStroke(1.dp, SandboxOutlineVariant)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        // Dialog Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = appInfo.appName,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Text(
              text = appInfo.packageName,
              fontSize = 12.sp,
              color = Color(0xFF64748B)
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF64748B))
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab Row
        TabRow(
          selectedTabIndex = selectedInspectorTab,
          containerColor = Color(0xFFF1F5F9),
          contentColor = SandboxPrimary,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .height(38.dp)
        ) {
          tabs.forEachIndexed { index, title ->
            Tab(
              selected = selectedInspectorTab == index,
              onClick = { selectedInspectorTab = index },
              text = { Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab Content
        Box(modifier = Modifier.weight(1f)) {
          when (selectedInspectorTab) {
            0 -> OverviewTab(appInfo)
            1 -> ComponentsTab(appInfo)
            2 -> PermissionsTab(appInfo)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Footer Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End
        ) {
          Button(
            onClick = {
              onLaunch(appInfo)
              onDismiss()
            },
            colors = ButtonDefaults.buttonColors(containerColor = SandboxPrimary),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("inspector_launch_button")
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("تشغيل في الحاوية", fontSize = 13.sp)
          }
        }
      }
    }
  }
}

@Composable
private fun OverviewTab(appInfo: VirtualAppInfo) {
  LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    item {
      InfoRow("إصدار الحزمة", "${appInfo.versionName} (Build ${appInfo.versionCode})")
      InfoRow("إصدار الأندرويد المستهدف", "API ${appInfo.targetSdk} (Min API ${appInfo.minSdk})")
      InfoRow("النشاط الرئيسي (Main)", appInfo.mainActivity)
      InfoRow("مسار الـ APK", appInfo.apkPath)
      InfoRow("حجم كود الـ DEX والملف", "${appInfo.apkSizeBytes} Bytes")
      InfoRow("بيئة التخزين المعزولة", "/data/data/${appInfo.packageName}/")
      InfoRow("نوع الحزمة", if (appInfo.isEmbedded) "مدمجة مسبقاً (Embedded)" else "مستوردة خارجياً (Custom APK)")
    }
  }
}

@Composable
private fun ComponentsTab(appInfo: VirtualAppInfo) {
  LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    items(appInfo.components) { comp ->
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(Color(0xFFF8FAFC))
          .border(1.dp, SandboxOutlineVariant, RoundedCornerShape(8.dp))
          .padding(10.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(if (comp.type == ComponentType.ACTIVITY) Color(0xFFE0F2FE) else Color(0xFFEEF2FF))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = comp.type.name,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = if (comp.type == ComponentType.ACTIVITY) SandboxPrimary else SandboxSecondary
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = comp.label.ifEmpty { comp.name.substringAfterLast('.') },
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Text(
              text = comp.name,
              fontSize = 11.sp,
              color = Color(0xFF64748B)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun PermissionsTab(appInfo: VirtualAppInfo) {
  LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    items(appInfo.permissions) { perm ->
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(Color(0xFFF8FAFC))
          .border(1.dp, SandboxOutlineVariant, RoundedCornerShape(8.dp))
          .padding(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = perm.shortName,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Text(
              text = perm.name,
              fontSize = 10.sp,
              color = Color(0xFF64748B)
            )
          }

          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(StatusActiveBg)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "مفعلة بالعزل",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = StatusActive
            )
          }
        }
      }
    }
  }
}

@Composable
private fun InfoRow(label: String, value: String) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(Color(0xFFF8FAFC))
      .border(1.dp, SandboxOutlineVariant, RoundedCornerShape(8.dp))
      .padding(10.dp)
  ) {
    Text(text = label, fontSize = 11.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = value, fontSize = 12.sp, color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
  }
}
