package com.example.emulator.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.emulator.guest.VmPowerState
import com.example.emulator.guest.VmTelemetry

@Composable
fun VmToolbar(
  powerState: VmPowerState,
  telemetry: VmTelemetry,
  onBack: () -> Unit,
  onHome: () -> Unit,
  onRecents: () -> Unit,
  onRestart: () -> Unit,
  onOpenTerminal: () -> Unit,
  onOpenRootFs: () -> Unit,
  onOpenApkInstaller: () -> Unit,
  onOpenSettings: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = Color(0xFF0F172A),
    shadowElevation = 8.dp,
    modifier = modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Top row: Telemetry strip & quick tools
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFF090D16))
          .padding(horizontal = 12.dp, vertical = 6.dp)
      ) {
        // Telemetry badges
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Surface(
            color = Color(0xFF1E293B),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "${telemetry.fps.toInt()} FPS",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF22C55E),
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          Surface(
            color = Color(0xFF1E293B),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "CPU ${telemetry.cpuUsagePercent.toInt()}%",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF38BDF8),
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          Surface(
            color = Color(0xFF1E293B),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "RAM ${(telemetry.ramUsedMb / 1024.0).format(1)}G",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFFA855F7),
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        // Quick action buttons
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          IconButton(onClick = onOpenApkInstaller, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.AddBox, contentDescription = "Install APK", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
          }
          IconButton(onClick = onOpenTerminal, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Terminal, contentDescription = "Terminal", tint = Color(0xFFE2E8F0), modifier = Modifier.size(18.dp))
          }
          IconButton(onClick = onOpenRootFs, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Folder, contentDescription = "RootFS Explorer", tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
          }
          IconButton(onClick = onOpenSettings, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Settings, contentDescription = "VM Settings", tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp))
          }
          IconButton(onClick = onRestart, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.RestartAlt, contentDescription = "Restart VM", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
          }
        }
      }

      // Bottom row: Standard Android 3-Button Navigation Bar
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .background(Color(0xFF020617))
      ) {
        // Back
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable { onBack() }
        ) {
          Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "Virtual Back",
            tint = Color(0xFFCBD5E1),
            modifier = Modifier.size(22.dp)
          )
        }

        // Home
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable { onHome() }
        ) {
          Box(
            modifier = Modifier
              .size(16.dp)
              .clip(CircleShape)
              .background(Color(0xFFCBD5E1))
          )
        }

        // Recents
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable { onRecents() }
        ) {
          Box(
            modifier = Modifier
              .size(14.dp)
              .background(Color(0xFFCBD5E1), RoundedCornerShape(2.dp))
          )
        }
      }
    }
  }
}

private fun Double.format(digits: Int) = String.format(java.util.Locale.US, "%.${digits}f", this)
