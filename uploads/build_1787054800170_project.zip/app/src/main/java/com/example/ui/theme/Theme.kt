package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val SandboxLightColorScheme = lightColorScheme(
  primary = SandboxPrimary,
  onPrimary = SandboxOnPrimary,
  primaryContainer = SandboxPrimaryContainer,
  onPrimaryContainer = SandboxOnPrimaryContainer,
  secondary = SandboxSecondary,
  onSecondary = SandboxOnSecondary,
  secondaryContainer = SandboxSecondaryContainer,
  onSecondaryContainer = SandboxOnSecondaryContainer,
  tertiary = SandboxTertiary,
  onTertiary = SandboxOnTertiary,
  tertiaryContainer = SandboxTertiaryContainer,
  onTertiaryContainer = SandboxOnTertiaryContainer,
  background = SandboxBackground,
  onBackground = SandboxOnBackground,
  surface = SandboxSurface,
  onSurface = SandboxOnSurface,
  surfaceVariant = SandboxSurfaceVariant,
  onSurfaceVariant = SandboxOnSurfaceVariant,
  outline = SandboxOutline,
  outlineVariant = SandboxOutlineVariant
)

@Composable
fun MyApplicationTheme(
  // Strictly enforce crisp Light Mode styling as requested
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = SandboxLightColorScheme,
    typography = Typography,
    content = content
  )
}

