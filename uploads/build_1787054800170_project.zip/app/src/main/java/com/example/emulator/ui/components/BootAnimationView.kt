package com.example.emulator.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.emulator.guest.BootStep

@Composable
fun BootAnimationView(
  bootProgress: Float,
  currentStep: BootStep?,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "boot_anim")
  val rotation by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(2400, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotation"
  )

  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.92f,
    targetValue = 1.08f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF070B14)),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier
        .fillMaxWidth()
        .padding(24.dp)
    ) {
      // Glowing Core Logo
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(130.dp)
          .scale(pulseScale)
      ) {
        // Outer rotating glowing ring
        Box(
          modifier = Modifier
            .size(126.dp)
            .rotate(rotation)
            .clip(CircleShape)
            .background(
              Brush.sweepGradient(
                listOf(
                  Color(0xFF38BDF8),
                  Color(0xFF818CF8),
                  Color(0xFFC084FC),
                  Color(0xFF38BDF8)
                )
              )
            )
        )

        // Inner dark badge
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(112.dp)
            .clip(CircleShape)
            .background(Color(0xFF0F172A))
        ) {
          Icon(
            imageVector = Icons.Default.Android,
            contentDescription = "Android Micro-VM",
            tint = Color(0xFF38BDF8),
            modifier = Modifier.size(56.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(28.dp))

      Text(
        text = "Android 14 Micro-VM",
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFFF8FAFC)
      )

      Text(
        text = "Standalone Linux Kernel & ARM64 RootFS Container",
        fontSize = 13.sp,
        color = Color(0xFF94A3B8),
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 4.dp)
      )

      Spacer(modifier = Modifier.height(28.dp))

      // Boot Progress Bar
      LinearProgressIndicator(
        progress = { bootProgress },
        modifier = Modifier
          .fillMaxWidth(0.85f)
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = Color(0xFF38BDF8),
        trackColor = Color(0xFF1E293B),
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Stage Title
      Text(
        text = currentStep?.title ?: "إعداد بيئة التشغيل الافتراضية...",
        fontSize = 15.sp,
        fontWeight = FontWeight.SemiBold,
        color = Color(0xFF38BDF8)
      )

      Text(
        text = currentStep?.description ?: "جاري فك ضغط RootFS وتحميل الخدمات الأساسية",
        fontSize = 12.sp,
        color = Color(0xFF64748B),
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 4.dp)
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Kernel Boot Log Box
      Surface(
        color = Color(0xFF0F172A),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .fillMaxWidth(0.9f)
          .height(72.dp)
      ) {
        Column(
          modifier = Modifier.padding(8.dp),
          verticalArrangement = Arrangement.Center
        ) {
          Text(
            text = "KERNEL INIT CONSOLE:",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0EA5E9),
            fontFamily = FontFamily.Monospace
          )
          Text(
            text = currentStep?.logLine ?: "[0.000000] Virtual ARM64 micro-hypervisor ready",
            fontSize = 11.sp,
            color = Color(0xFFE2E8F0),
            fontFamily = FontFamily.Monospace,
            maxLines = 2
          )
        }
      }
    }
  }
}
