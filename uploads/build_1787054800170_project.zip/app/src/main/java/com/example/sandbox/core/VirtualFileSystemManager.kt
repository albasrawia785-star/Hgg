package com.example.sandbox.core

import android.content.Context
import com.example.sandbox.model.SandboxFileItem
import com.example.sandbox.model.SandboxStorageMetrics
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Virtual File System Manager isolating guest app data under `/data/data/<host>/sandbox/`.
 * Ensures full multi-tenant sandboxing where guest APKs cannot read/write host storage.
 */
class VirtualFileSystemManager(private val context: Context) {

  val sandboxRootDir: File by lazy {
    File(context.filesDir.parentFile ?: context.filesDir, "sandbox").apply {
      if (!exists()) mkdirs()
    }
  }

  val apkStoreDir: File by lazy {
    File(sandboxRootDir, "apk_store").apply {
      if (!exists()) mkdirs()
    }
  }

  val optDexDir: File by lazy {
    File(sandboxRootDir, "opt_dex").apply {
      if (!exists()) mkdirs()
    }
  }

  val nativeLibsDir: File by lazy {
    File(sandboxRootDir, "native_libs").apply {
      if (!exists()) mkdirs()
    }
  }

  val virtualDataRootDir: File by lazy {
    File(sandboxRootDir, "data/data").apply {
      if (!exists()) mkdirs()
    }
  }

  val virtualSdcardDir: File by lazy {
    File(sandboxRootDir, "sdcard/Android/data").apply {
      if (!exists()) mkdirs()
    }
  }

  init {
    ensureDirectories()
  }

  private fun ensureDirectories() {
    sandboxRootDir.mkdirs()
    apkStoreDir.mkdirs()
    optDexDir.mkdirs()
    nativeLibsDir.mkdirs()
    virtualDataRootDir.mkdirs()
    virtualSdcardDir.mkdirs()
  }

  /**
   * Initializes isolated sandbox directory tree for a specific package.
   */
  fun initializePackageSandbox(packageName: String): File {
    val appDataDir = File(virtualDataRootDir, packageName)
    val filesDir = File(appDataDir, "files")
    val cacheDir = File(appDataDir, "cache")
    val dbDir = File(appDataDir, "databases")
    val prefsDir = File(appDataDir, "shared_prefs")
    val codeCacheDir = File(appDataDir, "code_cache")
    val externalDataDir = File(virtualSdcardDir, packageName)

    filesDir.mkdirs()
    cacheDir.mkdirs()
    dbDir.mkdirs()
    prefsDir.mkdirs()
    codeCacheDir.mkdirs()
    externalDataDir.mkdirs()

    // Initialize mock default sandboxed config file if not present
    val configFile = File(filesDir, "sandbox_env.json")
    if (!configFile.exists()) {
      configFile.writeText(
        """
        {
          "virtual_package": "$packageName",
          "isolation_level": "STRICT_CONTAINER",
          "storage_engine": "VFS_V2",
          "created_at": ${System.currentTimeMillis()},
          "sandboxed": true
        }
        """.trimIndent()
      )
    }

    return appDataDir
  }

  fun getPackageDataDir(packageName: String): File {
    val dir = File(virtualDataRootDir, packageName)
    if (!dir.exists()) dir.mkdirs()
    return dir
  }

  fun getPackageFilesDir(packageName: String): File {
    val dir = File(getPackageDataDir(packageName), "files")
    if (!dir.exists()) dir.mkdirs()
    return dir
  }

  fun getPackageCacheDir(packageName: String): File {
    val dir = File(getPackageDataDir(packageName), "cache")
    if (!dir.exists()) dir.mkdirs()
    return dir
  }

  fun getPackageDatabasesDir(packageName: String): File {
    val dir = File(getPackageDataDir(packageName), "databases")
    if (!dir.exists()) dir.mkdirs()
    return dir
  }

  fun getPackagePrefsDir(packageName: String): File {
    val dir = File(getPackageDataDir(packageName), "shared_prefs")
    if (!dir.exists()) dir.mkdirs()
    return dir
  }

  /**
   * Redirects a guest request for a file path into its sandboxed counterpart.
   */
  fun redirectVirtualPath(requestedPath: String, packageName: String): File {
    val normalized = requestedPath.replace("\\", "/")
    return when {
      normalized.startsWith("/data/data/$packageName") -> {
        val subPath = normalized.removePrefix("/data/data/$packageName").trimStart('/')
        File(getPackageDataDir(packageName), subPath)
      }
      normalized.startsWith("/data/user/0/$packageName") -> {
        val subPath = normalized.removePrefix("/data/user/0/$packageName").trimStart('/')
        File(getPackageDataDir(packageName), subPath)
      }
      normalized.startsWith("/sdcard") || normalized.startsWith("/storage/emulated/0") -> {
        val subPath = normalized
          .removePrefix("/storage/emulated/0")
          .removePrefix("/sdcard")
          .trimStart('/')
        File(File(virtualSdcardDir, packageName), subPath)
      }
      else -> {
        // Safe fallback within package files directory
        val fileName = File(normalized).name
        File(getPackageFilesDir(packageName), fileName)
      }
    }
  }

  /**
   * Computes granular storage metrics across the whole sandbox or specific package.
   */
  fun calculateStorageMetrics(packageName: String? = null): SandboxStorageMetrics {
    var totalBytes = 0L
    var dataBytes = 0L
    var cacheBytes = 0L
    var databaseBytes = 0L
    var prefsBytes = 0L
    var dexBytes = 0L
    var apkBytes = 0L
    var fileCount = 0

    fun calculateDir(dir: File, onFile: (File, Long) -> Unit) {
      if (!dir.exists()) return
      dir.walkTopDown().forEach { file ->
        if (file.isFile) {
          val length = file.length()
          totalBytes += length
          fileCount++
          onFile(file, length)
        }
      }
    }

    if (packageName != null) {
      val appDir = File(virtualDataRootDir, packageName)
      calculateDir(File(appDir, "files")) { _, len -> dataBytes += len }
      calculateDir(File(appDir, "cache")) { _, len -> cacheBytes += len }
      calculateDir(File(appDir, "databases")) { _, len -> databaseBytes += len }
      calculateDir(File(appDir, "shared_prefs")) { _, len -> prefsBytes += len }
    } else {
      calculateDir(sandboxRootDir) { file, len ->
        val path = file.absolutePath
        when {
          path.contains("/cache/") -> cacheBytes += len
          path.contains("/databases/") -> databaseBytes += len
          path.contains("/shared_prefs/") -> prefsBytes += len
          path.contains("/opt_dex/") -> dexBytes += len
          path.contains("/apk_store/") -> apkBytes += len
          path.contains("/files/") -> dataBytes += len
          else -> dataBytes += len
        }
      }
    }

    return SandboxStorageMetrics(
      totalBytes = totalBytes,
      dataBytes = dataBytes,
      cacheBytes = cacheBytes,
      databaseBytes = databaseBytes,
      prefsBytes = prefsBytes,
      dexBytes = dexBytes,
      apkBytes = apkBytes,
      fileCount = fileCount
    )
  }

  /**
   * Lists files for interactive UI exploration in the sandbox browser.
   */
  fun listSandboxDirectory(directoryPath: String? = null): List<SandboxFileItem> {
    val targetDir = if (directoryPath.isNullOrBlank()) sandboxRootDir else File(directoryPath)
    if (!targetDir.exists() || !targetDir.isDirectory) return emptyList()

    val files = targetDir.listFiles() ?: return emptyList()
    return files.map { file ->
      val relative = file.absolutePath.removePrefix(sandboxRootDir.absolutePath)
        .ifEmpty { "/" }
      SandboxFileItem(
        name = file.name,
        absolutePath = file.absolutePath,
        relativeVirtualPath = relative,
        isDirectory = file.isDirectory,
        sizeBytes = if (file.isDirectory) calculateDirSize(file) else file.length(),
        lastModified = file.lastModified(),
        extension = file.extension,
        childrenCount = if (file.isDirectory) file.list()?.size ?: 0 else 0
      )
    }.sortedWith(compareByDescending<SandboxFileItem> { it.isDirectory }.thenBy { it.name })
  }

  private fun calculateDirSize(dir: File): Long {
    var size = 0L
    dir.walkTopDown().forEach { if (it.isFile) size += it.length() }
    return size
  }

  /**
   * Purges the cache directory for a package or all packages.
   */
  fun purgeCache(packageName: String? = null): Boolean {
    return try {
      if (packageName != null) {
        val cache = File(getPackageDataDir(packageName), "cache")
        cache.deleteRecursively()
        cache.mkdirs()
      } else {
        virtualDataRootDir.listFiles()?.forEach { appDir ->
          val cache = File(appDir, "cache")
          cache.deleteRecursively()
          cache.mkdirs()
        }
      }
      true
    } catch (e: Exception) {
      false
    }
  }

  /**
   * Wipes the entire sandbox data (resetting the environment).
   */
  fun resetSandbox(): Boolean {
    return try {
      sandboxRootDir.deleteRecursively()
      ensureDirectories()
      true
    } catch (e: Exception) {
      false
    }
  }

  /**
   * Copies a file from source into the sandbox APK store.
   */
  fun storeApkFile(sourceFile: File, destinationFileName: String): File {
    val dest = File(apkStoreDir, destinationFileName)
    sourceFile.copyTo(dest, overwrite = true)
    return dest
  }
}
