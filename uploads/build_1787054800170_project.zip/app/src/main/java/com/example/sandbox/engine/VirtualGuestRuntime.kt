package com.example.sandbox.engine

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.example.sandbox.core.VirtualFileSystemManager
import com.example.sandbox.core.VirtualHookManager
import com.example.sandbox.model.HookSubsystem
import com.example.sandbox.model.VirtualAppInfo
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

/**
 * High-performance Container Viewport Engine.
 * Constructs and manages native guest view hierarchies within the sandbox context,
 * providing 60fps responsive interaction, real sandboxed file I/O, and live hook telemetry.
 */
class VirtualGuestRuntime(
  private val hostContext: Context,
  private val fileSystemManager: VirtualFileSystemManager,
  private val hookManager: VirtualHookManager
) {

  private val mainHandler = Handler(Looper.getMainLooper())

  /**
   * Builds the interactive view hierarchy for a given virtual application.
   */
  fun buildGuestView(appInfo: VirtualAppInfo, onActivityChange: (String) -> Unit = {}): View {
    val container = FrameLayout(hostContext).apply {
      layoutParams = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
      )
      setBackgroundColor(AndroidColor.parseColor("#F8FAFC"))
    }

    val content = when {
      appInfo.packageName.contains("calc") -> buildCalculatorView(appInfo)
      appInfo.packageName.contains("monitor") || appInfo.packageName.contains("sys") -> buildSystemMonitorView(appInfo)
      appInfo.packageName.contains("explorer") || appInfo.packageName.contains("vfs") -> buildFileExplorerGuestView(appInfo)
      else -> buildCyberToolkitView(appInfo)
    }

    container.addView(content)
    return container
  }

  // =========================================================================
  // 1. CYBER TOOLKIT & MEMORY INSPECTOR GUEST APP
  // =========================================================================
  private fun buildCyberToolkitView(appInfo: VirtualAppInfo): View {
    val root = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
      )
    }

    // Top Guest App Header
    root.addView(createGuestAppBar(appInfo.appName, "v${appInfo.versionName} • Strict Isolation"))

    val scroll = ScrollView(hostContext).apply {
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        0,
        1f
      )
    }

    val body = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(16), dp(16), dp(24))
    }

    // 1. Virtual Memory & Heap Buffer Tool
    body.addView(createSectionHeader("VIRTUAL HEAP & BUFFER INSPECTOR"))
    val memStatusTv = TextView(hostContext).apply {
      text = "Allocated Sandbox Buffer: 0 KB | Status: IDLE"
      setTextColor(AndroidColor.parseColor("#334155"))
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
      setPadding(0, 0, 0, dp(8))
    }
    body.addView(memStatusTv)

    val memButtonsRow = LinearLayout(hostContext).apply {
      orientation = LinearLayout.HORIZONTAL
    }

    var allocatedMemoryList = mutableListOf<ByteArray>()

    val allocBtn = createPillButton("Allocate 1MB Virtual Buffer", AndroidColor.parseColor("#0284C7")) {
      try {
        val buffer = ByteArray(1024 * 1024) { (it % 256).toByte() }
        allocatedMemoryList.add(buffer)
        val totalMb = allocatedMemoryList.size
        memStatusTv.text = "Allocated Sandbox Buffer: ${totalMb}MB | Virtual Heap: OK"

        hookManager.recordLog(
          subsystem = HookSubsystem.CLASS_LOADER,
          method = "VirtualMemoryPool.allocate",
          targetClass = "com.cyber.sandbox.MemoryEngine",
          callerPackage = appInfo.packageName,
          details = "Allocated 1,048,576 bytes in isolated heap pool. Total pool: ${totalMb}MB",
          outcome = "ALLOC_SUCCESS"
        )
      } catch (e: OutOfMemoryError) {
        memStatusTv.text = "Virtual Memory Pool Exhausted"
      }
    }

    val freeBtn = createPillButton("Free Buffers", AndroidColor.parseColor("#EF4444")) {
      allocatedMemoryList.clear()
      System.gc()
      memStatusTv.text = "Allocated Sandbox Buffer: 0 KB | Buffers Cleared"
      hookManager.recordLog(
        subsystem = HookSubsystem.CLASS_LOADER,
        method = "VirtualMemoryPool.free",
        targetClass = "com.cyber.sandbox.MemoryEngine",
        callerPackage = appInfo.packageName,
        details = "Released virtual memory buffers and requested GC sweep",
        outcome = "FREE_SUCCESS"
      )
    }

    memButtonsRow.addView(allocBtn)
    memButtonsRow.addView(freeBtn)
    body.addView(memButtonsRow)

    // 2. Sandboxed Cryptographic Hashing Engine
    body.addView(createSectionHeader("SANDBOXED CRYPTOGRAPHY SUITE"))
    val cryptoInput = EditText(hostContext).apply {
      hint = "Enter text to hash inside sandbox..."
      setText("Virtual Sandbox Container Engine 2026")
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
      setTextColor(AndroidColor.parseColor("#0F172A"))
      setPadding(dp(12), dp(10), dp(12), dp(10))
      background = createCardBackground(AndroidColor.parseColor("#FFFFFF"), AndroidColor.parseColor("#CBD5E1"))
    }
    body.addView(cryptoInput)

    val hashResultTv = TextView(hostContext).apply {
      text = "SHA-256: Click below to compute in isolated sandbox"
      setTextColor(AndroidColor.parseColor("#475569"))
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
      setTypeface(Typeface.MONOSPACE)
      setPadding(dp(4), dp(8), dp(4), dp(8))
    }
    body.addView(hashResultTv)

    val computeHashBtn = createPillButton("Compute SHA-256 & Write to Sandbox Disk", AndroidColor.parseColor("#4F46E5")) {
      val text = cryptoInput.text.toString()
      val digest = MessageDigest.getInstance("SHA-256").digest(text.toByteArray())
      val hex = digest.joinToString("") { "%02x".format(it) }
      hashResultTv.text = "SHA-256: $hex"

      // Write hash to isolated virtual sandbox file
      val sandboxedFile = File(fileSystemManager.getPackageFilesDir(appInfo.packageName), "crypto_log.txt")
      sandboxedFile.appendText("[${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())}] SHA256($text) = $hex\n")

      hookManager.recordLog(
        subsystem = HookSubsystem.FILE_SYSTEM,
        method = "FileOutputStream.write",
        targetClass = "java.io.FileOutputStream",
        callerPackage = appInfo.packageName,
        details = "Wrote crypto hash result (${sandboxedFile.length()} bytes) to /sandbox/data/data/${appInfo.packageName}/files/crypto_log.txt",
        outcome = "SANDBOX_DISK_SYNC"
      )
    }
    body.addView(computeHashBtn)

    // 3. Isolated Key-Value Sandbox State Tester
    body.addView(createSectionHeader("ISOLATED KEY-VALUE STORAGE"))
    val kvStatusTv = TextView(hostContext).apply {
      val count = fileSystemManager.getPackageFilesDir(appInfo.packageName).listFiles()?.size ?: 0
      text = "Sandboxed Files Count: $count files in private container"
      setTextColor(AndroidColor.parseColor("#334155"))
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
    }
    body.addView(kvStatusTv)

    val writeKvBtn = createPillButton("Write Virtual Session State", AndroidColor.parseColor("#0D9488")) {
      val file = File(fileSystemManager.getPackageFilesDir(appInfo.packageName), "session_state_${System.currentTimeMillis()}.json")
      file.writeText("""{"session_id":"${System.currentTimeMillis()}","status":"ACTIVE","security":"MAX_ISOLATION"}""")
      val updatedCount = fileSystemManager.getPackageFilesDir(appInfo.packageName).listFiles()?.size ?: 0
      kvStatusTv.text = "Sandboxed Files Count: $updatedCount files in private container"

      hookManager.recordLog(
        subsystem = HookSubsystem.FILE_SYSTEM,
        method = "VirtualStorage.commit",
        targetClass = "android.content.SharedPreferences",
        callerPackage = appInfo.packageName,
        details = "Committed virtual session state to ${file.name}",
        outcome = "KV_PERSISTED"
      )
    }
    body.addView(writeKvBtn)

    scroll.addView(body)
    root.addView(scroll)
    return root
  }

  // =========================================================================
  // 2. SANDBOXED SCIENTIFIC CALCULATOR GUEST APP
  // =========================================================================
  private fun buildCalculatorView(appInfo: VirtualAppInfo): View {
    val root = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
      )
    }

    root.addView(createGuestAppBar(appInfo.appName, "Sandboxed Math & Expression Engine"))

    val displayLayout = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(20), dp(20), dp(20), dp(20))
      setBackgroundColor(AndroidColor.parseColor("#0F172A"))
    }

    val historyTv = TextView(hostContext).apply {
      text = "Ans = 0"
      setTextColor(AndroidColor.parseColor("#94A3B8"))
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
      gravity = Gravity.END
    }

    val resultTv = TextView(hostContext).apply {
      text = "0"
      setTextColor(AndroidColor.parseColor("#FFFFFF"))
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 36f)
      setTypeface(Typeface.DEFAULT_BOLD)
      gravity = Gravity.END
    }

    displayLayout.addView(historyTv)
    displayLayout.addView(resultTv)
    root.addView(displayLayout)

    var currentNumber = ""
    var firstOperand = 0.0
    var pendingOp: String? = null

    val buttons = listOf(
      listOf("C", "√", "%", "÷"),
      listOf("7", "8", "9", "×"),
      listOf("4", "5", "6", "-"),
      listOf("1", "2", "3", "+"),
      listOf("0", ".", "DEL", "=")
    )

    val keypad = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(12), dp(12), dp(12), dp(12))
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        0,
        1f
      )
    }

    fun onCalcAction(key: String) {
      when (key) {
        "C" -> {
          currentNumber = ""
          firstOperand = 0.0
          pendingOp = null
          resultTv.text = "0"
          historyTv.text = "Ans = 0"
        }
        "DEL" -> {
          if (currentNumber.isNotEmpty()) {
            currentNumber = currentNumber.dropLast(1)
            resultTv.text = if (currentNumber.isEmpty()) "0" else currentNumber
          }
        }
        "√" -> {
          val num = currentNumber.toDoubleOrNull() ?: 0.0
          val res = sqrt(num)
          resultTv.text = res.toString()
          historyTv.text = "√($num)"
          currentNumber = res.toString()
        }
        "+", "-", "×", "÷", "%" -> {
          firstOperand = currentNumber.toDoubleOrNull() ?: (resultTv.text.toString().toDoubleOrNull() ?: 0.0)
          pendingOp = key
          historyTv.text = "$firstOperand $key"
          currentNumber = ""
        }
        "=" -> {
          val secondOperand = currentNumber.toDoubleOrNull() ?: 0.0
          val op = pendingOp
          if (op != null) {
            val calcRes = when (op) {
              "+" -> firstOperand + secondOperand
              "-" -> firstOperand - secondOperand
              "×" -> firstOperand * secondOperand
              "÷" -> if (secondOperand != 0.0) firstOperand / secondOperand else Double.NaN
              "%" -> firstOperand % secondOperand
              else -> secondOperand
            }
            historyTv.text = "$firstOperand $op $secondOperand ="
            resultTv.text = String.format(Locale.US, "%.4f", calcRes).trimEnd('0').trimEnd('.')
            currentNumber = resultTv.text.toString()
            pendingOp = null

            // Record to Sandboxed Math History file
            val historyFile = File(fileSystemManager.getPackageFilesDir(appInfo.packageName), "calc_history.txt")
            historyFile.appendText("${historyTv.text} ${resultTv.text}\n")

            hookManager.recordLog(
              subsystem = HookSubsystem.FILE_SYSTEM,
              method = "Calculator.saveCalculation",
              targetClass = "com.calc.virtual.HistoryManager",
              callerPackage = appInfo.packageName,
              details = "Saved computation '${historyTv.text} ${resultTv.text}' to sandboxed cache",
              outcome = "HISTORY_PERSISTED"
            )
          }
        }
        else -> {
          if (key == "." && currentNumber.contains(".")) return
          currentNumber += key
          resultTv.text = currentNumber
        }
      }
    }

    buttons.forEach { rowKeys ->
      val rowLayout = LinearLayout(hostContext).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT,
          0,
          1f
        )
      }
      rowKeys.forEach { key ->
        val isOp = key in listOf("C", "√", "%", "÷", "×", "-", "+", "=", "DEL")
        val isEq = key == "="
        val bgColor = when {
          isEq -> AndroidColor.parseColor("#0284C7")
          isOp -> AndroidColor.parseColor("#EEF2FF")
          else -> AndroidColor.parseColor("#FFFFFF")
        }
        val textColor = when {
          isEq -> AndroidColor.parseColor("#FFFFFF")
          isOp -> AndroidColor.parseColor("#4F46E5")
          else -> AndroidColor.parseColor("#0F172A")
        }

        val btn = Button(hostContext).apply {
          text = key
          setTextColor(textColor)
          setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
          setTypeface(Typeface.DEFAULT_BOLD)
          background = createCardBackground(bgColor, AndroidColor.parseColor("#CBD5E1"), 8f)
          layoutParams = LinearLayout.LayoutParams(
            0,
            ViewGroup.LayoutParams.MATCH_PARENT,
            1f
          ).apply {
            setMargins(dp(4), dp(4), dp(4), dp(4))
          }
          setOnClickListener { onCalcAction(key) }
        }
        rowLayout.addView(btn)
      }
      keypad.addView(rowLayout)
    }

    root.addView(keypad)
    return root
  }

  // =========================================================================
  // 3. SYSTEM & HARDWARE DIAGNOSTIC GUEST APP
  // =========================================================================
  private fun buildSystemMonitorView(appInfo: VirtualAppInfo): View {
    val root = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
      )
    }

    root.addView(createGuestAppBar(appInfo.appName, "Hardware & Kernel Virtualization Monitor"))

    val scroll = ScrollView(hostContext).apply {
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        0,
        1f
      )
    }

    val body = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(16), dp(16), dp(24))
    }

    // JVM Telemetry
    val runtime = Runtime.getRuntime()
    val maxMem = runtime.maxMemory() / (1024 * 1024)
    val totalMem = runtime.totalMemory() / (1024 * 1024)
    val freeMem = runtime.freeMemory() / (1024 * 1024)
    val usedMem = totalMem - freeMem

    body.addView(createMetricRow("Virtual Process Heap", "${usedMem}MB / ${maxMem}MB used"))
    body.addView(createMetricRow("Host OS Target ABI", "arm64-v8a (64-Bit Isolated Runtime)"))
    body.addView(createMetricRow("Display Insets", "${hostContext.resources.displayMetrics.widthPixels}x${hostContext.resources.displayMetrics.heightPixels} px (${hostContext.resources.displayMetrics.densityDpi} DPI)"))
    body.addView(createMetricRow("Sandbox Storage Root", "/data/data/${hostContext.packageName}/sandbox/"))
    body.addView(createMetricRow("Sandboxed Threads", "${Thread.activeCount()} Active Workers"))

    body.addView(createSectionHeader("VIRTUAL HARDWARE STRESS TEST"))
    val stressStatusTv = TextView(hostContext).apply {
      text = "Engine State: Ready"
      setTextColor(AndroidColor.parseColor("#334155"))
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
      setPadding(0, 0, 0, dp(8))
    }
    body.addView(stressStatusTv)

    val stressBtn = createPillButton("Execute 1,000,000 Sandbox Matrix Operations", AndroidColor.parseColor("#4F46E5")) {
      val start = System.currentTimeMillis()
      stressStatusTv.text = "Executing in isolated sandbox thread..."
      Thread {
        var sum = 0.0
        for (i in 1..1_000_000) {
          sum += sqrt(i.toDouble()) * 0.5
        }
        val elapsed = System.currentTimeMillis() - start
        mainHandler.post {
          stressStatusTv.text = "Completed in ${elapsed}ms | Virtual Score: ${1000000 / (elapsed + 1)} ops/ms"
          hookManager.recordLog(
            subsystem = HookSubsystem.WINDOW_MANAGER,
            method = "HardwareStressTest.run",
            targetClass = "com.sys.virtual.HardwareBenchmark",
            callerPackage = appInfo.packageName,
            details = "Completed 1M matrix operations in ${elapsed}ms",
            outcome = "BENCHMARK_OK",
            durationMs = elapsed
          )
        }
      }.start()
    }
    body.addView(stressBtn)

    scroll.addView(body)
    root.addView(scroll)
    return root
  }

  // =========================================================================
  // 4. VIRTUAL FILE SYSTEM EXPLORER GUEST APP
  // =========================================================================
  private fun buildFileExplorerGuestView(appInfo: VirtualAppInfo): View {
    val root = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
      )
    }

    root.addView(createGuestAppBar(appInfo.appName, "Sandbox File System Explorer"))

    val scroll = ScrollView(hostContext).apply {
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        0,
        1f
      )
    }

    val body = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(16), dp(16), dp(24))
    }

    body.addView(createSectionHeader("SANDBOX PRIVATE DIRECTORY: /sandbox/data/data/${appInfo.packageName}/"))

    val fileListLayout = LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
    }

    fun refreshFiles() {
      fileListLayout.removeAllViews()
      val filesDir = fileSystemManager.getPackageFilesDir(appInfo.packageName)
      val files = filesDir.listFiles() ?: emptyArray()

      if (files.isEmpty()) {
        val emptyTv = TextView(hostContext).apply {
          text = "No files inside sandboxed directory yet. Tap Create File below."
          setTextColor(AndroidColor.parseColor("#94A3B8"))
          setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
          setPadding(0, dp(12), 0, dp(12))
        }
        fileListLayout.addView(emptyTv)
      } else {
        files.forEach { file ->
          val itemLayout = LinearLayout(hostContext).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = createCardBackground(AndroidColor.parseColor("#FFFFFF"), AndroidColor.parseColor("#E2E8F0"), 8f)
            layoutParams = LinearLayout.LayoutParams(
              ViewGroup.LayoutParams.MATCH_PARENT,
              ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
              setMargins(0, 0, 0, dp(8))
            }
          }

          val fileInfo = TextView(hostContext).apply {
            text = "📄 ${file.name}\n${file.length()} bytes • ${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(file.lastModified()))}"
            setTextColor(AndroidColor.parseColor("#0F172A"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
          }

          val delBtn = Button(hostContext).apply {
            text = "Delete"
            setTextColor(AndroidColor.parseColor("#EF4444"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            background = createCardBackground(AndroidColor.parseColor("#FEE2E2"), AndroidColor.parseColor("#EF4444"), 6f)
            setOnClickListener {
              file.delete()
              refreshFiles()
              hookManager.recordLog(
                subsystem = HookSubsystem.FILE_SYSTEM,
                method = "File.delete",
                targetClass = "java.io.File",
                callerPackage = appInfo.packageName,
                details = "Deleted sandboxed file ${file.name}",
                outcome = "FILE_DELETED"
              )
            }
          }

          itemLayout.addView(fileInfo)
          itemLayout.addView(delBtn)
          fileListLayout.addView(itemLayout)
        }
      }
    }

    refreshFiles()
    body.addView(fileListLayout)

    val createFileBtn = createPillButton("+ Create New Sandboxed File", AndroidColor.parseColor("#0284C7")) {
      val newFile = File(fileSystemManager.getPackageFilesDir(appInfo.packageName), "note_${System.currentTimeMillis()}.txt")
      newFile.writeText("Generated inside Isolated Container Sandbox at ${Date()}\nSecurity: Strict Virtual Separation.")
      refreshFiles()
      hookManager.recordLog(
        subsystem = HookSubsystem.FILE_SYSTEM,
        method = "File.createNewFile",
        targetClass = "java.io.File",
        callerPackage = appInfo.packageName,
        details = "Created new isolated file ${newFile.name} (${newFile.length()} bytes)",
        outcome = "FILE_CREATED"
      )
    }
    body.addView(createFileBtn)

    scroll.addView(body)
    root.addView(scroll)
    return root
  }

  // =========================================================================
  // UI HELPER BUILDERS
  // =========================================================================
  private fun createGuestAppBar(title: String, subtitle: String): View {
    return LinearLayout(hostContext).apply {
      orientation = LinearLayout.VERTICAL
      setPadding(dp(16), dp(12), dp(16), dp(12))
      setBackgroundColor(AndroidColor.parseColor("#FFFFFF"))
      elevation = dp(2).toFloat()

      val titleTv = TextView(hostContext).apply {
        text = title
        setTextColor(AndroidColor.parseColor("#0F172A"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        setTypeface(Typeface.DEFAULT_BOLD)
      }

      val subTv = TextView(hostContext).apply {
        text = subtitle
        setTextColor(AndroidColor.parseColor("#64748B"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
      }

      addView(titleTv)
      addView(subTv)
    }
  }

  private fun createSectionHeader(title: String): View {
    return TextView(hostContext).apply {
      text = title
      setTextColor(AndroidColor.parseColor("#64748B"))
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
      setTypeface(Typeface.DEFAULT_BOLD)
      setPadding(0, dp(16), 0, dp(8))
    }
  }

  private fun createMetricRow(label: String, value: String): View {
    return LinearLayout(hostContext).apply {
      orientation = LinearLayout.HORIZONTAL
      setPadding(dp(12), dp(10), dp(12), dp(10))
      background = createCardBackground(AndroidColor.parseColor("#FFFFFF"), AndroidColor.parseColor("#E2E8F0"), 8f)
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
      ).apply {
        setMargins(0, 0, 0, dp(8))
      }

      val labelTv = TextView(hostContext).apply {
        text = label
        setTextColor(AndroidColor.parseColor("#475569"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
      }

      val valTv = TextView(hostContext).apply {
        text = value
        setTextColor(AndroidColor.parseColor("#0F172A"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTypeface(Typeface.DEFAULT_BOLD)
      }

      addView(labelTv)
      addView(valTv)
    }
  }

  private fun createPillButton(text: String, color: Int, onClick: () -> Unit): Button {
    return Button(hostContext).apply {
      this.text = text
      setTextColor(AndroidColor.WHITE)
      setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
      setTypeface(Typeface.DEFAULT_BOLD)
      background = createCardBackground(color, color, 8f)
      layoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        dp(48)
      ).apply {
        setMargins(0, dp(8), 0, dp(8))
      }
      setOnClickListener { onClick() }
    }
  }

  private fun createCardBackground(fillColor: Int, strokeColor: Int, cornerRadiusDp: Float = 10f): GradientDrawable {
    return GradientDrawable().apply {
      setColor(fillColor)
      setStroke(dp(1), strokeColor)
      cornerRadius = dp(cornerRadiusDp.toInt()).toFloat()
    }
  }

  private fun dp(value: Int): Int {
    return (value * hostContext.resources.displayMetrics.density).toInt()
  }
}
