package com.example.emulator.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.emulator.guest.GuestApp

@Composable
fun ApkInstallerDialog(
  installedApps: List<GuestApp>,
  onInstallApkUri: (Uri, String?) -> Unit,
  onLaunchApp: (GuestApp) -> Unit,
  onUninstallApp: (String) -> Unit = {},
  onDismiss: () -> Unit
) {
  val apkFilePicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "imported_app.apk"
      onInstallApkUri(uri, fileName)
      onDismiss()
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color(0xFF0F172A),
      modifier = Modifier
        .fillMaxWidth()
        .height(580.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp)
      ) {
        // Header
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.InstallMobile, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("مدير تثبيت التطبيقات والألعاب (APK)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Import APK from Host Device Button
        Button(
          onClick = { apkFilePicker.launch("application/vnd.android.package-archive") },
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
        ) {
          Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("اختيار ملف APK من ذاكرة الهاتف وتثبيته", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Surface(
          color = Color(0xFF1E293B),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "يتم استخراج وقراءة بيانات حزمة الـ APK وحفظها مباشرة داخل مسار /data/app/ في نظام الـ RootFS المعزول.",
            fontSize = 11.sp,
            color = Color(0xFF94A3B8),
            modifier = Modifier.padding(8.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "التطبيقات المثبتة في الـ RootFS (${installedApps.size})",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = Color(0xFF38BDF8)
        )

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
        ) {
          items(installedApps, key = { it.id }) { app ->
            Surface(
              color = Color(0xFF1E293B),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(8.dp)
              ) {
                Icon(
                  imageVector = if (app.isSystemApp) Icons.Default.Security else Icons.Default.Apps,
                  contentDescription = null,
                  tint = if (app.isSystemApp) Color(0xFF94A3B8) else Color(0xFF22C55E),
                  modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = app.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                  Text(text = "${app.packageName} • ${app.apkSizeMb} MB", fontSize = 9.sp, color = Color(0xFF94A3B8))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                  if (!app.isSystemApp) {
                    IconButton(
                      onClick = { onUninstallApp(app.packageName) },
                      modifier = Modifier.size(28.dp)
                    ) {
                      Icon(Icons.Default.Delete, contentDescription = "Uninstall", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                    }
                  }
                  Button(
                    onClick = {
                      onLaunchApp(app)
                      onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                  ) {
                    Text("تشغيل", fontSize = 10.sp, color = Color.White)
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("إغلاق", color = Color(0xFFCBD5E1))
        }
      }
    }
  }
}
