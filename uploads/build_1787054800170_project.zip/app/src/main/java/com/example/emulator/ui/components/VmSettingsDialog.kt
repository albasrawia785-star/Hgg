package com.example.emulator.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.emulator.guest.VmHardwareProfile

@Composable
fun VmSettingsDialog(
  currentProfile: VmHardwareProfile,
  onSaveProfile: (VmHardwareProfile) -> Unit,
  onDismiss: () -> Unit
) {
  var ramMb by remember { mutableStateOf(currentProfile.ramMb) }
  var cpuCores by remember { mutableStateOf(currentProfile.cpuCores) }
  var hasRoot by remember { mutableStateOf(currentProfile.hasRoot) }
  var hasGpu by remember { mutableStateOf(currentProfile.hasGpuAcceleration) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color(0xFF0F172A),
      modifier = Modifier
        .fillMaxWidth()
        .height(520.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp)
      ) {
        // Header
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Memory, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("إعدادات العتاد الافتراضي (VM Profile)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
          modifier = Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          // RAM Selection
          Text("تخصيص الذاكرة العشوائية (RAM): ${ramMb / 1024} GB", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(2048, 4096, 6144, 8192).forEach { mb ->
              FilterChip(
                selected = ramMb == mb,
                onClick = { ramMb = mb },
                label = { Text("${mb / 1024} GB", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = Color(0xFF0284C7),
                  selectedLabelColor = Color.White
                )
              )
            }
          }

          // CPU Cores Selection
          Text("أنوية المعالج الافتراضي (vCPU): $cpuCores Cores", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(2, 4, 8).forEach { cores ->
              FilterChip(
                selected = cpuCores == cores,
                onClick = { cpuCores = cores },
                label = { Text("$cores Cores", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = Color(0xFF0284C7),
                  selectedLabelColor = Color.White
                )
              )
            }
          }

          HorizontalDivider(color = Color(0xFF334155))

          // Root toggle
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column {
              Text("صلاحيات الـ Root (Superuser)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
              Text("تفعيل su الثنائي والوصول المباشر للـ RootFS", fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
            Switch(
              checked = hasRoot,
              onCheckedChange = { hasRoot = it },
              colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF22C55E))
            )
          }

          // GPU Acceleration toggle
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column {
              Text("تسريع الرسوميات (GPU Acceleration)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
              Text("معالجة OpenGL ES 3.2 و EGL المباشرة", fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
            Switch(
              checked = hasGpu,
              onCheckedChange = { hasGpu = it },
              colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF0284C7))
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء", color = Color(0xFF94A3B8))
          }
          Button(
            onClick = {
              onSaveProfile(
                currentProfile.copy(
                  ramMb = ramMb,
                  cpuCores = cpuCores,
                  hasRoot = hasRoot,
                  hasGpuAcceleration = hasGpu
                )
              )
              onDismiss()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ التغييرات", color = Color.White)
          }
        }
      }
    }
  }
}
