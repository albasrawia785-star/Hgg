package com.example.emulator.rootfs

import android.content.Context
import android.util.Log
import com.example.emulator.guest.RootFsNode
import java.io.File
import java.io.FileOutputStream

/**
 * RootFS & Linux Namespace / chroot Simulation Engine.
 * Manages physical disk layout for the Android Micro-VM Guest OS.
 */
class VirtualRootFsManager(private val context: Context) {
  private val TAG = "VirtualRootFsManager"

  val rootFsDir: File by lazy {
    File(context.filesDir, "microvm_rootfs").apply { if (!exists()) mkdirs() }
  }

  val systemDir: File by lazy { File(rootFsDir, "system").apply { if (!exists()) mkdirs() } }
  val vendorDir: File by lazy { File(rootFsDir, "vendor").apply { if (!exists()) mkdirs() } }
  val dataDir: File by lazy { File(rootFsDir, "data").apply { if (!exists()) mkdirs() } }
  val dataAppDir: File by lazy { File(dataDir, "app").apply { if (!exists()) mkdirs() } }
  val dataDataDir: File by lazy { File(dataDir, "data").apply { if (!exists()) mkdirs() } }
  val dataSystemDir: File by lazy { File(dataDir, "system").apply { if (!exists()) mkdirs() } }
  val apexDir: File by lazy { File(rootFsDir, "apex").apply { if (!exists()) mkdirs() } }
  val devDir: File by lazy { File(rootFsDir, "dev").apply { if (!exists()) mkdirs() } }
  val procDir: File by lazy { File(rootFsDir, "proc").apply { if (!exists()) mkdirs() } }
  val sysDir: File by lazy { File(rootFsDir, "sys").apply { if (!exists()) mkdirs() } }
  val etcDir: File by lazy { File(rootFsDir, "etc").apply { if (!exists()) mkdirs() } }
  val storageDir: File by lazy { File(rootFsDir, "storage").apply { if (!exists()) mkdirs() } }

  init {
    initializeRootFsStructure()
  }

  fun initializeRootFsStructure() {
    try {
      // 1. Generate /system/build.prop
      val buildPropFile = File(systemDir, "build.prop")
      if (!buildPropFile.exists()) {
        buildPropFile.writeText(
          """
          # Android Micro-VM Guest Properties
          ro.build.version.release=14
          ro.build.version.sdk=34
          ro.build.version.preview_sdk=0
          ro.build.version.codename=REL
          ro.build.type=userdebug
          ro.product.model=MicroVM-Pro-64
          ro.product.brand=AndroidVirtual
          ro.product.name=virtual_arm64
          ro.product.device=microvm_arm64
          ro.product.board=virtual_cortex
          ro.product.cpu.abilist=arm64-v8a,armeabi-v7a,armeabi
          ro.product.cpu.abi=arm64-v8a
          ro.product.cpu.abi2=armeabi-v7a
          ro.hardware=virtual_goldfish
          ro.hardware.gpu=opengles3.2_virtual
          ro.sf.lcd_density=440
          persist.sys.timezone=Asia/Riyadh
          persist.sys.root_access=3
          """.trimIndent()
        )
      }

      // 2. Generate /init.rc
      val initRcFile = File(rootFsDir, "init.rc")
      if (!initRcFile.exists()) {
        initRcFile.writeText(
          """
          # Micro-VM Android init.rc
          on early-init
              start ueventd
              mkdir /dev/binder_virtual 0666 root root
              mount tmpfs tmpfs /dev mode=0755
          
          on init
              export PATH /system/bin:/system/xbin:/vendor/bin
              export ANDROID_ROOT /system
              export ANDROID_DATA /data
              export ANDROID_STORAGE /storage
              export ANDROID_ART_ROOT /apex/com.android.art
          
          on boot
              ifup lo
              hostname microvm-guest
              start servicemanager
              start surfaceflinger
              start zygote
          """.trimIndent()
        )
      }

      // 3. Create essential binaries in /system/bin
      val systemBin = File(systemDir, "bin").apply { if (!exists()) mkdirs() }
      listOf("sh", "su", "pm", "am", "logcat", "getprop", "setprop", "df", "ps", "top", "ls", "cat", "chmod", "chown").forEach { binName ->
        val binFile = File(systemBin, binName)
        if (!binFile.exists()) {
          binFile.writeText("#!/system/bin/sh\n# Micro-VM guest binary stub: $binName\n")
        }
      }

      // 4. Generate /data/system/packages.xml
      val packagesXml = File(dataSystemDir, "packages.xml")
      if (!packagesXml.exists()) {
        packagesXml.writeText(
          """
          <?xml version='1.0' encoding='utf-8' standalone='yes' ?>
          <packages>
              <package name="com.android.systemui" codePath="/system/priv-app/SystemUI" ft="16b2" it="16b2" ut="16b2" version="34" userId="10010" />
              <package name="com.android.launcher3" codePath="/system/priv-app/Launcher3" ft="16b2" it="16b2" ut="16b2" version="34" userId="10011" />
              <package name="com.android.settings" codePath="/system/priv-app/Settings" ft="16b2" it="16b2" ut="16b2" version="34" userId="10012" />
          </packages>
          """.trimIndent()
        )
      }

      // 5. Create default guest storage
      val sdcard = File(storageDir, "emulated/0").apply { if (!exists()) mkdirs() }
      listOf("Download", "Documents", "DCIM", "Pictures", "Music").forEach { folder ->
        File(sdcard, folder).apply { if (!exists()) mkdirs() }
      }

      Log.i(TAG, "RootFS successfully initialized at ${rootFsDir.absolutePath}")
    } catch (e: Exception) {
      Log.e(TAG, "Error initializing RootFS: ${e.message}", e)
    }
  }

  fun listDirectoryNodes(dirPath: String): List<RootFsNode> {
    val targetDir = File(dirPath)
    if (!targetDir.exists() || !targetDir.isDirectory) return emptyList()

    return targetDir.listFiles()?.map { file ->
      RootFsNode(
        name = file.name,
        absolutePath = file.absolutePath,
        isDirectory = file.isDirectory,
        sizeBytes = if (file.isDirectory) 4096L else file.length(),
        permissions = if (file.isDirectory) "drwxr-xr-x" else "-rw-r--r--",
        owner = "root",
        group = "root",
        childrenCount = if (file.isDirectory) file.listFiles()?.size ?: 0 else 0
      )
    }?.sortedWith(compareByDescending<RootFsNode> { it.isDirectory }.thenBy { it.name.lowercase() })
      ?: emptyList()
  }

  fun installApkToRootFs(packageName: String, apkBytes: ByteArray): File {
    val appDir = File(dataAppDir, packageName).apply { if (!exists()) mkdirs() }
    val apkFile = File(appDir, "base.apk")
    FileOutputStream(apkFile).use { out ->
      out.write(apkBytes)
    }
    
    // Create guest app data dir
    val appDataDir = File(dataDataDir, packageName).apply { if (!exists()) mkdirs() }
    File(appDataDir, "files").apply { if (!exists()) mkdirs() }
    File(appDataDir, "databases").apply { if (!exists()) mkdirs() }
    File(appDataDir, "shared_prefs").apply { if (!exists()) mkdirs() }
    File(appDataDir, "cache").apply { if (!exists()) mkdirs() }

    return apkFile
  }

  fun calculateRootFsUsageMb(): Pair<Double, Double> {
    fun getDirSize(file: File): Long {
      var size = 0L
      if (file.isDirectory) {
        file.listFiles()?.forEach { size += getDirSize(it) }
      } else {
        size += file.length()
      }
      return size
    }
    val usedBytes = getDirSize(rootFsDir)
    val usedMb = (usedBytes / (1024.0 * 1024.0)) + 1250.0 // Base system image offset
    val totalMb = 8192.0 // 8GB Virtual Partition
    return Pair(usedMb, totalMb)
  }
}
