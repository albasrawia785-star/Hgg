package com.example.sandbox.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sandbox.model.VirtualAppInfo
import com.example.ui.theme.SandboxOutlineVariant
import com.example.ui.theme.SandboxPrimary
import com.example.ui.theme.SandboxSecondary
import com.example.ui.theme.SandboxTertiary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusActiveBg

/**
 * Installed & Embedded APK Packages Management Screen.
 */
@Composable
fun PackagesTab(
  installedApps: List<VirtualAppInfo>,
  runningApp: VirtualAppInfo?,
  onLaunchApp: (VirtualAppInfo) -> Unit,
  onInspectApp: (VirtualAppInfo) -> Unit,
  onImportApk: (android.net.Uri) -> Unit,
  modifier: Modifier = Modifier
) {
  val apkPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri ->
    if (uri != null) {
      onImportApk(uri)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    // Header & Import Button Row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "الحزم والتطبيقات الافتراضية",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF0F172A)
        )
        Text(
          text = "${installedApps.size} حزم مثبتة ضمن بيئة العزل",
          fontSize = 12.sp,
          color = Color(0xFF64748B)
        )
      }

      Button(
        onClick = { apkPickerLauncher.launch("application/vnd.android.package-archive") },
        colors = ButtonDefaults.buttonColors(containerColor = SandboxPrimary),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.testTag("import_external_apk_button")
      ) {
        Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("استيراد APK", fontSize = 13.sp)
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // List of Installed Virtual Apps
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      items(installedApps) { app ->
        val isRunning = runningApp?.packageName == app.packageName

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("app_item_${app.packageName}"),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = androidx.compose.foundation.BorderStroke(
            if (isRunning) 1.5.dp else 1.dp,
            if (isRunning) SandboxPrimary else SandboxOutlineVariant
          ),
          elevation = CardDefaults.cardElevation(defaultElevation = if (isRunning) 3.dp else 1.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            // App Avatar / Icon Placeholder
            Box(
              modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(if (app.isEmbedded) Color(0xFFE0F2FE) else Color(0xFFEEF2FF)),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Android,
                contentDescription = null,
                tint = if (app.isEmbedded) SandboxPrimary else SandboxSecondary,
                modifier = Modifier.size(26.dp)
              )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // App Metadata
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = app.appName,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F172A)
                )
                if (isRunning) {
                  Spacer(modifier = Modifier.width(6.dp))
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(StatusActiveBg)
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = "مشغل حالياً",
                      fontSize = 9.sp,
                      fontWeight = FontWeight.Bold,
                      color = StatusActive
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(2.dp))

              Text(
                text = "${app.packageName} • v${app.versionName}",
                fontSize = 11.sp,
                color = Color(0xFF64748B)
              )

              Spacer(modifier = Modifier.height(4.dp))

              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Target SDK: ${app.targetSdk} • ${app.components.size} مكونات",
                  fontSize = 11.sp,
                  color = Color(0xFF94A3B8)
                )
              }
            }

            // Action Buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { onInspectApp(app) },
                modifier = Modifier.testTag("inspect_app_${app.packageName}")
              ) {
                Icon(
                  imageVector = Icons.Default.Info,
                  contentDescription = "Inspect Manifest",
                  tint = Color(0xFF64748B),
                  modifier = Modifier.size(20.dp)
                )
              }

              Button(
                onClick = { onLaunchApp(app) },
                colors = ButtonDefaults.buttonColors(
                  containerColor = if (isRunning) StatusActive else SandboxPrimary
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("launch_app_${app.packageName}")
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isRunning) "تبديل" else "تشغيل", fontSize = 12.sp)
              }
            }
          }
        }
      }
    }
  }
}
