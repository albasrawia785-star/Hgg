package com.example.sandbox.core

import android.content.Context
import android.content.res.AssetManager
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.util.DisplayMetrics
import android.util.Log
import com.example.sandbox.model.HookSubsystem
import java.io.File
import java.lang.reflect.Method
import java.util.concurrent.ConcurrentHashMap

/**
 * Dynamic AssetManager & Resources Manager for external/embedded APKs.
 * Uses reflection on `AssetManager.addAssetPath()` to construct custom `Resources`
 * allowing the container to render guest layouts and resources in-memory.
 */
class VirtualResourcesManager(
  private val context: Context,
  private val hookManager: VirtualHookManager? = null
) {
  private val TAG = "VirtualResourcesManager"
  private val resourcesCache = ConcurrentHashMap<String, VirtualAppResources>()

  data class VirtualAppResources(
    val assetManager: AssetManager,
    val resources: Resources,
    val apkPath: String
  )

  private fun isZipArchive(file: File): Boolean {
    if (!file.exists() || file.length() < 4) return false
    return try {
      file.inputStream().use { stream ->
        val header = ByteArray(4)
        val read = stream.read(header)
        read == 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()
      }
    } catch (e: Exception) {
      false
    }
  }

  /**
   * Generates or retrieves custom Resources instance for a given APK file path.
   */
  fun getResourcesForApk(apkPath: String): VirtualAppResources {
    val cached = resourcesCache[apkPath]
    if (cached != null) return cached

    val start = System.currentTimeMillis()
    val apkFile = File(apkPath)

    if (!isZipArchive(apkFile)) {
      val fallback = VirtualAppResources(
        assetManager = context.assets,
        resources = context.resources,
        apkPath = apkPath
      )
      resourcesCache[apkPath] = fallback
      hookManager?.recordLog(
        subsystem = HookSubsystem.RESOURCES_MANAGER,
        method = "VirtualResourcesManager.load",
        targetClass = "android.content.res.Resources",
        callerPackage = apkFile.nameWithoutExtension,
        details = "Loaded virtual container standard resources for ${apkFile.nameWithoutExtension}",
        outcome = "CONTAINER_RES_ATTACHED",
        durationMs = System.currentTimeMillis() - start
      )
      return fallback
    }

    try {
      // 1. Create instance of AssetManager via reflection
      val assetManagerClass = AssetManager::class.java
      val assetManager = assetManagerClass.newInstance()

      // 2. Locate addAssetPath method (hidden API)
      val addAssetPathMethod: Method = assetManagerClass.getDeclaredMethod("addAssetPath", String::class.java)
      addAssetPathMethod.isAccessible = true
      val cookie = addAssetPathMethod.invoke(assetManager, apkPath)

      // 3. Create host-compatible Resources instance
      val hostRes = context.resources
      val customResources = Resources(
        assetManager,
        hostRes.displayMetrics,
        hostRes.configuration
      )

      val result = VirtualAppResources(
        assetManager = assetManager,
        resources = customResources,
        apkPath = apkPath
      )

      resourcesCache[apkPath] = result

      hookManager?.recordLog(
        subsystem = HookSubsystem.RESOURCES_MANAGER,
        method = "AssetManager.addAssetPath",
        targetClass = "android.content.res.AssetManager",
        callerPackage = File(apkPath).nameWithoutExtension,
        details = "Injected asset path '$apkPath' (cookie=$cookie) into custom Resources instance",
        outcome = "RESOURCES_INITIALIZED_OK",
        durationMs = System.currentTimeMillis() - start
      )

      return result
    } catch (e: Exception) {
      Log.e(TAG, "Failed to build custom resources for $apkPath: ${e.message}", e)
      
      // Fallback to host resources
      val fallback = VirtualAppResources(
        assetManager = context.assets,
        resources = context.resources,
        apkPath = apkPath
      )
      
      hookManager?.recordLog(
        subsystem = HookSubsystem.RESOURCES_MANAGER,
        method = "AssetManager.addAssetPath",
        targetClass = "android.content.res.AssetManager",
        callerPackage = File(apkPath).nameWithoutExtension,
        details = "Fallback to host resources: ${e.javaClass.simpleName}: ${e.message}",
        outcome = "FALLBACK_HOST_RES",
        durationMs = System.currentTimeMillis() - start
      )
      return fallback
    }
  }

  /**
   * Attempts to load a drawable from the APK by resource name.
   */
  fun loadDrawable(apkPath: String, resName: String, defType: String = "drawable"): Drawable? {
    return try {
      val appRes = getResourcesForApk(apkPath)
      val resId = appRes.resources.getIdentifier(resName, defType, getPackageNameFromPath(apkPath))
      if (resId != 0) {
        appRes.resources.getDrawable(resId, null)
      } else {
        null
      }
    } catch (e: Exception) {
      null
    }
  }

  /**
   * Attempts to load a localized string from the APK by resource name.
   */
  fun loadString(apkPath: String, stringName: String): String? {
    return try {
      val appRes = getResourcesForApk(apkPath)
      val resId = appRes.resources.getIdentifier(stringName, "string", getPackageNameFromPath(apkPath))
      if (resId != 0) {
        appRes.resources.getString(resId)
      } else {
        null
      }
    } catch (e: Exception) {
      null
    }
  }

  private fun getPackageNameFromPath(apkPath: String): String {
    return try {
      val info = context.packageManager.getPackageArchiveInfo(apkPath, 0)
      info?.packageName ?: File(apkPath).nameWithoutExtension
    } catch (e: Exception) {
      File(apkPath).nameWithoutExtension
    }
  }

  fun clearCache() {
    resourcesCache.clear()
  }
}
