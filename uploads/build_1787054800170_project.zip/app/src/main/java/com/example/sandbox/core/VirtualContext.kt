package com.example.sandbox.core

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.AssetManager
import android.content.res.Resources
import com.example.sandbox.model.HookSubsystem
import java.io.File

/**
 * Sandboxed ContextWrapper for guest applications.
 * Enforces strict virtual boundary by routing file I/O, preferences, databases,
 * and system resources into isolated sandbox paths.
 */
class VirtualContext(
  base: Context,
  private val virtualPackageName: String,
  private val fileSystemManager: VirtualFileSystemManager,
  private val resourcesManager: VirtualResourcesManager,
  private val hookManager: VirtualHookManager,
  private val guestClassLoader: ClassLoader,
  private val apkPath: String,
  private val onStartActivityRequested: (Intent) -> Unit = {}
) : ContextWrapper(base) {

  private val appResources by lazy {
    resourcesManager.getResourcesForApk(apkPath)
  }

  override fun getPackageName(): String {
    return virtualPackageName
  }

  override fun getApplicationInfo(): ApplicationInfo {
    val info = super.getApplicationInfo()
    val virtualInfo = ApplicationInfo(info)
    virtualInfo.packageName = virtualPackageName
    virtualInfo.dataDir = fileSystemManager.getPackageDataDir(virtualPackageName).absolutePath
    virtualInfo.sourceDir = apkPath
    virtualInfo.publicSourceDir = apkPath
    return virtualInfo
  }

  override fun getFilesDir(): File {
    return fileSystemManager.getPackageFilesDir(virtualPackageName)
  }

  override fun getCacheDir(): File {
    return fileSystemManager.getPackageCacheDir(virtualPackageName)
  }

  override fun getCodeCacheDir(): File {
    val codeCache = File(fileSystemManager.getPackageDataDir(virtualPackageName), "code_cache")
    if (!codeCache.exists()) codeCache.mkdirs()
    return codeCache
  }

  override fun getDatabasePath(name: String): File {
    val dbDir = fileSystemManager.getPackageDatabasesDir(virtualPackageName)
    return File(dbDir, name)
  }

  override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
    hookManager.recordLog(
      subsystem = HookSubsystem.FILE_SYSTEM,
      method = "getSharedPreferences",
      targetClass = "android.content.Context",
      callerPackage = virtualPackageName,
      details = "Opened sandboxed shared prefs '$name.xml'",
      outcome = "SANDBOX_ISOLATED_PREFS"
    )
    return super.getSharedPreferences("sandbox_${virtualPackageName}_$name", mode)
  }

  override fun getResources(): Resources {
    return appResources.resources
  }

  override fun getAssets(): AssetManager {
    return appResources.assetManager
  }

  override fun getClassLoader(): ClassLoader {
    return guestClassLoader
  }

  override fun startActivity(intent: Intent) {
    hookManager.recordLog(
      subsystem = HookSubsystem.ACTIVITY_MANAGER,
      method = "startActivity",
      targetClass = "VirtualContext",
      callerPackage = virtualPackageName,
      details = "Guest invoked startActivity(${intent.component?.className ?: intent.action})",
      outcome = "ROUTED_TO_CONTAINER"
    )
    onStartActivityRequested(intent)
  }

  override fun startActivity(intent: Intent, options: android.os.Bundle?) {
    startActivity(intent)
  }
}
