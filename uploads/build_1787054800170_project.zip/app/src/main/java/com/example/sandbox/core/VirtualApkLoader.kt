package com.example.sandbox.core

import android.app.Application
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.sandbox.model.HookSubsystem
import com.example.sandbox.model.VirtualAppInfo
import dalvik.system.DexClassLoader
import java.io.File
import java.io.FileOutputStream

/**
 * Dynamic APK Loader & DEX ClassLoader Engine.
 * Extracts APKs, generates isolated DexClassLoaders, and initializes
 * guest Application and Activity life cycles dynamically.
 */
class VirtualApkLoader(
  private val hostContext: Context,
  private val fileSystemManager: VirtualFileSystemManager,
  private val resourcesManager: VirtualResourcesManager,
  private val hookManager: VirtualHookManager
) {
  private val TAG = "VirtualApkLoader"

  /**
   * Extracts an APK bundled inside assets/ to the sandbox APK store.
   */
  fun extractAssetApk(assetFileName: String, targetPackageName: String): File? {
    val start = System.currentTimeMillis()
    return try {
      val targetApkFile = File(fileSystemManager.apkStoreDir, "$targetPackageName.apk")
      if (targetApkFile.exists() && targetApkFile.length() > 0) {
        return targetApkFile
      }

      hostContext.assets.open(assetFileName).use { input ->
        FileOutputStream(targetApkFile).use { output ->
          input.copyTo(output)
        }
      }

      hookManager.recordLog(
        subsystem = HookSubsystem.CLASS_LOADER,
        method = "extractAssetApk",
        targetClass = "VirtualApkLoader",
        callerPackage = targetPackageName,
        details = "Extracted asset '$assetFileName' -> '${targetApkFile.name}' (${targetApkFile.length()} bytes)",
        outcome = "EXTRACTED_OK",
        durationMs = System.currentTimeMillis() - start
      )
      targetApkFile
    } catch (e: Exception) {
      Log.e(TAG, "Failed extracting asset $assetFileName: ${e.message}")
      null
    }
  }

  /**
   * Creates a dedicated DexClassLoader for an APK.
   */
  fun createClassLoader(apkPath: String): DexClassLoader {
    val start = System.currentTimeMillis()
    val optDir = fileSystemManager.optDexDir
    val nativeLibDir = fileSystemManager.nativeLibsDir

    val classLoader = DexClassLoader(
      apkPath,
      optDir.absolutePath,
      nativeLibDir.absolutePath,
      hostContext.classLoader
    )

    hookManager.recordLog(
      subsystem = HookSubsystem.CLASS_LOADER,
      method = "createClassLoader",
      targetClass = "dalvik.system.DexClassLoader",
      callerPackage = File(apkPath).nameWithoutExtension,
      details = "Initialized DexClassLoader for $apkPath [dexOpt=${optDir.name}, nativeLibs=${nativeLibDir.name}]",
      outcome = "CLASSLOADER_READY",
      durationMs = System.currentTimeMillis() - start
    )

    return classLoader
  }

  /**
   * Initializes and executes guest Application lifecycle (attachBaseContext, onCreate).
   */
  fun instantiateAndLaunchApplication(
    appInfo: VirtualAppInfo,
    classLoader: ClassLoader,
    onStartActivity: (Intent) -> Unit
  ): Application? {
    val start = System.currentTimeMillis()
    val virtualContext = VirtualContext(
      base = hostContext,
      virtualPackageName = appInfo.packageName,
      fileSystemManager = fileSystemManager,
      resourcesManager = resourcesManager,
      hookManager = hookManager,
      guestClassLoader = classLoader,
      apkPath = appInfo.apkPath,
      onStartActivityRequested = onStartActivity
    )

    return try {
      // Try to load custom Application class or default android.app.Application
      val appClassName = "android.app.Application"
      val appClass = classLoader.loadClass(appClassName)
      val appInstance = appClass.newInstance() as Application

      // Invoke attachBaseContext using reflection
      val attachMethod = Application::class.java.getDeclaredMethod("attachBaseContext", Context::class.java)
      attachMethod.isAccessible = true
      attachMethod.invoke(appInstance, virtualContext)

      // Invoke onCreate
      appInstance.onCreate()

      hookManager.recordLog(
        subsystem = HookSubsystem.ACTIVITY_MANAGER,
        method = "Application.onCreate",
        targetClass = appClassName,
        callerPackage = appInfo.packageName,
        details = "Dispatched guest Application lifecycle: attachBaseContext + onCreate()",
        outcome = "APP_INITIALIZED_OK",
        durationMs = System.currentTimeMillis() - start
      )

      appInstance
    } catch (e: Exception) {
      Log.w(TAG, "Could not instantiate custom Application subclass: ${e.message}")
      hookManager.recordLog(
        subsystem = HookSubsystem.ACTIVITY_MANAGER,
        method = "Application.onCreate",
        targetClass = "android.app.Application",
        callerPackage = appInfo.packageName,
        details = "Default container context attached: ${e.message}",
        outcome = "DEFAULT_CONTEXT_ACTIVE",
        durationMs = System.currentTimeMillis() - start
      )
      null
    }
  }
}
