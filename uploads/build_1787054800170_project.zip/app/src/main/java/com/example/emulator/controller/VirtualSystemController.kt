package com.example.emulator.controller

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.emulator.guest.*
import com.example.emulator.nativecore.NativeVirtualCore
import com.example.emulator.rootfs.VirtualRootFsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicLong

class VirtualSystemController(application: Application) : AndroidViewModel(application) {

  val rootFsManager = VirtualRootFsManager(application)
  val packageManager = GuestPackageManager(application, rootFsManager)
  val shellEngine = GuestShellEngine(rootFsManager)

  private val _powerState = MutableStateFlow(VmPowerState.RUNNING)
  val powerState: StateFlow<VmPowerState> = _powerState.asStateFlow()

  private val _hardwareProfile = MutableStateFlow(VmHardwareProfile())
  val hardwareProfile: StateFlow<VmHardwareProfile> = _hardwareProfile.asStateFlow()

  private val _telemetry = MutableStateFlow(VmTelemetry())
  val telemetry: StateFlow<VmTelemetry> = _telemetry.asStateFlow()

  private val _bootProgress = MutableStateFlow(1.0f)
  val bootProgress: StateFlow<Float> = _bootProgress.asStateFlow()

  private val _currentBootStep = MutableStateFlow<BootStep?>(null)
  val currentBootStep: StateFlow<BootStep?> = _currentBootStep.asStateFlow()

  private val _installedApps = MutableStateFlow<List<GuestApp>>(packageManager.getInstalledApps())
  val installedApps: StateFlow<List<GuestApp>> = _installedApps.asStateFlow()

  private val _activeApp = MutableStateFlow<GuestApp?>(null)
  val activeApp: StateFlow<GuestApp?> = _activeApp.asStateFlow()

  private val _appBackStack = MutableStateFlow<List<GuestApp>>(emptyList())
  val appBackStack: StateFlow<List<GuestApp>> = _appBackStack.asStateFlow()

  private val _guestLogs = MutableStateFlow<List<GuestLogEntry>>(emptyList())
  val guestLogs: StateFlow<List<GuestLogEntry>> = _guestLogs.asStateFlow()

  private val _currentRootFsPath = MutableStateFlow(rootFsManager.rootFsDir.absolutePath)
  val currentRootFsPath: StateFlow<String> = _currentRootFsPath.asStateFlow()

  private val _currentDirectoryNodes = MutableStateFlow<List<RootFsNode>>(emptyList())
  val currentDirectoryNodes: StateFlow<List<RootFsNode>> = _currentDirectoryNodes.asStateFlow()

  private val _terminalHistory = MutableStateFlow<List<Pair<String, String>>>(
    listOf(
      "init" to "Android Micro-VM Core 14.0.0 (aarch64)\nType 'help' for available commands.\n"
    )
  )
  val terminalHistory: StateFlow<List<Pair<String, String>>> = _terminalHistory.asStateFlow()

  private val _notificationMessage = MutableStateFlow<String?>(null)
  val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

  private val logCounter = AtomicLong(1)
  private var telemetryJob: Job? = null
  private var startTimeMs = System.currentTimeMillis()

  init {
    NativeVirtualCore.initialize(
      rootfsPath = rootFsManager.rootFsDir.absolutePath,
      systemImgPath = File(rootFsManager.systemDir, "system.img").absolutePath,
      ramSizeMb = _hardwareProfile.value.ramMb,
      cpuCores = _hardwareProfile.value.cpuCores,
      enableRoot = _hardwareProfile.value.hasRoot,
      enableGpu = _hardwareProfile.value.hasGpuAcceleration
    )
    NativeVirtualCore.boot()
    startTelemetryLoop()
    browseRootFsPath(rootFsManager.rootFsDir.absolutePath)
    logGuestEvent("I", "MicroVMInit", 1, "Micro-VM Container initialized and running on host")
  }

  fun startBootSequence() {
    viewModelScope.launch(Dispatchers.IO) {
      _powerState.value = VmPowerState.BOOTING
      _activeApp.value = null
      _bootProgress.value = 0.0f
      NativeVirtualCore.shutdown()

      val steps = listOf(
        BootStep(1, "Linux Kernel & Init", "Loading 5.15 aarch64 virtual kernel and mounting /dev/rootfs", "kernel: [0.000000] Linux version 5.15.110-microvm-arm64", 0.25f),
        BootStep(2, "Hardware HAL & Daemons", "Starting ueventd, servicemanager, and binder_virtual driver", "init: Starting service 'servicemanager' (PID 120)...", 0.50f),
        BootStep(3, "SurfaceFlinger & Zygote", "Initializing EGL GPU context & Zygote64 runtime", "surfaceflinger: Initialized Virtual EGL Display (1080x2340@60Hz)", 0.75f),
        BootStep(4, "SystemServer & Launcher3", "Loading Package Manager, Activity Manager, & SystemUI", "system_server: Boot complete. Launcher desktop ready.", 1.0f)
      )

      for (step in steps) {
        _currentBootStep.value = step
        _bootProgress.value = step.progress
        logGuestEvent("I", "BootManager", step.stepNumber * 100, step.logLine)
        delay(600)
      }

      NativeVirtualCore.initialize(
        rootfsPath = rootFsManager.rootFsDir.absolutePath,
        systemImgPath = "",
        ramSizeMb = _hardwareProfile.value.ramMb,
        cpuCores = _hardwareProfile.value.cpuCores,
        enableRoot = _hardwareProfile.value.hasRoot,
        enableGpu = _hardwareProfile.value.hasGpuAcceleration
      )
      NativeVirtualCore.boot()

      _powerState.value = VmPowerState.RUNNING
      _currentBootStep.value = null
      startTimeMs = System.currentTimeMillis()
      showToast("تم إقلاع نظام الأندرويد الافتراضي بنجاح (Android 14)")
    }
  }

  fun powerOffVm() {
    _powerState.value = VmPowerState.POWERED_OFF
    _activeApp.value = null
    NativeVirtualCore.shutdown()
    showToast("تم إيقاف تشغيل النظام الافتراضي")
  }

  fun togglePauseVm() {
    if (_powerState.value == VmPowerState.RUNNING) {
      _powerState.value = VmPowerState.PAUSED
      NativeVirtualCore.pause()
      showToast("تم إيقاف النظام مؤقتاً")
    } else if (_powerState.value == VmPowerState.PAUSED) {
      _powerState.value = VmPowerState.RUNNING
      NativeVirtualCore.resume()
      showToast("تم استئناف تشغيل النظام")
    }
  }

  fun launchApp(app: GuestApp) {
    if (_powerState.value != VmPowerState.RUNNING) {
      showToast("يرجى تشغيل النظام الافتراضي أولاً")
      return
    }
    val current = _activeApp.value
    if (current != null && current.id != app.id) {
      _appBackStack.value = _appBackStack.value + current
    }
    _activeApp.value = app
    logGuestEvent("I", "ActivityTaskManager", 350, "START u0 {act=android.intent.action.MAIN cat=[android.intent.category.LAUNCHER] cmp=${app.packageName}/${app.activityClass}}")
  }

  fun pressVirtualBack() {
    val stack = _appBackStack.value
    if (stack.isNotEmpty()) {
      _activeApp.value = stack.last()
      _appBackStack.value = stack.dropLast(1)
      logGuestEvent("D", "InputDispatcher", 150, "Virtual BACK dispatched -> Navigating back in task stack")
    } else {
      if (_activeApp.value != null) {
        _activeApp.value = null
        logGuestEvent("D", "InputDispatcher", 150, "Virtual BACK dispatched -> Returned to Launcher desktop")
      }
    }
  }

  fun pressVirtualHome() {
    if (_activeApp.value != null) {
      val current = _activeApp.value!!
      _appBackStack.value = _appBackStack.value + current
      _activeApp.value = null
      logGuestEvent("D", "InputDispatcher", 150, "Virtual HOME dispatched -> Switched to Launcher desktop")
    }
  }

  fun pressVirtualRecents() {
    showToast("قائمة المهام النشطة (Recent Tasks Stack)")
  }

  fun installApk(uri: Uri, fileName: String?) {
    viewModelScope.launch(Dispatchers.IO) {
      val app = packageManager.installApkFromUri(uri, fileName)
      if (app != null) {
        _installedApps.value = packageManager.getInstalledApps()
        refreshRootFsDirectory()
        logGuestEvent("I", "PackageManager", 350, "Successfully installed package '${app.packageName}' to /data/app/${app.packageName}/base.apk")
        showToast("تم تثبيت التطبيق: ${app.name} بنجاح داخل النظام")
      } else {
        showToast("فشل تثبيت ملف الـ APK")
      }
    }
  }

  fun installStoreApp(app: GuestApp) {
    viewModelScope.launch(Dispatchers.IO) {
      val success = packageManager.installCatalogApp(app)
      if (success) {
        _installedApps.value = packageManager.getInstalledApps()
        refreshRootFsDirectory()
        logGuestEvent("I", "StoreManager", 350, "Installed catalog app: ${app.name} (${app.packageName})")
        showToast("تم تثبيت ${app.name} في النظام الافتراضي")
      } else {
        showToast("التطبيق مثبت بالفعل في النظام")
      }
    }
  }

  fun uninstallApp(packageName: String) {
    viewModelScope.launch(Dispatchers.IO) {
      val success = packageManager.uninstallGuestApp(packageName)
      if (success) {
        _installedApps.value = packageManager.getInstalledApps()
        if (_activeApp.value?.packageName == packageName) {
          _activeApp.value = null
        }
        refreshRootFsDirectory()
        logGuestEvent("I", "PackageManager", 350, "Uninstalled package $packageName from /data/app/")
        showToast("تم إلغاء تثبيت التطبيق بنجاح")
      }
    }
  }

  fun executeTerminalCommand(cmd: String) {
    if (cmd.trim().isEmpty()) return
    val output = shellEngine.execute(cmd)
    _terminalHistory.value = _terminalHistory.value + (cmd to output)
    logGuestEvent("D", "GuestShell", 580, "Command executed: $cmd")
  }

  fun clearTerminal() {
    _terminalHistory.value = emptyList()
  }

  fun browseRootFsPath(path: String) {
    _currentRootFsPath.value = path
    _currentDirectoryNodes.value = rootFsManager.listDirectoryNodes(path)
  }

  fun navigateUpRootFs() {
    val current = File(_currentRootFsPath.value)
    val parent = current.parentFile
    if (parent != null && parent.absolutePath.startsWith(rootFsManager.rootFsDir.absolutePath)) {
      browseRootFsPath(parent.absolutePath)
    }
  }

  fun refreshRootFsDirectory() {
    browseRootFsPath(_currentRootFsPath.value)
  }

  fun updateHardwareProfile(newProfile: VmHardwareProfile) {
    _hardwareProfile.value = newProfile
    showToast("تم تحديث مواصفات العتاد الافتراضي. سيتم تطبيق التغييرات عند إعادة الإقلاع.")
  }

  fun dismissNotification() {
    _notificationMessage.value = null
  }

  private fun showToast(msg: String) {
    _notificationMessage.value = msg
  }

  private fun logGuestEvent(level: String, tag: String, pid: Int, message: String) {
    val entry = GuestLogEntry(
      id = logCounter.getAndIncrement(),
      timestamp = System.currentTimeMillis(),
      level = level,
      tag = tag,
      pid = pid,
      message = message
    )
    _guestLogs.value = listOf(entry) + _guestLogs.value.take(299)
  }

  private fun startTelemetryLoop() {
    telemetryJob?.cancel()
    telemetryJob = viewModelScope.launch(Dispatchers.IO) {
      while (true) {
        delay(1000)
        if (_powerState.value == VmPowerState.RUNNING) {
          val (usedStorage, totalStorage) = rootFsManager.calculateRootFsUsageMb()
          val elapsedSec = (System.currentTimeMillis() - startTimeMs) / 1000L
          val fps = NativeVirtualCore.getFps()
          val binderCount = NativeVirtualCore.getBinderInterceptCount()

          _telemetry.value = VmTelemetry(
            fps = fps,
            cpuUsagePercent = (12.0 + (System.currentTimeMillis() % 1500) / 100.0),
            ramUsedMb = 1250.0 + (System.currentTimeMillis() % 200),
            ramTotalMb = _hardwareProfile.value.ramMb.toDouble(),
            rootFsUsedMb = usedStorage,
            rootFsTotalMb = totalStorage,
            uptimeSeconds = elapsedSec,
            binderTransactions = binderCount + (elapsedSec * 12).toInt(),
            translatedBlocks = 18000L + (elapsedSec * 45)
          )
        }
      }
    }
  }
}
