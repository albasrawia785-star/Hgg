package com.example.sandbox.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sandbox.core.VirtualActivityManager
import com.example.sandbox.core.VirtualApkLoader
import com.example.sandbox.core.VirtualFileSystemManager
import com.example.sandbox.core.VirtualHookManager
import com.example.sandbox.core.VirtualPackageManager
import com.example.sandbox.core.VirtualResourcesManager
import com.example.sandbox.engine.VirtualGuestRuntime
import com.example.sandbox.model.InterceptionLog
import com.example.sandbox.model.ProcessStatus
import com.example.sandbox.model.SandboxFileItem
import com.example.sandbox.model.SandboxStorageMetrics
import com.example.sandbox.model.VirtualAppInfo
import com.example.sandbox.model.VirtualProcessState
import com.example.sandbox.model.VirtualTaskRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.Random

enum class SandboxTab(val title: String, val icon: String) {
  VIEWPORT("مشغل الحاوية", "phone_android"),
  PACKAGES("إدارة الحزم", "apps"),
  STORAGE("نظام الملفات", "folder"),
  HOOKS("سجل الاعتراض", "security"),
  DIAGNOSTICS("المقاييس", "speed")
}

class SandboxViewModel(application: Application) : AndroidViewModel(application) {

  private val _interceptionLogs = MutableStateFlow<List<InterceptionLog>>(emptyList())
  val interceptionLogs: StateFlow<List<InterceptionLog>> = _interceptionLogs.asStateFlow()

  val fileSystemManager: VirtualFileSystemManager = VirtualFileSystemManager(application)
  val hookManager: VirtualHookManager = VirtualHookManager(application) { newLog ->
    _interceptionLogs.value = listOf(newLog) + _interceptionLogs.value.take(199)
  }
  val resourcesManager: VirtualResourcesManager = VirtualResourcesManager(application, hookManager)
  val packageManager: VirtualPackageManager = VirtualPackageManager(application, hookManager, resourcesManager, fileSystemManager)
  val activityManager: VirtualActivityManager = VirtualActivityManager(application, hookManager)
  val apkLoader: VirtualApkLoader = VirtualApkLoader(application, fileSystemManager, resourcesManager, hookManager)
  val guestRuntime: VirtualGuestRuntime = VirtualGuestRuntime(application, fileSystemManager, hookManager)

  private val _installedApps = MutableStateFlow<List<VirtualAppInfo>>(emptyList())
  val installedApps: StateFlow<List<VirtualAppInfo>> = _installedApps.asStateFlow()

  private val _runningApp = MutableStateFlow<VirtualAppInfo?>(null)
  val runningApp: StateFlow<VirtualAppInfo?> = _runningApp.asStateFlow()

  private val _processState = MutableStateFlow<VirtualProcessState>(
    VirtualProcessState(
      pid = 28491,
      processName = "com.aistudio.virtualsandbox:guest_vm",
      status = ProcessStatus.RUNNING,
      heapMemoryMb = 24.5,
      threadCount = 6,
      uptimeSeconds = 0L,
      activePackage = "com.cyber.sandbox.toolkit"
    )
  )
  val processState: StateFlow<VirtualProcessState> = _processState.asStateFlow()

  private val _storageMetrics = MutableStateFlow<SandboxStorageMetrics>(
    fileSystemManager.calculateStorageMetrics()
  )
  val storageMetrics: StateFlow<SandboxStorageMetrics> = _storageMetrics.asStateFlow()

  private val _currentTask = MutableStateFlow<VirtualTaskRecord?>(null)
  val currentTask: StateFlow<VirtualTaskRecord?> = _currentTask.asStateFlow()

  private val _currentSandboxDir = MutableStateFlow<String>(fileSystemManager.sandboxRootDir.absolutePath)
  val currentSandboxDir: StateFlow<String> = _currentSandboxDir.asStateFlow()

  private val _sandboxFiles = MutableStateFlow<List<SandboxFileItem>>(emptyList())
  val sandboxFiles: StateFlow<List<SandboxFileItem>> = _sandboxFiles.asStateFlow()

  private val _selectedTab = MutableStateFlow(SandboxTab.VIEWPORT)
  val selectedTab: StateFlow<SandboxTab> = _selectedTab.asStateFlow()

  private val _inspectingApp = MutableStateFlow<VirtualAppInfo?>(null)
  val inspectingApp: StateFlow<VirtualAppInfo?> = _inspectingApp.asStateFlow()

  private val _notificationMessage = MutableStateFlow<String?>(null)
  val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

  private var containerStartTime = System.currentTimeMillis()

  init {
    initializeDefaultBundledApps()
    startTelemetryTicker()
    refreshStorage()
    browseSandboxDirectory(fileSystemManager.sandboxRootDir.absolutePath)
  }

  private fun initializeDefaultBundledApps() {
    viewModelScope.launch(Dispatchers.IO) {
      // Create and register pre-bundled embedded sandboxed applications
      val bundledApps = listOf(
        Triple(
          "embedded_cyber_suite.apk",
          "com.cyber.sandbox.toolkit",
          "Sandboxed Cyber Toolkit & Memory"
        ),
        Triple(
          "embedded_calculator.apk",
          "com.calc.virtual.pro",
          "Sandboxed Scientific Calculator"
        ),
        Triple(
          "embedded_sys_monitor.apk",
          "com.sys.virtual.monitor",
          "Hardware & Virtualization Monitor"
        ),
        Triple(
          "embedded_file_explorer.apk",
          "com.vfs.virtual.explorer",
          "Sandbox File & DB Explorer"
        )
      )

      bundledApps.forEach { (assetName, pkg, appName) ->
        val apkFile = File(fileSystemManager.apkStoreDir, "$pkg.apk")
        if (!apkFile.exists()) {
          // Write synthetic APK container metadata file
          apkFile.writeText("SANDBOX_EMBEDDED_DEX_CONTAINER_V2_$pkg")
        }
        packageManager.parseAndRegisterApk(apkFile.absolutePath, isEmbedded = true, overrideName = appName)
      }

      val allApps = packageManager.getInstalledApps()
      _installedApps.value = allApps

      // Launch primary suite by default
      val defaultApp = allApps.firstOrNull { it.packageName == "com.cyber.sandbox.toolkit" } ?: allApps.firstOrNull()
      if (defaultApp != null) {
        launchApp(defaultApp)
      }
    }
  }

  private fun startTelemetryTicker() {
    viewModelScope.launch(Dispatchers.Default) {
      val random = Random()
      while (isActive) {
        delay(1000)
        val runtime = Runtime.getRuntime()
        val totalMem = runtime.totalMemory() / (1024.0 * 1024.0)
        val freeMem = runtime.freeMemory() / (1024.0 * 1024.0)
        val usedMem = totalMem - freeMem

        val uptime = (System.currentTimeMillis() - containerStartTime) / 1000

        _processState.value = _processState.value.copy(
          heapMemoryMb = Math.round(usedMem * 10.0) / 10.0,
          threadCount = Thread.activeCount(),
          uptimeSeconds = uptime
        )

        _storageMetrics.value = fileSystemManager.calculateStorageMetrics()
      }
    }
  }

  fun launchApp(appInfo: VirtualAppInfo) {
    viewModelScope.launch(Dispatchers.IO) {
      val task = activityManager.startActivity(appInfo)
      _currentTask.value = task
      _runningApp.value = appInfo

      _processState.value = _processState.value.copy(
        status = ProcessStatus.RUNNING,
        activePackage = appInfo.packageName
      )

      showToast("تشغيل ${appInfo.appName} في الحاوية المعزولة")
    }
  }

  fun restartContainer() {
    viewModelScope.launch(Dispatchers.IO) {
      containerStartTime = System.currentTimeMillis()
      activityManager.resetTask()
      _runningApp.value?.let { launchApp(it) }
      showToast("تمت إعادة تشغيل الحاوية الافتراضية بنجاح")
    }
  }

  fun purgeCache() {
    viewModelScope.launch(Dispatchers.IO) {
      val success = fileSystemManager.purgeCache(_runningApp.value?.packageName)
      refreshStorage()
      browseSandboxDirectory(_currentSandboxDir.value)
      showToast(if (success) "تم مسح الذاكرة المؤقتة (Cache) للحاوية" else "فشل مسح الكاش")
    }
  }

  fun wipeAllSandboxData() {
    viewModelScope.launch(Dispatchers.IO) {
      fileSystemManager.resetSandbox()
      initializeDefaultBundledApps()
      refreshStorage()
      browseSandboxDirectory(fileSystemManager.sandboxRootDir.absolutePath)
      showToast("تم تصفير بيئة التخزين المعزولة بالكامل")
    }
  }

  fun toggleHooking(enabled: Boolean) {
    hookManager.setHookingEnabled(enabled)
    showToast(if (enabled) "تم تفعيل اعتراض الدوال الديناميكي (Hooks Active)" else "تم تعطيل اعتراض الدوال")
  }

  fun handleBackPressed(): Boolean {
    val handled = activityManager.handleBackPressed()
    _currentTask.value = activityManager.getCurrentTask()
    return handled
  }

  fun switchTab(tab: SandboxTab) {
    _selectedTab.value = tab
    if (tab == SandboxTab.STORAGE) {
      browseSandboxDirectory(_currentSandboxDir.value)
    }
  }

  fun inspectApp(appInfo: VirtualAppInfo?) {
    _inspectingApp.value = appInfo
  }

  fun browseSandboxDirectory(path: String) {
    _currentSandboxDir.value = path
    _sandboxFiles.value = fileSystemManager.listSandboxDirectory(path)
  }

  fun navigateUpDirectory() {
    val current = File(_currentSandboxDir.value)
    val root = fileSystemManager.sandboxRootDir
    if (current.absolutePath != root.absolutePath && current.parentFile != null) {
      browseSandboxDirectory(current.parentFile!!.absolutePath)
    }
  }

  fun refreshStorage() {
    _storageMetrics.value = fileSystemManager.calculateStorageMetrics()
  }

  fun clearLogs() {
    hookManager.clearLogs()
    _interceptionLogs.value = emptyList()
    showToast("تم مسح سجلات الاعتراض")
  }

  fun importApkFromUri(uri: Uri) {
    viewModelScope.launch(Dispatchers.IO) {
      try {
        val resolver = getApplication<Application>().contentResolver
        val tempApk = File(fileSystemManager.apkStoreDir, "imported_${System.currentTimeMillis()}.apk")
        
        resolver.openInputStream(uri)?.use { input ->
          FileOutputStream(tempApk).use { output ->
            input.copyTo(output)
          }
        }

        val appInfo = packageManager.parseAndRegisterApk(tempApk.absolutePath, isEmbedded = false)
        if (appInfo != null) {
          _installedApps.value = packageManager.getInstalledApps()
          showToast("تم تثبيت الحزمة الافتراضية بنجاح: ${appInfo.appName}")
          launchApp(appInfo)
          _selectedTab.value = SandboxTab.VIEWPORT
        } else {
          showToast("تعذر قراءة ملف الـ APK")
        }
      } catch (e: Exception) {
        showToast("خطأ أثناء استيراد الـ APK: ${e.message}")
      }
    }
  }

  private fun showToast(msg: String) {
    _notificationMessage.value = msg
  }

  fun dismissNotification() {
    _notificationMessage.value = null
  }
}
