package com.example.sandbox.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sandbox.ui.components.ApkInspectorDialog
import com.example.sandbox.ui.components.ContainerMetricsCard
import com.example.sandbox.ui.components.DiagnosticsTab
import com.example.sandbox.ui.components.HookLogsTab
import com.example.sandbox.ui.components.PackagesTab
import com.example.sandbox.ui.components.StorageTab
import com.example.sandbox.ui.components.VirtualViewport
import com.example.ui.theme.SandboxOutlineVariant
import com.example.ui.theme.SandboxPrimary
import com.example.ui.theme.SandboxSecondary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusActiveBg

/**
 * Main Sandbox Container UI Screen.
 * Implements strict Material 3 Light Mode styling with 8dp grid spacing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SandboxMainScreen(
  viewModel: SandboxViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val runningApp by viewModel.runningApp.collectAsState()
  val installedApps by viewModel.installedApps.collectAsState()
  val processState by viewModel.processState.collectAsState()
  val storageMetrics by viewModel.storageMetrics.collectAsState()
  val interceptionLogs by viewModel.interceptionLogs.collectAsState()
  val selectedTab by viewModel.selectedTab.collectAsState()
  val inspectingApp by viewModel.inspectingApp.collectAsState()
  val notificationMessage by viewModel.notificationMessage.collectAsState()
  val currentDir by viewModel.currentSandboxDir.collectAsState()
  val sandboxFiles by viewModel.sandboxFiles.collectAsState()

  val snackbarHostState = remember { SnackbarHostState() }

  // Intercept back button to navigate within guest container if active
  BackHandler {
    if (selectedTab == SandboxTab.VIEWPORT) {
      val handled = viewModel.handleBackPressed()
      if (!handled) {
        // Switch to packages tab if task stack is empty
        viewModel.switchTab(SandboxTab.PACKAGES)
      }
    } else {
      viewModel.switchTab(SandboxTab.VIEWPORT)
    }
  }

  LaunchedEffect(notificationMessage) {
    notificationMessage?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.dismissNotification()
    }
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text(
              text = "Virtual Sandbox Engine",
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )
            Text(
              text = "Standalone Dynamic App-in-App Container",
              fontSize = 11.sp,
              color = Color(0xFF64748B)
            )
          }
        },
        actions = {
          if (runningApp != null) {
            Box(
              modifier = Modifier
                .padding(end = 12.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(StatusActiveBg)
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "VM Active",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = StatusActive
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = Color.White
        )
      )
    },
    bottomBar = {
      NavigationBar(
        containerColor = Color.White,
        contentColor = SandboxPrimary,
        tonalElevation = 4.dp,
        modifier = Modifier
          .navigationBarsPadding()
          .testTag("sandbox_bottom_navigation")
      ) {
        val navItems = listOf(
          Triple(SandboxTab.VIEWPORT, Icons.Default.PhoneAndroid, "المشغل"),
          Triple(SandboxTab.PACKAGES, Icons.Default.Apps, "الحزم"),
          Triple(SandboxTab.STORAGE, Icons.Default.Folder, "التخزين"),
          Triple(SandboxTab.HOOKS, Icons.Default.Security, "الاعتراض"),
          Triple(SandboxTab.DIAGNOSTICS, Icons.Default.Speed, "المقاييس")
        )

        navItems.forEach { (tab, icon, label) ->
          val selected = selectedTab == tab
          NavigationBarItem(
            selected = selected,
            onClick = { viewModel.switchTab(tab) },
            icon = {
              Icon(
                imageVector = icon,
                contentDescription = label,
                modifier = Modifier.size(20.dp)
              )
            },
            label = {
              Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = SandboxPrimary,
              selectedTextColor = SandboxPrimary,
              indicatorColor = Color(0xFFE0F2FE),
              unselectedIconColor = Color(0xFF64748B),
              unselectedTextColor = Color(0xFF64748B)
            ),
            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
          )
        }
      }
    },
    containerColor = Color(0xFFF8FAFC),
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      when (selectedTab) {
        SandboxTab.VIEWPORT -> {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(16.dp)
          ) {
            // Container Metrics HUD Card
            ContainerMetricsCard(
              processState = processState,
              storageMetrics = storageMetrics,
              isHookingActive = viewModel.hookManager.isHookingEnabled,
              onRestart = { viewModel.restartContainer() },
              onPurgeCache = { viewModel.purgeCache() },
              onToggleHooking = { viewModel.toggleHooking(it) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Virtual Viewport Screen Card
            VirtualViewport(
              runningApp = runningApp,
              guestRuntime = viewModel.guestRuntime,
              onBackPressed = { viewModel.handleBackPressed() },
              onHomePressed = { viewModel.switchTab(SandboxTab.PACKAGES) },
              onRestartApp = { viewModel.restartContainer() },
              onOpenPackages = { viewModel.switchTab(SandboxTab.PACKAGES) }
            )
          }
        }

        SandboxTab.PACKAGES -> {
          PackagesTab(
            installedApps = installedApps,
            runningApp = runningApp,
            onLaunchApp = { app ->
              viewModel.launchApp(app)
              viewModel.switchTab(SandboxTab.VIEWPORT)
            },
            onInspectApp = { app -> viewModel.inspectApp(app) },
            onImportApk = { uri -> viewModel.importApkFromUri(uri) }
          )
        }

        SandboxTab.STORAGE -> {
          StorageTab(
            currentPath = currentDir,
            files = sandboxFiles,
            metrics = storageMetrics,
            onNavigateDir = { dir -> viewModel.browseSandboxDirectory(dir) },
            onNavigateUp = { viewModel.navigateUpDirectory() },
            onPurgeCache = { viewModel.purgeCache() },
            onWipeSandbox = { viewModel.wipeAllSandboxData() }
          )
        }

        SandboxTab.HOOKS -> {
          HookLogsTab(
            logs = interceptionLogs,
            onClearLogs = { viewModel.clearLogs() }
          )
        }

        SandboxTab.DIAGNOSTICS -> {
          DiagnosticsTab(processState = processState)
        }
      }

      // APK Manifest Inspector Modal
      inspectingApp?.let { app ->
        ApkInspectorDialog(
          appInfo = app,
          onDismiss = { viewModel.inspectApp(null) },
          onLaunch = { appToLaunch ->
            viewModel.launchApp(appToLaunch)
            viewModel.switchTab(SandboxTab.VIEWPORT)
          }
        )
      }
    }
  }
}
