package com.example.sandbox.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sandbox.model.SandboxFileItem
import com.example.sandbox.model.SandboxStorageMetrics
import com.example.ui.theme.SandboxOutlineVariant
import com.example.ui.theme.SandboxPrimary
import com.example.ui.theme.SandboxSecondary
import com.example.ui.theme.SandboxTertiary
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusWarning
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Isolated Virtual File System Explorer & Storage Metrics Screen.
 */
@Composable
fun StorageTab(
  currentPath: String,
  files: List<SandboxFileItem>,
  metrics: SandboxStorageMetrics,
  onNavigateDir: (String) -> Unit,
  onNavigateUp: () -> Unit,
  onPurgeCache: () -> Unit,
  onWipeSandbox: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    // Top Storage Breakdown Card
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .testTag("storage_breakdown_card"),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      border = androidx.compose.foundation.BorderStroke(1.dp, SandboxOutlineVariant)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "مساحة التخزين الافتراضية المعزولة",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
          )
          Text(
            text = metrics.formattedTotal,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = SandboxPrimary
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Metrics Grid
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          StorageCategoryBadge("البيانات (Data)", metrics.formattedData, SandboxPrimary, Modifier.weight(1f))
          StorageCategoryBadge("الكاش (Cache)", metrics.formattedCache, StatusWarning, Modifier.weight(1f))
          StorageCategoryBadge("قواعد البيانات (DB)", metrics.formattedDatabase, SandboxSecondary, Modifier.weight(1f))
          StorageCategoryBadge("كود DEX", metrics.formattedDex, SandboxTertiary, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = onPurgeCache,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFEF3C7)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("storage_purge_cache_button")
          ) {
            Text("مسح الكاش الوهمي", color = Color(0xFFB45309), fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onWipeSandbox,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFEE2E2)),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("storage_wipe_sandbox_button")
          ) {
            Text("تصفير الحاوية بالكامل", color = StatusDanger, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Directory Path Navigation Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .background(Color(0xFFF1F5F9))
        .border(1.dp, SandboxOutlineVariant, RoundedCornerShape(10.dp))
        .padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = onNavigateUp,
        modifier = Modifier.size(32.dp)
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Up",
          tint = Color(0xFF475569),
          modifier = Modifier.size(18.dp)
        )
      }

      Spacer(modifier = Modifier.width(4.dp))

      Text(
        text = currentPath.substringAfterLast("/files").ifEmpty { "/sandbox" },
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        color = Color(0xFF0F172A),
        modifier = Modifier.weight(1f)
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // File Items List
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      if (files.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "المجلد الافتراضي فارغ",
              fontSize = 13.sp,
              color = Color(0xFF94A3B8)
            )
          }
        }
      } else {
        items(files) { file ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clickable(enabled = file.isDirectory) { onNavigateDir(file.absolutePath) }
              .testTag("file_item_${file.name}"),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, SandboxOutlineVariant)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = if (file.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                contentDescription = null,
                tint = if (file.isDirectory) SandboxPrimary else Color(0xFF64748B),
                modifier = Modifier.size(24.dp)
              )

              Spacer(modifier = Modifier.width(12.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = file.name,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F172A)
                )
                Text(
                  text = if (file.isDirectory) "${file.childrenCount} عناصر" else "${file.sizeBytes} Bytes • ${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(file.lastModified))}",
                  fontSize = 11.sp,
                  color = Color(0xFF64748B)
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StorageCategoryBadge(title: String, sizeText: String, color: Color, modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .background(Color(0xFFF8FAFC))
      .border(1.dp, SandboxOutlineVariant, RoundedCornerShape(8.dp))
      .padding(6.dp)
  ) {
    Column {
      Text(text = title, fontSize = 9.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
      Spacer(modifier = Modifier.height(2.dp))
      Text(text = sizeText, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
    }
  }
}
