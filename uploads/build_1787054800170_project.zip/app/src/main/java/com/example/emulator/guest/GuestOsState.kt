package com.example.emulator.guest

enum class VmPowerState(val label: String) {
  POWERED_OFF("متوقف"),
  BOOTING("جاري الإقلاع..."),
  RUNNING("قيد التشغيل"),
  PAUSED("موقوف مؤقتاً"),
  SHUTTING_DOWN("جاري إيقاف التشغيل...")
}

data class VmHardwareProfile(
  val androidVersion: String = "Android 14 (Upside Down Cake)",
  val apiLevel: Int = 34,
  val architecture: String = "ARM64-v8a (with ARMv7 binary translation)",
  val cpuCores: Int = 8,
  val ramMb: Int = 4096,
  val resolutionWidth: Int = 1080,
  val resolutionHeight: Int = 2340,
  val densityDpi: Int = 440,
  val hasRoot: Boolean = true,
  val hasGpuAcceleration: Boolean = true,
  val selinuxMode: String = "Permissive"
)

data class VmTelemetry(
  val fps: Float = 60.0f,
  val cpuUsagePercent: Double = 14.5,
  val ramUsedMb: Double = 1280.0,
  val ramTotalMb: Double = 4096.0,
  val rootFsUsedMb: Double = 1420.0,
  val rootFsTotalMb: Double = 8192.0,
  val uptimeSeconds: Long = 0L,
  val binderTransactions: Int = 3840,
  val translatedBlocks: Long = 18450L
)

data class GuestApp(
  val id: String,
  val packageName: String,
  val name: String,
  val iconResName: String,
  val isSystemApp: Boolean = false,
  val activityClass: String = "$packageName.MainActivity",
  val description: String = "",
  val installedTime: Long = System.currentTimeMillis(),
  val apkSizeMb: Double = 12.4
)

data class BootStep(
  val stepNumber: Int,
  val title: String,
  val description: String,
  val logLine: String,
  val progress: Float
)

data class RootFsNode(
  val name: String,
  val absolutePath: String,
  val isDirectory: Boolean,
  val sizeBytes: Long = 0L,
  val permissions: String = "rwxr-xr-x",
  val owner: String = "root",
  val group: String = "root",
  val childrenCount: Int = 0
)

data class GuestLogEntry(
  val id: Long,
  val timestamp: Long,
  val level: String, // V, D, I, W, E
  val tag: String,
  val pid: Int,
  val message: String
)
