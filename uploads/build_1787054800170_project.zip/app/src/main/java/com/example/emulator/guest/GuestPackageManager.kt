package com.example.emulator.guest

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.emulator.rootfs.VirtualRootFsManager
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Guest OS Package Management Service.
 * Manages installed apps inside the virtual rootfs `/data/app/` with real APK archive parsing.
 */
class GuestPackageManager(
  private val context: Context,
  private val rootFsManager: VirtualRootFsManager
) {
  private val TAG = "GuestPackageManager"
  private val installedGuestApps = mutableListOf<GuestApp>()

  // Built-in App & Game catalogue available for 1-click installation into the Micro-VM
  val availableStoreCatalog = listOf(
    GuestApp(
      id = "store_game_2048",
      packageName = "com.game.retro2048",
      name = "لعبة 2048 الكلاسيكية",
      iconResName = "games",
      isSystemApp = false,
      description = "لعبة ألغاز وأرقام تفاعلية تعمل باللمس وحساب النقاط داخل النظام الافتراضي",
      apkSizeMb = 3.2
    ),
    GuestApp(
      id = "store_game_flappy",
      packageName = "com.game.flappydroid",
      name = "لعبة Flappy Droid",
      iconResName = "sports_esports",
      isSystemApp = false,
      description = "لعبة أركيد ومغامرات تفاعلية تعمل بمحرك فيزيائي وتحدي النقاط العالية",
      apkSizeMb = 4.5
    ),
    GuestApp(
      id = "store_game_tictactoe",
      packageName = "com.game.tictactoe",
      name = "لعبة X-O الذكية (AI)",
      iconResName = "grid_view",
      isSystemApp = false,
      description = "لعبة تيك تاك تو ضد الذكاء الاصطناعي مع مستويات صعوبة متعددة",
      apkSizeMb = 2.8
    ),
    GuestApp(
      id = "store_calc_pro",
      packageName = "com.tools.calculator",
      name = "الآلة الحاسبة العلمية",
      iconResName = "calculate",
      isSystemApp = false,
      description = "محرك حسابي متقدم للعمليات الرياضية والدوال مع حفظ سجل الحسابات",
      apkSizeMb = 3.8
    ),
    GuestApp(
      id = "store_cyber_tools",
      packageName = "com.cyber.sandbox.toolkit",
      name = "حقيبة أدوات الحماية والذاكرة",
      iconResName = "security",
      isSystemApp = false,
      description = "أداة فحص التشفير SHA-256 وتحليل استهلاك الذاكرة وتجزئة البيانات في RootFS",
      apkSizeMb = 6.2
    ),
    GuestApp(
      id = "store_magisk_root",
      packageName = "com.topjohnwu.magisk",
      name = "مدير الـ Root (Magisk VM)",
      iconResName = "admin_panel_settings",
      isSystemApp = false,
      description = "إدارة صلاحيات الجذر وتصاريح الـ SU لكافة العمليات داخل الحاوية",
      apkSizeMb = 5.0
    )
  )

  init {
    loadDefaultGuestSystemApps()
  }

  private fun loadDefaultGuestSystemApps() {
    installedGuestApps.clear()
    installedGuestApps.addAll(
      listOf(
        GuestApp(
          id = "sys_settings",
          packageName = "com.android.settings",
          name = "إعدادات النظام",
          iconResName = "settings",
          isSystemApp = true,
          description = "إعدادات نظام Android 14، الشاشة، الصوت، خيارات المطور وصلاحيات Root"
        ),
        GuestApp(
          id = "sys_appstore",
          packageName = "com.android.vending",
          name = "متجر التطبيقات والألعاب",
          iconResName = "store",
          isSystemApp = true,
          description = "متجر مدمج لتثبيت الألعاب والتطبيقات التفاعلية مباشرة داخل النظام"
        ),
        GuestApp(
          id = "sys_browser",
          packageName = "com.android.chrome",
          name = "متصفح الويب (Browser)",
          iconResName = "language",
          isSystemApp = true,
          description = "متصفح ويب سريع داخل البيئة الافتراضية مع دعم كامل للشبكة المعزولة"
        ),
        GuestApp(
          id = "sys_terminal",
          packageName = "com.android.terminal",
          name = "طرفية الأوامر (Root Shell)",
          iconResName = "terminal",
          isSystemApp = true,
          description = "طرفية لينكس وأندرويد تفاعلية بصلاحيات root كاملة (su, pm, am, logcat)"
        ),
        GuestApp(
          id = "sys_files",
          packageName = "com.android.documentsui",
          name = "مدير الملفات (Files)",
          iconResName = "folder_open",
          isSystemApp = true,
          description = "مستعرض ملفات RootFS وذاكرة التخزين الافتراضية /storage/emulated/0"
        ),
        // Pre-installed starter games & tools
        availableStoreCatalog[0], // 2048 Game
        availableStoreCatalog[1], // Flappy Droid Game
        availableStoreCatalog[3]  // Scientific Calculator
      )
    )
  }

  fun getInstalledApps(): List<GuestApp> = installedGuestApps.toList()

  /**
   * Installs an APK from Uri into the guest RootFS `/data/app/<pkg>/base.apk`
   * with full Android PackageArchiveInfo extraction.
   */
  fun installApkFromUri(uri: Uri, fileName: String? = null): GuestApp? {
    try {
      val input: InputStream? = context.contentResolver.openInputStream(uri)
      if (input != null) {
        val bytes = input.use { it.readBytes() }
        
        // Write to a temporary file first to inspect package metadata
        val tempApk = File(context.cacheDir, "temp_import_${System.currentTimeMillis()}.apk")
        FileOutputStream(tempApk).use { it.write(bytes) }

        val pm = context.packageManager
        val flags = PackageManager.GET_ACTIVITIES or PackageManager.GET_PERMISSIONS or PackageManager.GET_META_DATA
        val packageInfo: PackageInfo? = try {
          pm.getPackageArchiveInfo(tempApk.absolutePath, flags)
        } catch (e: Exception) {
          null
        }

        val packageName: String
        val appName: String
        val versionName: String

        if (packageInfo != null) {
          packageName = packageInfo.packageName
          packageInfo.applicationInfo?.sourceDir = tempApk.absolutePath
          packageInfo.applicationInfo?.publicSourceDir = tempApk.absolutePath

          val rawLabel = try {
            packageInfo.applicationInfo?.loadLabel(pm)?.toString()
          } catch (e: Exception) {
            null
          }

          appName = rawLabel ?: (fileName ?: tempApk.nameWithoutExtension).replace(".apk", "").replace("_", " ").capitalize()
          versionName = packageInfo.versionName ?: "1.0.0"
        } else {
          // Fallback for non-standard or raw container APK files
          val rawName = fileName ?: "app_${System.currentTimeMillis()}"
          packageName = "com.user." + rawName.replace(".apk", "").lowercase().replace("[^a-z0-9_]".toRegex(), "")
          appName = rawName.replace(".apk", "").replace("_", " ").capitalize()
          versionName = "1.0.0"
        }

        // Install to RootFS: /data/app/<packageName>/base.apk
        rootFsManager.installApkToRootFs(packageName, bytes)
        tempApk.delete()

        val newApp = GuestApp(
          id = "user_app_${System.currentTimeMillis()}",
          packageName = packageName,
          name = appName,
          iconResName = "apps",
          isSystemApp = false,
          description = "تطبيق حقيقي مثبت في بارتشن /data/app/$packageName (الإصدار: $versionName)",
          apkSizeMb = bytes.size / (1024.0 * 1024.0).coerceAtLeast(0.5)
        )

        // Remove old version if present and add new
        installedGuestApps.removeAll { it.packageName == packageName }
        installedGuestApps.add(newApp)
        Log.i(TAG, "Successfully installed APK: $packageName ($appName) to RootFS")
        return newApp
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error installing APK: ${e.message}", e)
    }
    return null
  }

  fun installCatalogApp(app: GuestApp): Boolean {
    if (installedGuestApps.none { it.packageName == app.packageName }) {
      installedGuestApps.add(app)
      rootFsManager.installApkToRootFs(app.packageName, "GUEST_STANDALONE_DEX_APK_PKG_${app.packageName}".toByteArray())
      return true
    }
    return false
  }

  fun uninstallGuestApp(packageName: String): Boolean {
    val app = installedGuestApps.find { it.packageName == packageName }
    if (app != null && !app.isSystemApp) {
      installedGuestApps.remove(app)
      File(rootFsManager.dataAppDir, packageName).deleteRecursively()
      File(rootFsManager.dataDataDir, packageName).deleteRecursively()
      return true
    }
    return false
  }
}
