package com.example.sandbox.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sandbox.model.SandboxStorageMetrics
import com.example.sandbox.model.VirtualProcessState
import com.example.ui.theme.SandboxOutlineVariant
import com.example.ui.theme.SandboxPrimary
import com.example.ui.theme.SandboxSecondary
import com.example.ui.theme.SandboxTertiary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusActiveBg
import com.example.ui.theme.StatusHook
import com.example.ui.theme.StatusHookBg
import com.example.ui.theme.StatusWarning

/**
 * Live Container Status and Telemetry HUD Card.
 */
@Composable
fun ContainerMetricsCard(
  processState: VirtualProcessState,
  storageMetrics: SandboxStorageMetrics,
  isHookingActive: Boolean,
  onRestart: () -> Unit,
  onPurgeCache: () -> Unit,
  onToggleHooking: (Boolean) -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("container_metrics_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    border = androidx.compose.foundation.BorderStroke(1.dp, SandboxOutlineVariant),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      // Top status row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(StatusActive)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "بيئة العزل الافتراضية نشطة",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
          )
        }

        // Quick Container Actions
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onRestart,
            modifier = Modifier
              .size(36.dp)
              .testTag("restart_container_button")
          ) {
            Icon(
              imageVector = Icons.Default.Cached,
              contentDescription = "Restart Sandbox",
              tint = SandboxPrimary,
              modifier = Modifier.size(20.dp)
            )
          }

          IconButton(
            onClick = onPurgeCache,
            modifier = Modifier
              .size(36.dp)
              .testTag("purge_cache_button")
          ) {
            Icon(
              imageVector = Icons.Default.DeleteOutline,
              contentDescription = "Purge Cache",
              tint = StatusWarning,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 4 Telemetry Badges Grid
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        MetricTile(
          icon = Icons.Default.Memory,
          label = "RAM المستهلك",
          value = "${processState.heapMemoryMb} MB",
          badgeColor = SandboxPrimary,
          modifier = Modifier.weight(1f)
        )

        MetricTile(
          icon = Icons.Default.Storage,
          label = "تخزين العزل",
          value = storageMetrics.formattedTotal,
          badgeColor = SandboxTertiary,
          modifier = Modifier.weight(1f)
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        MetricTile(
          icon = Icons.Default.Security,
          label = "اعتراض الدوال",
          value = if (isHookingActive) "Dynamic Active" else "Bypass",
          badgeColor = if (isHookingActive) StatusHook else Color.Gray,
          modifier = Modifier
            .weight(1f)
            .clickable { onToggleHooking(!isHookingActive) }
        )

        MetricTile(
          icon = Icons.Default.PowerSettingsNew,
          label = "معرف العملية PID",
          value = "#${processState.pid}",
          badgeColor = SandboxSecondary,
          modifier = Modifier.weight(1f)
        )
      }
    }
  }
}

@Composable
private fun MetricTile(
  icon: ImageVector,
  label: String,
  value: String,
  badgeColor: Color,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(Color(0xFFF8FAFC))
      .border(1.dp, SandboxOutlineVariant, RoundedCornerShape(12.dp))
      .padding(horizontal = 12.dp, vertical = 10.dp)
  ) {
    Column {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = badgeColor,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = label,
          fontSize = 11.sp,
          color = Color(0xFF64748B),
          fontWeight = FontWeight.Medium
        )
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF0F172A)
      )
    }
  }
}
