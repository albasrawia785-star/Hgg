package com.example.sandbox.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sandbox.model.VirtualProcessState
import com.example.ui.theme.SandboxOutlineVariant
import com.example.ui.theme.SandboxPrimary
import com.example.ui.theme.SandboxSecondary
import com.example.ui.theme.SandboxTertiary
import com.example.ui.theme.StatusActive

/**
 * System Diagnostics, Virtual Process & JVM Heap Memory Metrics Screen.
 */
@Composable
fun DiagnosticsTab(
  processState: VirtualProcessState,
  modifier: Modifier = Modifier
) {
  val runtime = Runtime.getRuntime()
  val maxHeapMb = runtime.maxMemory() / (1024 * 1024)
  val totalHeapMb = runtime.totalMemory() / (1024 * 1024)
  val freeHeapMb = runtime.freeMemory() / (1024 * 1024)
  val usedHeapMb = totalHeapMb - freeHeapMb

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    Text(
      text = "مقاييس الأداء والنواة الافتراضية",
      fontSize = 17.sp,
      fontWeight = FontWeight.Bold,
      color = Color(0xFF0F172A)
    )
    Text(
      text = "معلومات الذاكرة والعمليات المعزولة بالزمن الحقيقي",
      fontSize = 12.sp,
      color = Color(0xFF64748B)
    )

    Spacer(modifier = Modifier.height(16.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      // Memory Status Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = androidx.compose.foundation.BorderStroke(1.dp, SandboxOutlineVariant)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Memory, contentDescription = null, tint = SandboxPrimary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "ذاكرة كومة JVM للحاوية (Heap)",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF0F172A)
                )
              }

              Button(
                onClick = { System.gc() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEEF2FF)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("trigger_gc_button")
              ) {
                Icon(Icons.Default.CleaningServices, contentDescription = null, tint = SandboxSecondary, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تنظيف الذاكرة (GC)", color = SandboxSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Memory Progress Bar
            val usageRatio = (usedHeapMb.toFloat() / maxHeapMb.toFloat()).coerceIn(0f, 1f)
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFE2E8F0))
            ) {
              Box(
                modifier = Modifier
                  .fillMaxWidth(fraction = usageRatio)
                  .height(12.dp)
                  .clip(RoundedCornerShape(6.dp))
                  .background(SandboxPrimary)
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "المستخدم: ${usedHeapMb} MB", fontSize = 11.sp, color = Color(0xFF64748B))
              Text(text = "الإجمالي: ${totalHeapMb} MB", fontSize = 11.sp, color = Color(0xFF64748B))
              Text(text = "الحد الأقصى: ${maxHeapMb} MB", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SandboxPrimary)
            }
          }
        }
      }

      // Process & Kernel Metrics Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = androidx.compose.foundation.BorderStroke(1.dp, SandboxOutlineVariant)
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "حالة العملية الافتراضية (Virtual Process)",
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF0F172A)
            )

            Spacer(modifier = Modifier.height(12.dp))

            DiagRow("اسم العملية الافتراضية", processState.processName)
            DiagRow("معرف العملية PID", "#${processState.pid}")
            DiagRow("خيوط التنفيذ النشطة (Threads)", "${processState.threadCount} Threads")
            DiagRow("وقت التشغيل المستمر (Uptime)", "${processState.uptimeSeconds} ثانية")
            DiagRow("الحزمة النشطة", processState.activePackage)
            DiagRow("بنية المعالج المعتمدة", "arm64-v8a (AArch64 Native Layer)")
            DiagRow("نواة التحميل المخصصة", "dalvik.system.DexClassLoader")
          }
        }
      }
    }
  }
}

@Composable
private fun DiagRow(label: String, value: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(text = label, fontSize = 12.sp, color = Color(0xFF64748B))
    Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
  }
}
