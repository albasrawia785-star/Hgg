package com.example.sandbox.core

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.example.sandbox.model.ComponentType
import com.example.sandbox.model.HookSubsystem
import com.example.sandbox.model.VirtualAppInfo
import com.example.sandbox.model.VirtualComponentInfo
import com.example.sandbox.model.VirtualPermission
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Dynamic Virtual Package Manager.
 * Parses APKs without installation on the host operating system,
 * extracting manifests, components, permissions, and metadata.
 */
class VirtualPackageManager(
  private val context: Context,
  private val hookManager: VirtualHookManager,
  private val resourcesManager: VirtualResourcesManager,
  private val fileSystemManager: VirtualFileSystemManager
) {
  private val installedVirtualApps = ConcurrentHashMap<String, VirtualAppInfo>()

  init {
    loadKnownInstalledPackages()
  }

  private fun loadKnownInstalledPackages() {
    val apkDir = fileSystemManager.apkStoreDir
    apkDir.listFiles { file -> file.extension == "apk" }?.forEach { apkFile ->
      parseAndRegisterApk(apkFile.absolutePath, isEmbedded = false)
    }
  }

  /**
   * Checks whether a file has standard ZIP/APK header magic bytes (PK\x03\x04 or PK\x05\x06).
   */
  private fun isZipArchive(file: File): Boolean {
    if (!file.exists() || file.length() < 4) return false
    return try {
      file.inputStream().use { stream ->
        val header = ByteArray(4)
        val read = stream.read(header)
        read == 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()
      }
    } catch (e: Exception) {
      false
    }
  }

  /**
   * Parses an APK archive and registers it in the virtual runtime.
   */
  fun parseAndRegisterApk(apkPath: String, isEmbedded: Boolean = false, overrideName: String? = null): VirtualAppInfo? {
    val start = System.currentTimeMillis()
    try {
      val apkFile = File(apkPath)
      val pm = context.packageManager
      val flags = PackageManager.GET_ACTIVITIES or
          PackageManager.GET_PERMISSIONS or
          PackageManager.GET_SERVICES or
          PackageManager.GET_RECEIVERS or
          PackageManager.GET_META_DATA

      val packageInfo: PackageInfo? = if (isZipArchive(apkFile)) {
        try {
          pm.getPackageArchiveInfo(apkPath, flags)
        } catch (e: Exception) {
          null
        }
      } else {
        null
      }

      val packageName: String
      val appName: String
      val versionName: String
      val versionCode: Long
      val targetSdk: Int
      val minSdk: Int
      val mainActivity: String
      val permissions = mutableListOf<VirtualPermission>()
      val components = mutableListOf<VirtualComponentInfo>()

      if (packageInfo != null) {
        packageName = packageInfo.packageName
        val appInfoObj = packageInfo.applicationInfo
        if (appInfoObj != null) {
          appInfoObj.sourceDir = apkPath
          appInfoObj.publicSourceDir = apkPath
        }

        val rawLabel = try {
          val labelRes = appInfoObj?.labelRes ?: 0
          if (labelRes != 0) {
            resourcesManager.getResourcesForApk(apkPath).resources.getString(labelRes)
          } else {
            appInfoObj?.nonLocalizedLabel?.toString() ?: appInfoObj?.name
          }
        } catch (e: Exception) {
          null
        }

        appName = overrideName ?: rawLabel ?: apkFile.nameWithoutExtension.replace("_", " ").capitalize()
        versionName = packageInfo.versionName ?: "1.0.0"
        versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
          packageInfo.longVersionCode
        } else {
          @Suppress("DEPRECATION")
          packageInfo.versionCode.toLong()
        }
        targetSdk = appInfoObj?.targetSdkVersion ?: 34
        minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
          appInfoObj?.minSdkVersion ?: 21
        } else 21

        // Activities
        packageInfo.activities?.forEach { act ->
          components.add(
            VirtualComponentInfo(
              name = act.name,
              type = ComponentType.ACTIVITY,
              exported = act.exported,
              label = act.loadLabel(pm)?.toString() ?: act.name.substringAfterLast('.'),
              permission = act.permission
            )
          )
        }

        mainActivity = packageInfo.activities?.firstOrNull()?.name
          ?: "$packageName.MainActivity"

        // Services
        packageInfo.services?.forEach { srv ->
          components.add(
            VirtualComponentInfo(
              name = srv.name,
              type = ComponentType.SERVICE,
              exported = srv.exported,
              label = srv.name.substringAfterLast('.'),
              permission = srv.permission
            )
          )
        }

        // Receivers
        packageInfo.receivers?.forEach { rec ->
          components.add(
            VirtualComponentInfo(
              name = rec.name,
              type = ComponentType.RECEIVER,
              exported = rec.exported,
              label = rec.name.substringAfterLast('.'),
              permission = rec.permission
            )
          )
        }

        // Permissions
        packageInfo.requestedPermissions?.forEachIndexed { index, permName ->
          val short = permName.substringAfterLast('.')
          val category = when {
            permName.contains("STORAGE") || permName.contains("READ_") || permName.contains("WRITE_") -> "Storage"
            permName.contains("INTERNET") || permName.contains("NETWORK") -> "Network"
            permName.contains("CAMERA") || permName.contains("AUDIO") -> "Hardware"
            permName.contains("LOCATION") -> "Location"
            else -> "System"
          }
          permissions.add(
            VirtualPermission(
              name = permName,
              shortName = short,
              isGranted = true, // Sandboxed runtime grants safely inside virtual container
              protectionLevel = "normal",
              description = "Virtual container isolated access to $short",
              category = category
            )
          )
        }

        // Register in HookManager
        hookManager.registerVirtualPackage(packageName, packageInfo)
      } else {
        // Fallback synthetic registration for standalone/mock APK files
        val baseName = apkFile.nameWithoutExtension
        packageName = if (baseName.startsWith("com.") || baseName.contains('.')) {
          baseName
        } else {
          "com.virtual.${baseName.lowercase().replace("[^a-z0-9_]".toRegex(), "")}"
        }
        appName = overrideName ?: baseName.replace("_", " ").capitalize()
        versionName = "1.0.0-sandbox"
        versionCode = 100L
        targetSdk = 34
        minSdk = 24
        mainActivity = "$packageName.MainActivity"
        
        components.add(VirtualComponentInfo(mainActivity, ComponentType.ACTIVITY, true, "Main Dashboard"))
        components.add(VirtualComponentInfo("$packageName.DiagnosticService", ComponentType.SERVICE, false, "Container Service"))
        
        permissions.add(VirtualPermission("android.permission.INTERNET", "INTERNET", true, "normal", "Network telemetry", "Network"))
        permissions.add(VirtualPermission("android.permission.READ_EXTERNAL_STORAGE", "READ_STORAGE", true, "dangerous", "Sandboxed storage", "Storage"))
      }

      val iconDrawable = try {
        packageInfo?.applicationInfo?.let { pm.getApplicationIcon(it) }
      } catch (e: Exception) {
        null
      }

      val appInfo = VirtualAppInfo(
        packageName = packageName,
        appName = appName,
        versionName = versionName,
        versionCode = versionCode,
        apkPath = apkPath,
        mainActivity = mainActivity,
        targetSdk = targetSdk,
        minSdk = minSdk,
        permissions = permissions,
        components = components,
        isEmbedded = isEmbedded,
        apkSizeBytes = apkFile.length(),
        dataSizeBytes = fileSystemManager.calculateStorageMetrics(packageName).totalBytes,
        iconDrawable = iconDrawable,
        description = "Sandboxed Application (Target SDK $targetSdk, ${components.size} components)"
      )

      installedVirtualApps[packageName] = appInfo
      fileSystemManager.initializePackageSandbox(packageName)

      hookManager.recordLog(
        subsystem = HookSubsystem.PACKAGE_MANAGER,
        method = "parseAndRegisterApk",
        targetClass = "android.content.pm.PackageParser",
        callerPackage = packageName,
        details = "Extracted Manifest: $appName (pkg=$packageName, acts=${components.count { it.type == ComponentType.ACTIVITY }}, perms=${permissions.size})",
        outcome = "SUCCESS_PARSED",
        durationMs = System.currentTimeMillis() - start
      )

      return appInfo
    } catch (e: Exception) {
      hookManager.recordLog(
        subsystem = HookSubsystem.PACKAGE_MANAGER,
        method = "parseAndRegisterApk",
        targetClass = "android.content.pm.PackageParser",
        callerPackage = File(apkPath).nameWithoutExtension,
        details = "Parsing failed: ${e.message}",
        outcome = "PARSE_ERROR",
        durationMs = System.currentTimeMillis() - start
      )
      return null
    }
  }

  fun getInstalledApps(): List<VirtualAppInfo> = installedVirtualApps.values.toList()

  fun getAppByPackage(packageName: String): VirtualAppInfo? = installedVirtualApps[packageName]

  fun uninstallApp(packageName: String): Boolean {
    val app = installedVirtualApps.remove(packageName) ?: return false
    val apkFile = File(app.apkPath)
    if (apkFile.exists() && !app.isEmbedded) {
      apkFile.delete()
    }
    fileSystemManager.purgeCache(packageName)
    hookManager.recordLog(
      subsystem = HookSubsystem.PACKAGE_MANAGER,
      method = "uninstallApp",
      targetClass = "VirtualPackageManager",
      callerPackage = packageName,
      details = "Uninstalled virtual package $packageName and cleaned sandbox directory",
      outcome = "UNINSTALL_OK"
    )
    return true
  }

  private fun String.capitalize(): String {
    return this.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
  }
}
