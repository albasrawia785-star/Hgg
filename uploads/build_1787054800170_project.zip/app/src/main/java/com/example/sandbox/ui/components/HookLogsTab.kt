package com.example.sandbox.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sandbox.model.HookSubsystem
import com.example.sandbox.model.InterceptionLog
import com.example.ui.theme.SandboxOutlineVariant
import com.example.ui.theme.SandboxPrimary
import com.example.ui.theme.SandboxSecondary
import com.example.ui.theme.SandboxTertiary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusActiveBg
import com.example.ui.theme.StatusHook
import com.example.ui.theme.StatusHookBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Live Dynamic Proxy & Reflection Interception Logs Stream.
 */
@Composable
fun HookLogsTab(
  logs: List<InterceptionLog>,
  onClearLogs: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedSubsystem by remember { mutableStateOf<HookSubsystem?>(null) }

  val filteredLogs = remember(logs, selectedSubsystem) {
    if (selectedSubsystem == null) logs else logs.filter { it.subsystem == selectedSubsystem }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    // Header Row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "سجل الاعتراض والمحاكاة (Dynamic Hooks)",
          fontSize = 17.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF0F172A)
        )
        Text(
          text = "${logs.size} استدعاء تم اعتراضه وتوجيهه للحاوية",
          fontSize = 12.sp,
          color = Color(0xFF64748B)
        )
      }

      IconButton(
        onClick = onClearLogs,
        modifier = Modifier.testTag("clear_logs_button")
      ) {
        Icon(
          imageVector = Icons.Default.ClearAll,
          contentDescription = "Clear Logs",
          tint = Color(0xFF64748B)
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Subsystems Filter Chips
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      item {
        FilterChip(
          selected = selectedSubsystem == null,
          onClick = { selectedSubsystem = null },
          label = { Text("الكل (${logs.size})", fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = SandboxPrimary,
            selectedLabelColor = Color.White
          )
        )
      }

      HookSubsystem.values().forEach { sub ->
        val count = logs.count { it.subsystem == sub }
        item {
          FilterChip(
            selected = selectedSubsystem == sub,
            onClick = { selectedSubsystem = if (selectedSubsystem == sub) null else sub },
            label = { Text("${sub.name} ($count)", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = getSubsystemColor(sub),
              selectedLabelColor = Color.White
            )
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Logs Stream
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      if (filteredLogs.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "لا توجد سجلات اعتراض مطابقة حالياً",
              fontSize = 13.sp,
              color = Color(0xFF94A3B8)
            )
          }
        }
      } else {
        items(filteredLogs) { log ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("log_item_${log.id}"),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, SandboxOutlineVariant)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              // Top Bar of Log
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(getSubsystemColor(log.subsystem).copy(alpha = 0.15f))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
                  ) {
                    Text(
                      text = log.subsystem.name,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      color = getSubsystemColor(log.subsystem)
                    )
                  }

                  Spacer(modifier = Modifier.width(8.dp))

                  Text(
                    text = log.method,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                  )
                }

                Text(
                  text = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(log.timestamp)),
                  fontSize = 10.sp,
                  color = Color(0xFF94A3B8)
                )
              }

              Spacer(modifier = Modifier.height(4.dp))

              Text(
                text = log.details,
                fontSize = 12.sp,
                color = Color(0xFF334155),
                lineHeight = 16.sp
              )

              Spacer(modifier = Modifier.height(6.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Caller: ${log.callerPackage} • ${log.targetClass}",
                  fontSize = 10.sp,
                  color = Color(0xFF64748B)
                )

                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(StatusActiveBg)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = log.outcome,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = StatusActive
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

private fun getSubsystemColor(subsystem: HookSubsystem): Color {
  return when (subsystem) {
    HookSubsystem.ACTIVITY_MANAGER -> SandboxPrimary
    HookSubsystem.PACKAGE_MANAGER -> SandboxSecondary
    HookSubsystem.RESOURCES_MANAGER -> SandboxTertiary
    HookSubsystem.FILE_SYSTEM -> StatusWarning
    HookSubsystem.CLASS_LOADER -> StatusHook
    HookSubsystem.WINDOW_MANAGER -> Color(0xFF0284C7)
  }
}
