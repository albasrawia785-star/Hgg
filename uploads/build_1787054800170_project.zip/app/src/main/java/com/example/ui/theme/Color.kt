package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Clean Sandbox Palette (Optimized for Light Mode & Enterprise Container UI)
val SandboxPrimary = Color(0xFF0284C7)        // Ocean Sky Cyan/Blue
val SandboxOnPrimary = Color(0xFFFFFFFF)
val SandboxPrimaryContainer = Color(0xFFE0F2FE)
val SandboxOnPrimaryContainer = Color(0xFF0369A1)

val SandboxSecondary = Color(0xFF4F46E5)      // Indigo Engine
val SandboxOnSecondary = Color(0xFFFFFFFF)
val SandboxSecondaryContainer = Color(0xFFEEF2FF)
val SandboxOnSecondaryContainer = Color(0xFF3730A3)

val SandboxTertiary = Color(0xFF0D9488)       // Teal Virtual Core
val SandboxOnTertiary = Color(0xFFFFFFFF)
val SandboxTertiaryContainer = Color(0xFFCCFBF1)
val SandboxOnTertiaryContainer = Color(0xFF115E59)

val SandboxBackground = Color(0xFFF8FAFC)     // Crisp Clean Canvas (Slate 50)
val SandboxOnBackground = Color(0xFF0F172A)   // Dark Slate 900
val SandboxSurface = Color(0xFFFFFFFF)        // Pure White Surface
val SandboxOnSurface = Color(0xFF1E293B)      // Slate 800
val SandboxSurfaceVariant = Color(0xFFF1F5F9) // Slate 100
val SandboxOnSurfaceVariant = Color(0xFF475569)// Slate 600

val SandboxOutline = Color(0xFFCBD5E1)        // Slate 300
val SandboxOutlineVariant = Color(0xFFE2E8F0) // Slate 200

// Status & Metric Colors
val StatusActive = Color(0xFF10B981)          // Emerald Green
val StatusActiveBg = Color(0xFFD1FAE5)
val StatusWarning = Color(0xFFF59E0B)         // Amber
val StatusWarningBg = Color(0xFFFEF3C7)
val StatusDanger = Color(0xFFEF4444)          // Rose
val StatusDangerBg = Color(0xFFFEE2E2)
val StatusHook = Color(0xFF8B5CF6)            // Purple Hook
val StatusHookBg = Color(0xFFEDE9FE)
