package com.example.emulator.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
fun GuestTerminalDialog(
  terminalHistory: List<Pair<String, String>>,
  onExecuteCommand: (String) -> Unit,
  onClear: () -> Unit,
  onDismiss: () -> Unit
) {
  var cmdText by remember { mutableStateOf("") }
  val quickCommands = listOf("uname -a", "getprop", "df -h", "top", "id", "pm list packages", "ps", "ls -la /system/bin")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color(0xFF030712),
      modifier = Modifier
        .fillMaxWidth()
        .height(600.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(14.dp)
      ) {
        // Header
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Terminal, contentDescription = null, tint = Color(0xFF22C55E), modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("طرفية أوامر أندرويد (Root Shell)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
              Text("Micro-VM aarch64 Toybox Shell", fontSize = 10.sp, color = Color(0xFF94A3B8))
            }
          }
          Row {
            IconButton(onClick = onClear) {
              Icon(Icons.Default.DeleteSweep, contentDescription = "Clear", tint = Color(0xFF94A3B8))
            }
            IconButton(onClick = onDismiss) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = Color(0xFF94A3B8))
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Command Chips
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          quickCommands.forEach { cmd ->
            Surface(
              color = Color(0xFF1F2937),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.height(28.dp)
            ) {
              TextButton(
                onClick = { onExecuteCommand(cmd) },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
              ) {
                Text(cmd, fontSize = 10.sp, color = Color(0xFF38BDF8), fontFamily = FontFamily.Monospace)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Terminal Console Area
        Surface(
          color = Color(0xFF0B0F19),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
        ) {
          val scrollState = rememberScrollState()
          LaunchedEffect(terminalHistory.size) {
            scrollState.animateScrollTo(scrollState.maxValue)
          }

          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(8.dp)
              .verticalScroll(scrollState)
          ) {
            terminalHistory.forEach { (cmd, out) ->
              Text(
                text = "microvm:/ # $cmd",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFEF4444),
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = out,
                fontSize = 11.sp,
                color = Color(0xFFE2E8F0),
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input Field
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth()
        ) {
          OutlinedTextField(
            value = cmdText,
            onValueChange = { cmdText = it },
            placeholder = { Text("أدخل الأمر هنا...", fontSize = 11.sp, color = Color(0xFF64748B)) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = Color.White,
              unfocusedTextColor = Color(0xFFE2E8F0),
              focusedContainerColor = Color(0xFF111827),
              unfocusedContainerColor = Color(0xFF111827),
              focusedBorderColor = Color(0xFF22C55E),
              unfocusedBorderColor = Color(0xFF374151)
            ),
            modifier = Modifier.weight(1f)
          )
          Spacer(modifier = Modifier.width(6.dp))
          IconButton(
            onClick = {
              if (cmdText.isNotBlank()) {
                onExecuteCommand(cmdText)
                cmdText = ""
              }
            }
          ) {
            Icon(Icons.Default.Send, contentDescription = "Run", tint = Color(0xFF22C55E))
          }
        }
      }
    }
  }
}
