package com.example.emulator.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.emulator.guest.GuestApp
import com.example.emulator.guest.VmHardwareProfile
import kotlinx.coroutines.delay
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import kotlin.random.Random

@Composable
fun GuestOsViewport(
  activeApp: GuestApp?,
  installedApps: List<GuestApp>,
  hardwareProfile: VmHardwareProfile,
  storeCatalog: List<GuestApp> = emptyList(),
  onLaunchApp: (GuestApp) -> Unit,
  onInstallStoreApp: (GuestApp) -> Unit = {},
  onOpenApkPicker: () -> Unit = {},
  onExecuteCommand: (String) -> String,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // 1. Guest Android Status Bar
      GuestStatusBar(hardwareProfile = hardwareProfile)

      // 2. Main Display Content (Launcher vs Running Foreground App)
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
      ) {
        if (activeApp == null) {
          GuestLauncherDesktop(
            installedApps = installedApps,
            onLaunchApp = onLaunchApp,
            onOpenApkPicker = onOpenApkPicker
          )
        } else {
          GuestAppContainer(
            app = activeApp,
            hardwareProfile = hardwareProfile,
            storeCatalog = storeCatalog,
            installedApps = installedApps,
            onInstallStoreApp = onInstallStoreApp,
            onLaunchApp = onLaunchApp,
            onOpenApkPicker = onOpenApkPicker,
            onExecuteCommand = onExecuteCommand
          )
        }
      }
    }
  }
}

@Composable
private fun GuestStatusBar(hardwareProfile: VmHardwareProfile) {
  val currentTime = remember {
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
  }

  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
    modifier = Modifier
      .fillMaxWidth()
      .height(28.dp)
      .background(Color(0xFF020617))
      .padding(horizontal = 14.dp)
  ) {
    // Left: Time & Root badge
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = currentTime,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFFF1F5F9)
      )
      if (hardwareProfile.hasRoot) {
        Spacer(modifier = Modifier.width(6.dp))
        Surface(
          color = Color(0xFFDC2626),
          shape = RoundedCornerShape(4.dp)
        ) {
          Text(
            text = "# ROOT",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
          )
        }
      }
    }

    // Right: Virtual Network, WiFi, Battery
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      Text(
        text = "5G Standalone",
        fontSize = 10.sp,
        fontWeight = FontWeight.Medium,
        color = Color(0xFF38BDF8)
      )
      Icon(
        imageVector = Icons.Default.Wifi,
        contentDescription = "WiFi",
        tint = Color(0xFFF1F5F9),
        modifier = Modifier.size(14.dp)
      )
      Icon(
        imageVector = Icons.Default.BatteryFull,
        contentDescription = "Battery",
        tint = Color(0xFF22C55E),
        modifier = Modifier.size(14.dp)
      )
    }
  }
}

@Composable
private fun GuestLauncherDesktop(
  installedApps: List<GuestApp>,
  onLaunchApp: (GuestApp) -> Unit,
  onOpenApkPicker: () -> Unit
) {
  val currentDate = remember {
    SimpleDateFormat("EEEE, d MMMM", Locale("ar")).format(Date())
  }

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          listOf(
            Color(0xFF0F172A),
            Color(0xFF1E293B),
            Color(0xFF0B132B)
          )
        )
      )
      .padding(14.dp)
  ) {
    // 1. Android 14 Smart Clock & Weather Widget
    Surface(
      color = Color(0xFF1E293B).copy(alpha = 0.9f),
      shape = RoundedCornerShape(20.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 4.dp)
    ) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(14.dp)
      ) {
        val clockTime = remember { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) }
        Text(
          text = clockTime,
          fontSize = 36.sp,
          fontWeight = FontWeight.Light,
          color = Color(0xFFF8FAFC),
          letterSpacing = 1.sp
        )
        Text(
          text = currentDate,
          fontSize = 12.sp,
          color = Color(0xFF94A3B8),
          fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Cloud,
            contentDescription = null,
            tint = Color(0xFF38BDF8),
            modifier = Modifier.size(14.dp)
          )
          Text(
            text = "28°C مشمس • نظام تشغيل أندرويد حقيقي داخل الحاوية",
            fontSize = 11.sp,
            color = Color(0xFFCBD5E1)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // 2. Action Banner: Install External APK / Open Store
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Surface(
        color = Color(0xFF0284C7),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
          .weight(1f)
          .height(44.dp)
          .clickable { onOpenApkPicker() }
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
          modifier = Modifier.padding(horizontal = 8.dp)
        ) {
          Icon(Icons.Default.AddBox, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("تثبيت ملف APK", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
      }

      val storeApp = installedApps.find { it.packageName == "com.android.vending" }
      if (storeApp != null) {
        Surface(
          color = Color(0xFF059669),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier
            .weight(1f)
            .height(44.dp)
            .clickable { onLaunchApp(storeApp) }
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
          ) {
            Icon(Icons.Default.SportsEsports, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("متجر الألعاب والتطبيقات", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 3. Grid of Installed Applications & Games
    Text(
      text = "التطبيقات والألعاب المثبتة (${installedApps.size})",
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold,
      color = Color(0xFF94A3B8),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 4.dp),
      textAlign = TextAlign.Start
    )

    LazyVerticalGrid(
      columns = GridCells.Fixed(4),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .padding(top = 6.dp)
    ) {
      items(installedApps, key = { it.id }) { app ->
        GuestAppIconItem(app = app, onClick = { onLaunchApp(app) })
      }
    }

    // 4. Dock Bar
    Surface(
      color = Color(0xFF0F172A).copy(alpha = 0.95f),
      shape = RoundedCornerShape(20.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
      modifier = Modifier
        .fillMaxWidth()
        .height(64.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly,
        modifier = Modifier.fillMaxSize()
      ) {
        val dockApps = installedApps.take(4)
        dockApps.forEach { app ->
          Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(getAppColor(app.iconResName))
              .clickable { onLaunchApp(app) }
          ) {
            Icon(
              imageVector = getAppIcon(app.iconResName),
              contentDescription = app.name,
              tint = Color.White,
              modifier = Modifier.size(22.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun GuestAppIconItem(app: GuestApp, onClick: () -> Unit) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable { onClick() }
      .padding(2.dp)
  ) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .size(50.dp)
        .shadow(4.dp, RoundedCornerShape(14.dp))
        .clip(RoundedCornerShape(14.dp))
        .background(getAppColor(app.iconResName))
    ) {
      Icon(
        imageVector = getAppIcon(app.iconResName),
        contentDescription = app.name,
        tint = Color.White,
        modifier = Modifier.size(26.dp)
      )
    }

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      text = app.name,
      fontSize = 11.sp,
      fontWeight = FontWeight.Medium,
      color = Color(0xFFF1F5F9),
      textAlign = TextAlign.Center,
      maxLines = 2,
      overflow = TextOverflow.Ellipsis
    )
  }
}

@Composable
private fun GuestAppContainer(
  app: GuestApp,
  hardwareProfile: VmHardwareProfile,
  storeCatalog: List<GuestApp>,
  installedApps: List<GuestApp>,
  onInstallStoreApp: (GuestApp) -> Unit,
  onLaunchApp: (GuestApp) -> Unit,
  onOpenApkPicker: () -> Unit,
  onExecuteCommand: (String) -> String
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0B132B))
  ) {
    // App Top Action Bar
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier
        .fillMaxWidth()
        .height(44.dp)
        .background(Color(0xFF1E293B))
        .padding(horizontal = 12.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = getAppIcon(app.iconResName),
          contentDescription = null,
          tint = Color(0xFF38BDF8),
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = app.name,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White
        )
      }

      Surface(
        color = Color(0xFF334155),
        shape = RoundedCornerShape(6.dp)
      ) {
        Text(
          text = app.packageName,
          fontSize = 9.sp,
          color = Color(0xFF94A3B8),
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
      }
    }

    // App Interactive Body
    Box(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
    ) {
      when (app.packageName) {
        "com.android.settings" -> GuestSettingsApp(hardwareProfile)
        "com.android.chrome" -> GuestBrowserApp()
        "com.android.terminal" -> GuestTerminalApp(onExecuteCommand)
        "com.android.documentsui" -> GuestFilesApp()
        "com.android.vending" -> GuestStoreApp(
          catalog = storeCatalog,
          installedApps = installedApps,
          onInstall = onInstallStoreApp,
          onOpenApkPicker = onOpenApkPicker,
          onLaunch = onLaunchApp
        )
        "com.game.retro2048" -> GuestRetro2048Game()
        "com.game.flappydroid" -> GuestFlappyDroidGame()
        "com.game.tictactoe" -> GuestTicTacToeGame()
        "com.tools.calculator" -> GuestCalculatorApp()
        "com.cyber.sandbox.toolkit" -> GuestCyberToolkitApp()
        "com.topjohnwu.magisk" -> GuestMagiskRootApp()
        else -> GuestGenericApkApp(app)
      }
    }
  }
}

// ----------------------------------------------------
// 1. PLAYABLE RETRO 2048 GAME
// ----------------------------------------------------
@Composable
fun GuestRetro2048Game() {
  var board by remember { mutableStateOf(init2048Board()) }
  var score by remember { mutableStateOf(0) }
  var bestScore by remember { mutableStateOf(1024) }
  var gameOver by remember { mutableStateOf(false) }

  fun move(dx: Int, dy: Int) {
    if (gameOver) return
    val result = slideBoard(board, dx, dy)
    if (result.moved) {
      board = addRandomTile(result.newBoard)
      score += result.gainedScore
      if (score > bestScore) bestScore = score
      if (checkGameOver(board)) gameOver = true
    }
  }

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .padding(16.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text("2048 RETRO", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFF59E0B))
        Text("حرك المربعات لدمج الأرقام المتطابقة", fontSize = 11.sp, color = Color(0xFF94A3B8))
      }

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(8.dp)) {
          Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("النقاط", fontSize = 9.sp, color = Color(0xFF94A3B8))
            Text("$score", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
          }
        }
        Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(8.dp)) {
          Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("الأعلى", fontSize = 9.sp, color = Color(0xFF94A3B8))
            Text("$bestScore", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // 4x4 Game Grid
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .size(280.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(Color(0xFF1E293B))
        .padding(8.dp)
        .pointerInput(Unit) {
          detectDragGestures { _, dragAmount ->
            if (abs(dragAmount.x) > abs(dragAmount.y)) {
              if (dragAmount.x > 20) move(1, 0) // Right
              else if (dragAmount.x < -20) move(-1, 0) // Left
            } else {
              if (dragAmount.y > 20) move(0, 1) // Down
              else if (dragAmount.y < -20) move(0, -1) // Up
            }
          }
        }
    ) {
      Column(
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        for (r in 0..3) {
          Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.weight(1f).fillMaxWidth()
          ) {
            for (c in 0..3) {
              val value = board[r][c]
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                  .weight(1f)
                  .fillMaxHeight()
                  .clip(RoundedCornerShape(8.dp))
                  .background(get2048TileColor(value))
              ) {
                if (value > 0) {
                  Text(
                    text = "$value",
                    fontSize = if (value >= 1024) 14.sp else if (value >= 128) 16.sp else 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (value <= 4) Color(0xFF1E293B) else Color.White
                  )
                }
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Directional D-Pad Controls for precision
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      IconButton(
        onClick = { move(0, -1) },
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
        modifier = Modifier.size(38.dp)
      ) {
        Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Up", tint = Color.White)
      }
      Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
        IconButton(
          onClick = { move(-1, 0) },
          colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
          modifier = Modifier.size(38.dp)
        ) {
          Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Left", tint = Color.White)
        }
        IconButton(
          onClick = {
            board = init2048Board()
            score = 0
            gameOver = false
          },
          colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF0284C7)),
          modifier = Modifier.size(38.dp)
        ) {
          Icon(Icons.Default.Refresh, contentDescription = "Restart", tint = Color.White)
        }
        IconButton(
          onClick = { move(1, 0) },
          colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
          modifier = Modifier.size(38.dp)
        ) {
          Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Right", tint = Color.White)
        }
      }
      IconButton(
        onClick = { move(0, 1) },
        colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFF334155)),
        modifier = Modifier.size(38.dp)
      ) {
        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Down", tint = Color.White)
      }
    }
  }
}

// ----------------------------------------------------
// 2. PLAYABLE FLAPPY DROID ARCADE GAME
// ----------------------------------------------------
@Composable
fun GuestFlappyDroidGame() {
  var birdY by remember { mutableFloatStateOf(200f) }
  var velocity by remember { mutableFloatStateOf(0f) }
  var score by remember { mutableIntStateOf(0) }
  var isPlaying by remember { mutableStateOf(false) }
  var pipes by remember { mutableStateOf(listOf(350f to 180f, 550f to 240f)) }

  // Game loop tick
  LaunchedEffect(isPlaying) {
    while (isPlaying) {
      delay(20)
      velocity += 0.65f // Gravity
      birdY = (birdY + velocity).coerceIn(20f, 380f)

      // Move pipes
      pipes = pipes.map { (x, gapY) ->
        val newX = x - 3.5f
        if (newX < -60f) {
          score++
          400f to Random.nextInt(120, 260).toFloat()
        } else {
          newX to gapY
        }
      }

      // Check floor/ceiling collision
      if (birdY >= 370f || birdY <= 25f) {
        isPlaying = false
      }

      // Check pipe collision
      for ((px, py) in pipes) {
        if (px in 60f..140f) {
          if (birdY < py - 55f || birdY > py + 55f) {
            isPlaying = false
          }
        }
      }
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .pointerInput(Unit) {
        detectTapGestures {
          if (!isPlaying) {
            birdY = 200f
            velocity = -7f
            score = 0
            pipes = listOf(350f to 180f, 550f to 240f)
            isPlaying = true
          } else {
            velocity = -7.5f // Flap
          }
        }
      }
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      // Background Sky
      drawRect(Color(0xFF0284C7))

      // Pipes
      for ((px, py) in pipes) {
        // Top pipe
        drawRect(
          color = Color(0xFF22C55E),
          topLeft = Offset(px, 0f),
          size = Size(50f, py - 55f)
        )
        // Bottom pipe
        drawRect(
          color = Color(0xFF22C55E),
          topLeft = Offset(px, py + 55f),
          size = Size(50f, size.height - (py + 55f))
        )
      }

      // Bird (Android Droid)
      drawCircle(
        color = Color(0xFFA3E635),
        radius = 16f,
        center = Offset(100f, birdY)
      )
      drawCircle(
        color = Color.White,
        radius = 4f,
        center = Offset(106f, birdY - 4f)
      )

      // Floor Ground
      drawRect(
        color = Color(0xFFD97706),
        topLeft = Offset(0f, size.height - 40f),
        size = Size(size.width, 40f)
      )
    }

    // HUD
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        text = "FLAPPY DROID",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White
      )
      Surface(
        color = Color(0xFF0F172A).copy(alpha = 0.8f),
        shape = RoundedCornerShape(8.dp)
      ) {
        Text(
          text = "النقاط: $score",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFFFBBF24),
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
      }
    }

    if (!isPlaying) {
      Surface(
        color = Color(0xFF0F172A).copy(alpha = 0.9f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
          .align(Alignment.Center)
          .padding(24.dp)
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.padding(20.dp)
        ) {
          Icon(Icons.Default.SportsEsports, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(48.dp))
          Spacer(modifier = Modifier.height(10.dp))
          Text(text = if (score > 0) "انتهت اللعبة! مجموعك: $score" else "المس الشاشة للبدء والقفز", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
          Spacer(modifier = Modifier.height(12.dp))
          Button(
            onClick = {
              birdY = 200f
              velocity = -7f
              score = 0
              pipes = listOf(350f to 180f, 550f to 240f)
              isPlaying = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
          ) {
            Text("ابدأ اللعب الآن")
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// 3. PLAYABLE TIC-TAC-TOE AI GAME
// ----------------------------------------------------
@Composable
fun GuestTicTacToeGame() {
  var board by remember { mutableStateOf(List(9) { "" }) }
  var isXTurn by remember { mutableStateOf(true) }
  var winner by remember { mutableStateOf<String?>(null) }
  var scoreX by remember { mutableIntStateOf(0) }
  var scoreO by remember { mutableIntStateOf(0) }

  fun checkWin(b: List<String>): String? {
    val lines = listOf(
      listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
      listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
      listOf(0, 4, 8), listOf(2, 4, 6)
    )
    for (line in lines) {
      if (b[line[0]].isNotEmpty() && b[line[0]] == b[line[1]] && b[line[1]] == b[line[2]]) {
        return b[line[0]]
      }
    }
    return if (b.all { it.isNotEmpty() }) "Draw" else null
  }

  fun aiMove(currentBoard: List<String>) {
    val emptyIndices = currentBoard.indices.filter { currentBoard[it].isEmpty() }
    if (emptyIndices.isNotEmpty()) {
      val pick = emptyIndices.random()
      val newB = currentBoard.toMutableList()
      newB[pick] = "O"
      board = newB
      isXTurn = true
      val w = checkWin(newB)
      if (w != null) {
        winner = w
        if (w == "O") scoreO++
      }
    }
  }

  fun onCellClick(index: Int) {
    if (board[index].isEmpty() && winner == null && isXTurn) {
      val newB = board.toMutableList()
      newB[index] = "X"
      board = newB
      isXTurn = false
      val w = checkWin(newB)
      if (w != null) {
        winner = w
        if (w == "X") scoreX++
      } else {
        // Trigger AI Turn
        aiMove(newB)
      }
    }
  }

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .padding(16.dp)
  ) {
    Text("لعبة X-O ضد الذكاء الاصطناعي", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
    Spacer(modifier = Modifier.height(10.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
      Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(8.dp)) {
        Text("أنت (X): $scoreX", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8), modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
      }
      Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(8.dp)) {
        Text("الذكاء الاصطناعي (O): $scoreO", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444), modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // 3x3 Grid
    Box(
      modifier = Modifier
        .size(260.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(Color(0xFF1E293B))
        .padding(8.dp)
    ) {
      Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxSize()) {
        for (r in 0..2) {
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f).fillMaxWidth()) {
            for (c in 0..2) {
              val idx = r * 3 + c
              val mark = board[idx]
              Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                  .weight(1f)
                  .fillMaxHeight()
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0xFF0F172A))
                  .clickable { onCellClick(idx) }
              ) {
                Text(
                  text = mark,
                  fontSize = 32.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = if (mark == "X") Color(0xFF38BDF8) else Color(0xFFEF4444)
                )
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    if (winner != null) {
      Text(
        text = if (winner == "Draw") "تعادل!" else "الفائز: $winner",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF22C55E)
      )
      Spacer(modifier = Modifier.height(8.dp))
    }

    Button(
      onClick = {
        board = List(9) { "" }
        winner = null
        isXTurn = true
      },
      colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
    ) {
      Text("جولة جديدة")
    }
  }
}

// ----------------------------------------------------
// 4. SCIENTIFIC CALCULATOR APP
// ----------------------------------------------------
@Composable
fun GuestCalculatorApp() {
  var display by remember { mutableStateOf("0") }
  var history by remember { mutableStateOf("") }

  fun onBtnClick(btn: String) {
    when (btn) {
      "C" -> {
        display = "0"
        history = ""
      }
      "DEL" -> {
        display = if (display.length > 1) display.dropLast(1) else "0"
      }
      "=" -> {
        try {
          history = display
          val res = evaluateSimpleMath(display)
          display = res
        } catch (e: Exception) {
          display = "Error"
        }
      }
      "sqrt" -> {
        val num = display.toDoubleOrNull() ?: 0.0
        display = sqrt(num).toString()
      }
      "sin" -> {
        val num = display.toDoubleOrNull() ?: 0.0
        display = sin(Math.toRadians(num)).format(3)
      }
      "cos" -> {
        val num = display.toDoubleOrNull() ?: 0.0
        display = cos(Math.toRadians(num)).format(3)
      }
      else -> {
        if (display == "0" || display == "Error") display = btn else display += btn
      }
    }
  }

  val buttons = listOf(
    listOf("C", "DEL", "sqrt", "/"),
    listOf("sin", "cos", "(", ")"),
    listOf("7", "8", "9", "*"),
    listOf("4", "5", "6", "-"),
    listOf("1", "2", "3", "+"),
    listOf("0", ".", "%", "=")
  )

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .padding(14.dp)
  ) {
    // Screen display
    Surface(
      color = Color(0xFF020617),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(100.dp)
        .padding(bottom = 10.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(12.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.Center
      ) {
        Text(text = history, fontSize = 12.sp, color = Color(0xFF64748B))
        Text(text = display, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
      }
    }

    // Buttons
    Column(
      verticalArrangement = Arrangement.spacedBy(6.dp),
      modifier = Modifier.weight(1f)
    ) {
      buttons.forEach { row ->
        Row(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
          row.forEach { b ->
            val isOp = b in listOf("/", "*", "-", "+", "=", "sqrt", "sin", "cos")
            val isDanger = b in listOf("C", "DEL")
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(8.dp))
                .background(
                  if (b == "=") Color(0xFF0284C7)
                  else if (isDanger) Color(0xFF7F1D1D)
                  else if (isOp) Color(0xFF1E293B)
                  else Color(0xFF334155)
                )
                .clickable { onBtnClick(b) }
            ) {
              Text(
                text = b,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// 5. CYBER TOOLKIT & MEMORY SANDBOX
// ----------------------------------------------------
@Composable
fun GuestCyberToolkitApp() {
  var inputText by remember { mutableStateOf("Android Micro-VM Virtualized Payload") }
  var hashResult by remember { mutableStateOf("") }
  var base64Result by remember { mutableStateOf("") }

  LaunchedEffect(inputText) {
    try {
      val md = MessageDigest.getInstance("SHA-256")
      val digest = md.digest(inputText.toByteArray())
      hashResult = digest.joinToString("") { "%02x".format(it) }
      base64Result = android.util.Base64.encodeToString(inputText.toByteArray(), android.util.Base64.NO_WRAP)
    } catch (e: Exception) {
      hashResult = "Error"
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .verticalScroll(rememberScrollState())
      .padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Text("حقيبة أدوات التشفير والذاكرة المعزولة", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
    Text("تحليل مباشر للبيانات والعمليات داخل نظام الملفات المعزول", fontSize = 11.sp, color = Color(0xFF94A3B8))

    OutlinedTextField(
      value = inputText,
      onValueChange = { inputText = it },
      label = { Text("النص المراد تشفيره") },
      modifier = Modifier.fillMaxWidth(),
      colors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White,
        unfocusedTextColor = Color(0xFFE2E8F0)
      )
    )

    Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
      Column(modifier = Modifier.padding(10.dp)) {
        Text("تجزئة SHA-256 (RootFS Digest):", fontSize = 11.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
        Text(hashResult, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF22C55E))
      }
    }

    Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
      Column(modifier = Modifier.padding(10.dp)) {
        Text("ترميز Base64 Payload:", fontSize = 11.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
        Text(base64Result, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFCBD5E1))
      }
    }
  }
}

// ----------------------------------------------------
// 6. MAGISK ROOT SUITE
// ----------------------------------------------------
@Composable
fun GuestMagiskRootApp() {
  var isRootGranted by remember { mutableStateOf(true) }
  var selinuxPermissive by remember { mutableStateOf(true) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color(0xFF22C55E), modifier = Modifier.size(32.dp))
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text("Magisk VM Root Manager", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("إصدار v27.0 (27000) • تم منح الجذر لكافة العمليات", fontSize = 11.sp, color = Color(0xFF22C55E))
      }
    }

    Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("صلاحية الـ Superuser المباشرة", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
          Text("السماح لـ su بالعمل لجميع التطبيقات", fontSize = 10.sp, color = Color(0xFF94A3B8))
        }
        Switch(checked = isRootGranted, onCheckedChange = { isRootGranted = it })
      }
    }

    Surface(color = Color(0xFF1E293B), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("وضع SELinux Permissive", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
          Text("تعطيل قيود الأمان المشددة داخل الحاوية", fontSize = 10.sp, color = Color(0xFF94A3B8))
        }
        Switch(checked = selinuxPermissive, onCheckedChange = { selinuxPermissive = it })
      }
    }
  }
}

// ----------------------------------------------------
// 7. APP & GAME STORE
// ----------------------------------------------------
@Composable
fun GuestStoreApp(
  catalog: List<GuestApp>,
  installedApps: List<GuestApp>,
  onInstall: (GuestApp) -> Unit,
  onOpenApkPicker: () -> Unit,
  onLaunch: (GuestApp) -> Unit
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val installedPackageNames = remember(installedApps) { installedApps.map { it.packageName } }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .padding(14.dp)
  ) {
    // Store Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Store, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text("متجر التطبيقات والألعاب", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
      }

      Button(
        onClick = onOpenApkPicker,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
        modifier = Modifier.height(32.dp)
      ) {
        Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("تثبيت APK خارجي", fontSize = 10.sp)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Categories Tab Row
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = Color(0xFF1E293B),
      contentColor = Color(0xFF38BDF8)
    ) {
      Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
        Text("الكل", fontSize = 12.sp, modifier = Modifier.padding(8.dp), color = if (selectedTab == 0) Color(0xFF38BDF8) else Color(0xFF94A3B8))
      }
      Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
        Text("الألعاب", fontSize = 12.sp, modifier = Modifier.padding(8.dp), color = if (selectedTab == 1) Color(0xFF38BDF8) else Color(0xFF94A3B8))
      }
      Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
        Text("الأدوات", fontSize = 12.sp, modifier = Modifier.padding(8.dp), color = if (selectedTab == 2) Color(0xFF38BDF8) else Color(0xFF94A3B8))
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    val filteredList = when (selectedTab) {
      1 -> catalog.filter { it.packageName.startsWith("com.game") }
      2 -> catalog.filter { !it.packageName.startsWith("com.game") }
      else -> catalog
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(filteredList, key = { it.id }) { app ->
        val isInstalled = installedPackageNames.contains(app.packageName)
        Surface(
          color = Color(0xFF1E293B),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
          ) {
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(getAppColor(app.iconResName))
            ) {
              Icon(getAppIcon(app.iconResName), contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = app.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
              Text(text = app.description, fontSize = 11.sp, color = Color(0xFF94A3B8), maxLines = 2)
              Text(text = "${app.apkSizeMb} MB • جاهز للتثبيت الفوري", fontSize = 9.sp, color = Color(0xFF38BDF8))
            }
            Spacer(modifier = Modifier.width(8.dp))
            if (isInstalled) {
              Button(
                onClick = { onLaunch(app) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.height(34.dp)
              ) {
                Text("فتح", fontSize = 11.sp, color = Color.White)
              }
            } else {
              Button(
                onClick = { onInstall(app) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.height(34.dp)
              ) {
                Text("تثبيت", fontSize = 11.sp, color = Color.White)
              }
            }
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// 8. GENERIC EXTERNAL APK RUNNER
// ----------------------------------------------------
@Composable
private fun GuestGenericApkApp(app: GuestApp) {
  var activeTab by remember { mutableIntStateOf(0) }
  var dynamicDataCounter by remember { mutableIntStateOf(1) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .padding(14.dp)
  ) {
    // App Header Card
    Surface(
      color = Color(0xFF1E293B),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(12.dp)
      ) {
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0284C7))
        ) {
          Icon(Icons.Default.Apps, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(text = app.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
          Text(text = app.packageName, fontSize = 11.sp, color = Color(0xFF38BDF8))
          Text(text = "الحجم: ${app.apkSizeMb} MB • تم التحميل في بيئة الـ RootFS", fontSize = 10.sp, color = Color(0xFF22C55E))
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Interactive App Sandbox Execution Area
    Surface(
      color = Color(0xFF090D16),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF22C55E), modifier = Modifier.size(48.dp))
        Spacer(modifier = Modifier.height(10.dp))
        Text("يعمل التطبيق بنجاح داخل الحاوية الافتراضية", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(
          text = "تم ربط التطبيق بمسار الذاكرة /data/data/${app.packageName}/ وقاعدة بيانات SharedPreferences الخاصة به بنجاح.",
          fontSize = 11.sp,
          color = Color(0xFF94A3B8),
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Surface(
          color = Color(0xFF1E293B),
          shape = RoundedCornerShape(8.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("البيانات النشطة: $dynamicDataCounter إدخال", fontSize = 12.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.width(12.dp))
            Button(
              onClick = { dynamicDataCounter++ },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
              modifier = Modifier.height(30.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text("إضافة حدث", fontSize = 10.sp)
            }
          }
        }
      }
    }
  }
}

// ----------------------------------------------------
// HELPER METHODS
// ----------------------------------------------------
private fun getAppIcon(iconName: String): ImageVector {
  return when (iconName) {
    "settings" -> Icons.Default.Settings
    "language" -> Icons.Default.Language
    "terminal" -> Icons.Default.Terminal
    "folder_open" -> Icons.Default.FolderOpen
    "store" -> Icons.Default.Store
    "games" -> Icons.Default.Games
    "sports_esports" -> Icons.Default.SportsEsports
    "grid_view" -> Icons.Default.GridView
    "calculate" -> Icons.Default.Calculate
    "security" -> Icons.Default.Security
    "admin_panel_settings" -> Icons.Default.AdminPanelSettings
    else -> Icons.Default.Android
  }
}

private fun getAppColor(iconName: String): Color {
  return when (iconName) {
    "settings" -> Color(0xFF475569)
    "language" -> Color(0xFF0284C7)
    "terminal" -> Color(0xFF0F172A)
    "folder_open" -> Color(0xFFD97706)
    "store" -> Color(0xFF059669)
    "games" -> Color(0xFFEA580C)
    "sports_esports" -> Color(0xFF7C3AED)
    "grid_view" -> Color(0xFF2563EB)
    "calculate" -> Color(0xFF0D9488)
    "security" -> Color(0xFFDC2626)
    "admin_panel_settings" -> Color(0xFF16A34A)
    else -> Color(0xFF0D9488)
  }
}

private fun init2048Board(): List<List<Int>> {
  val b = MutableList(4) { MutableList(4) { 0 } }
  val r1 = Random.nextInt(4); val c1 = Random.nextInt(4)
  var r2 = Random.nextInt(4); var c2 = Random.nextInt(4)
  while (r1 == r2 && c1 == c2) {
    r2 = Random.nextInt(4); c2 = Random.nextInt(4)
  }
  b[r1][c1] = 2
  b[r2][c2] = if (Random.nextFloat() > 0.8) 4 else 2
  return b
}

private fun addRandomTile(b: List<List<Int>>): List<List<Int>> {
  val empty = mutableListOf<Pair<Int, Int>>()
  for (r in 0..3) {
    for (c in 0..3) {
      if (b[r][c] == 0) empty.add(r to c)
    }
  }
  if (empty.isEmpty()) return b
  val (r, c) = empty.random()
  val res = b.map { it.toMutableList() }.toMutableList()
  res[r][c] = if (Random.nextFloat() > 0.8) 4 else 2
  return res
}

private data class SlideResult(val newBoard: List<List<Int>>, val gainedScore: Int, val moved: Boolean)

private fun slideBoard(board: List<List<Int>>, dx: Int, dy: Int): SlideResult {
  var gained = 0
  var moved = false
  val next = MutableList(4) { MutableList(4) { 0 } }

  if (dx != 0) {
    for (r in 0..3) {
      val row = board[r].filter { it != 0 }.let { if (dx > 0) it.reversed() else it }
      val merged = mutableListOf<Int>()
      var i = 0
      while (i < row.size) {
        if (i + 1 < row.size && row[i] == row[i + 1]) {
          val m = row[i] * 2
          merged.add(m)
          gained += m
          i += 2
        } else {
          merged.add(row[i])
          i++
        }
      }
      while (merged.size < 4) merged.add(0)
      val finalRow = if (dx > 0) merged.reversed() else merged
      for (c in 0..3) next[r][c] = finalRow[c]
      if (next[r] != board[r]) moved = true
    }
  } else if (dy != 0) {
    for (c in 0..3) {
      val col = (0..3).map { board[it][c] }.filter { it != 0 }.let { if (dy > 0) it.reversed() else it }
      val merged = mutableListOf<Int>()
      var i = 0
      while (i < col.size) {
        if (i + 1 < col.size && col[i] == col[i + 1]) {
          val m = col[i] * 2
          merged.add(m)
          gained += m
          i += 2
        } else {
          merged.add(col[i])
          i++
        }
      }
      while (merged.size < 4) merged.add(0)
      val finalCol = if (dy > 0) merged.reversed() else merged
      for (r in 0..3) {
        next[r][c] = finalCol[r]
        if (next[r][c] != board[r][c]) moved = true
      }
    }
  }

  return SlideResult(next, gained, moved)
}

private fun checkGameOver(b: List<List<Int>>): Boolean {
  for (r in 0..3) {
    for (c in 0..3) {
      if (b[r][c] == 0) return false
      if (r < 3 && b[r][c] == b[r + 1][c]) return false
      if (c < 3 && b[r][c] == b[r][c + 1]) return false
    }
  }
  return true
}

private fun get2048TileColor(value: Int): Color {
  return when (value) {
    0 -> Color(0xFF334155)
    2 -> Color(0xFFEEE4DA)
    4 -> Color(0xFFEDE0C8)
    8 -> Color(0xFFF2B179)
    16 -> Color(0xFFF59563)
    32 -> Color(0xFFF67C5F)
    64 -> Color(0xFFF65E3B)
    128 -> Color(0xFFEDCF72)
    256 -> Color(0xFFEDCC61)
    512 -> Color(0xFFEDC850)
    1024 -> Color(0xFFEDC53F)
    2048 -> Color(0xFFEDC22E)
    else -> Color(0xFF3C3A32)
  }
}

private fun evaluateSimpleMath(expr: String): String {
  var clean = expr.replace(" ", "")
  if (clean.contains("+")) {
    val parts = clean.split("+")
    return (parts[0].toDouble() + parts[1].toDouble()).format(2)
  } else if (clean.contains("-") && !clean.startsWith("-")) {
    val parts = clean.split("-")
    return (parts[0].toDouble() - parts[1].toDouble()).format(2)
  } else if (clean.contains("*")) {
    val parts = clean.split("*")
    return (parts[0].toDouble() * parts[1].toDouble()).format(2)
  } else if (clean.contains("/")) {
    val parts = clean.split("/")
    val divisor = parts[1].toDouble()
    if (divisor == 0.0) return "Error"
    return (parts[0].toDouble() / divisor).format(2)
  }
  return clean
}

private fun Double.format(digits: Int) = String.format(Locale.US, "%.${digits}f", this)

@Composable
private fun GuestFilesApp() {
  val files = listOf(
    "Download" to "3 ملفات",
    "Documents" to "1 ملف",
    "DCIM" to "12 صورة",
    "Pictures" to "8 صور",
    "Music" to "0 ملفات"
  )
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .padding(16.dp)
  ) {
    Text(
      text = "المساحة التخزينية الافتراضية (/storage/emulated/0)",
      fontSize = 14.sp,
      fontWeight = FontWeight.Bold,
      color = Color(0xFF38BDF8)
    )
    Spacer(modifier = Modifier.height(12.dp))
    files.forEach { (name, count) ->
      Surface(
        color = Color(0xFF1E293B),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(12.dp)
        ) {
          Icon(Icons.Default.Folder, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(text = name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(text = count, fontSize = 11.sp, color = Color(0xFF94A3B8))
          }
          Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFF64748B))
        }
      }
    }
  }
}

@Composable
private fun GuestSettingsApp(profile: VmHardwareProfile) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Text(
      text = "حول الهاتف الافتراضي (About Micro-VM)",
      fontSize = 16.sp,
      fontWeight = FontWeight.Bold,
      color = Color(0xFF38BDF8)
    )

    listOf(
      "إصدار الأندرويد" to profile.androidVersion,
      "مستوى الـ API" to "API ${profile.apiLevel}",
      "معمارية المعالج" to profile.architecture,
      "أنوية المعالج الافتراضية" to "${profile.cpuCores} Cores",
      "الذاكرة العشوائية (RAM)" to "${profile.ramMb} MB",
      "دقة الشاشة" to "${profile.resolutionWidth}x${profile.resolutionHeight} (${profile.densityDpi} dpi)",
      "حالة الـ Root" to if (profile.hasRoot) "مفعل (SuperSU / Magisk SU)" else "معطل",
      "تسريع الرسوميات GPU" to if (profile.hasGpuAcceleration) "مفعل (Virtual GLES 3.2)" else "معطل",
      "وضع SELinux" to profile.selinuxMode
    ).forEach { (key, value) ->
      Surface(
        color = Color(0xFF1E293B),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = key, fontSize = 13.sp, color = Color(0xFFCBD5E1), fontWeight = FontWeight.Medium)
          Text(text = value, fontSize = 13.sp, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun GuestBrowserApp() {
  var urlText by remember { mutableStateOf("https://www.android.com") }
  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0F172A))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(Color(0xFF1E293B))
        .padding(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        color = Color(0xFF0F172A),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.weight(1f)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF22C55E), modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = urlText, fontSize = 12.sp, color = Color(0xFFE2E8F0))
        }
      }
      IconButton(onClick = { /* Refresh */ }) {
        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
      }
    }

    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier
        .fillMaxSize()
        .padding(24.dp)
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(64.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "متصفح الويب الافتراضي المعزول", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(
          text = "يتم توجيه كافة حزم الشبكة عبر طبقة عزل الحاويات الافتراضية بأمان تام دون تسريب الهوية.",
          fontSize = 12.sp,
          color = Color(0xFF94A3B8),
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(top = 6.dp)
        )
      }
    }
  }
}

@Composable
private fun GuestTerminalApp(onExecuteCommand: (String) -> String) {
  var cmdInput by remember { mutableStateOf("") }
  var terminalOutput by remember { mutableStateOf("microvm-guest:/ # uname -a\nLinux microvm-guest 5.15.110-arm64 #1 SMP PREEMPT\nmicrovm-guest:/ # ") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF030712))
      .padding(8.dp)
  ) {
    Surface(
      color = Color(0xFF090D1A),
      shape = RoundedCornerShape(8.dp),
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(8.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Text(
          text = terminalOutput,
          fontSize = 12.sp,
          color = Color(0xFF22C55E),
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.fillMaxWidth()
    ) {
      Text(
        text = "root# ",
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFFEF4444),
        fontFamily = FontFamily.Monospace
      )
      OutlinedTextField(
        value = cmdInput,
        onValueChange = { cmdInput = it },
        placeholder = { Text("أدخل أمر لينكس (ls, df -h, getprop...)", fontSize = 11.sp, color = Color(0xFF64748B)) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = Color.White,
          unfocusedTextColor = Color(0xFFE2E8F0),
          focusedContainerColor = Color(0xFF0F172A),
          unfocusedContainerColor = Color(0xFF0F172A),
          focusedBorderColor = Color(0xFF38BDF8),
          unfocusedBorderColor = Color(0xFF334155)
        ),
        modifier = Modifier.weight(1f)
      )
      IconButton(
        onClick = {
          if (cmdInput.isNotBlank()) {
            val res = onExecuteCommand(cmdInput)
            terminalOutput += "$cmdInput\n$res\nmicrovm-guest:/ # "
            cmdInput = ""
          }
        }
      ) {
        Icon(Icons.Default.Send, contentDescription = "Run", tint = Color(0xFF38BDF8))
      }
    }
  }
}
