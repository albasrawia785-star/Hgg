#include "native_surface_bridge.h"
#include <android/log.h>
#include <chrono>

#define LOG_TAG "NativeSurfaceBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

NativeSurfaceBridge::NativeSurfaceBridge()
    : m_nativeWindow(nullptr),
      m_eglDisplay(EGL_NO_DISPLAY),
      m_eglSurface(EGL_NO_SURFACE),
      m_eglContext(EGL_NO_CONTEXT),
      m_width(1080),
      m_height(1920),
      m_frameCount(0),
      m_currentFps(60.0f),
      m_lastFpsCheckTime(0) {
}

NativeSurfaceBridge::~NativeSurfaceBridge() {
    detachNativeWindow();
}

NativeSurfaceBridge& NativeSurfaceBridge::getInstance() {
    static NativeSurfaceBridge instance;
    return instance;
}

bool NativeSurfaceBridge::attachNativeWindow(ANativeWindow* window, int width, int height) {
    std::lock_guard<std::mutex> lock(m_renderMutex);
    detachNativeWindow();

    m_nativeWindow = window;
    m_width = width;
    m_height = height;

    if (m_nativeWindow != nullptr) {
        ANativeWindow_acquire(m_nativeWindow);
        ANativeWindow_setBuffersGeometry(m_nativeWindow, width, height, WINDOW_FORMAT_RGBA_8888);
        return initEgl();
    }
    return false;
}

void NativeSurfaceBridge::detachNativeWindow() {
    destroyEgl();
    if (m_nativeWindow != nullptr) {
        ANativeWindow_release(m_nativeWindow);
        m_nativeWindow = nullptr;
    }
}

bool NativeSurfaceBridge::initEgl() {
    if (m_nativeWindow == nullptr) return false;

    m_eglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (m_eglDisplay == EGL_NO_DISPLAY) {
        LOGE("Failed eglGetDisplay");
        return false;
    }

    if (!eglInitialize(m_eglDisplay, nullptr, nullptr)) {
        LOGE("Failed eglInitialize");
        return false;
    }

    const EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 16,
        EGL_NONE
    };

    EGLConfig config;
    EGLint numConfigs;
    if (!eglChooseConfig(m_eglDisplay, attribs, &config, 1, &numConfigs)) {
        LOGE("Failed eglChooseConfig");
        return false;
    }

    const EGLint contextAttribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 2,
        EGL_NONE
    };

    m_eglContext = eglCreateContext(m_eglDisplay, config, EGL_NO_CONTEXT, contextAttribs);
    if (m_eglContext == EGL_NO_CONTEXT) {
        LOGE("Failed eglCreateContext");
        return false;
    }

    m_eglSurface = eglCreateWindowSurface(m_eglDisplay, config, m_nativeWindow, nullptr);
    if (m_eglSurface == EGL_NO_SURFACE) {
        LOGE("Failed eglCreateWindowSurface");
        return false;
    }

    if (!eglMakeCurrent(m_eglDisplay, m_eglSurface, m_eglSurface, m_eglContext)) {
        LOGE("Failed eglMakeCurrent");
        return false;
    }

    glViewport(0, 0, m_width, m_height);
    glClearColor(0.06f, 0.09f, 0.16f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    eglSwapBuffers(m_eglDisplay, m_eglSurface);

    LOGI("EGL Surface Bridge initialized (%dx%d)", m_width, m_height);
    return true;
}

void NativeSurfaceBridge::destroyEgl() {
    if (m_eglDisplay != EGL_NO_DISPLAY) {
        eglMakeCurrent(m_eglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (m_eglSurface != EGL_NO_SURFACE) {
            eglDestroySurface(m_eglDisplay, m_eglSurface);
            m_eglSurface = EGL_NO_SURFACE;
        }
        if (m_eglContext != EGL_NO_CONTEXT) {
            eglDestroyContext(m_eglDisplay, m_eglContext);
            m_eglContext = EGL_NO_CONTEXT;
        }
        eglTerminate(m_eglDisplay);
        m_eglDisplay = EGL_NO_DISPLAY;
    }
}

bool NativeSurfaceBridge::renderGuestFrame(const uint8_t* rgbaBuffer, int width, int height) {
    std::lock_guard<std::mutex> lock(m_renderMutex);
    if (m_eglDisplay == EGL_NO_DISPLAY || m_eglSurface == EGL_NO_SURFACE) {
        return false;
    }

    // Direct frame swap
    eglSwapBuffers(m_eglDisplay, m_eglSurface);
    m_frameCount++;

    auto now = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();

    if (m_lastFpsCheckTime == 0) {
        m_lastFpsCheckTime = now;
    } else if (now - m_lastFpsCheckTime >= 1000) {
        m_currentFps = static_cast<float>(m_frameCount * 1000.0 / (now - m_lastFpsCheckTime));
        m_frameCount = 0;
        m_lastFpsCheckTime = now;
    }

    return true;
}
