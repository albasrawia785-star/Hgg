#ifndef BINDER_INTERCEPTOR_H
#define BINDER_INTERCEPTOR_H

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>
#include <mutex>

enum class BinderTransactionType {
    TRANSACTION = 0,
    REPLY = 1,
    ACQUIRE = 2,
    RELEASE = 3,
    INCREFS = 4,
    DECREFS = 5
};

struct BinderVirtualPacket {
    uint32_t targetHandle;
    uint32_t code;
    uint32_t flags;
    int32_t senderPid;
    int32_t senderUid;
    std::vector<uint8_t> data;
};

class BinderVirtualizationDriver {
public:
    static BinderVirtualizationDriver& getInstance();

    bool initializeDriver(const std::string& virtualDevPath = "/dev/binder_virtual");
    bool registerGuestService(const std::string& serviceName, uint32_t handle);
    uint32_t resolveGuestService(const std::string& serviceName);

    // Intercepts and redirects binder ioctl calls
    int virtualIoctl(int cmd, void* arg);

    int getInterceptedCount() const { return m_interceptedCount; }

private:
    BinderVirtualizationDriver();
    ~BinderVirtualizationDriver();

    std::string m_driverPath;
    std::unordered_map<std::string, uint32_t> m_serviceRegistry;
    std::mutex m_driverMutex;
    int m_interceptedCount;
};

#endif // BINDER_INTERCEPTOR_H
