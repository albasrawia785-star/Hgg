#ifndef NATIVE_SURFACE_BRIDGE_H
#define NATIVE_SURFACE_BRIDGE_H

#include <jni.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <mutex>
#include <vector>

class NativeSurfaceBridge {
public:
    static NativeSurfaceBridge& getInstance();

    bool attachNativeWindow(ANativeWindow* window, int width, int height);
    void detachNativeWindow();

    // Renders a SurfaceFlinger frame from guest buffer onto the host EGL surface
    bool renderGuestFrame(const uint8_t* rgbaBuffer, int width, int height);

    int getRenderedFrameCount() const { return m_frameCount; }
    float getCurrentFps() const { return m_currentFps; }

private:
    NativeSurfaceBridge();
    ~NativeSurfaceBridge();

    bool initEgl();
    void destroyEgl();

    ANativeWindow* m_nativeWindow;
    EGLDisplay m_eglDisplay;
    EGLSurface m_eglSurface;
    EGLContext m_eglContext;
    int m_width;
    int m_height;
    int m_frameCount;
    float m_currentFps;
    int64_t m_lastFpsCheckTime;
    std::mutex m_renderMutex;
};

#endif // NATIVE_SURFACE_BRIDGE_H
