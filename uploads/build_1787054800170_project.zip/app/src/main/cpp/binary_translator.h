#ifndef BINARY_TRANSLATOR_H
#define BINARY_TRANSLATOR_H

#include <cstdint>
#include <cstddef>
#include <unordered_map>
#include <vector>
#include <string>

enum class TargetArch {
    ARM_V7 = 32,
    ARM_V8 = 64,
    X86 = 32,
    X86_64 = 64
};

struct TranslationBlock {
    uintptr_t guestPc;
    uintptr_t hostPc;
    size_t guestSize;
    size_t hostSize;
    uint32_t executionCount;
};

class DynamicBinaryTranslator {
public:
    static DynamicBinaryTranslator& getInstance();

    bool initialize(TargetArch guestArch, TargetArch hostArch);
    
    // Translates an ARM32 instruction block into ARM64 native JIT buffer
    uintptr_t translateBlock(uintptr_t guestAddress, const uint8_t* code, size_t length);

    size_t getCachedBlockCount() const { return m_translationCache.size(); }
    uint64_t getTotalTranslatedBytes() const { return m_totalTranslatedBytes; }

private:
    DynamicBinaryTranslator();
    ~DynamicBinaryTranslator();

    TargetArch m_guestArch;
    TargetArch m_hostArch;
    std::unordered_map<uintptr_t, TranslationBlock> m_translationCache;
    uint64_t m_totalTranslatedBytes;
};

#endif // BINARY_TRANSLATOR_H
