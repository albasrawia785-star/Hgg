#ifndef VIRTUAL_CORE_H
#define VIRTUAL_CORE_H

#include <jni.h>
#include <string>
#include <vector>
#include <memory>
#include <android/log.h>

#define LOG_TAG "NativeVirtualCore"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

enum class VmState {
    STOPPED = 0,
    BOOTING = 1,
    RUNNING = 2,
    PAUSED = 3,
    TERMINATED = 4
};

struct VmConfig {
    std::string rootfsPath;
    std::string systemImgPath;
    int ramSizeMb;
    int cpuCores;
    bool enableRoot;
    bool enableGpuAcceleration;
};

class VirtualCoreEngine {
public:
    static VirtualCoreEngine& getInstance();

    bool initialize(const VmConfig& config);
    bool bootGuestOs();
    bool pauseGuestOs();
    bool resumeGuestOs();
    bool shutdownGuestOs();

    VmState getState() const { return m_state; }
    int64_t getUptimeMs() const;
    double getCpuUsage() const;
    int64_t getAllocatedMemory() const;

    // Direct RootFS chroot & namespace emulation
    int executeGuestCommand(const std::string& command, std::string& output);

private:
    VirtualCoreEngine();
    ~VirtualCoreEngine();

    VmConfig m_config;
    VmState m_state;
    int64_t m_bootTimeMs;
    bool m_initialized;
};

#endif // VIRTUAL_CORE_H
