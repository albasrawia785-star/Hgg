#include "binder_interceptor.h"
#include <android/log.h>

#define LOG_TAG "BinderVirtualization"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

BinderVirtualizationDriver::BinderVirtualizationDriver()
    : m_driverPath("/dev/binder_virtual"), m_interceptedCount(0) {
}

BinderVirtualizationDriver::~BinderVirtualizationDriver() {
}

BinderVirtualizationDriver& BinderVirtualizationDriver::getInstance() {
    static BinderVirtualizationDriver instance;
    return instance;
}

bool BinderVirtualizationDriver::initializeDriver(const std::string& virtualDevPath) {
    std::lock_guard<std::mutex> lock(m_driverMutex);
    m_driverPath = virtualDevPath;
    m_interceptedCount = 0;
    
    // Register standard Android guest system services
    m_serviceRegistry["activity"] = 1001;
    m_serviceRegistry["package"] = 1002;
    m_serviceRegistry["window"] = 1003;
    m_serviceRegistry["input"] = 1004;
    m_serviceRegistry["power"] = 1005;
    m_serviceRegistry["display"] = 1006;
    m_serviceRegistry["audio"] = 1007;
    m_serviceRegistry["surfaceflinger"] = 1008;

    LOGI("Binder virtualization driver initialized at %s with %zu default guest services", 
         m_driverPath.c_str(), m_serviceRegistry.size());
    return true;
}

bool BinderVirtualizationDriver::registerGuestService(const std::string& serviceName, uint32_t handle) {
    std::lock_guard<std::mutex> lock(m_driverMutex);
    m_serviceRegistry[serviceName] = handle;
    LOGI("Registered guest Binder service '%s' -> handle #%u", serviceName.c_str(), handle);
    return true;
}

uint32_t BinderVirtualizationDriver::resolveGuestService(const std::string& serviceName) {
    std::lock_guard<std::mutex> lock(m_driverMutex);
    auto it = m_serviceRegistry.find(serviceName);
    if (it != m_serviceRegistry.end()) {
        return it->second;
    }
    return 0;
}

int BinderVirtualizationDriver::virtualIoctl(int cmd, void* arg) {
    std::lock_guard<std::mutex> lock(m_driverMutex);
    m_interceptedCount++;
    // Returns 0 (SUCCESS) for intercepted binder commands
    return 0;
}
