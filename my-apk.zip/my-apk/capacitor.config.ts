import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aqsath.app',
  appName: 'Aqsath App',
  webDir: '../dist',
  android: {
    path: '.'
  }
};

export default config;
