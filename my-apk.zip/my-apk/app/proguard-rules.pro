# Capacitor ProGuard Rules

# Keep Capacitor Core classes and bridge mechanisms
-keep class com.getcapacitor.** { *; }
-keep interface com.getcapacitor.** { *; }

# Keep Cordova plugins
-keep class org.apache.cordova.** { *; }
-keep interface org.apache.cordova.** { *; }

# Keep JavaScript Interface classes so JavaScript-to-Native bridge works
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Preserve line numbers and source files for readable crash logs in production
-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod

# Keep custom native plugins in com.aqsath.app package
-keep class com.aqsath.app.** { *; }

# Keep Android Support and Jetpack libraries
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

# Keep standard library models
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}
