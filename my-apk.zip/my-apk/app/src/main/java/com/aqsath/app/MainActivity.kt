package com.aqsath.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.ActivityCompat
import com.getcapacitor.BridgeActivity
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.OutputStream
import java.util.UUID

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Register our custom Aqsath native bridge plugin
        registerPlugin(AqsathNativeBridge::class.java)
    }
}

@CapacitorPlugin(name = "AqsathNativeBridge")
class AqsathNativeBridge : Plugin() {

    private val PRINTER_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") // SPP UUID for classic Bluetooth printers
    private var bluetoothSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null

    @PluginMethod
    fun triggerVibration(call: PluginCall) {
        val type = call.getString("type") ?: "success"
        val context = context
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (vibrator.hasVibrator()) {
            val pattern = if (type == "success") {
                longArrayOf(0, 100, 50, 100) // Double short vibe
            } else {
                longArrayOf(0, 500) // Long single vibe
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(pattern, -1)
            }
            call.resolve()
        } else {
            call.reject("Vibrator not available on this device")
        }
    }

    @PluginMethod
    fun checkWifiStatus(call: PluginCall) {
        val context = context
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wifiManager.connectionInfo
        
        val response = JSObject()
        response.put("ssid", info.ssid)
        response.put("rssi", info.rssi)
        response.put("linkSpeed", info.linkSpeed)
        
        val isEnabled = wifiManager.isWifiEnabled
        response.put("enabled", isEnabled)
        
        call.resolve(response)
    }

    @PluginMethod
    fun getHighPrecisionLocation(call: PluginCall) {
        val context = context
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            call.reject("Location permission ACCESS_FINE_LOCATION not granted")
            return
        }

        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = locationManager.getProviders(true)
        var bestLocation: Location? = null

        for (provider in providers) {
            val l = locationManager.getLastKnownLocation(provider) ?: continue
            if (bestLocation == null || l.accuracy < bestLocation.accuracy) {
                bestLocation = l
            }
        }

        if (bestLocation != null) {
            val response = JSObject()
            response.put("latitude", bestLocation.latitude)
            response.put("longitude", bestLocation.longitude)
            response.put("accuracy", bestLocation.accuracy)
            response.put("altitude", bestLocation.altitude)
            response.put("time", bestLocation.time)
            call.resolve(response)
        } else {
            call.reject("Could not retrieve a high-precision location lock. Ensure GPS is enabled.")
        }
    }

    @PluginMethod
    fun scanBluetoothPrinters(call: PluginCall) {
        val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) {
            call.reject("Bluetooth is not supported on this device")
            return
        }

        if (!bluetoothAdapter.isEnabled) {
            call.reject("Bluetooth is disabled. Please enable Bluetooth.")
            return
        }

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            call.reject("Bluetooth Connect permission not granted")
            return
        }

        val devicesArray = JSObject()
        val pairedDevices: Set<BluetoothDevice> = bluetoothAdapter.bondedDevices
        val devicesList = com.getcapacitor.JSArray()

        for (device in pairedDevices) {
            val devObj = JSObject()
            devObj.put("name", device.name ?: "Unknown Printer")
            devObj.put("address", device.address)
            devicesList.put(devObj)
        }

        devicesArray.put("printers", devicesList)
        call.resolve(devicesArray)
    }

    @PluginMethod
    fun printReceipt(call: PluginCall) {
        val printerAddress = call.getString("address")
        val content = call.getString("content")
        if (printerAddress == null || content == null) {
            call.reject("Missing printer address or content parameters")
            return
        }

        val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) {
            call.reject("Bluetooth is not available or not enabled")
            return
        }

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            call.reject("Bluetooth Connect permission not granted")
            return
        }

        try {
            val device = bluetoothAdapter.getRemoteDevice(printerAddress)
            bluetoothSocket = device.createRfcommSocketToServiceRecord(PRINTER_UUID)
            bluetoothSocket?.connect()
            outputStream = bluetoothSocket?.outputStream

            // Send raw formatted text bytes
            val formattedText = parseEscPosFormatting(content)
            outputStream?.write(formattedText)
            outputStream?.flush()

            // Close sockets safely
            outputStream?.close()
            bluetoothSocket?.close()
            bluetoothSocket = null
            outputStream = null

            call.resolve()
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                outputStream?.close()
                bluetoothSocket?.close()
            } catch (ex: Exception) { }
            bluetoothSocket = null
            outputStream = null
            call.reject("Printing failed: " + e.message)
        }
    }

    @PluginMethod
    fun checkNfcSupport(call: PluginCall) {
        val nfcAdapter = NfcAdapter.getDefaultAdapter(context)
        val response = JSObject()
        if (nfcAdapter == null) {
            response.put("supported", false)
            response.put("enabled", false)
        } else {
            response.put("supported", true)
            response.put("enabled", nfcAdapter.isEnabled)
        }
        call.resolve(response)
    }

    private fun parseEscPosFormatting(text: String): ByteArray {
        val ESC = 0x1B.toByte()
        val GS = 0x1D.toByte()
        val LF = 0x0A.toByte()

        val list = mutableListOf<Byte>()

        // Initialize printer
        list.add(ESC)
        list.add(0x40.toByte()) // '@' init printer

        // Enable Arabic character code page (standard CP1256 Windows-1256 for Arabic receipts)
        list.add(ESC)
        list.add(0x74.toByte()) // 't'
        list.add(22.toByte())   // Code page 22 (Arabic Windows-1256 in most ESC/POS thermal printers)

        val lines = text.split("\n")
        for (line in lines) {
            var formattedLine = line
            var isCenter = false
            var isBold = false

            if (formattedLine.startsWith("[C]")) {
                isCenter = true
                formattedLine = formattedLine.substring(3)
            }
            if (formattedLine.startsWith("[B]")) {
                isBold = true
                formattedLine = formattedLine.substring(3)
            }

            // Alignments
            list.add(ESC)
            list.add(0x61.toByte()) // 'a'
            if (isCenter) {
                list.add(1.toByte()) // Center
            } else {
                list.add(0.toByte()) // Left/Right
            }

            // Bold
            list.add(ESC)
            list.add(0x45.toByte()) // 'E'
            if (isBold) {
                list.add(1.toByte()) // Bold ON
            } else {
                list.add(0.toByte()) // Bold OFF
            }

            // Convert to bytes using windows-1256
            try {
                val bytes = formattedLine.toByteArray(charset("windows-1256"))
                for (b in bytes) {
                    list.add(b)
                }
            } catch (e: Exception) {
                val bytes = formattedLine.toByteArray()
                for (b in bytes) {
                    list.add(b)
                }
            }

            list.add(LF)
        }

        // Space and cut paper
        list.add(LF)
        list.add(LF)
        list.add(LF)
        
        list.add(GS)
        list.add(0x56.toByte()) // 'V'
        list.add(66.toByte())
        list.add(0.toByte())

        return list.toByteArray()
    }
}
