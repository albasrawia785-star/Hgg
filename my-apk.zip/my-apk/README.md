# مشروع أقساط - تطبيق الموبايل الأصلي (Android Native Project)

هذا المجلد يحتوي على مشروع **أقساط** المخصص لهواتف الأندرويد والمبني باستخدام **Capacitor** و **Kotlin**. يوفر التطبيق أداءً ممتازًا وتكاملاً كاملاً مع عتاد الأجهزة والخدمات الأصلية مثل الطابعات الحرارية اللاسلكية وقارئ الـ NFC وحساسات GPS عالية الدقة والاهتزاز اللمسي.

---

## 📂 هيكلية المشروع والميزات الأصلية المضافة

يحتوي هذا المجلد على مشروع Android Studio متكامل ومستقل ومنظم كالتالي:
- **`app/src/main/java/com/aqsath/app/MainActivity.kt`**: الجسر البرمجي الأصلي المطور بلغة **Kotlin** (`AqsathNativeBridge`) لتمكين صفحة الويب من الوصول إلى العتاد مباشرة.
- **`app/src/main/AndroidManifest.xml`**: تم ضبط كافة الصلاحيات الأمنية المطلوبة للوصول إلى طابعات البلوتوث، الكاميرا، حساسات GPS، قارئ الـ NFC، حالة شبكة الـ Wi-Fi، ووحدات التخزين.
- **`app/build.gradle`**: مجهز لتبديل وتشفير الكود عبر **ProGuard** في نسخة الإنتاج وتضمين مفاتيح التوقيع الرقمي ومكتبات الأندرويد الحديثة.
- **`app/proguard-rules.pro`**: قواعد أمان وحماية الكود وتقليل الحجم دون التأثير على أداء الجسر البرمجي أو WebView.
- **`app/src/main/res/values/colors.xml` و `values-night/colors.xml`**: دعم تلقائي كامل وثنائي للثيم الفاتح (Light Theme) والثيم الداكن (Dark Theme) متناسق مع إعدادات هاتف المستخدم.

---

## 🛠️ متطلبات التشغيل والتهيئة

لفتح وبناء المشروع، تأكد من تنصيب الأدوات التالية على حاسوبك:
1. **Android Studio** (نسخة Ladybug أو أحدث).
2. **Java JDK 17** (موصى به لـ Gradle الحديث).
3. **Node.js** و بيئة العمل الرئيسية الخاصة بمشروع الويب.

---

## 🚀 كيفية البناء والتشغيل (Build & Run)

اتبع الخطوات البسيطة التالية لنقل تعديلات واجهة الويب وبناء ملف الـ APK:

### 1. بناء واجهات الويب (React Web Build)
في المجلد الرئيسي للمشروع (خارج `my-apk`):
```bash
npm run build
```
هذا الأمر سينتج مجلد الإنتاج `dist/`.

### 2. مزامنة الملفات مع مشروع الأندرويد (Capacitor Sync)
لمزامنة ملفات الويب والإعدادات والجسر البرمجي مع مشروع الأندرويد:
```bash
npx cap sync
```

### 3. فتح المشروع في Android Studio
يمكنك فتح المجلد `my-apk` مباشرة في برنامج **Android Studio** كـ "Existing Android Studio Project"، أو يمكنك تشغيل الأمر التالي لفتحه تلقائياً:
```bash
npx cap open android
```

### 4. بناء نسخة التجربة (Debug APK)
داخل Android Studio، اضغط على **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
أو عبر السطر البرمجي من داخل مجلد `my-apk`:
```bash
./gradlew assembleDebug
```
ستجد ملف الـ APK الناتج في المسار:
`my-apk/app/build/outputs/apk/debug/app-debug.apk`

---

## 🔐 توقيع التطبيق للنشر (Release APK & AAB)

تم تجهيز الإعدادات مسبقاً داخل `app/build.gradle` لدعم التوقيع الرقمي التلقائي. لنشر التطبيق على متجر Google Play:
1. قم بتوليد مفتاح توقيع رقمي (Keystore) باسم `release-key.jks` وضعه داخل المجلد `my-apk/app/`.
2. افتح ملف `my-apk/app/build.gradle` وقم بإزالة التعليق (`//`) عن الأسطر الخاصة بـ `signingConfigs.release` وتحديث كلمات المرور وعنوان المفتاح:
   ```groovy
   storeFile file("release-key.jks")
   storePassword "كلمة_مرور_المخزن"
   keyAlias "عنوان_المفتاح"
   keyPassword "كلمة_مرور_المفتاح"
   ```
3. قم بتشغيل بناء نسخة النشر من السطر البرمجي:
   ```bash
   ./gradlew assembleRelease # لإنتاج APK
   ./gradlew bundleRelease   # لإنتاج AAB الخاص بمتجر جوجل بلاي
   ```

---

## 🔌 ميزات الجسر البرمجي الأصلي (AqsathNativeBridge)

إذا رغبت في استدعاء وظائف العتاد من أي مكان في كود React، يمكنك استيراد كائن `nativeBridge` من الكود البرمجي في المسار `src/utils/nativeBridge.ts`:

### 1. طباعة وصولات الأقساط والعقود (Thermal ESC/POS Printing)
يتم البحث والاتصال بطابعات البلوتوث اللاسلكية بنقرة واحدة وإرسال البيانات باللغة العربية (ترمز تلقائياً بـ CP1256):
```typescript
import { nativeBridge } from '../utils/nativeBridge';

// 1. فحص وجلب الطابعات المقترنة بالجهاز
const printers = await nativeBridge.getPairedPrinters();

// 2. إرسال أمر الطباعة الحرارية المنسق
const address = printers[0].address;
const receiptText = `
[C][B]مجموعة أقساط المالية
[C]تاريخ العملية: 2026-07-16
--------------------------------
العميل: محمد علي حسن
القسط المدفوع: 150,000 د.ع
المتبقي بذمته: 450,000 د.ع
--------------------------------
[C]شكرًا لالتزامكم بالتسديد.
`;
await nativeBridge.printReceipt(address, receiptText);
```

### 2. رصد المواقع لتوثيق توقيع العقود (High-Precision GPS Location)
لحماية حقوق المعرض وضمان مكان توقيع العقد، يقوم الحساس برصد إحداثيات GPS دقيقة وفورية:
```typescript
const location = await nativeBridge.getLocation();
console.log("إحداثيات العقد:", location.latitude, location.longitude);
```

### 3. الاهتزاز اللمسي الذكي (Haptic Vibrations)
إعطاء المستخدم تغذية راجعة لمسية عند نجاح أو فشل العمليات المالية:
```typescript
await nativeBridge.vibrate('success'); // اهتزاز ثنائي سريع ومريح لبث الطمأنينة
await nativeBridge.vibrate('error');   // اهتزاز طويل للتنبيه بوجود خطأ أو رفض عملية
```

### 4. كشف وحساس كروت الزبائن (NFC Reader Support)
التحقق من جاهزية مستشعر NFC لقراءة الكروت الذكية للزبائن:
```typescript
const nfc = await nativeBridge.checkNfc();
if (nfc.supported && nfc.enabled) {
    // المستشعر جاهز لاستلام الكروت الذكية
}
```

---

## 🛠️ حل المشاكل الشائعة (Troubleshooting)

* **مشكلة: فشل الـ Sync أو عدم ظهور التعديلات الجديدة في الهاتف**
  * **الحل**: تأكد دائمًا من تشغيل `npm run build` أولاً لإنتاج الملفات المحدثة، ثم نفذ `npx cap sync` لنقلها إلى الأندرويد.
* **مشكلة: خطأ "SDK Location not found" أثناء البناء البرمجي**
  * **الحل**: افتح برنامج Android Studio، وسيقوم تلقائياً بإنشاء ملف `local.properties` وتحديد مسار الـ Android SDK على حاسوبك.
* **مشكلة: تعليق أو عدم استجابة WebView للطباعة في المتصفح العادي**
  * **الحل**: الجسر البرمجي ذكي ومجهز بسلوك احتياطي (Browser Fallback)؛ فعند تشغيله على المتصفح العادي سيقوم بمحاكاة طباعة الوصل بعرضه في لوحة المطورين (Console Logs) وإعلام المستخدم بنجاح العملية تجريبياً بدلاً من إيقاف أو تعطيل التطبيق.
