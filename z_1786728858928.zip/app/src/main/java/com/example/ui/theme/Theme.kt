package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = NeonGreen,
    onPrimary = SlateBg,
    secondary = CalmBlue,
    onSecondary = Color.White,
    tertiary = WarmOrange,
    onTertiary = Color.White,
    background = SlateBg,
    onBackground = Color.White,
    surface = SlateSurface,
    onSurface = Color.White,
    surfaceVariant = SlateSurface,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = SlateBorder,
    error = ElegantRed,
    onError = Color.White
  )

private val LightColorScheme = DarkColorScheme // Force dark slate mode everywhere as requested

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to true
  dynamicColor: Boolean = false, // Disable dynamic color to enforce our beautiful custom palette
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
