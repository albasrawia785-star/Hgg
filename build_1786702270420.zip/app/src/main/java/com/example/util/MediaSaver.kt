package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import java.io.File
import java.io.FileInputStream

object MediaSaver {
    private const val TAG = "MediaSaver"

    fun saveToGallery(context: Context, filePath: String, isVideo: Boolean, fileName: String? = null): Boolean {
        val success = try {
            val file = File(filePath)
            if (!file.exists()) {
                Log.e(TAG, "File does not exist: $filePath")
                false
            } else {
                val name = fileName ?: file.name
                val resolver = context.contentResolver

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val collection = if (isVideo) {
                        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    } else {
                        MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    }

                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, if (isVideo) "video/*" else "image/*")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, if (isVideo) Environment.DIRECTORY_MOVIES + "/Wasel" else Environment.DIRECTORY_PICTURES + "/Wasel")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }

                    val itemUri = resolver.insert(collection, contentValues)
                    if (itemUri != null) {
                        resolver.openOutputStream(itemUri)?.use { out ->
                            FileInputStream(file).use { input ->
                                input.copyTo(out, bufferSize = 64 * 1024)
                            }
                        }
                        contentValues.clear()
                        contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                        resolver.update(itemUri, contentValues, null, null)
                        true
                    } else {
                        false
                    }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(
                        if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
                    )
                    val waselDir = File(dir, "Wasel")
                    if (!waselDir.exists()) waselDir.mkdirs()
                    val destFile = File(waselDir, name)
                    file.copyTo(destFile, overwrite = true)

                    val intent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE).apply {
                        data = Uri.fromFile(destFile)
                    }
                    context.sendBroadcast(intent)
                    true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving media to gallery", e)
            false
        }

        if (success) {
            val typeText = if (isVideo) "الفيديو" else "الصورة"
            Toast.makeText(context, "تم حفظ $typeText بنجاح في المعرض 💾", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "تعذر حفظ الملف", Toast.LENGTH_SHORT).show()
        }
        return success
    }

    fun saveToDownloads(context: Context, filePath: String, fileName: String? = null): Boolean {
        val success = try {
            val file = File(filePath)
            if (!file.exists()) {
                Log.e(TAG, "File does not exist: $filePath")
                false
            } else {
                val name = fileName ?: file.name
                val resolver = context.contentResolver

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Wasel")
                        put(MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                    val itemUri = resolver.insert(collection, contentValues)
                    if (itemUri != null) {
                        resolver.openOutputStream(itemUri)?.use { out ->
                            FileInputStream(file).use { input ->
                                input.copyTo(out, bufferSize = 64 * 1024)
                            }
                        }
                        contentValues.clear()
                        contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                        resolver.update(itemUri, contentValues, null, null)
                        true
                    } else {
                        false
                    }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val waselDir = File(dir, "Wasel")
                    if (!waselDir.exists()) waselDir.mkdirs()
                    val destFile = File(waselDir, name)
                    file.copyTo(destFile, overwrite = true)
                    true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving file to downloads", e)
            false
        }

        if (success) {
            Toast.makeText(context, "تم حفظ الملف بنجاح في التنزيلات 📁", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "تعذر حفظ الملف", Toast.LENGTH_SHORT).show()
        }
        return success
    }
}
