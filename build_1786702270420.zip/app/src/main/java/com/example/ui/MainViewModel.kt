package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.WaselApplication
import com.example.data.local.NotificationSettingsManager
import com.example.data.network.CallState
import com.example.data.network.LanService
import com.example.data.repository.ChatRepository
import com.example.domain.model.ChatMessage
import com.example.domain.model.ConnectionState
import com.example.domain.model.DeviceDomain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val waselApp = application as WaselApplication
    val repository: ChatRepository = waselApp.chatRepository
    val notificationSettings: NotificationSettingsManager = waselApp.notificationSettings

    val discoveredDevices: StateFlow<List<DeviceDomain>> = repository.discoveredDevices
    val connectionState: StateFlow<ConnectionState> = repository.connectionState
    val isWifiConnected: StateFlow<Boolean> = repository.isWifiConnected
    val fileProgress: StateFlow<Map<Long, Float>> = repository.fileProgress

    val incomingConnectionRequest = repository.incomingConnectionRequest
    val outgoingConnectionRequest = repository.outgoingConnectionRequest
    val openChatEvents = repository.openChatEvents

    val callState: StateFlow<CallState> = waselApp.lanController.voiceCallManager.callState

    val notificationsEnabled: StateFlow<Boolean> = notificationSettings.notificationsEnabled
    val notificationSoundUri: StateFlow<String> = notificationSettings.soundUri
    val notificationSoundTitle: StateFlow<String> = notificationSettings.soundTitle
    val persistentBackgroundEnabled: StateFlow<Boolean> = notificationSettings.persistentBackgroundEnabled

    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog.asStateFlow()

    private val _activeChatDevice = MutableStateFlow<DeviceDomain?>(null)
    val activeChatDevice: StateFlow<DeviceDomain?> = _activeChatDevice.asStateFlow()

    private val _messageInput = MutableStateFlow("")
    val messageInput: StateFlow<String> = _messageInput.asStateFlow()

    private val _showAboutDialog = MutableStateFlow(false)
    val showAboutDialog: StateFlow<Boolean> = _showAboutDialog.asStateFlow()

    private val _showDeleteConfirmDialog = MutableStateFlow(false)
    val showDeleteConfirmDialog: StateFlow<Boolean> = _showDeleteConfirmDialog.asStateFlow()

    private val _toastEvents = MutableSharedFlow<String>()
    val toastEvents: SharedFlow<String> = _toastEvents.asSharedFlow()

    var isChatScreenOpen = false

    val activeChatMessages = _activeChatDevice.flatMapLatest { device ->
        if (device != null) {
            repository.getMessagesForDevice(device.address)
        } else {
            flowOf(emptyList())
        }
    }

    init {
        LanService.startService(application)

        // Observe open chat events when connection is accepted
        viewModelScope.launch {
            repository.openChatEvents.collect { device ->
                _activeChatDevice.value = device
            }
        }

        // Observe incoming LAN events
        viewModelScope.launch {
            repository.events.collect { eventMessage ->
                _toastEvents.emit(eventMessage)
            }
        }

        // Listen for incoming messages for in-app sound/vibration
        viewModelScope.launch {
            repository.incomingMessages.collect { message ->
                triggerMessageVibration()

                if (notificationSettings.isNotificationsEnabled()) {
                    val activeDevice = _activeChatDevice.value
                    val isCurrentChatOpenAndActive = isChatScreenOpen && (activeDevice?.address == message.senderAddress)

                    if (isCurrentChatOpenAndActive) {
                        playNotificationSound(notificationSettings.getSoundUriString())
                    }
                }
            }
        }
    }

    fun playNotificationSound(customSoundUri: String? = null) {
        try {
            val soundUriStr = customSoundUri ?: notificationSettings.getSoundUriString()
            if (soundUriStr.isNotEmpty()) {
                val uri = Uri.parse(soundUriStr)
                val ringtone = android.media.RingtoneManager.getRingtone(getApplication(), uri)
                ringtone?.play()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        notificationSettings.setNotificationsEnabled(enabled)
    }

    fun setPersistentBackgroundEnabled(enabled: Boolean) {
        notificationSettings.setPersistentBackgroundEnabled(enabled)
    }

    fun setNotificationSound(uriString: String, title: String) {
        notificationSettings.setSound(uriString, title)
    }

    fun setShowSettingsDialog(show: Boolean) {
        _showSettingsDialog.value = show
    }

    private fun triggerMessageVibration() {
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator.vibrate(
                    VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(200)
                }
            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "Vibration failed: ${e.message}")
        }
    }

    fun connectToDevice(device: DeviceDomain) {
        repository.requestConnection(device)
    }

    fun acceptConnectionRequest() {
        repository.acceptConnectionRequest()
    }

    fun rejectConnectionRequest() {
        repository.rejectConnectionRequest()
    }

    fun cancelOutgoingConnectionRequest() {
        repository.cancelOutgoingConnectionRequest()
    }

    fun selectChatDevice(device: DeviceDomain) {
        _activeChatDevice.value = device
    }

    fun disconnect() {
        repository.disconnect()
    }

    fun onMessageInputChange(text: String) {
        _messageInput.value = text
    }

    fun sendMessage() {
        val text = _messageInput.value.trim()
        val device = _activeChatDevice.value ?: return
        if (text.isEmpty()) return

        _messageInput.value = ""

        viewModelScope.launch {
            val success = repository.sendMessage(device.address, text)
            if (!success) {
                _toastEvents.emit("تعذر إرسال الرسالة، يرجى التأكد من الاتصال بالشاشة والجهاز")
            }
        }
    }

    fun resendMessage(message: ChatMessage) {
        val deviceAddress = message.receiverAddress.ifEmpty { _activeChatDevice.value?.address ?: "" }
        if (deviceAddress.isEmpty()) return

        viewModelScope.launch {
            val success = repository.resendMessage(deviceAddress, message)
            if (success) {
                _toastEvents.emit("تمت إعادة إرسال الرسالة بنجاح")
            } else {
                _toastEvents.emit("فشلت إعادة الإرسال، تحقق من اتصال الجهازيْن عبر Wi-Fi")
            }
        }
    }

    fun sendMediaFile(context: Context, uri: Uri, mediaType: String) {
        val device = _activeChatDevice.value ?: return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val contentResolver = context.contentResolver
                var fileName = when (mediaType) {
                    "IMAGE" -> "image_${System.currentTimeMillis()}.jpg"
                    "VIDEO" -> "video_${System.currentTimeMillis()}.mp4"
                    else -> "file_${System.currentTimeMillis()}"
                }
                var fileSize = 0L

                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: fileName
                        if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                    }
                }

                val localDir = File(context.filesDir, "wasel_sent_files")
                if (!localDir.exists()) localDir.mkdirs()
                val localFile = File(localDir, "${System.currentTimeMillis()}_$fileName")

                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(localFile).use { output ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    }
                }

                if (fileSize <= 0L && localFile.exists()) {
                    fileSize = localFile.length()
                }

                val success = repository.sendMediaMessage(
                    targetDeviceAddress = device.address,
                    type = mediaType,
                    file = localFile,
                    fileName = fileName,
                    fileSize = fileSize
                )

                if (!success) {
                    _toastEvents.emit("فشل إرسال الملف عبر الشبكة المحليّة")
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error sending media: ${e.message}")
                _toastEvents.emit("حدث خطأ أثناء معالجة الملف")
            }
        }
    }

    fun sendAudioMessage(context: Context, audioFile: File) {
        val device = _activeChatDevice.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fileName = "voice_${System.currentTimeMillis()}.m4a"
                val fileSize = audioFile.length()

                val success = repository.sendMediaMessage(
                    targetDeviceAddress = device.address,
                    type = "AUDIO",
                    file = audioFile,
                    fileName = fileName,
                    fileSize = fileSize
                )

                if (!success) {
                    _toastEvents.emit("فشل إرسال البصمة الصوتية عبر الشبكة المحليّة")
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error sending audio: ${e.message}")
                _toastEvents.emit("حدث خطأ أثناء إرسال التسجيل الصوتي")
            }
        }
    }

    fun deleteMessage(message: ChatMessage) {
        viewModelScope.launch {
            repository.deleteMessage(message)
            _toastEvents.emit("تم حذف الرسالة")
        }
    }

    fun deleteChatForDevice(deviceAddress: String) {
        viewModelScope.launch {
            repository.deleteMessagesForDevice(deviceAddress)
            if (_activeChatDevice.value?.address == deviceAddress) {
                _activeChatDevice.value = null
            }
            _toastEvents.emit("تم حذف المحادثة")
        }
    }

    fun setShowAboutDialog(show: Boolean) {
        _showAboutDialog.value = show
    }

    fun setShowDeleteConfirmDialog(show: Boolean) {
        _showDeleteConfirmDialog.value = show
    }

    fun deleteAllMessages() {
        viewModelScope.launch {
            repository.deleteAllMessages()
            _showDeleteConfirmDialog.value = false
            _toastEvents.emit("تم حذف جميع المحادثات بنجاح")
        }
    }

    // Voice Call Actions
    fun startVoiceCall(targetDevice: DeviceDomain) {
        waselApp.lanController.voiceCallManager.initiateCall(
            targetName = targetDevice.name,
            targetAddress = targetDevice.address
        )
    }

    fun acceptVoiceCall() {
        waselApp.lanController.voiceCallManager.acceptCall()
    }

    fun rejectVoiceCall() {
        waselApp.lanController.voiceCallManager.rejectCall()
    }

    fun endVoiceCall() {
        waselApp.lanController.voiceCallManager.endCall()
    }

    fun toggleCallMute() {
        waselApp.lanController.voiceCallManager.toggleMute()
    }

    fun toggleCallSpeaker() {
        waselApp.lanController.voiceCallManager.toggleSpeaker()
    }
}
