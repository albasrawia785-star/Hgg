package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.Wasl
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CodeModel(
    val codeId: String,
    val name: String,
    val maxDevices: Int,
    val expiryDate: String,
    val isActive: Boolean,
    val registeredDevices: Map<String, DeviceModel>
)

data class DeviceModel(
    val deviceId: String,
    val deviceName: String,
    val codeId: String,
    val lastSeen: Long
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var codesList by remember { mutableStateOf<List<CodeModel>>(emptyList()) }
    var globalDevices by remember { mutableStateOf<List<DeviceModel>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }

    // Dialog state
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedCodeForDevices by remember { mutableStateOf<CodeModel?>(null) }
    var editingCode by remember { mutableStateOf<CodeModel?>(null) }

    fun loadData() {
        isLoading = true
        coroutineScope.launch {
            val rawCodes = Wasl.fetchAllCodes()
            val rawGlobalDevices = Wasl.fetchAllDevices()

            val parsedCodes = mutableListOf<CodeModel>()
            for ((key, obj) in rawCodes) {
                val name = obj.optString("name", "كود تفعيل")
                val maxDevices = obj.optInt("maxDevices", 1)
                val expiryDate = obj.optString("expiryDate", "غير محدود")
                val isActive = obj.optBoolean("isActive", true)

                val devicesMap = mutableMapOf<String, DeviceModel>()
                val registeredObj = obj.optJSONObject("registeredDevices")
                if (registeredObj != null) {
                    val devKeys = registeredObj.keys()
                    while (devKeys.hasNext()) {
                        val dKey = devKeys.next()
                        val devObj = registeredObj.optJSONObject(dKey)
                        if (devObj != null) {
                            devicesMap[dKey] = DeviceModel(
                                deviceId = devObj.optString("deviceId", dKey),
                                deviceName = devObj.optString("deviceName", "جهاز مجهول"),
                                codeId = key,
                                lastSeen = devObj.optLong("lastSeen", 0L)
                            )
                        }
                    }
                }

                parsedCodes.add(
                    CodeModel(
                        codeId = key,
                        name = name,
                        maxDevices = maxDevices,
                        expiryDate = expiryDate,
                        isActive = isActive,
                        registeredDevices = devicesMap
                    )
                )
            }

            val parsedDevices = mutableListOf<DeviceModel>()
            for ((key, obj) in rawGlobalDevices) {
                parsedDevices.add(
                    DeviceModel(
                        deviceId = key,
                        deviceName = obj.optString("deviceName", "جهاز"),
                        codeId = obj.optString("codeId", ""),
                        lastSeen = obj.optLong("lastSeen", 0L)
                    )
                )
            }

            codesList = parsedCodes
            globalDevices = parsedDevices
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    val totalCodes = codesList.size
    val totalRegisteredDevices = codesList.sumOf { it.registeredDevices.size }
    val now = System.currentTimeMillis()
    val connectedDevices = globalDevices.count { (now - it.lastSeen) < 300000 } // active within 5 min

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "لوحة إدارة الأكواد - واصل",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                actions = {
                    IconButton(onClick = { loadData() }) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "تحديث")
                    }
                    IconButton(onClick = {
                        Wasl.clearSession(context)
                        onLogout()
                    }) {
                        Icon(imageVector = Icons.Default.Logout, contentDescription = "تسجيل خروج")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    editingCode = null
                    showAddDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("إنشاء كود جديد") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Stats Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "إجمالي الأكواد",
                    value = totalCodes.toString(),
                    icon = Icons.Default.Key,
                    color = MaterialTheme.colorScheme.primary
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "المستخدمين",
                    value = codesList.count { it.registeredDevices.isNotEmpty() }.toString(),
                    icon = Icons.Default.Group,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "الأجهزة المسجلة",
                    value = totalRegisteredDevices.toString(),
                    icon = Icons.Default.Devices,
                    color = MaterialTheme.colorScheme.tertiary
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    title = "الأجهزة المتصلة",
                    value = connectedDevices.toString(),
                    icon = Icons.Default.WifiTethering,
                    color = Color(0xFF2E7D32)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "قائمة الأكواد المتاحة ($totalCodes)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (codesList.isEmpty() && !isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد أكواد تفعيل حالياً. اضغط على 'إنشاء كود جديد' للبدء.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.outline,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(codesList, key = { it.codeId }) { code ->
                        CodeCardItem(
                            code = code,
                            onToggleActive = {
                                coroutineScope.launch {
                                    Wasl.createOrUpdateCode(
                                        code.codeId,
                                        code.name,
                                        code.maxDevices,
                                        code.expiryDate,
                                        !code.isActive
                                    )
                                    loadData()
                                }
                            },
                            onEdit = {
                                editingCode = code
                                showAddDialog = true
                            },
                            onDelete = {
                                coroutineScope.launch {
                                    Wasl.deleteCode(code.codeId)
                                    Toast.makeText(context, "تم حذف الكود بنجاح", Toast.LENGTH_SHORT).show()
                                    loadData()
                                }
                            },
                            onViewDevices = {
                                selectedCodeForDevices = code
                            }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Code Dialog
    if (showAddDialog) {
        AddEditCodeDialog(
            existingCode = editingCode,
            onDismiss = { showAddDialog = false },
            onConfirm = { codeVal, nameVal, maxDevs, expiryStr, isActive ->
                coroutineScope.launch {
                    val success = Wasl.createOrUpdateCode(
                        codeId = codeVal,
                        codeName = nameVal,
                        maxDevices = maxDevs,
                        expiryDate = expiryStr,
                        isActive = isActive
                    )
                    if (success) {
                        Toast.makeText(context, "تم حفظ البيانات بنجاح", Toast.LENGTH_SHORT).show()
                        showAddDialog = false
                        loadData()
                    } else {
                        Toast.makeText(context, "فشل في حفظ البيانات", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }

    // Devices List Dialog
    selectedCodeForDevices?.let { codeModel ->
        CodeDevicesDialog(
            codeModel = codeModel,
            onDismiss = { selectedCodeForDevices = null },
            onRevokeDevice = { deviceId ->
                coroutineScope.launch {
                    val ok = Wasl.revokeDevice(codeModel.codeId, deviceId)
                    if (ok) {
                        Toast.makeText(context, "تم إلغاء تسجيل الجهاز", Toast.LENGTH_SHORT).show()
                        selectedCodeForDevices = null
                        loadData()
                    }
                }
            }
        )
    }
}

@Composable
fun StatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.12f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
            }
        }
    }
}

@Composable
fun CodeCardItem(
    code: CodeModel,
    onToggleActive: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onViewDevices: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = code.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = if (code.isActive) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (code.isActive) "فعال" else "معطل",
                            color = if (code.isActive) Color(0xFF2E7D32) else Color(0xFFC62828),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                Row {
                    IconButton(onClick = onToggleActive, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (code.isActive) Icons.Default.Block else Icons.Default.CheckCircle,
                            contentDescription = "تعطيل/تفعيل",
                            tint = if (code.isActive) Color(0xFFC62828) else Color(0xFF2E7D32)
                        )
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "الكود: ${code.codeId}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الأجهزة: ${code.registeredDevices.size} / ${code.maxDevices}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "الانتهاء: ${code.expiryDate}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = onViewDevices,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("عرض الأجهزة (${code.registeredDevices.size})", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun AddEditCodeDialog(
    existingCode: CodeModel?,
    onDismiss: () -> Unit,
    onConfirm: (code: String, name: String, maxDevices: Int, expiryDate: String, isActive: Boolean) -> Unit
) {
    var codeValue by remember { mutableStateOf(existingCode?.codeId ?: "WASL-" + (1000..9999).random()) }
    var nameValue by remember { mutableStateOf(existingCode?.name ?: "كود جديد") }
    var maxDevicesStr by remember { mutableStateOf(existingCode?.maxDevices?.toString() ?: "5") }
    var expiryValue by remember { mutableStateOf(existingCode?.expiryDate ?: "2027-12-31") }
    var isActiveValue by remember { mutableStateOf(existingCode?.isActive ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existingCode == null) "إنشاء كود تفعيل جديد" else "تعديل كود التفعيل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = codeValue,
                    onValueChange = { codeValue = it },
                    label = { Text("رمز الكود (Code)") },
                    enabled = existingCode == null,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nameValue,
                    onValueChange = { nameValue = it },
                    label = { Text("اسم الكود / الوصف") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = maxDevicesStr,
                    onValueChange = { maxDevicesStr = it },
                    label = { Text("الحد الأقصى للأجهزة المسموح بها") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = expiryValue,
                    onValueChange = { expiryValue = it },
                    label = { Text("تاريخ الانتهاء (مثال: 2027-12-31)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("حالة الكود (فعال/معطل)")
                    Switch(checked = isActiveValue, onCheckedChange = { isActiveValue = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val maxDevs = maxDevicesStr.toIntOrNull() ?: 1
                    onConfirm(codeValue.trim(), nameValue.trim(), maxDevs, expiryValue.trim(), isActiveValue)
                }
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun CodeDevicesDialog(
    codeModel: CodeModel,
    onDismiss: () -> Unit,
    onRevokeDevice: (deviceId: String) -> Unit
) {
    val devicesList = codeModel.registeredDevices.values.toList()
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الأجهزة المرتبطة بالكود (${codeModel.name})") },
        text = {
            if (devicesList.isEmpty()) {
                Text("لا يوجد أجهزة مسجلة على هذا الكود حالياً.")
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(devicesList, key = { it.deviceId }) { dev ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = dev.deviceName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(text = "المعرف: ${dev.deviceId}", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    Text(text = "آخر ظهور: ${sdf.format(Date(dev.lastSeen))}", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                }
                                IconButton(onClick = { onRevokeDevice(dev.deviceId) }) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "إلغاء تسجيل الجهاز", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}
