package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.network.LanService
import com.example.domain.model.DeviceDomain
import com.example.ui.MainViewModel
import com.example.ui.components.AboutDialog
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.VoiceCallOverlay
import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.DevicesScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ActivationScreen
import com.example.ui.screens.AdminDashboardScreen
import com.example.Wasl
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

enum class Screen {
    ACTIVATION,
    ADMIN_DASHBOARD,
    ONBOARDING,
    DEVICES,
    CHAT
}

class MainActivity : ComponentActivity() {

    private var targetDeviceAddressFromNotification: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleNotificationIntent(intent)

        // Start background services when app is in foreground
        LanService.startService(this)

        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        WaselChatApp(targetAddress = targetDeviceAddressFromNotification)
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val app = application as? WaselApplication
        if (app?.notificationSettings?.isPersistentBackgroundEnabled() != false) {
            LanService.startService(this)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
    }

    private fun handleNotificationIntent(intent: Intent?) {
        val address = intent?.getStringExtra(LanService.EXTRA_DEVICE_ADDRESS)
        if (!address.isNullOrBlank()) {
            targetDeviceAddressFromNotification = address
        }
    }
}

@Composable
fun WaselChatApp(
    targetAddress: String? = null,
    viewModel: MainViewModel = viewModel()
) {
    val context = LocalContext.current

    val discoveredDevices by viewModel.discoveredDevices.collectAsStateWithLifecycle()
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val isWifiConnected by viewModel.isWifiConnected.collectAsStateWithLifecycle()
    val activeChatDevice by viewModel.activeChatDevice.collectAsStateWithLifecycle()
    val activeMessages by viewModel.activeChatMessages.collectAsStateWithLifecycle(initialValue = emptyList())
    val messageInput by viewModel.messageInput.collectAsStateWithLifecycle()
    val showAboutDialog by viewModel.showAboutDialog.collectAsStateWithLifecycle()
    val showDeleteConfirmDialog by viewModel.showDeleteConfirmDialog.collectAsStateWithLifecycle()
    val showSettingsDialog by viewModel.showSettingsDialog.collectAsStateWithLifecycle()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsStateWithLifecycle()
    val persistentBackgroundEnabled by viewModel.persistentBackgroundEnabled.collectAsStateWithLifecycle()
    val notificationSoundTitle by viewModel.notificationSoundTitle.collectAsStateWithLifecycle()
    val notificationSoundUri by viewModel.notificationSoundUri.collectAsStateWithLifecycle()
    val callState by viewModel.callState.collectAsStateWithLifecycle()

    val incomingConnectionRequest by viewModel.incomingConnectionRequest.collectAsStateWithLifecycle()
    val outgoingConnectionRequest by viewModel.outgoingConnectionRequest.collectAsStateWithLifecycle()

    val sharedPrefs = remember { context.getSharedPreferences("wasel_settings", Context.MODE_PRIVATE) }
    val isOnboardingCompleted = remember { sharedPrefs.getBoolean("onboarding_completed", false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val initialScreen = remember {
        if (!Wasl.isActivated(context)) {
            Screen.ACTIVATION
        } else if (Wasl.isAdmin(context)) {
            Screen.ADMIN_DASHBOARD
        } else if (isOnboardingCompleted) {
            Screen.DEVICES
        } else {
            Screen.ONBOARDING
        }
    }
    var currentScreen by remember { mutableStateOf(initialScreen) }

    // Heartbeat and real-time activation verification
    LaunchedEffect(Unit) {
        while (isActive) {
            val savedCode = Wasl.getSavedCode(context)
            if (Wasl.isActivated(context) && savedCode.isNotBlank()) {
                Wasl.updateDeviceHeartbeat(context, savedCode)
                if (!Wasl.isAdmin(context)) {
                    val isStillValid = Wasl.checkCurrentDeviceStatus(context, savedCode)
                    if (!isStillValid) {
                        Wasl.clearSession(context)
                        Toast.makeText(context, "تم إلغاء تفعيل حسابك أو إزالة جهازك من قبل المدير", Toast.LENGTH_LONG).show()
                        currentScreen = Screen.ACTIVATION
                    }
                }
            }
            delay(15000)
        }
    }

    LaunchedEffect(currentScreen) {
        viewModel.isChatScreenOpen = (currentScreen == Screen.CHAT)
    }

    LaunchedEffect(targetAddress, discoveredDevices) {
        if (!targetAddress.isNullOrBlank()) {
            val device = discoveredDevices.find { it.address == targetAddress }
                ?: DeviceDomain(name = "جهاز $targetAddress", address = targetAddress)
            viewModel.selectChatDevice(device)
            currentScreen = Screen.CHAT
        }
    }

    val permissionsToRequest = remember {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        list.toTypedArray()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (permissionsToRequest.isNotEmpty()) {
            val hasAll = permissionsToRequest.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
            if (!hasAll) {
                permissionLauncher.launch(permissionsToRequest)
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.toastEvents.collect { message ->
            snackbarHostState.showSnackbar(
                message = message,
                duration = SnackbarDuration.Short
            )
        }
    }

    LaunchedEffect(activeChatDevice) {
        if (activeChatDevice != null && currentScreen == Screen.DEVICES) {
            currentScreen = Screen.CHAT
        }
    }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = {
            fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
        },
        label = "ScreenTransition"
    ) { screen ->
        when (screen) {
            Screen.ACTIVATION -> {
                ActivationScreen(
                    onActivatedUser = {
                        currentScreen = if (isOnboardingCompleted) Screen.DEVICES else Screen.ONBOARDING
                    },
                    onActivatedAdmin = {
                        currentScreen = Screen.ADMIN_DASHBOARD
                    }
                )
            }

            Screen.ADMIN_DASHBOARD -> {
                AdminDashboardScreen(
                    onLogout = {
                        currentScreen = Screen.ACTIVATION
                    }
                )
            }

            Screen.ONBOARDING -> {
                OnboardingScreen(
                    onStartClick = {
                        sharedPrefs.edit().putBoolean("onboarding_completed", true).apply()
                        currentScreen = Screen.DEVICES
                    }
                )
            }

            Screen.DEVICES -> {
                DevicesScreen(
                    discoveredDevices = discoveredDevices,
                    connectionState = connectionState,
                    isWifiConnected = isWifiConnected,
                    snackbarHostState = snackbarHostState,
                    onConnectDevice = { device -> viewModel.connectToDevice(device) },
                    onSelectChat = { device ->
                        viewModel.selectChatDevice(device)
                        currentScreen = Screen.CHAT
                    },
                    onDeleteChatForDevice = { address -> viewModel.deleteChatForDevice(address) },
                    onShowSettings = { viewModel.setShowSettingsDialog(true) },
                    onShowAbout = { viewModel.setShowAboutDialog(true) }
                )
            }

            Screen.CHAT -> {
                val ctx = LocalContext.current
                activeChatDevice?.let { device ->
                    val liveDevice = discoveredDevices.find { it.address == device.address }
                        ?.let { discovered ->
                            discovered.copy(
                                name = if (device.name.isNotBlank() && !device.name.startsWith("جهاز 192")) device.name else discovered.name
                            )
                        } ?: device

                    val fileProgress by viewModel.fileProgress.collectAsStateWithLifecycle()

                    ChatScreen(
                        device = liveDevice,
                        connectionState = connectionState,
                        messages = activeMessages,
                        messageInput = messageInput,
                        snackbarHostState = snackbarHostState,
                        fileProgress = fileProgress,
                        onMessageInputChange = { text -> viewModel.onMessageInputChange(text) },
                        onSendMessage = { viewModel.sendMessage() },
                        onSendMedia = { uri, mediaType -> viewModel.sendMediaFile(ctx, uri, mediaType) },
                        onSendAudioMessage = { audioFile -> viewModel.sendAudioMessage(ctx, audioFile) },
                        onDeleteMessage = { message -> viewModel.deleteMessage(message) },
                        onDeleteConversation = { viewModel.deleteChatForDevice(liveDevice.address) },
                        onRetryMessage = { message -> viewModel.resendMessage(message) },
                        onStartCall = { viewModel.startVoiceCall(liveDevice) },
                        onBack = { currentScreen = Screen.DEVICES }
                    )
                } ?: run {
                    currentScreen = Screen.DEVICES
                }
            }
        }
    }

    VoiceCallOverlay(
        callState = callState,
        onAccept = { viewModel.acceptVoiceCall() },
        onReject = { viewModel.rejectVoiceCall() },
        onEnd = { viewModel.endVoiceCall() },
        onToggleMute = { viewModel.toggleCallMute() },
        onToggleSpeaker = { viewModel.toggleCallSpeaker() }
    )

    if (showSettingsDialog) {
        com.example.ui.components.SettingsDialog(
            notificationsEnabled = notificationsEnabled,
            persistentBackgroundEnabled = persistentBackgroundEnabled,
            soundTitle = notificationSoundTitle,
            soundUri = notificationSoundUri,
            onToggleNotifications = { viewModel.setNotificationsEnabled(it) },
            onTogglePersistentBackground = { viewModel.setPersistentBackgroundEnabled(it) },
            onSetSound = { uri, title -> viewModel.setNotificationSound(uri, title) },
            onTestSound = { viewModel.playNotificationSound() },
            onDismiss = { viewModel.setShowSettingsDialog(false) }
        )
    }

    if (showAboutDialog) {
        AboutDialog(
            onDismiss = { viewModel.setShowAboutDialog(false) }
        )
    }

    if (showDeleteConfirmDialog) {
        DeleteConfirmDialog(
            onConfirm = { viewModel.deleteAllMessages() },
            onDismiss = { viewModel.setShowDeleteConfirmDialog(false) }
        )
    }

    incomingConnectionRequest?.let { req ->
        com.example.ui.components.IncomingConnectionRequestDialog(
            request = req,
            onAccept = { viewModel.acceptConnectionRequest() },
            onReject = { viewModel.rejectConnectionRequest() }
        )
    }

    outgoingConnectionRequest?.let { dev ->
        com.example.ui.components.OutgoingConnectionRequestDialog(
            device = dev,
            onCancel = { viewModel.cancelOutgoingConnectionRequest() }
        )
    }
}
