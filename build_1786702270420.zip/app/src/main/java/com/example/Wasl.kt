package com.example

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Wasl Firebase Configuration & Activation System Helper
 */
object Wasl {
    // Firebase Web Configuration Credentials
    const val API_KEY = "AIzaSyDozxel6eMwf4_Y377VfNZ7WOHltXyNors"
    const val AUTH_DOMAIN = "cohesive-bonbon-421722.firebaseapp.com"
    const val DATABASE_URL = "https://cohesive-bonbon-421722-default-rtdb.europe-west1.firebasedatabase.app"
    const val PROJECT_ID = "cohesive-bonbon-421722"
    const val STORAGE_BUCKET = "cohesive-bonbon-421722.firebasestorage.app"
    const val MESSAGING_SENDER_ID = "475485328675"
    const val APP_ID = "1:475485328675:web:43b225b2642ff5a3602896"
    const val MEASUREMENT_ID = "G-SYRGQX3GQ7"

    const val ADMIN_CODE = "19971997"
    private const val TAG = "WaslFirebase"
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences("wasl_activation_prefs", Context.MODE_PRIVATE)
    }

    fun getDeviceId(context: Context): String {
        val prefs = getPrefs(context)
        var id = prefs.getString("device_id", null)
        if (id.isNullOrBlank()) {
            id = "DEV_" + UUID.randomUUID().toString().take(8)
            prefs.edit().putString("device_id", id).apply()
        }
        return id
    }

    fun getDeviceName(): String {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        val model = Build.MODEL
        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "$manufacturer $model"
        }
    }

    fun isActivated(context: Context): Boolean {
        return getPrefs(context).getBoolean("is_activated", false)
    }

    fun isAdmin(context: Context): Boolean {
        return getPrefs(context).getBoolean("is_admin", false)
    }

    fun getSavedCode(context: Context): String {
        return getPrefs(context).getString("saved_code", "") ?: ""
    }

    fun saveSession(context: Context, code: String, isAdmin: Boolean) {
        getPrefs(context).edit()
            .putBoolean("is_activated", true)
            .putBoolean("is_admin", isAdmin)
            .putString("saved_code", code)
            .apply()
    }

    fun clearSession(context: Context) {
        getPrefs(context).edit()
            .putBoolean("is_activated", false)
            .putBoolean("is_admin", false)
            .putString("saved_code", "")
            .apply()
    }

    // --- Firebase RTDB Rest API Methods ---

    suspend fun fetchAllCodes(): Map<String, JSONObject> = withContext(Dispatchers.IO) {
        val url = "$DATABASE_URL/activation_codes.json"
        val request = Request.Builder().url(url).get().build()
        val result = mutableMapOf<String, JSONObject>()
        try {
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (!body.isNullOrBlank() && body != "null") {
                val json = JSONObject(body)
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val obj = json.optJSONObject(key)
                    if (obj != null) {
                        result[key] = obj
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching codes: ${e.message}")
        }
        result
    }

    suspend fun fetchAllDevices(): Map<String, JSONObject> = withContext(Dispatchers.IO) {
        val url = "$DATABASE_URL/devices.json"
        val request = Request.Builder().url(url).get().build()
        val result = mutableMapOf<String, JSONObject>()
        try {
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (!body.isNullOrBlank() && body != "null") {
                val json = JSONObject(body)
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val obj = json.optJSONObject(key)
                    if (obj != null) {
                        result[key] = obj
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching devices: ${e.message}")
        }
        result
    }

    suspend fun createOrUpdateCode(
        codeId: String,
        codeName: String,
        maxDevices: Int,
        expiryDate: String,
        isActive: Boolean
    ): Boolean = withContext(Dispatchers.IO) {
        val url = "$DATABASE_URL/activation_codes/$codeId.json"
        val json = JSONObject().apply {
            put("code", codeId)
            put("name", codeName)
            put("maxDevices", maxDevices)
            put("expiryDate", expiryDate)
            put("isActive", isActive)
            put("updatedAt", System.currentTimeMillis())
        }
        val request = Request.Builder()
            .url(url)
            .patch(json.toString().toRequestBody(JSON_MEDIA))
            .build()
        try {
            val response = client.newCall(request).execute()
            response.isSuccessful
        } catch (e: Exception) {
            Log.e(TAG, "Error updating code: ${e.message}")
            false
        }
    }

    suspend fun deleteCode(codeId: String): Boolean = withContext(Dispatchers.IO) {
        val url = "$DATABASE_URL/activation_codes/$codeId.json"
        val request = Request.Builder().url(url).delete().build()
        try {
            val response = client.newCall(request).execute()
            response.isSuccessful
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting code: ${e.message}")
            false
        }
    }

    suspend fun registerDeviceToCode(
        context: Context,
        codeId: String,
        deviceId: String,
        deviceName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val deviceUrl = "$DATABASE_URL/activation_codes/$codeId/registeredDevices/$deviceId.json"
        val globalDeviceUrl = "$DATABASE_URL/devices/$deviceId.json"

        val deviceJson = JSONObject().apply {
            put("deviceId", deviceId)
            put("deviceName", deviceName)
            put("codeId", codeId)
            put("lastSeen", System.currentTimeMillis())
            put("isOnline", true)
        }

        try {
            client.newCall(Request.Builder().url(deviceUrl).put(deviceJson.toString().toRequestBody(JSON_MEDIA)).build()).execute()
            client.newCall(Request.Builder().url(globalDeviceUrl).put(deviceJson.toString().toRequestBody(JSON_MEDIA)).build()).execute()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error registering device: ${e.message}")
            false
        }
    }

    suspend fun revokeDevice(codeId: String, deviceId: String): Boolean = withContext(Dispatchers.IO) {
        val deviceUrl = "$DATABASE_URL/activation_codes/$codeId/registeredDevices/$deviceId.json"
        val globalDeviceUrl = "$DATABASE_URL/devices/$deviceId.json"
        try {
            client.newCall(Request.Builder().url(deviceUrl).delete().build()).execute()
            client.newCall(Request.Builder().url(globalDeviceUrl).delete().build()).execute()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error revoking device: ${e.message}")
            false
        }
    }

    suspend fun updateDeviceHeartbeat(context: Context, codeId: String) = withContext(Dispatchers.IO) {
        if (codeId.isBlank() || codeId == ADMIN_CODE) return@withContext
        val deviceId = getDeviceId(context)
        val url = "$DATABASE_URL/activation_codes/$codeId/registeredDevices/$deviceId/lastSeen.json"
        val globalUrl = "$DATABASE_URL/devices/$deviceId/lastSeen.json"
        val body = System.currentTimeMillis().toString().toRequestBody(JSON_MEDIA)
        try {
            client.newCall(Request.Builder().url(url).put(body).build()).execute()
            client.newCall(Request.Builder().url(globalUrl).put(body).build()).execute()
        } catch (_: Exception) {}
    }

    sealed class ActivationResult {
        object SuccessAdmin : ActivationResult()
        object SuccessUser : ActivationResult()
        data class Error(val message: String) : ActivationResult()
    }

    suspend fun verifyActivationCode(context: Context, inputCode: String): ActivationResult = withContext(Dispatchers.IO) {
        val trimmed = inputCode.trim()
        if (trimmed == ADMIN_CODE) {
            return@withContext ActivationResult.SuccessAdmin
        }

        val url = "$DATABASE_URL/activation_codes/$trimmed.json"
        val request = Request.Builder().url(url).get().build()
        try {
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (body.isNullOrBlank() || body == "null") {
                return@withContext ActivationResult.Error("كود التفعيل غير صحيح")
            }

            val codeObj = JSONObject(body)
            val isActive = codeObj.optBoolean("isActive", true)
            if (!isActive) {
                return@withContext ActivationResult.Error("تم تعطيل كود التفعيل هذا من قبل المدير")
            }

            val maxDevices = codeObj.optInt("maxDevices", 1)
            val devicesObj = codeObj.optJSONObject("registeredDevices")
            val currentDeviceId = getDeviceId(context)
            var currentDeviceRegistered = false
            var deviceCount = 0

            if (devicesObj != null) {
                val keys = devicesObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    deviceCount++
                    if (key == currentDeviceId) {
                        currentDeviceRegistered = true
                    }
                }
            }

            if (!currentDeviceRegistered && deviceCount >= maxDevices) {
                return@withContext ActivationResult.Error("تجاوزت الحد الأقصى للأجهزة المسموح بها لهذا الكود ($maxDevices أجهزة)")
            }

            // Register current device
            val deviceName = getDeviceName()
            registerDeviceToCode(context, trimmed, currentDeviceId, deviceName)

            return@withContext ActivationResult.SuccessUser
        } catch (e: Exception) {
            Log.e(TAG, "Error verifying activation code: ${e.message}")
            return@withContext ActivationResult.Error("تعذر الاتصال بخادم التفعيل، يرجى التحقق من الاتصال بالإنترنت")
        }
    }

    suspend fun checkCurrentDeviceStatus(context: Context, codeId: String): Boolean = withContext(Dispatchers.IO) {
        if (codeId == ADMIN_CODE) return@withContext true
        val trimmed = codeId.trim()
        val deviceId = getDeviceId(context)
        val url = "$DATABASE_URL/activation_codes/$trimmed.json"
        try {
            val response = client.newCall(Request.Builder().url(url).get().build()).execute()
            val body = response.body?.string()
            if (body.isNullOrBlank() || body == "null") return@withContext false

            val codeObj = JSONObject(body)
            val isActive = codeObj.optBoolean("isActive", true)
            if (!isActive) return@withContext false

            val devicesObj = codeObj.optJSONObject("registeredDevices") ?: return@withContext false
            return@withContext devicesObj.has(deviceId)
        } catch (_: Exception) {
            return@withContext true // Maintain session during temporary network flicker
        }
    }
}
