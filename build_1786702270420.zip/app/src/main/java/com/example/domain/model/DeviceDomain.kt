package com.example.domain.model

data class DeviceDomain(
    val name: String,
    val address: String, // IP Address e.g. "192.168.1.15"
    val port: Int = 8888,
    val isConnected: Boolean = false,
    val isOnline: Boolean = true,
    val lastSeen: Long = System.currentTimeMillis()
)
