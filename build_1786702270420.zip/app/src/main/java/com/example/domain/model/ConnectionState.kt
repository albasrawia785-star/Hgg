package com.example.domain.model

data class ConnectionRequest(
    val senderName: String,
    val senderAddress: String,
    val timestamp: Long = System.currentTimeMillis()
)

sealed interface ConnectionState {
    data object Disconnected : ConnectionState
    data class Connecting(val device: DeviceDomain) : ConnectionState
    data class Connected(val device: DeviceDomain) : ConnectionState
    data class Error(val message: String) : ConnectionState
}

