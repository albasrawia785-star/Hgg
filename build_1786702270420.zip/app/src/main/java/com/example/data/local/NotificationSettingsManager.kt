package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.media.RingtoneManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NotificationSettingsManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("wasel_notification_settings", Context.MODE_PRIVATE)

    companion object {
        const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        const val KEY_SOUND_URI = "sound_uri"
        const val KEY_SOUND_TITLE = "sound_title"
        const val KEY_PERSISTENT_BACKGROUND = "persistent_background_enabled"
    }

    private val _notificationsEnabled = MutableStateFlow(isNotificationsEnabled())
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _soundUri = MutableStateFlow(getSoundUriString())
    val soundUri: StateFlow<String> = _soundUri.asStateFlow()

    private val _soundTitle = MutableStateFlow(getSoundTitle())
    val soundTitle: StateFlow<String> = _soundTitle.asStateFlow()

    private val _persistentBackgroundEnabled = MutableStateFlow(isPersistentBackgroundEnabled())
    val persistentBackgroundEnabled: StateFlow<Boolean> = _persistentBackgroundEnabled.asStateFlow()

    fun isPersistentBackgroundEnabled(): Boolean {
        return prefs.getBoolean(KEY_PERSISTENT_BACKGROUND, true)
    }

    fun setPersistentBackgroundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PERSISTENT_BACKGROUND, enabled).apply()
        _persistentBackgroundEnabled.value = enabled
        if (enabled) {
            com.example.data.network.LanService.startService(context)
        } else {
            com.example.data.network.LanService.stopService(context)
        }
    }

    fun isNotificationsEnabled(): Boolean {
        return prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled).apply()
        _notificationsEnabled.value = enabled
    }

    fun getSoundUriString(): String {
        val defaultUri = try {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)?.toString() ?: ""
        } catch (_: Exception) {
            ""
        }
        return prefs.getString(KEY_SOUND_URI, defaultUri) ?: defaultUri
    }

    fun getSoundTitle(): String {
        return prefs.getString(KEY_SOUND_TITLE, "نغمة الإشعارات الافتراضية") ?: "نغمة الإشعارات الافتراضية"
    }

    fun setSound(uriString: String, title: String) {
        prefs.edit()
            .putString(KEY_SOUND_URI, uriString)
            .putString(KEY_SOUND_TITLE, title)
            .apply()
        _soundUri.value = uriString
        _soundTitle.value = title
    }
}
