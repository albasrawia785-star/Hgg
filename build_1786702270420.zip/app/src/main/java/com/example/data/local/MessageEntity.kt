package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.ChatMessage

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val deviceAddress: String,
    val senderAddress: String,
    val text: String,
    val timestamp: Long,
    val isFromMe: Boolean,
    val messageType: String = "TEXT",
    val mediaPath: String? = null,
    val fileName: String? = null,
    val fileSize: Long = 0L,
    val status: Int = 1
)

fun MessageEntity.toChatMessage(currentDeviceAddress: String): ChatMessage {
    return ChatMessage(
        id = id,
        senderAddress = senderAddress,
        receiverAddress = deviceAddress,
        text = text,
        timestamp = timestamp,
        isFromMe = isFromMe,
        messageType = messageType,
        mediaPath = mediaPath,
        fileName = fileName,
        fileSize = fileSize,
        status = status
    )
}

fun ChatMessage.toEntity(deviceAddress: String): MessageEntity {
    return MessageEntity(
        id = id,
        deviceAddress = deviceAddress,
        senderAddress = senderAddress,
        text = text,
        timestamp = timestamp,
        isFromMe = isFromMe,
        messageType = messageType,
        mediaPath = mediaPath,
        fileName = fileName,
        fileSize = fileSize,
        status = status
    )
}
