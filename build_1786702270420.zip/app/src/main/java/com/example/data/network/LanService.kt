package com.example.data.network

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.WaselApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class LanService : Service() {

    companion object {
        private const val TAG = "LanService"
        const val CHANNEL_ID = "wasel_lan_service_channel"
        const val CHANNEL_MESSAGES_ID = "wasel_messages_channel"
        const val NOTIFICATION_ID = 1001
        const val MESSAGE_NOTIFICATION_ID = 2002
        const val CALL_NOTIFICATION_ID = 3003

        const val ACTION_START_SERVICE = "ACTION_START_SERVICE"
        const val ACTION_STOP_SERVICE = "ACTION_STOP_SERVICE"
        const val EXTRA_DEVICE_ADDRESS = "EXTRA_DEVICE_ADDRESS"

        fun startService(context: Context) {
            val intent = Intent(context, LanService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        context.startForegroundService(intent)
                    } catch (e: Throwable) {
                        Log.w(TAG, "Foreground service start postponed until activity is active: ${e.message}")
                    }
                } else {
                    context.startService(intent)
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Failed starting LanService: ${e.message}")
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, LanService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            try {
                context.stopService(intent)
            } catch (e: Throwable) {
                Log.e(TAG, "Error stopping LanService: ${e.message}")
            }
        }

        fun showMessageNotification(
            context: Context,
            deviceName: String,
            deviceAddress: String,
            text: String,
            soundUriString: String? = null
        ) {
            try {
                createNotificationChannelsIfNeeded(context)
                val openChatIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(EXTRA_DEVICE_ADDRESS, deviceAddress)
                }

                val pendingIntent = PendingIntent.getActivity(
                    context,
                    MESSAGE_NOTIFICATION_ID,
                    openChatIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val soundUri = soundUriString?.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

                val notification = NotificationCompat.Builder(context, CHANNEL_MESSAGES_ID)
                    .setContentTitle(deviceName)
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.stat_notify_chat)
                    .setSound(soundUri)
                    .setVibrate(longArrayOf(0, 250, 100, 250))
                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentIntent(pendingIntent)
                    .build()

                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.notify(MESSAGE_NOTIFICATION_ID + System.currentTimeMillis().toInt(), notification)
            } catch (e: Throwable) {
                Log.e(TAG, "Error posting notification directly: ${e.message}")
            }
        }

        fun showCallNotification(
            context: Context,
            callerName: String,
            callerAddress: String
        ) {
            try {
                createNotificationChannelsIfNeeded(context)
                val openAppIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(EXTRA_DEVICE_ADDRESS, callerAddress)
                }

                val pendingIntent = PendingIntent.getActivity(
                    context,
                    CALL_NOTIFICATION_ID,
                    openAppIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

                val notification = NotificationCompat.Builder(context, CHANNEL_MESSAGES_ID)
                    .setContentTitle("مكالمة صوتية واردة 📞")
                    .setContentText("$callerName يتصل بك الآن...")
                    .setSmallIcon(android.R.drawable.stat_sys_phone_call)
                    .setSound(soundUri)
                    .setVibrate(longArrayOf(0, 1000, 500, 1000))
                    .setCategory(NotificationCompat.CATEGORY_CALL)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setFullScreenIntent(pendingIntent, true)
                    .setOngoing(true)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .build()

                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.notify(CALL_NOTIFICATION_ID, notification)
            } catch (e: Throwable) {
                Log.e(TAG, "Error posting call notification: ${e.message}")
            }
        }

        fun cancelCallNotification(context: Context) {
            try {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(CALL_NOTIFICATION_ID)
            } catch (_: Throwable) {}
        }

        private fun createNotificationChannelsIfNeeded(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val serviceChannel = NotificationChannel(
                    CHANNEL_ID,
                    "خدمة واصل لشبكة Wi-Fi",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "إشعار تشغيل خدمة التواصل عبر شبكة Wi-Fi المحلية"
                }

                val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
                    .build()

                val messagesChannel = NotificationChannel(
                    CHANNEL_MESSAGES_ID,
                    "رسائل واصل",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "إشعارات الرسائل الجديدة المباشرة"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 250, 100, 250)
                    setSound(defaultSoundUri, audioAttributes)
                }

                val manager = context.getSystemService(NotificationManager::class.java)
                manager?.createNotificationChannel(serviceChannel)
                manager?.createNotificationChannel(messagesChannel)
            }
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannelsIfNeeded(this)
        promoteToForeground()
        observeIncomingMessages()
        try {
            (application as? WaselApplication)?.lanController?.startLanServices()
        } catch (e: Throwable) {
            Log.e(TAG, "Error starting LAN services from LanService: ${e.message}")
        }
    }

    private fun promoteToForeground() {
        try {
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("واصل - شبكة Wi-Fi المحلية")
                .setContentText("التطبيق جاهز لاستقبال وإرسال الرسائل عبر الشبكة في الخلفية")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                } else {
                    0
                }
                if (serviceType != 0) {
                    startForeground(NOTIFICATION_ID, notification, serviceType)
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "startForeground failed or disallowed: ${e.message}")
        }
    }

    private fun observeIncomingMessages() {
        serviceScope.launch {
            try {
                val app = application as? WaselApplication ?: return@launch
                app.lanController.incomingMessages.collect { message ->
                    val notificationSettings = app.notificationSettings
                    if (notificationSettings.isNotificationsEnabled()) {
                        val senderDevice = app.lanController.discoveredDevices.value.find { it.address == message.senderAddress }
                        val senderName = senderDevice?.name ?: "جهاز ${message.senderAddress}"
                        val soundUriStr = notificationSettings.getSoundUriString()

                        val textToDisplay = when (message.messageType) {
                            "IMAGE" -> "📷 صورة جديدة"
                            "FILE" -> "📁 ملف جديد: ${message.fileName ?: "مستند"}"
                            else -> message.text
                        }

                        showMessageNotification(
                            context = this@LanService,
                            deviceName = senderName,
                            deviceAddress = message.senderAddress,
                            text = textToDisplay,
                            soundUriString = soundUriStr
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error collecting incoming messages: ${e.message}")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } else {
                    @Suppress("DEPRECATION")
                    stopForeground(true)
                }
            } catch (_: Throwable) {}
            stopSelf()
            return START_NOT_STICKY
        }
        promoteToForeground()
        try {
            (application as? WaselApplication)?.lanController?.startLanServices()
        } catch (_: Throwable) {}
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Log.d(TAG, "Task removed (app swiped away) - re-triggering service restart")
        val app = application as? WaselApplication
        if (app?.notificationSettings?.isPersistentBackgroundEnabled() != false) {
            val restartIntent = Intent(applicationContext, LanService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            val pendingIntent = PendingIntent.getService(
                applicationContext,
                1001,
                restartIntent,
                PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            alarmManager?.set(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 500,
                pendingIntent
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
