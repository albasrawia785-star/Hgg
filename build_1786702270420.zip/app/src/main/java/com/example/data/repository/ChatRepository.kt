package com.example.data.repository

import android.util.Base64
import com.example.data.local.MessageDao
import com.example.data.local.toChatMessage
import com.example.data.local.toEntity
import com.example.data.network.LanController
import com.example.domain.model.ChatMessage
import com.example.domain.model.ConnectionState
import com.example.domain.model.DeviceDomain
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.io.File

class ChatRepository(
    private val messageDao: MessageDao,
    val lanController: LanController
) {
    private val scope = CoroutineScope(Dispatchers.IO)

    val discoveredDevices: StateFlow<List<DeviceDomain>> = lanController.discoveredDevices
    val connectionState: StateFlow<ConnectionState> = lanController.connectionState
    val incomingMessages: SharedFlow<ChatMessage> = lanController.incomingMessages
    val events: SharedFlow<String> = lanController.events
    val isWifiConnected: StateFlow<Boolean> = lanController.isWifiConnected

    val incomingConnectionRequest: StateFlow<com.example.domain.model.ConnectionRequest?> = lanController.incomingConnectionRequest
    val outgoingConnectionRequest: StateFlow<DeviceDomain?> = lanController.outgoingConnectionRequest
    val openChatEvents: SharedFlow<DeviceDomain> = lanController.openChatEvents
    val fileProgress: StateFlow<Map<Long, Float>> = lanController.fileProgress

    init {
        // Automatically persist incoming LAN messages to Room Database
        scope.launch {
            lanController.incomingMessages.collect { message ->
                messageDao.insertMessage(message.toEntity(message.senderAddress))
            }
        }

        // Listen for ACK events to update message status to DELIVERED (2)
        scope.launch {
            lanController.incomingAckEvents.collect { messageId ->
                messageDao.updateMessageStatusByTimestamp(messageId, 2)
            }
        }
    }

    fun getMessagesForDevice(deviceAddress: String): Flow<List<ChatMessage>> {
        return messageDao.getMessagesForDevice(deviceAddress).map { entities ->
            entities.map { it.toChatMessage(deviceAddress) }
        }
    }

    suspend fun sendMessage(targetDeviceAddress: String, text: String): Boolean {
        val timestamp = System.currentTimeMillis()
        val success = lanController.sendMessagePacket(
            targetAddress = targetDeviceAddress,
            type = "TEXT",
            messageId = timestamp,
            text = text
        )
        val message = ChatMessage(
            senderAddress = lanController.myAddress(),
            receiverAddress = targetDeviceAddress,
            text = text,
            timestamp = timestamp,
            isFromMe = true,
            messageType = "TEXT",
            status = if (success) 1 else 0
        )
        messageDao.insertMessage(message.toEntity(targetDeviceAddress))
        return success
    }

    suspend fun sendMediaMessage(
        targetDeviceAddress: String,
        type: String,
        file: File,
        fileName: String,
        fileSize: Long
    ): Boolean {
        val timestamp = System.currentTimeMillis()
        val initialMessage = ChatMessage(
            senderAddress = lanController.myAddress(),
            receiverAddress = targetDeviceAddress,
            text = if (type == "IMAGE") "صورة" else if (type == "VIDEO") "فيديو" else fileName,
            timestamp = timestamp,
            isFromMe = true,
            messageType = type,
            mediaPath = file.absolutePath,
            fileName = fileName,
            fileSize = fileSize,
            status = 2
        )
        val insertedId = messageDao.insertMessage(initialMessage.toEntity(targetDeviceAddress))
        val msgId = if (insertedId > 0) insertedId else timestamp

        val success = lanController.sendFileInChunks(
            targetAddress = targetDeviceAddress,
            messageId = msgId,
            file = file,
            fileName = fileName,
            fileSize = fileSize,
            type = type
        )

        val finalStatus = if (success) 1 else 0
        messageDao.updateMessageStatus(msgId, finalStatus)
        return success
    }

    suspend fun resendMessage(targetDeviceAddress: String, message: ChatMessage): Boolean {
        val success = if (message.messageType == "TEXT") {
            lanController.sendMessagePacket(
                targetAddress = targetDeviceAddress,
                type = "TEXT",
                messageId = message.timestamp,
                text = message.text
            )
        } else {
            val file = message.mediaPath?.let { File(it) }
            if (file != null && file.exists()) {
                val msgId = if (message.id > 0) message.id else message.timestamp
                lanController.sendFileInChunks(
                    targetAddress = targetDeviceAddress,
                    messageId = msgId,
                    file = file,
                    fileName = message.fileName ?: file.name,
                    fileSize = if (message.fileSize > 0) message.fileSize else file.length(),
                    type = message.messageType
                )
            } else {
                false
            }
        }

        val newStatus = if (success) 1 else 0
        if (message.id > 0) {
            messageDao.updateMessageStatus(message.id, newStatus)
        } else {
            messageDao.updateMessageStatusByTimestamp(message.timestamp, newStatus)
        }
        return success
    }

    fun requestConnection(device: DeviceDomain) {
        lanController.requestConnection(device)
    }

    fun acceptConnectionRequest() {
        lanController.acceptConnectionRequest()
    }

    fun rejectConnectionRequest() {
        lanController.rejectConnectionRequest()
    }

    fun cancelOutgoingConnectionRequest() {
        lanController.cancelOutgoingConnectionRequest()
    }

    fun connectToDevice(device: DeviceDomain) {
        lanController.requestConnection(device)
    }

    fun disconnect() {
        lanController.closeConnection()
    }

    suspend fun deleteMessage(message: ChatMessage) {
        if (message.id > 0) {
            messageDao.deleteMessageById(message.id)
        } else {
            messageDao.deleteMessageByTimestamp(message.timestamp)
        }
    }

    suspend fun deleteAllMessages() {
        messageDao.deleteAllMessages()
    }

    suspend fun deleteMessagesForDevice(deviceAddress: String) {
        messageDao.deleteMessagesForDevice(deviceAddress)
    }
}
